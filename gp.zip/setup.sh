#!/bin/bash
# ============================================================
# OGUltra Panel — Setup Script (Proot-Compatible)
# Works on: Real Linux VPS, Proot Ubuntu, any Node.js env
# Uses: detached spawn + log file watching + RCON
# ============================================================

set -e

echo ""
echo "=========================================="
echo "  OGUltra Panel v2.0 — Setup"
echo "  Proot-Compatible Minecraft Panel"
echo "=========================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}ERROR: Node.js is not installed!${NC}"
    echo "Install Node.js 18+:"
    echo "  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -"
    echo "  apt install -y nodejs"
    exit 1
fi

NODE_VERSION=$(node -v | sed 's/v//' | cut -d. -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${RED}ERROR: Node.js 18+ required (found v$(node -v))${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Node.js v$(node -v) found${NC}"

# Check npm
if ! command -v npm &> /dev/null; then
    echo -e "${RED}ERROR: npm is not installed!${NC}"
    exit 1
fi
echo -e "${GREEN}✓ npm v$(npm -v) found${NC}"

# Check for Java (optional, for Minecraft servers)
if command -v java &> /dev/null; then
    JAVA_VER=$(java -version 2>&1 | head -1 | cut -d'"' -f2)
    echo -e "${GREEN}✓ Java $JAVA_VER found${NC}"
else
    echo -e "${YELLOW}⚠ Java not found — Minecraft servers won't start without it${NC}"
    echo "  Install Java 21: apt install -y openjdk-21-jdk-headless"
fi

# Detect environment
if grep -q 'container=y' /proc/1/environ 2>/dev/null || [ -f //.dockerenv ] 2>/dev/null; then
    echo -e "${YELLOW}⚠ Container/Proot environment detected — using Proot-compatible mode${NC}"
    echo "  (detached spawn + log file watching + RCON)"
else
    echo -e "${GREEN}✓ Native Linux environment detected${NC}"
fi

echo ""
echo -e "${BLUE}--- Step 1: Install Panel Dependencies ---${NC}"
npm install
echo -e "${GREEN}✓ Panel dependencies installed${NC}"

echo ""
echo -e "${BLUE}--- Step 2: Setup Database ---${NC}"
npx prisma generate
npx prisma db push --force-reset
echo -e "${GREEN}✓ Database ready${NC}"

echo ""
echo -e "${BLUE}--- Step 3: Seed Admin User ---${NC}"
npx tsx prisma/seed.ts
echo -e "${GREEN}✓ Admin user created${NC}"

echo ""
echo -e "${BLUE}--- Step 4: Install Daemon Dependencies ---${NC}"
cd mini-services/ogultra-daemon
npm install
cd ../..
echo -e "${GREEN}✓ Daemon dependencies installed${NC}"

# Create servers directory
mkdir -p mini-services/ogultra-daemon/servers

echo ""
echo "=========================================="
echo -e "${GREEN}  Setup Complete!${NC}"
echo "=========================================="
echo ""
echo "Default Admin Credentials:"
echo -e "  ${YELLOW}Email:    admin@ogultra.com${NC}"
echo -e "  ${YELLOW}Password: admin123${NC}"
echo ""
echo "=== QUICK START (Same Machine) ==="
echo ""
echo -e "  ${BLUE}Terminal 1 — Start Daemon:${NC}"
echo "  cd mini-services/ogultra-daemon && npm start"
echo ""
echo -e "  ${BLUE}Terminal 2 — Start Panel:${NC}"
echo "  npm run dev"
echo ""
echo "Then open http://localhost:3000"
echo ""
echo "=== PM2 (Recommended for Production) ==="
echo ""
echo "  pm2 start mini-services/ogultra-daemon/index.ts --name ogultra-daemon --interpreter tsx"
echo "  pm2 start npm --name ogultra-panel -- run dev"
echo "  pm2 save"
echo "  pm2 startup"
echo ""
echo "=== MULTI-NODE SETUP ==="
echo ""
echo "  1. Copy 'mini-services/ogultra-daemon/' to each node VPS"
echo "  2. On each node, run: cd ogultra-daemon && npm install"
echo "  3. Set these env vars on each node:"
echo "     DAEMON_TOKEN=same-secret-token-on-all-nodes"
echo "     DAEMON_UUID=unique-id-per-node (e.g. node-1, node-2)"
echo "     DAEMON_PORT=3003 (or any available port)"
echo "     SERVERS_DIR=/path/to/servers (where MC server files go)"
echo "  4. Start daemon: DAEMON_UUID=node-2 npm start"
echo "  5. In Admin Panel → Nodes → Add Node:"
echo "     - Name: Node 2"
echo "     - FQDN/IP: your-node-2-ip-or-domain"
echo "     - Daemon Port: 3003"
echo "     - Daemon Token: same-secret-token"
echo ""
echo "=== HOW IT WORKS (Proot Compatible) ==="
echo ""
echo "  Server Start:  spawn java -jar server.jar (detached + unref)"
echo "  Console Output: watches logs/latest.log file (not stdin pipes)"
echo "  Commands:      RCON over TCP (not stdin)"
echo "  Stop:          RCON 'stop' → SIGTERM → SIGKILL"
echo "  PID Tracking:  .server.pid file (survives daemon restart)"
echo "  Reconnect:     daemon reads PID files on startup"
echo ""