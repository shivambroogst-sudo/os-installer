// ============================================================
// OGUltra DAEMON — Proot-Compatible Minecraft Server Manager
// Approach: spawn detached + PID file + log file watching + RCON
// Works on: Real Linux, Proot, any environment with Java + Node
// ============================================================

import { spawn, ChildProcess, execSync, exec } from 'child_process';
import { WebSocketServer, WebSocket } from 'ws';
import http, { createServer, IncomingMessage, ServerResponse } from 'http';
import {
  readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync,
  statSync, unlinkSync, rmdirSync, createReadStream, createWriteStream,
  rmSync, watchFile, unwatchFile, appendFileSync, openSync, closeSync
} from 'fs';
import { join, basename, extname, relative, dirname, resolve } from 'path';
import { platform, arch, totalmem, freemem, cpus } from 'os';
import axios from 'axios';
import { createConnection, Rcon } from 'rcon-client';

// ============ TYPES ============

interface ServerConfig {
  id: string;
  uuid: string;
  name: string;
  workingDir: string;
  startupCommand: string;
  stopCommand: string;
  javaPath: string | null;
  memoryLimit: number; // MB
  cpuLimit: number;
  autoRestart: boolean;
  crashDetection: boolean;
  port: number;
  ip: string;
  rconPort?: number;
  rconPassword?: string;
}

interface ServerState {
  id: string;
  status: 'installing' | 'stopped' | 'starting' | 'running' | 'stopping' | 'crashed';
  config: ServerConfig;
  startedAt: number | null;
  pid: number | null;
  consoleBuffer: ConsoleLine[];
  crashCount: number;
  lastCrashAt: number | null;
  connections: Set<WebSocket>;
  logPosition: number;
  logWatcher: any | null;
  rconClient: any | null;
  startAttempts: number;
  lastStartAttempt: number | null;
}

interface ConsoleLine {
  id: number;
  text: string;
  level: 'info' | 'warn' | 'error' | 'success';
  timestamp: number;
}

interface NodeInfo {
  uuid: string;
  hostname: string;
  platform: string;
  arch: string;
  totalMemory: number;
  freeMemory: number;
  cpuCount: number;
  cpuModel: string;
  daemonVersion: string;
  totalDisk: number;
  usedDisk: number;
  serverCount: number;
  runningServers: number;
}

// ============ DAEMON CONFIG ============

const DAEMON_PORT = parseInt(process.env.DAEMON_PORT || '3003');
const AUTH_TOKEN = process.env.DAEMON_TOKEN || 'ogultra-daemon-secret-token';
const SERVERS_DIR = process.env.SERVERS_DIR || join(process.cwd(), 'servers');
const DAEMON_UUID = process.env.DAEMON_UUID || 'local-daemon-' + Math.random().toString(36).slice(2, 10);
const DAEMON_VERSION = '2.0.0-proot';

// ============ STATE ============

const servers = new Map<string, ServerState>();
let consoleLineIdCounter = 0;

// ============ UTILITIES ============

function log(level: string, msg: string) {
  const ts = new Date().toISOString();
  console.log(`[${ts}] [${level.toUpperCase()}] ${msg}`);
}

function addConsoleLine(serverId: string, text: string, level: ConsoleLine['level'] = 'info') {
  const state = servers.get(serverId);
  if (!state) return;
  const line: ConsoleLine = {
    id: ++consoleLineIdCounter,
    text,
    level,
    timestamp: Date.now(),
  };
  state.consoleBuffer.push(line);
  if (state.consoleBuffer.length > 5000) {
    state.consoleBuffer = state.consoleBuffer.slice(-3000);
  }
  // Broadcast to WebSocket connections
  for (const ws of state.connections) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ event: 'console_output', data: line }));
    }
  }
}

function broadcastServerStatus(serverId: string) {
  const state = servers.get(serverId);
  if (!state) return;
  for (const ws of state.connections) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ event: 'status', data: { status: state.status, pid: state.pid } }));
    }
  }
}

function detectJava(): string | null {
  try {
    const result = execSync('which java 2>/dev/null || echo ""', { encoding: 'utf-8' }).trim();
    if (result) return result;
  } catch {}
  const paths = [
    '/usr/bin/java', '/usr/local/bin/java',
    '/usr/lib/jvm/java-21/bin/java', '/usr/lib/jvm/java-17/bin/java',
    '/usr/lib/jvm/java-11/bin/java', '/usr/lib/jvm/java-8/bin/java',
  ];
  for (const p of paths) {
    if (existsSync(p)) return p;
  }
  return null;
}

function isProcessRunning(pid: number): boolean {
  try {
    process.kill(pid, 0); // Signal 0 = check if process exists
    return true;
  } catch {
    return false;
  }
}

function readPidFile(serverId: string): number | null {
  const state = servers.get(serverId);
  if (!state) return null;
  const pidFile = join(state.config.workingDir, '.server.pid');
  try {
    if (existsSync(pidFile)) {
      return parseInt(readFileSync(pidFile, 'utf-8').trim());
    }
  } catch {}
  return null;
}

function writePidFile(serverId: string, pid: number) {
  const state = servers.get(serverId);
  if (!state) return;
  const pidFile = join(state.config.workingDir, '.server.pid');
  try {
    writeFileSync(pidFile, pid.toString());
  } catch (err) {
    log('error', `Failed to write PID file for ${serverId}: ${err}`);
  }
}

function deletePidFile(serverId: string) {
  const state = servers.get(serverId);
  if (!state) return;
  const pidFile = join(state.config.workingDir, '.server.pid');
  try {
    if (existsSync(pidFile)) unlinkSync(pidFile);
  } catch {}
}

// ============ LOG FILE WATCHING (Primary Console Method) ============
// This is the key to Proot compatibility - reads logs/latest.log

function startLogWatching(serverId: string) {
  const state = servers.get(serverId);
  if (!state) return;
  const logDir = join(state.config.workingDir, 'logs');
  const logPath = join(logDir, 'latest.log');

  // Ensure log dir exists
  try {
    mkdirSync(logDir, { recursive: true });
  } catch {}

  // Initialize position
  if (state.logPosition === 0 && existsSync(logPath)) {
    try {
      state.logPosition = statSync(logPath).size;
    } catch {}
  }

  const readNewLines = () => {
    try {
      if (!existsSync(logPath)) return;
      const stats = statSync(logPath);
      // Log file was rotated (smaller than before)
      if (stats.size < state.logPosition) {
        state.logPosition = 0;
      }
      if (stats.size > state.logPosition) {
        const stream = createReadStream(logPath, {
          start: state.logPosition,
          end: stats.size
        });
        let buffer = '';
        stream.on('data', (chunk: Buffer) => {
          buffer += chunk.toString('utf-8');
        });
        stream.on('end', () => {
          const lines = buffer.split('\n');
          for (const line of lines) {
            if (line.trim()) {
              const level = detectLogLevel(line);
              addConsoleLine(serverId, line + '\n', level);
            }
          }
          state.logPosition = stats.size;
        });
        stream.on('error', () => {});
      }
    } catch {}
  };

  // Read initial content
  readNewLines();

  // Watch for changes using polling (more reliable on Proot than fs.watch)
  const watchInterval = setInterval(readNewLines, 1000);
  state.logWatcher = watchInterval;

  // Also try fs.watch as secondary method
  try {
    if (existsSync(logPath)) {
      const watcher = require('fs').watch(logPath, (eventType: string) => {
        if (eventType === 'change') readNewLines();
      });
      watcher.on('error', () => {});
      // Store reference for cleanup
      (state as any)._fsWatcher = watcher;
    }
  } catch {}
}

function stopLogWatching(serverId: string) {
  const state = servers.get(serverId);
  if (!state) return;
  if (state.logWatcher) {
    clearInterval(state.logWatcher);
    state.logWatcher = null;
  }
  if ((state as any)._fsWatcher) {
    try { (state as any)._fsWatcher.close(); } catch {}
    (state as any)._fsWatcher = null;
  }
}

function detectLogLevel(text: string): ConsoleLine['level'] {
  const lower = text.toLowerCase();
  if (lower.includes('error') || lower.includes('exception') || lower.includes('fatal') || lower.includes('failed')) return 'error';
  if (lower.includes('warn') || lower.includes('warning')) return 'warn';
  if (lower.includes('done (') || lower.includes('started') || lower.includes('listening') || lower.includes('joined')) return 'success';
  return 'info';
}

// ============ RCON MANAGEMENT ============
// RCON is the primary method for sending commands (works over TCP, no stdin needed)

async function enableRcon(serverId: string): Promise<{ port: number; password: string }> {
  const state = servers.get(serverId);
  if (!state) throw new Error('Server not found');

  const rconPort = state.config.rconPort || (state.config.port + 1000);
  const rconPassword = state.config.rconPassword || 'ogultra_rcon_' + state.config.uuid.slice(0, 8);
  const propsPath = join(state.config.workingDir, 'server.properties');

  if (!existsSync(propsPath)) {
    // Create minimal server.properties with RCON
    const content = `server-port=${state.config.port}\nenable-rcon=true\nrcon.port=${rconPort}\nrcon.password=${rconPassword}\n`;
    writeFileSync(propsPath, content);
    log('info', `Created server.properties with RCON for ${serverId}`);
    return { port: rconPort, password: rconPassword };
  }

  try {
    let content = readFileSync(propsPath, 'utf-8');
    // Remove existing RCON settings
    content = content.replace(/enable-rcon=.*/g, '');
    content = content.replace(/rcon\.port=.*/g, '');
    content = content.replace(/rcon\.password=.*/g, '');
    // Ensure server-port is correct
    content = content.replace(/server-port=.*/g, `server-port=${state.config.port}`);
    // Append RCON settings
    content = content.trim() + '\n' +
      `enable-rcon=true\nrcon.port=${rconPort}\nrcon.password=${rconPassword}\n`;
    writeFileSync(propsPath, content);
    log('info', `RCON enabled for ${serverId} on port ${rconPort}`);
    return { port: rconPort, password: rconPassword };
  } catch (err) {
    log('error', `Failed to enable RCON for ${serverId}: ${err}`);
    return { port: rconPort, password: rconPassword };
  }
}

async function connectRcon(serverId: string): Promise<boolean> {
  const state = servers.get(serverId);
  if (!state) return false;

  // Disconnect existing
  if (state.rconClient) {
    try { await state.rconClient.end(); } catch {}
    state.rconClient = null;
  }

  const rconPort = state.config.rconPort || (state.config.port + 1000);
  const rconPassword = state.config.rconPassword || 'ogultra_rcon_' + state.config.uuid.slice(0, 8);

  try {
    const rcon = await Rcon.connect({
      host: state.config.ip || '127.0.0.1',
      port: rconPort,
      password: rconPassword,
      timeout: 5000
    });
    state.rconClient = rcon;
    rcon.on('error', () => {
      state.rconClient = null;
    });
    rcon.on('end', () => {
      state.rconClient = null;
    });
    log('info', `RCON connected for ${serverId}`);
    return true;
  } catch (err) {
    log('warn', `RCON connection failed for ${serverId}: ${err}`);
    state.rconClient = null;
    return false;
  }
}

async function sendRconCommand(serverId: string, command: string): Promise<string | null> {
  const state = servers.get(serverId);
  if (!state) return null;

  // Try existing RCON connection
  if (state.rconClient) {
    try {
      const response = await state.rconClient.send(command);
      return response;
    } catch {
      state.rconClient = null;
    }
  }

  // Try connecting
  if (await connectRcon(serverId)) {
    try {
      const response = await state.rconClient.send(command);
      return response;
    } catch {
      return null;
    }
  }
  return null;
}

// ============ STARTUP ARG BUILDER ============

function buildStartupArgs(config: ServerConfig): string[] {
  const args: string[] = [];
  args.push(`-Xms${Math.min(512, config.memoryLimit)}M`);
  args.push(`-Xmx${config.memoryLimit}M`);
  // Common JVM flags
  args.push('-XX:+UseG1GC');
  args.push('-XX:+ParallelRefProcEnabled');
  args.push('-XX:MaxGCPauseMillis=200');
  args.push('-XX:+UnlockExperimentalVMOptions');
  args.push('-XX:+DisableExplicitGC');
  args.push('-XX:G1NewSizePercent=30');
  args.push('-XX:G1MaxNewSizePercent=40');
  args.push('-XX:G1HeapRegionSize=8M');
  args.push('-XX:G1ReservePercent=20');
  args.push('-XX:G1HeapWastePercent=5');
  args.push('-XX:G1MixedGCCountTarget=4');
  args.push('-XX:InitiatingHeapOccupancyPercent=15');
  args.push('-XX:G1MixedGCLiveThresholdPercent=90');
  args.push('-XX:G1RSetUpdatingPauseTimePercent=5');
  args.push('-XX:SurvivorRatio=32');
  args.push('-XX:+PerfDisableSharedMem');
  args.push('-XX:MaxTenuringThreshold=1');
  args.push('-Dusing.aikars.flags=https://mcflags.emc.gs');
  args.push('-Daikars.new.flags=true');

  // Check if we should use nogui
  const jarFiles = readdirSync(config.workingDir).filter(f => f.endsWith('.jar'));
  if (jarFiles.length > 0) {
    args.push('-jar');
    args.push(jarFiles.find(f => f.includes('server') || f.includes('paper') || f.includes('purpur') || f.includes('vanilla')) || jarFiles[0]);
    args.push('nogui');
  } else if (config.startupCommand) {
    // Parse startup command for jar and additional args
    const parts = config.startupCommand.split(/\s+/);
    const jarIdx = parts.findIndex(p => p.endsWith('.jar'));
    if (jarIdx >= 0) {
      args.push('-jar');
      args.push(parts[jarIdx]);
      if (parts[jarIdx + 1] === 'nogui') {
        args.push('nogui');
      }
    }
  }
  return args;
}

// ============ SERVER LIFECYCLE ============

function registerServer(config: ServerConfig): boolean {
  if (servers.has(config.id)) {
    // Update config for existing server
    const state = servers.get(config.id)!;
    state.config = { ...state.config, ...config };
    log('info', `Server ${config.id} config updated`);
    return true;
  }
  const workDir = config.workingDir || join(SERVERS_DIR, config.id);
  config.workingDir = workDir;
  mkdirSync(workDir, { recursive: true });

  const state: ServerState = {
    id: config.id,
    status: 'stopped',
    config,
    startedAt: null,
    pid: null,
    consoleBuffer: [],
    crashCount: 0,
    lastCrashAt: null,
    connections: new Set(),
    logPosition: 0,
    logWatcher: null,
    rconClient: null,
    startAttempts: 0,
    lastStartAttempt: null,
  };
  servers.set(config.id, state);
  addConsoleLine(config.id, `[OGUltra Daemon] Server "${config.name}" registered`, 'success');
  log('info', `Server ${config.id} (${config.name}) registered`);
  return true;
}

async function startServer(serverId: string): Promise<{ success: boolean; error?: string }> {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };
  if (state.status === 'running' || state.status === 'starting') {
    return { success: false, error: 'Server is already running' };
  }

  // Clean up stale world lock
  const lockFile = join(state.config.workingDir, 'world', 'session.lock');
  try {
    if (existsSync(lockFile)) unlinkSync(lockFile);
  } catch {}

  // Enable RCON before starting
  const rconInfo = await enableRcon(serverId);
  state.config.rconPort = rconInfo.port;
  state.config.rconPassword = rconInfo.password;

  state.status = 'starting';
  state.startAttempts++;
  state.lastStartAttempt = Date.now();
  addConsoleLine(serverId, `[OGUltra] Starting server "${state.config.name}"...`, 'info');
  broadcastServerStatus(serverId);

  const javaPath = state.config.javaPath || detectJava() || 'java';
  const args = buildStartupArgs(state.config);

  log('info', `Starting ${serverId}: ${javaPath} ${args.join(' ')}`);

  try {
    const child = spawn(javaPath, args, {
      cwd: state.config.workingDir,
      detached: true,     // KEY: Run independently
      stdio: 'ignore',     // Don't rely on pipes - use log file + RCON
      env: { ...process.env },
    });

    // Unref so daemon can exit without killing the server
    child.unref();

    state.pid = child.pid || null;
    state.startedAt = Date.now();

    // Save PID to file (critical for Proot - reconnect after restart)
    if (state.pid) {
      writePidFile(serverId, state.pid);
    }

    addConsoleLine(serverId, `[OGUltra] Server process spawned (PID: ${state.pid})`, 'info');

    // Start log file watching (primary console method)
    startLogWatching(serverId);

    // Set up minimal process event handlers
    child.on('error', (err) => {
      log('error', `Server ${serverId} process error: ${err.message}`);
      addConsoleLine(serverId, `[OGUltra] Process error: ${err.message}`, 'error');
      if (state.status === 'starting') {
        state.status = 'crashed';
        state.crashCount++;
        state.lastCrashAt = Date.now();
        broadcastServerStatus(serverId);
      }
    });

    child.on('exit', (code, signal) => {
      log('info', `Server ${serverId} exited (code: ${code}, signal: ${signal})`);
      addConsoleLine(serverId, `[OGUltra] Server process exited (code: ${code})`, 'warn');
      cleanupAfterStop(serverId);

      // Auto-restart logic
      if (state.config.autoRestart && code !== 0 && code !== null) {
        const uptime = Date.now() - (state.startedAt || Date.now());
        if (uptime > 10000) { // Only auto-restart if ran for >10s
          addConsoleLine(serverId, `[OGUltra] Auto-restarting in 5 seconds...`, 'info');
          setTimeout(() => startServer(serverId), 5000);
        }
      }
    });

    // Wait a bit then check if still running, try to connect RCON
    setTimeout(async () => {
      if (state.pid && isProcessRunning(state.pid)) {
        if (state.status === 'starting') {
          state.status = 'running';
          addConsoleLine(serverId, `[OGUltra] Server is now running`, 'success');
          broadcastServerStatus(serverId);
        }
        // Try connecting RCON (will work once server finishes starting)
        setTimeout(async () => {
          if (state.status === 'running') {
            await connectRcon(serverId);
          }
        }, 15000); // Wait 15s for Minecraft to fully start
      } else {
        state.status = 'crashed';
        state.crashCount++;
        state.lastCrashAt = Date.now();
        addConsoleLine(serverId, `[OGUltra] Server failed to start - process exited immediately`, 'error');
        broadcastServerStatus(serverId);
      }
    }, 3000);

    return { success: true };
  } catch (err: any) {
    state.status = 'stopped';
    addConsoleLine(serverId, `[OGUltra] Failed to start: ${err.message}`, 'error');
    broadcastServerStatus(serverId);
    return { success: false, error: err.message };
  }
}

function stopServer(serverId: string, force: boolean = false): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };
  if (state.status === 'stopped' || state.status === 'stopping') {
    return { success: false, error: 'Server is not running' };
  }

  state.status = 'stopping';
  addConsoleLine(serverId, `[OGUltra] Stopping server "${state.config.name}"...`, 'info');
  broadcastServerStatus(serverId);

  const doCleanup = () => {
    cleanupAfterStop(serverId);
  };

  if (force) {
    // Force kill
    const pid = state.pid || readPidFile(serverId);
    if (pid) {
      try {
        process.kill(pid, 'SIGKILL');
        addConsoleLine(serverId, `[OGUltra] Server force killed (PID: ${pid})`, 'warn');
      } catch {
        // Already dead
      }
    }
    doCleanup();
    return { success: true };
  }

  // Graceful stop: Try RCON first, then stdin, then SIGTERM, then SIGKILL
  const pid = state.pid || readPidFile(serverId);
  if (!pid) {
    doCleanup();
    return { success: true };
  }

  // Attempt 1: RCON stop command (most reliable on Proot)
  (async () => {
    try {
      addConsoleLine(serverId, `[OGUltra] Sending stop command via RCON...`, 'info');
      const response = await sendRconCommand(serverId, 'stop');
      if (response !== null) {
        addConsoleLine(serverId, `[OGUltra] Stop command sent via RCON`, 'success');
        // Wait up to 30s for graceful shutdown
        let waited = 0;
        const checkInterval = setInterval(() => {
          waited += 1000;
          if (!isProcessRunning(pid)) {
            clearInterval(checkInterval);
            doCleanup();
          } else if (waited >= 30000) {
            clearInterval(checkInterval);
            // Force kill
            try { process.kill(pid, 'SIGKILL'); } catch {}
            addConsoleLine(serverId, `[OGUltra] Server didn't stop gracefully, force killed`, 'warn');
            doCleanup();
          }
        }, 1000);
        return;
      }
    } catch {}

    // Attempt 2: SIGTERM
    addConsoleLine(serverId, `[OGUltra] RCON failed, sending SIGTERM...`, 'warn');
    try {
      process.kill(pid, 'SIGTERM');
    } catch {}

    // Wait then force kill
    setTimeout(() => {
      if (isProcessRunning(pid)) {
        try { process.kill(pid, 'SIGKILL'); } catch {}
        addConsoleLine(serverId, `[OGUltra] Server force killed after SIGTERM timeout`, 'warn');
      }
      doCleanup();
    }, 10000);
  })();

  return { success: true };
}

function restartServer(serverId: string): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };

  stopServer(serverId);
  // Wait a moment then start
  setTimeout(() => startServer(serverId), 3000);
  return { success: true };
}

function killServer(serverId: string): { success: boolean; error?: string } {
  return stopServer(serverId, true);
}

function cleanupAfterStop(serverId: string) {
  const state = servers.get(serverId);
  if (!state) return;

  stopLogWatching(serverId);
  if (state.rconClient) {
    try { state.rconClient.end(); } catch {}
    state.rconClient = null;
  }
  deletePidFile(serverId);

  state.status = 'stopped';
  state.pid = null;
  state.startedAt = null;
  broadcastServerStatus(serverId);
  log('info', `Server ${serverId} stopped and cleaned up`);
}

async function sendCommand(serverId: string, command: string): Promise<{ success: boolean; response?: string; error?: string }> {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };
  if (state.status !== 'running') return { success: false, error: 'Server is not running' };

  // Method 1: RCON (primary for Proot compatibility)
  try {
    const response = await sendRconCommand(serverId, command);
    if (response !== null) {
      addConsoleLine(serverId, `> ${command}`, 'info');
      return { success: true, response };
    }
  } catch {}

  return { success: false, error: 'Failed to send command (RCON not connected)' };
}

// ============ RECONNECT RUNNING SERVERS (after daemon restart) ============

async function reconnectRunningServers() {
  log('info', 'Scanning for previously running servers...');
  for (const [serverId, state] of servers) {
    const pid = readPidFile(serverId);
    if (pid && isProcessRunning(pid)) {
      log('info', `Found running server ${serverId} (PID: ${pid})`);
      state.pid = pid;
      state.status = 'running';
      state.startedAt = Date.now(); // Approximate

      // Create pseudo-process (no stdin, but log watching + RCON will work)
      addConsoleLine(serverId, `[OGUltra] Reconnected to running server (PID: ${pid})`, 'success');

      // Start log watching (primary console method)
      startLogWatching(serverId);

      // Try connecting RCON
      const rconPort = state.config.rconPort || (state.config.port + 1000);
      const rconPassword = state.config.rconPassword || 'ogultra_rcon_' + state.config.uuid.slice(0, 8);
      state.config.rconPort = rconPort;
      state.config.rconPassword = rconPassword;
      connectRcon(serverId);

      broadcastServerStatus(serverId);
    }
  }
}

// ============ SERVER INSTALLATION ============

async function installServer(serverId: string, type: string, version: string): Promise<{ success: boolean; error?: string }> {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };

  state.status = 'installing';
  addConsoleLine(serverId, `[OGUltra] Installing ${type} ${version}...`, 'info');
  broadcastServerStatus(serverId);

  try {
    let downloadUrl = '';

    switch (type.toLowerCase()) {
      case 'paper': {
        // Get latest build for version
        const projectResp = await axios.get(`https://api.papermc.io/v2/projects/paper/versions/${version}`, { timeout: 15000 });
        const builds = projectResp.data.builds;
        const latestBuild = builds[builds.length - 1];
        downloadUrl = `https://api.papermc.io/v2/projects/paper/versions/${version}/builds/${latestBuild}/downloads/paper-${version}-${latestBuild}.jar`;
        break;
      }
      case 'purpur': {
        downloadUrl = `https://api.purpurmc.org/v2/purpur/${version}/latest/download`;
        break;
      }
      case 'vanilla': {
        const manifestResp = await axios.get('https://launchermeta.mojang.com/mc/game/version_manifest.json', { timeout: 15000 });
        const ver = manifestResp.data.versions.find((v: any) => v.id === version);
        if (!ver) throw new Error(`Version ${version} not found`);
        const verResp = await axios.get(ver.url, { timeout: 15000 });
        downloadUrl = verResp.data.downloads.server.url;
        break;
      }
      default:
        throw new Error(`Unknown server type: ${type}`);
    }

    addConsoleLine(serverId, `[OGUltra] Downloading from: ${downloadUrl}`, 'info');
    const response = await axios.get(downloadUrl, { responseType: 'stream', timeout: 120000 });
    const jarName = type === 'paper' ? `paper-${version}.jar` : type === 'purpur' ? `purpur-${version}.jar` : `server.jar`;
    const jarPath = join(state.config.workingDir, jarName);
    const writer = createWriteStream(jarPath);
    response.data.pipe(writer);

    await new Promise<void>((resolve, reject) => {
      writer.on('finish', resolve);
      writer.on('error', reject);
      response.data.on('error', reject);
    });

    // Accept EULA
    writeFileSync(join(state.config.workingDir, 'eula.txt'), 'eula=true\n');

    state.status = 'stopped';
    addConsoleLine(serverId, `[OGUltra] ${type} ${version} installed successfully as ${jarName}`, 'success');
    broadcastServerStatus(serverId);
    return { success: true };
  } catch (err: any) {
    state.status = 'stopped';
    addConsoleLine(serverId, `[OGUltra] Installation failed: ${err.message}`, 'error');
    broadcastServerStatus(serverId);
    return { success: false, error: err.message };
  }
}

// ============ FILE OPERATIONS ============

function listFiles(serverId: string, targetPath: string = '/'): any[] {
  const state = servers.get(serverId);
  if (!state) return [];

  const fsPath = join(state.config.workingDir, targetPath);
  if (!existsSync(fsPath)) return [];

  try {
    const entries = readdirSync(fsPath, { withFileTypes: true });
    return entries.map(entry => ({
      name: entry.name,
      path: join(targetPath, entry.name),
      isFile: entry.isFile(),
      isDirectory: entry.isDirectory(),
      size: entry.isFile() ? statSync(join(fsPath, entry.name)).size : 0,
      modified: statSync(join(fsPath, entry.name)).mtime.toISOString(),
    }));
  } catch {
    return [];
  }
}

function readFile(serverId: string, filePath: string): { content: string; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { content: '', error: 'Server not found' };

  const fullPath = join(state.config.workingDir, filePath);
  try {
    if (!existsSync(fullPath)) return { content: '', error: 'File not found' };
    const stats = statSync(fullPath);
    if (stats.size > 2 * 1024 * 1024) return { content: '', error: 'File too large (>2MB)' };
    return { content: readFileSync(fullPath, 'utf-8') };
  } catch (err: any) {
    return { content: '', error: err.message };
  }
}

function writeFile(serverId: string, filePath: string, content: string): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };

  const fullPath = join(state.config.workingDir, filePath);
  try {
    mkdirSync(dirname(fullPath), { recursive: true });
    writeFileSync(fullPath, content);
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

function deleteFileOrDir(serverId: string, filePath: string): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };

  const fullPath = join(state.config.workingDir, filePath);
  try {
    if (!existsSync(fullPath)) return { success: false, error: 'File not found' };
    const stats = statSync(fullPath);
    if (stats.isDirectory()) {
      rmSync(fullPath, { recursive: true, force: true });
    } else {
      unlinkSync(fullPath);
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

function createDirectory(serverId: string, dirPath: string): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };

  const fullPath = join(state.config.workingDir, dirPath);
  try {
    mkdirSync(fullPath, { recursive: true });
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

// ============ NODE INFO ============

function getNodeInfo(): NodeInfo {
  const cpuInfo = cpus();
  const tm = totalmem();
  const fm = freemem();
  let totalDisk = 51200;
  let usedDisk = 0;
  try {
    if (existsSync(SERVERS_DIR)) {
      const { execSync: es } = require('child_process');
      const df = es(`df -BM ${SERVERS_DIR} 2>/dev/null | tail -1`, { encoding: 'utf-8' }).trim().split(/\s+/);
      if (df.length >= 4) {
        totalDisk = parseInt(df[1]) || 51200;
        usedDisk = parseInt(df[2]) || 0;
      }
    }
  } catch {}

  let running = 0;
  for (const [, state] of servers) {
    if (state.status === 'running') running++;
  }

  return {
    uuid: DAEMON_UUID,
    hostname: require('os').hostname() || 'unknown',
    platform: platform(),
    arch: arch(),
    totalMemory: tm,
    freeMemory: fm,
    cpuCount: cpuInfo.length,
    cpuModel: cpuInfo[0]?.model || 'Unknown',
    daemonVersion: DAEMON_VERSION,
    totalDisk: totalDisk * 1024 * 1024,
    usedDisk: usedDisk * 1024 * 1024,
    serverCount: servers.size,
    runningServers: running,
  };
}

// ============ SERVER STATUS ============

function getServerStatus(serverId: string): any {
  const state = servers.get(serverId);
  if (!state) return null;

  const result: any = {
    id: serverId,
    status: state.status,
    pid: state.pid || readPidFile(serverId),
    name: state.config.name,
    memoryLimit: state.config.memoryLimit,
    cpuLimit: state.config.cpuLimit,
    port: state.config.port,
    startedAt: state.startedAt,
    uptime: state.startedAt ? Date.now() - state.startedAt : 0,
    cpuUsage: 0,
    memoryUsage: 0,
  };

  // Try to get resource usage
  const pid = result.pid;
  if (pid && state.status === 'running') {
    try {
      // Try pidusage if available
      const pidusage = require('pidusage');
      pidusage(pid).then((stats: any) => {
        result.cpuUsage = stats.cpu || 0;
        result.memoryUsage = stats.memory || 0;
      }).catch(() => {
        // Fallback: just show allocated memory
        result.memoryUsage = state.config.memoryLimit * 1024 * 1024 * 0.5;
      });
    } catch {
      result.memoryUsage = state.config.memoryLimit * 1024 * 1024 * 0.5;
    }
  }

  return result;
}

// ============ AUTH MIDDLEWARE ============

function authenticate(req: IncomingMessage): boolean {
  const auth = req.headers['authorization'];
  if (!auth) return false;
  const token = auth.replace('Bearer ', '');
  return token === AUTH_TOKEN;
}

function parseBody(req: IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => { body += chunk; });
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

// ============ HTTP SERVER ============

const httpServer = createServer(async (req, res) => {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // Auth check (except health)
  if (req.url !== '/health' && !authenticate(req)) {
    res.writeHead(401, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Unauthorized' }));
    return;
  }

  const url = new URL(req.url || '/', `http://localhost:${DAEMON_PORT}`);
  const pathname = url.pathname;

  try {
    // === HEALTH ===
    if (req.method === 'GET' && pathname === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'ok', version: DAEMON_VERSION, uuid: DAEMON_UUID }));
      return;
    }

    // === NODE INFO ===
    if (req.method === 'GET' && pathname === '/api/node') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(getNodeInfo()));
      return;
    }

    // === SERVERS LIST ===
    if (req.method === 'GET' && pathname === '/api/servers') {
      const list = Array.from(servers.values()).map(s => getServerStatus(s.id));
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(list));
      return;
    }

    // === SERVER REGISTER/CREATE ===
    if (req.method === 'POST' && pathname === '/api/servers') {
      const body = JSON.parse(await parseBody(req));
      const config: ServerConfig = {
        id: body.id || body.uuid || 'srv-' + Math.random().toString(36).slice(2, 8),
        uuid: body.uuid || body.id || Math.random().toString(36).slice(2, 8),
        name: body.name || 'Minecraft Server',
        workingDir: body.workingDir || join(SERVERS_DIR, body.id || 'default'),
        startupCommand: body.startupCommand || '',
        stopCommand: body.stopCommand || 'stop',
        javaPath: body.javaPath || null,
        memoryLimit: body.memoryLimit || 1024,
        cpuLimit: body.cpuLimit || 100,
        autoRestart: body.autoRestart ?? false,
        crashDetection: body.crashDetection ?? true,
        port: body.port || 25565,
        ip: body.ip || '0.0.0.0',
        rconPort: body.rconPort,
        rconPassword: body.rconPassword,
      };
      const ok = registerServer(config);
      res.writeHead(ok ? 201 : 409, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: ok, serverId: config.id }));
      return;
    }

    // === SERVER-SPECIFIC ROUTES ===
    const serverMatch = pathname.match(/^\/api\/servers\/([^/]+)(.*)$/);
    if (serverMatch) {
      const serverId = serverMatch[1];
      const subPath = serverMatch[2];

      // GET server status
      if (req.method === 'GET' && subPath === '') {
        const status = getServerStatus(serverId);
        if (!status) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Server not found' }));
          return;
        }
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(status));
        return;
      }

      // DELETE server
      if (req.method === 'DELETE' && subPath === '') {
        const state = servers.get(serverId);
        if (!state) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Server not found' }));
          return;
        }
        if (state.status === 'running') {
          stopServer(serverId, true);
        }
        servers.delete(serverId);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true }));
        return;
      }

      // === SERVER ACTIONS: individual routes (panel uses these) ===
      if (req.method === 'POST' && subPath === '/start') {
        const result = await startServer(serverId);
        res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }
      if (req.method === 'POST' && subPath === '/stop') {
        const result = stopServer(serverId);
        res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }
      if (req.method === 'POST' && subPath === '/restart') {
        const result = restartServer(serverId);
        res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }
      if (req.method === 'POST' && subPath === '/kill') {
        const result = killServer(serverId);
        res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }

      // === SERVER ACTION (unified, body-based) ===
      if (req.method === 'POST' && subPath === '/action') {
        const body = JSON.parse(await parseBody(req));
        const action = body.action;
        let result: any;
        switch (action) {
          case 'start': result = await startServer(serverId); break;
          case 'stop': result = stopServer(serverId); break;
          case 'restart': result = restartServer(serverId); break;
          case 'kill': result = killServer(serverId); break;
          default: result = { success: false, error: 'Unknown action' };
        }
        res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }

      // === SEND COMMAND ===
      if (req.method === 'POST' && subPath === '/command') {
        const body = JSON.parse(await parseBody(req));
        const result = await sendCommand(serverId, body.command);
        res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }

      // === INSTALL ===
      if (req.method === 'POST' && subPath === '/install') {
        const body = JSON.parse(await parseBody(req));
        const result = await installServer(serverId, body.type || 'paper', body.version || '1.21.4');
        res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }

      // === FILES ===
      // Must check more specific routes BEFORE the generic /files catch-all
      if (req.method === 'GET' && subPath.startsWith('/files/read')) {
        const filePath = url.searchParams.get('path') || '';
        const result = readFile(serverId, filePath);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }

      if (req.method === 'POST' && subPath.startsWith('/files/write')) {
        const body = JSON.parse(await parseBody(req));
        const result = writeFile(serverId, body.path, body.content);
        res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }

      // File delete via POST (panel sends POST to /files/delete with body)
      if (req.method === 'POST' && subPath === '/files/delete') {
        const body = JSON.parse(await parseBody(req));
        const result = deleteFileOrDir(serverId, body.path);
        res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }
      // File delete via DELETE with query param (alternative)
      if (req.method === 'DELETE' && (subPath === '/files' || subPath.startsWith('/files?'))) {
        const filePath = url.searchParams.get('path') || '';
        const result = deleteFileOrDir(serverId, filePath);
        res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }

      if (req.method === 'POST' && subPath.startsWith('/files/mkdir')) {
        const body = JSON.parse(await parseBody(req));
        const result = createDirectory(serverId, body.path);
        res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }

      // GET /files?path=... — list files (catch-all for /files GET)
      if (req.method === 'GET' && subPath.startsWith('/files')) {
        const filePath = url.searchParams.get('path') || '/';
        const result = listFiles(serverId, filePath);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
        return;
      }

      // === CONSOLE LOGS ===
      if (req.method === 'GET' && subPath === '/logs') {
        const state = servers.get(serverId);
        if (!state) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Server not found' }));
          return;
        }
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ lines: state.consoleBuffer }));
        return;
      }
    }

    // 404
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Route not found' }));

  } catch (err: any) {
    log('error', `HTTP error: ${err.message}`);
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: err.message }));
  }
});

// ============ WEBSOCKET SERVER (Console I/O) ============

const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

wss.on('connection', (ws: WebSocket, req) => {
  // Auth via query param or header
  const url = new URL(req.url || '/', `http://localhost:${DAEMON_PORT}`);
  const token = url.searchParams.get('token') || req.headers['authorization']?.toString().replace('Bearer ', '');
  if (token !== AUTH_TOKEN) {
    ws.close(4001, 'Unauthorized');
    return;
  }

  const serverId = url.searchParams.get('server_id');
  if (!serverId) {
    ws.close(4002, 'Missing server_id');
    return;
  }

  const state = servers.get(serverId);
  if (!state) {
    ws.close(4003, 'Server not found');
    return;
  }

  state.connections.add(ws);
  log('info', `WebSocket connected for server ${serverId}`);

  // Send existing console buffer
  ws.send(JSON.stringify({ event: 'console_buffer', data: state.consoleBuffer }));
  ws.send(JSON.stringify({ event: 'status', data: { status: state.status, pid: state.pid } }));

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data.toString());
      if (msg.event === 'command' && msg.data) {
        sendCommand(serverId, msg.data);
      }
    } catch {}
  });

  ws.on('close', () => {
    state.connections.delete(ws);
    log('info', `WebSocket disconnected for server ${serverId}`);
  });
});

// ============ START DAEMON ============

httpServer.listen(DAEMON_PORT, '0.0.0.0', async () => {
  log('info', `OGUltra Daemon v${DAEMON_VERSION} started on port ${DAEMON_PORT}`);
  log('info', `Servers directory: ${SERVERS_DIR}`);
  log('info', `Daemon UUID: ${DAEMON_UUID}`);
  log('info', `Java path: ${detectJava() || 'NOT FOUND'}`);
  log('info', `Platform: ${platform()} ${arch()}`);
  log('info', `Proot-compatible mode: ENABLED (detached spawn + log watch + RCON)`);

  // Reconnect to any servers that were running before daemon restart
  await reconnectRunningServers();
});

// Graceful shutdown
process.on('SIGINT', () => {
  log('info', 'Daemon shutting down...');
  for (const [id] of servers) {
    stopLogWatching(id);
    if (servers.get(id)?.rconClient) {
      try { servers.get(id)!.rconClient!.end(); } catch {}
    }
  }
  httpServer.close();
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('info', 'Daemon received SIGTERM, shutting down...');
  for (const [id] of servers) {
    stopLogWatching(id);
  }
  httpServer.close();
  process.exit(0);
});