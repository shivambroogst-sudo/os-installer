import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  const email = 'admin@ogultra.com';
  const username = 'admin';
  const password = 'admin123';

  // Check if admin user already exists
  const existing = await prisma.user.findFirst({
    where: { OR: [{ email }, { username }] },
  });

  if (existing) {
    console.log('⚠️  Admin user already exists, skipping seed.');
    console.log(`   Email: ${existing.email}, Username: ${existing.username}`);
    return;
  }

  const salt = await bcrypt.genSalt(12);
  const passwordHash = await bcrypt.hash(password, salt);

  const admin = await prisma.user.create({
    data: {
      email,
      username,
      passwordHash,
      role: 'admin',
      isRootAdmin: true,
      firstName: 'Root',
      lastName: 'Admin',
      isActive: true,
    },
  });

  console.log('✅ Admin user created successfully:');
  console.log(`   ID: ${admin.id}`);
  console.log(`   Email: ${admin.email}`);
  console.log(`   Username: ${admin.username}`);
  console.log(`   Role: ${admin.role}`);
  console.log(`   Is Root Admin: ${admin.isRootAdmin}`);

  // ── Seed default node ──
  const existingNode = await prisma.node.findFirst({ where: { name: 'Local Node' } });
  if (!existingNode) {
    await prisma.node.create({
      data: {
        uuid: 'local-node-001',
        name: 'Local Node',
        fqdn: '127.0.0.1',
        scheme: 'http',
        daemonPort: 3003,
        daemonToken: 'ogultra-daemon-secret-token',
        isPublic: true,
        totalCpu: 4,
        totalMemory: 8192,
        totalDisk: 51200,
        status: 'offline',
      },
    });
    console.log('✅ Default local node created');
  }

  // ── Seed panel settings ──
  const defaultSettings = [
    { key: 'company_name', value: 'OGUltra Panel', type: 'string', group: 'branding' },
    { key: 'registration_enabled', value: 'true', type: 'boolean', group: 'security' },
    { key: 'default_server_memory', value: '1024', type: 'number', group: 'general' },
    { key: 'default_server_cpu', value: '100', type: 'number', group: 'general' },
  ];
  for (const s of defaultSettings) {
    await prisma.panelSetting.upsert({ where: { key: s.key }, update: { value: s.value }, create: s });
  }
  console.log('✅ Panel settings seeded');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });