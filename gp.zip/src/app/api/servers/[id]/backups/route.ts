import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: List backups for a server
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const server = await db.server.findUnique({ where: { id } });
    if (!server) {
      return NextResponse.json(
        { success: false, error: 'Server not found' },
        { status: 404 }
      );
    }

    const backups = await db.backup.findMany({
      where: { serverId: id },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, data: backups });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// POST: Create backup entry
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = (await request.json()) as {
      name?: string;
      fileSize?: number;
      path?: string;
      isSuccessful?: boolean;
      checksum?: string;
    };

    const server = await db.server.findUnique({ where: { id } });
    if (!server) {
      return NextResponse.json(
        { success: false, error: 'Server not found' },
        { status: 404 }
      );
    }

    const backup = await db.backup.create({
      data: {
        serverId: id,
        name: body.name || `Backup ${new Date().toISOString()}`,
        fileSize: body.fileSize || 0,
        path: body.path || '',
        isSuccessful: body.isSuccessful ?? false,
        checksum: body.checksum || null,
      },
    });

    return NextResponse.json({ success: true, data: backup }, { status: 201 });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// DELETE: Delete backup entry
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = (await request.json()) as {
      backupId?: string;
    };

    if (!body.backupId) {
      return NextResponse.json(
        { success: false, error: 'backupId is required' },
        { status: 400 }
      );
    }

    const backup = await db.backup.findFirst({
      where: { id: body.backupId, serverId: id },
    });

    if (!backup) {
      return NextResponse.json(
        { success: false, error: 'Backup not found' },
        { status: 404 }
      );
    }

    await db.backup.delete({ where: { id: backup.id } });

    return NextResponse.json({ success: true, message: 'Backup deleted' });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}