import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: List schedules for a server
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const server = await db.server.findUnique({ where: { id } });
    if (!server) {
      return NextResponse.json(
        { success: false, error: 'Server not found' },
        { status: 404 }
      );
    }

    const schedules = await db.schedule.findMany({
      where: { serverId: id },
      include: {
        tasks: {
          orderBy: { sequenceOrder: 'asc' },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, data: schedules });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// POST: Create schedule
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = (await request.json()) as {
      name?: string;
      cronExpression?: string;
      isActive?: boolean;
      tasks?: Array<{
        action: string;
        payload?: string;
        sequenceOrder?: number;
        delaySeconds?: number;
        isContinueOnFailure?: boolean;
      }>;
    };

    const { name, cronExpression, isActive, tasks } = body;

    if (!name || !cronExpression) {
      return NextResponse.json(
        { success: false, error: 'name and cronExpression are required' },
        { status: 400 }
      );
    }

    const server = await db.server.findUnique({ where: { id } });
    if (!server) {
      return NextResponse.json(
        { success: false, error: 'Server not found' },
        { status: 404 }
      );
    }

    const schedule = await db.schedule.create({
      data: {
        serverId: id,
        name,
        cronExpression,
        isActive: isActive !== false,
        tasks: tasks
          ? {
              create: tasks.map((task, index) => ({
                action: task.action,
                payload: task.payload || null,
                sequenceOrder: task.sequenceOrder ?? index,
                delaySeconds: task.delaySeconds ?? 0,
                isContinueOnFailure: task.isContinueOnFailure ?? false,
              })),
            }
          : undefined,
      },
      include: { tasks: true },
    });

    return NextResponse.json({ success: true, data: schedule }, { status: 201 });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// PUT: Update schedule
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = (await request.json()) as {
      scheduleId?: string;
      name?: string;
      cronExpression?: string;
      isActive?: boolean;
    };

    const { scheduleId, name, cronExpression, isActive } = body;

    if (!scheduleId) {
      return NextResponse.json(
        { success: false, error: 'scheduleId is required' },
        { status: 400 }
      );
    }

    const schedule = await db.schedule.findFirst({
      where: { id: scheduleId, serverId: id },
    });

    if (!schedule) {
      return NextResponse.json(
        { success: false, error: 'Schedule not found' },
        { status: 404 }
      );
    }

    const updated = await db.schedule.update({
      where: { id: scheduleId },
      data: {
        ...(name !== undefined && { name }),
        ...(cronExpression !== undefined && { cronExpression }),
        ...(isActive !== undefined && { isActive }),
      },
      include: { tasks: true },
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// DELETE: Delete schedule
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = (await request.json()) as {
      scheduleId?: string;
    };

    if (!body.scheduleId) {
      return NextResponse.json(
        { success: false, error: 'scheduleId is required' },
        { status: 400 }
      );
    }

    const schedule = await db.schedule.findFirst({
      where: { id: body.scheduleId, serverId: id },
    });

    if (!schedule) {
      return NextResponse.json(
        { success: false, error: 'Schedule not found' },
        { status: 404 }
      );
    }

    await db.schedule.delete({ where: { id: schedule.id } });

    return NextResponse.json({ success: true, message: 'Schedule deleted' });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}