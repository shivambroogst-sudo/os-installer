import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { daemonFetch } from '@/lib/daemon';
import { requireAdmin } from '@/lib/auth';

// GET: Get server from DB with node info
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const server = await db.server.findUnique({
      where: { id },
      include: {
        node: {
          select: { id: true, uuid: true, name: true, fqdn: true, daemonPort: true, scheme: true },
        },
        members: {
          include: {
            user: {
              select: { id: true, username: true, email: true, avatar: true },
            },
          },
        },
        backups: {
          select: { id: true, name: true, fileSize: true, isSuccessful: true, createdAt: true },
          orderBy: { createdAt: 'desc' },
          take: 10,
        },
        schedules: {
          orderBy: { createdAt: 'desc' },
        },
        allocations: {
          select: { id: true, ip: true, port: true, isDefault: true, notes: true },
        },
      },
    });

    if (!server) {
      return NextResponse.json(
        { success: false, error: 'Server not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, data: server });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// PUT: Update server settings
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { error, status } = await requireAdmin();
    if (error) {
      return NextResponse.json({ success: false, error }, { status });
    }

    const { id } = await params;
    const body = (await request.json()) as {
      name?: string;
      description?: string;
      memoryLimit?: number;
      cpuLimit?: number;
      diskLimit?: number;
      startupCommand?: string;
      javaVersion?: string;
      customJava?: string;
      port?: number;
      queryPort?: number;
      ip?: string;
      isSuspended?: boolean;
    };

    const existing = await db.server.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Server not found' },
        { status: 404 }
      );
    }

    const updated = await db.server.update({
      where: { id },
      data: {
        ...(body.name !== undefined && { name: body.name }),
        ...(body.description !== undefined && { description: body.description || null }),
        ...(body.memoryLimit !== undefined && { memoryLimit: body.memoryLimit }),
        ...(body.cpuLimit !== undefined && { cpuLimit: body.cpuLimit }),
        ...(body.diskLimit !== undefined && { diskLimit: body.diskLimit }),
        ...(body.startupCommand !== undefined && { startupCommand: body.startupCommand || null }),
        ...(body.javaVersion !== undefined && { javaVersion: body.javaVersion }),
        ...(body.customJava !== undefined && { customJava: body.customJava || null }),
        ...(body.port !== undefined && { port: body.port }),
        ...(body.queryPort !== undefined && { queryPort: body.queryPort || null }),
        ...(body.ip !== undefined && { ip: body.ip }),
        ...(body.isSuspended !== undefined && { isSuspended: body.isSuspended }),
      },
      include: {
        node: {
          select: { name: true, fqdn: true },
        },
      },
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// DELETE: Delete from DB + kill on daemon
export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { error, status } = await requireAdmin();
    if (error) {
      return NextResponse.json({ success: false, error }, { status });
    }

    const { id } = await params;

    const server = await db.server.findUnique({ where: { id } });
    if (!server) {
      return NextResponse.json(
        { success: false, error: 'Server not found' },
        { status: 404 }
      );
    }

    // Kill on daemon (best effort)
    try {
      await daemonFetch(`/api/servers/${server.uuid}`, {
        method: 'DELETE',
      });
    } catch {
      // Daemon may be offline, continue with DB deletion
    }

    // Delete from DB
    await db.server.delete({ where: { id } });

    return NextResponse.json({ success: true, message: 'Server deleted' });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}