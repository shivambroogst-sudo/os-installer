import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';
import { daemonFetch } from '@/lib/daemon';
import { requireAdmin } from '@/lib/auth';

// GET: List servers from DB (with node info)
export async function GET() {
  try {
    const { error, status } = await requireAdmin();
    if (error) {
      return NextResponse.json({ success: false, error }, { status });
    }

    const servers = await db.server.findMany({
      include: {
        node: {
          select: { name: true, fqdn: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, data: servers });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// POST: Create server in DB + register on daemon
export async function POST(request: Request) {
  try {
    const { error, status } = await requireAdmin();
    if (error) {
      return NextResponse.json({ success: false, error }, { status });
    }

    const body = (await request.json()) as {
      name?: string;
      nodeId?: string;
      memoryLimit?: number;
      cpuLimit?: number;
      port?: number;
      startupCommand?: string;
      software?: string;
      javaVersion?: string;
    };

    const {
      name,
      nodeId,
      memoryLimit,
      cpuLimit,
      port,
      startupCommand,
      software,
      javaVersion,
    } = body;

    if (!name || !nodeId) {
      return NextResponse.json(
        { success: false, error: 'name and nodeId are required' },
        { status: 400 }
      );
    }

    // Verify node exists
    const node = await db.node.findUnique({ where: { id: nodeId } });
    if (!node) {
      return NextResponse.json(
        { success: false, error: 'Node not found' },
        { status: 404 }
      );
    }

    const serverUuid = uuidv4();

    // Create server in DB
    const server = await db.server.create({
      data: {
        uuid: serverUuid,
        name,
        nodeId,
        memoryLimit: memoryLimit || 1024,
        cpuLimit: cpuLimit || 100,
        diskLimit: 5120,
        port: port || 25565,
        startupCommand: startupCommand || null,
        software: software || null,
        javaVersion: javaVersion || '21',
        status: 'installing',
        installState: 'pending',
      },
      include: {
        node: {
          select: { name: true, fqdn: true },
        },
      },
    });

    // Register on daemon
    try {
      await daemonFetch('/api/servers', {
        method: 'POST',
        body: JSON.stringify({
          uuid: serverUuid,
          name,
          memoryLimit: server.memoryLimit,
          cpuLimit: server.cpuLimit,
          diskLimit: server.diskLimit,
          port: server.port,
          javaVersion: server.javaVersion,
        }),
      });
    } catch {
      // Daemon registration failed but DB record exists
      // Server will show as installing but daemon is unaware
    }

    return NextResponse.json({ success: true, data: server }, { status: 201 });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}