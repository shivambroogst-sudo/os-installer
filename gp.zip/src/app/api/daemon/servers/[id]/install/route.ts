import { NextResponse } from 'next/server';
import { daemonFetch } from '@/lib/daemon';
import { db } from '@/lib/db';

// POST: Proxy install request to daemon
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = (await request.json()) as {
      software?: string;
      version?: string;
    };

    const { software, version } = body;

    if (!software || !version) {
      return NextResponse.json(
        { success: false, error: 'software and version are required' },
        { status: 400 }
      );
    }

    // Update server install state in DB
    await db.server.update({
      where: { id },
      data: {
        installState: 'installing',
        software,
      },
    });

    // Forward install request to daemon
    const res = await daemonFetch(`/api/servers/${id}/install`, {
      method: 'POST',
      body: JSON.stringify({ software, version }),
    });

    const data = await res.json();

    if (!res.ok) {
      // Mark install as failed
      await db.server.update({
        where: { id },
        data: { installState: 'failed' },
      });
    }

    return NextResponse.json(data, { status: res.status });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';

    // Try to mark as failed
    try {
      const { id } = await params;
      await db.server.update({
        where: { id },
        data: { installState: 'failed' },
      });
    } catch {
      // ignore
    }

    return NextResponse.json({ success: false, error: message }, { status: 502 });
  }
}