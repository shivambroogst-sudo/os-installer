import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';

// Default Minecraft eggs to seed
const DEFAULT_EGGS = [
  {
    name: 'Paper',
    description: 'High-performance Minecraft server software with plugin API',
    author: 'OGUltra',
    serverType: 'minecraft',
    software: 'paper',
    version: '1.21.4',
    startupCmd: 'java -Xms128M -Xmx{{MEMORY}}M -jar {{SERVER_JAR}} nogui',
    configJson: '{"downloadUrl": "https://api.papermc.io/v2/projects/paper/versions/1.21.4/builds/latest/downloads/paper-1.21.4-{{BUILD}}.jar"}',
    isDefault: true,
  },
  {
    name: 'Purpur',
    description: 'High-performance Minecraft server software with extensive customization',
    author: 'OGUltra',
    serverType: 'minecraft',
    software: 'purpur',
    version: '1.21.4',
    startupCmd: 'java -Xms128M -Xmx{{MEMORY}}M -jar {{SERVER_JAR}} nogui',
    configJson: '{"downloadUrl": "https://api.purpurmc.org/v2/purpur/1.21.4/latest/download"}',
    isDefault: true,
  },
  {
    name: 'Vanilla',
    description: 'Official Minecraft server software',
    author: 'Mojang',
    serverType: 'minecraft',
    software: 'vanilla',
    version: '1.21.4',
    startupCmd: 'java -Xms128M -Xmx{{MEMORY}}M -jar {{SERVER_JAR}} nogui',
    configJson: '{"downloadUrl": "https://launcher.mojang.com/v1/objects/1.21.4/server.jar"}',
    isDefault: true,
  },
  {
    name: 'Spigot',
    description: 'Popular Minecraft server software with plugin support',
    author: 'OGUltra',
    serverType: 'minecraft',
    software: 'spigot',
    version: '1.21.4',
    startupCmd: 'java -Xms128M -Xmx{{MEMORY}}M -jar {{SERVER_JAR}} nogui',
    configJson: '{}',
    isDefault: true,
  },
  {
    name: 'Fabric',
    description: 'Lightweight modding framework for Minecraft',
    author: 'OGUltra',
    serverType: 'minecraft',
    software: 'fabric',
    version: '1.21.4',
    startupCmd: 'java -Xms128M -Xmx{{MEMORY}}M -jar {{SERVER_JAR}} nogui',
    configJson: '{"loaderUrl": "https://meta.fabricmc.net/v2/versions/loader/1.21.4/{{LOADER_VERSION}}/server/json"}',
    isDefault: true,
  },
  {
    name: 'Forge',
    description: 'Minecraft modding platform with extensive mod support',
    author: 'OGUltra',
    serverType: 'minecraft',
    software: 'forge',
    version: '1.21.4',
    startupCmd: 'java -Xms128M -Xmx{{MEMORY}}M -jar {{SERVER_JAR}} nogui',
    configJson: '{}',
    isDefault: true,
  },
];

// GET: List all eggs
export async function GET() {
  try {
    const eggs = await db.egg.findMany({
      orderBy: { name: 'asc' },
    });

    // Auto-seed if no eggs exist
    if (eggs.length === 0) {
      const seeded = await db.egg.createMany({
        data: DEFAULT_EGGS.map((egg) => ({
          uuid: uuidv4(),
          ...egg,
        })),
      });

      const allEggs = await db.egg.findMany({ orderBy: { name: 'asc' } });
      return NextResponse.json({ success: true, data: allEggs, seeded: seeded.count });
    }

    return NextResponse.json({ success: true, data: eggs });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// POST: Create egg
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      name?: string;
      description?: string;
      author?: string;
      serverType?: string;
      software?: string;
      version?: string;
      downloadUrl?: string;
      startupCmd?: string;
      configJson?: string;
      isDefault?: boolean;
    };

    const {
      name,
      description,
      author,
      serverType,
      software,
      version,
      downloadUrl,
      startupCmd,
      configJson,
      isDefault,
    } = body;

    if (!name || !serverType || !software) {
      return NextResponse.json(
        { success: false, error: 'name, serverType, and software are required' },
        { status: 400 }
      );
    }

    // Check for duplicate software name
    const existing = await db.egg.findFirst({ where: { software } });
    if (existing) {
      return NextResponse.json(
        { success: false, error: `Egg with software '${software}' already exists` },
        { status: 409 }
      );
    }

    const egg = await db.egg.create({
      data: {
        uuid: uuidv4(),
        name,
        description: description || null,
        author: author || null,
        serverType,
        software,
        version: version || null,
        downloadUrl: downloadUrl || null,
        startupCmd: startupCmd || null,
        configJson: configJson || null,
        isDefault: isDefault ?? false,
      },
    });

    return NextResponse.json({ success: true, data: egg }, { status: 201 });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}