import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';

// POST: Sync node — fetch real stats from daemon and update DB
export async function POST(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { error, status } = await requireAdmin();
    if (error) {
      return NextResponse.json({ success: false, error }, { status });
    }

    const { id } = await params;

    const node = await db.node.findUnique({ where: { id } });
    if (!node) {
      return NextResponse.json(
        { success: false, error: 'Node not found' },
        { status: 404 }
      );
    }

    // Build daemon URL from node config
    const scheme = node.scheme || 'https';
    const daemonUrl = `${scheme}://${node.fqdn}:${node.daemonPort}`;

    // Fetch node stats from daemon
    const res = await fetch(`${daemonUrl}/api/node`, {
      headers: {
        Authorization: `Bearer ${node.daemonToken}`,
        'Content-Type': 'application/json',
      },
      signal: AbortSignal.timeout(10000),
    });

    if (!res.ok) {
      await db.node.update({
        where: { id },
        data: { status: 'offline' },
      });
      return NextResponse.json(
        { success: false, error: `Daemon returned ${res.status}` },
        { status: 502 }
      );
    }

    const data = (await res.json()) as {
      cpu?: number;
      memory?: number;
      disk?: number;
      totalCpu?: number;
      totalMemory?: number;
      totalDisk?: number;
    };

    // Update node with real stats
    const updated = await db.node.update({
      where: { id },
      data: {
        usedCpu: data.cpu ?? 0,
        usedMemory: data.memory ?? 0,
        usedDisk: data.disk ?? 0,
        status: 'online',
        lastPingAt: new Date(),
        ...(data.totalCpu !== undefined && { totalCpu: data.totalCpu }),
        ...(data.totalMemory !== undefined && { totalMemory: data.totalMemory }),
        ...(data.totalDisk !== undefined && { totalDisk: data.totalDisk }),
      },
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';

    // Mark node as offline on failure
    try {
      const { id } = await params;
      await db.node.update({
        where: { id },
        data: { status: 'offline' },
      });
    } catch {
      // ignore
    }

    return NextResponse.json({ success: false, error: message }, { status: 502 });
  }
}