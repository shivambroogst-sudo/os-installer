import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';

// GET: Get node by ID
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const node = await db.node.findUnique({
      where: { id },
      include: {
        _count: {
          select: { servers: true, allocations: true },
        },
        servers: {
          select: {
            id: true,
            uuid: true,
            name: true,
            status: true,
            memoryLimit: true,
            cpuLimit: true,
          },
        },
      },
    });

    if (!node) {
      return NextResponse.json(
        { success: false, error: 'Node not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, data: node });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// PUT: Update node
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { error, status } = await requireAdmin();
    if (error) {
      return NextResponse.json({ success: false, error }, { status });
    }

    const { id } = await params;
    const body = (await request.json()) as {
      name?: string;
      description?: string;
      fqdn?: string;
      daemonPort?: number;
      daemonToken?: string;
      scheme?: string;
      isPublic?: boolean;
      totalCpu?: number;
      totalMemory?: number;
      totalDisk?: number;
    };

    const existing = await db.node.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Node not found' },
        { status: 404 }
      );
    }

    const updated = await db.node.update({
      where: { id },
      data: {
        ...(body.name !== undefined && { name: body.name }),
        ...(body.description !== undefined && { description: body.description || null }),
        ...(body.fqdn !== undefined && { fqdn: body.fqdn }),
        ...(body.daemonPort !== undefined && { daemonPort: body.daemonPort }),
        ...(body.daemonToken !== undefined && { daemonToken: body.daemonToken }),
        ...(body.scheme !== undefined && { scheme: body.scheme }),
        ...(body.isPublic !== undefined && { isPublic: body.isPublic }),
        ...(body.totalCpu !== undefined && { totalCpu: body.totalCpu }),
        ...(body.totalMemory !== undefined && { totalMemory: body.totalMemory }),
        ...(body.totalDisk !== undefined && { totalDisk: body.totalDisk }),
      },
    });

    return NextResponse.json({ success: true, data: updated });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// DELETE: Delete node (only if no servers assigned)
export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { error, status } = await requireAdmin();
    if (error) {
      return NextResponse.json({ success: false, error }, { status });
    }

    const { id } = await params;

    const node = await db.node.findUnique({
      where: { id },
      include: { _count: { select: { servers: true } } },
    });

    if (!node) {
      return NextResponse.json(
        { success: false, error: 'Node not found' },
        { status: 404 }
      );
    }

    if (node._count.servers > 0) {
      return NextResponse.json(
        { success: false, error: 'Cannot delete node with servers assigned. Move or delete servers first.' },
        { status: 409 }
      );
    }

    await db.node.delete({ where: { id } });

    return NextResponse.json({ success: true, message: 'Node deleted' });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}