import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';
import { requireAdmin } from '@/lib/auth';

// GET: List all nodes
export async function GET() {
  try {
    const { error, status } = await requireAdmin();
    if (error) {
      return NextResponse.json({ success: false, error }, { status });
    }

    const nodes = await db.node.findMany({
      include: {
        _count: {
          select: { servers: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, data: nodes });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// POST: Create node
export async function POST(request: Request) {
  try {
    const { error, status } = await requireAdmin();
    if (error) {
      return NextResponse.json({ success: false, error }, { status });
    }

    const body = (await request.json()) as {
      name?: string;
      description?: string;
      fqdn?: string;
      daemonPort?: number;
      daemonToken?: string;
      scheme?: string;
      isPublic?: boolean;
      totalCpu?: number;
      totalMemory?: number;
      totalDisk?: number;
    };

    const {
      name,
      description,
      fqdn,
      daemonPort,
      daemonToken,
      scheme,
      isPublic,
      totalCpu,
      totalMemory,
      totalDisk,
    } = body;

    if (!name || !fqdn || !daemonToken || totalCpu === undefined || totalMemory === undefined || totalDisk === undefined) {
      return NextResponse.json(
        { success: false, error: 'name, fqdn, daemonToken, totalCpu, totalMemory, totalDisk are required' },
        { status: 400 }
      );
    }

    const node = await db.node.create({
      data: {
        uuid: uuidv4(),
        name,
        description: description || null,
        fqdn,
        daemonPort: daemonPort || 8080,
        daemonToken,
        scheme: scheme || 'https',
        isPublic: isPublic !== false,
        totalCpu,
        totalMemory,
        totalDisk,
      },
    });

    return NextResponse.json({ success: true, data: node }, { status: 201 });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}