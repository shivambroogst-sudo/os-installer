import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';

// GET: Get all panel settings
export async function GET() {
  try {
    const { error, status } = await requireAdmin();
    if (error) {
      return NextResponse.json({ success: false, error }, { status });
    }

    const settings = await db.panelSetting.findMany({
      orderBy: [{ group: 'asc' }, { key: 'asc' }],
    });

    return NextResponse.json({ success: true, data: settings });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}

// PUT: Update panel settings (upsert by key)
export async function PUT(request: Request) {
  try {
    const { error, status } = await requireAdmin();
    if (error) {
      return NextResponse.json({ success: false, error }, { status });
    }

    const body = (await request.json()) as {
      settings?: Array<{
        key: string;
        value: string;
        type?: string;
        group?: string;
      }>;
    };

    if (!body.settings || !Array.isArray(body.settings)) {
      return NextResponse.json(
        { success: false, error: 'settings array is required' },
        { status: 400 }
      );
    }

    const results = await Promise.all(
      body.settings.map((setting) =>
        db.panelSetting.upsert({
          where: { key: setting.key },
          update: {
            value: setting.value,
            ...(setting.type && { type: setting.type }),
            ...(setting.group && { group: setting.group }),
          },
          create: {
            key: setting.key,
            value: setting.value,
            type: setting.type || 'string',
            group: setting.group || 'general',
          },
        })
      )
    );

    return NextResponse.json({ success: true, data: results });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}