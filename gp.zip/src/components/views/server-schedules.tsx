'use client';
import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus,
  Play,
  Trash2,
  Edit3,
  Clock,
  CalendarClock,
  AlertCircle,
  Info,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { listSchedules } from '@/lib/api';
import { useNavStore } from '@/lib/store';
import { toast } from 'sonner';

// ============ Types ============
interface Schedule {
  id: string;
  name: string;
  cron: string;
  action: string;
  isActive: boolean;
  lastRun: string | null;
  nextRun: string | null;
}

// ============ Component ============
export default function ServerSchedules() {
  const { selectedServerId } = useNavStore();
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<Schedule | null>(null);

  const [formName, setFormName] = useState('');
  const [formCron, setFormCron] = useState('');
  const [formAction, setFormAction] = useState('restart');
  const [formEnabled, setFormEnabled] = useState(true);

  const fetchSchedules = useCallback(async () => {
    if (!selectedServerId) { setLoading(false); return; }
    setLoading(true);
    try {
      const res = await listSchedules(selectedServerId);
      if (res.success && Array.isArray(res.data)) {
        setSchedules(res.data);
      } else {
        setSchedules([]);
      }
    } catch {
      setSchedules([]);
    } finally {
      setLoading(false);
    }
  }, [selectedServerId]);

  useEffect(() => { fetchSchedules(); }, [fetchSchedules]);

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return '—';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const openCreateDialog = () => {
    setEditingSchedule(null);
    setFormName('');
    setFormCron('0 */6 * * *');
    setFormAction('restart');
    setFormEnabled(true);
    setDialogOpen(true);
  };

  const openEditDialog = (schedule: Schedule) => {
    setEditingSchedule(schedule);
    setFormName(schedule.name);
    setFormCron(schedule.cron);
    setFormAction(schedule.action.includes('Command:') ? 'command' : schedule.action.toLowerCase());
    setFormEnabled(schedule.isActive);
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formName.trim()) { toast.error('Schedule name is required'); return; }
    if (!formCron.trim()) { toast.error('Cron expression is required'); return; }
    const actionLabel = formAction === 'command' ? `Command: broadcast ${formName}` : formAction.charAt(0).toUpperCase() + formAction.slice(1);

    if (editingSchedule) {
      setSchedules((prev) => prev.map((s) => s.id === editingSchedule.id ? { ...s, name: formName, cron: formCron, action: actionLabel, isActive: formEnabled } : s));
      toast.success('Schedule updated');
    } else {
      const newSchedule: Schedule = { id: `sch_${Date.now()}`, name: formName, cron: formCron, action: actionLabel, isActive: formEnabled, lastRun: null, nextRun: new Date(Date.now() + 3600000).toISOString() };
      setSchedules((prev) => [...prev, newSchedule]);
      toast.success('Schedule created', { description: `${formName} will run: ${formCron}` });
    }
    setDialogOpen(false);
  };

  const handleToggle = (id: string) => {
    setSchedules((prev) => prev.map((s) => (s.id === id ? { ...s, isActive: !s.isActive } : s)));
  };

  const handleRunNow = (name: string) => {
    toast.success(`Running "${name}"`, { description: 'The scheduled task has been triggered manually.' });
  };

  const handleDelete = (id: string) => {
    setSchedules((prev) => prev.filter((s) => s.id !== id));
    toast.success('Schedule deleted');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-brand-400 animate-spin" />
      </div>
    );
  }

  return (
    <TooltipProvider>
      <motion.div className="space-y-6" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: 'easeOut' }}>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white">Schedule Manager</h2>
            <p className="text-sm text-zinc-400 mt-1">{schedules.length} scheduled tasks</p>
          </div>
          <Button className="bg-brand-600 hover:bg-brand-500 text-white" onClick={openCreateDialog}>
            <Plus className="w-4 h-4 mr-2" /> Create Schedule
          </Button>
        </div>

        {/* Cron Format Helper */}
        <motion.div className="glass-card p-4" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <div className="flex items-start gap-3">
            <div className="p-1.5 rounded-md bg-brand-500/20 shrink-0 mt-0.5"><Info className="w-4 h-4 text-brand-400" /></div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold text-white">Cron Expression Format</h3>
              <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                <code className="text-brand-400 bg-white/5 px-1.5 py-0.5 rounded text-xs">* * * * *</code> — minute hour day-of-month month day-of-week
              </p>
              <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-xs text-zinc-500">
                <span><code className="text-zinc-300">*/6 * * * *</code> — Every 6 hours</span>
                <span><code className="text-zinc-300">0 4 * * *</code> — Daily at 4 AM</span>
                <span><code className="text-zinc-300">0 */12 * * 1</code> — Every 12h on Monday</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Schedule Cards */}
        <div className="space-y-3">
          <AnimatePresence mode="popLayout">
            {schedules.map((schedule, index) => (
              <motion.div key={schedule.id} className="glass-card p-5" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -20, height: 0 }} transition={{ delay: index * 0.05 }} layout>
                <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                  <div className="flex items-start gap-4 flex-1 min-w-0">
                    <div className={`p-2 rounded-lg shrink-0 ${schedule.isActive ? 'bg-accent-500/20' : 'bg-zinc-800'}`}>
                      <CalendarClock className={`w-5 h-5 ${schedule.isActive ? 'text-accent-400' : 'text-zinc-500'}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm font-semibold text-white">{schedule.name}</h3>
                        {schedule.isActive ? (
                          <Badge className="bg-accent-500/20 text-accent-400 border-accent-500/30 text-xs">Active</Badge>
                        ) : (
                          <Badge variant="outline" className="border-zinc-700 text-zinc-500 text-xs">Inactive</Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 mt-1.5">
                        <code className="text-xs font-mono text-brand-400 bg-brand-500/10 px-2 py-0.5 rounded">{schedule.cron}</code>
                        <span className="text-xs text-zinc-500">·</span>
                        <span className="text-xs text-zinc-400">{schedule.action}</span>
                      </div>
                      <div className="flex flex-wrap gap-x-4 gap-y-0.5 mt-2">
                        <div className="flex items-center gap-1.5"><Clock className="w-3 h-3 text-zinc-600" /><span className="text-xs text-zinc-500">Last: {formatDate(schedule.lastRun)}</span></div>
                        <div className="flex items-center gap-1.5"><CalendarClock className="w-3 h-3 text-zinc-600" /><span className="text-xs text-zinc-500">Next: {formatDate(schedule.nextRun)}</span></div>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0 lg:ml-4">
                    <Switch checked={schedule.isActive} onCheckedChange={() => handleToggle(schedule.id)} className="data-[state=checked]:bg-accent-500" />
                    <Separator orientation="vertical" className="h-6 bg-zinc-800 hidden sm:block" />
                    <div className="flex items-center gap-1">
                      <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 text-zinc-400 hover:text-white hover:bg-white/5" onClick={() => openEditDialog(schedule)}><Edit3 className="w-3.5 h-3.5" /></Button></TooltipTrigger><TooltipContent>Edit</TooltipContent></Tooltip>
                      <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 text-accent-400/70 hover:text-accent-400 hover:bg-accent-500/10" onClick={() => handleRunNow(schedule.name)}><Play className="w-3.5 h-3.5" /></Button></TooltipTrigger><TooltipContent>Run Now</TooltipContent></Tooltip>
                      <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 text-red-400/70 hover:text-red-400 hover:bg-red-500/10" onClick={() => handleDelete(schedule.id)}><Trash2 className="w-3.5 h-3.5" /></Button></TooltipTrigger><TooltipContent>Delete</TooltipContent></Tooltip>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {schedules.length === 0 && (
            <motion.div className="glass-card p-12 flex flex-col items-center justify-center text-center" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="p-4 rounded-2xl bg-white/5 mb-4"><CalendarClock className="w-10 h-10 text-zinc-600" /></div>
              <h3 className="text-lg font-semibold text-white mb-2">No schedules</h3>
              <p className="text-sm text-zinc-400 max-w-sm">Create a scheduled task to automate backups, restarts, or custom commands.</p>
            </motion.div>
          )}
        </div>

        {/* Create/Edit Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-md">
            <DialogHeader><DialogTitle>{editingSchedule ? 'Edit Schedule' : 'Create Schedule'}</DialogTitle></DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2"><Label className="text-zinc-300 text-sm">Name</Label><Input value={formName} onChange={(e) => setFormName(e.target.value)} placeholder="e.g. Auto Restart" className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600" /></div>
              <div className="space-y-2">
                <Label className="text-zinc-300 text-sm flex items-center gap-1.5">Cron Expression <code className="text-xs text-zinc-500 font-normal">* * * * *</code></Label>
                <Input value={formCron} onChange={(e) => setFormCron(e.target.value)} placeholder="0 */6 * * *" className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600 font-mono" />
                <p className="text-xs text-zinc-500 flex items-center gap-1"><AlertCircle className="w-3 h-3" /> minute hour day month weekday</p>
              </div>
              <div className="space-y-2"><Label className="text-zinc-300 text-sm">Action</Label><Select value={formAction} onValueChange={setFormAction}><SelectTrigger className="bg-white/5 border-zinc-700 text-white"><SelectValue /></SelectTrigger><SelectContent className="bg-zinc-900 border-zinc-800"><SelectItem value="restart">Restart</SelectItem><SelectItem value="start">Start</SelectItem><SelectItem value="stop">Stop</SelectItem><SelectItem value="kill">Kill</SelectItem><SelectItem value="backup">Backup</SelectItem><SelectItem value="command">Custom Command</SelectItem></SelectContent></Select></div>
              <div className="flex items-center justify-between"><Label className="text-zinc-300 text-sm">Enabled</Label><Switch checked={formEnabled} onCheckedChange={setFormEnabled} className="data-[state=checked]:bg-accent-500" /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button className="bg-brand-600 hover:bg-brand-500 text-white" onClick={handleSave}>{editingSchedule ? 'Update' : 'Create'}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>
    </TooltipProvider>
  );
}