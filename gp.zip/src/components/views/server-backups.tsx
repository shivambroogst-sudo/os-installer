'use client';
import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus,
  Download,
  Trash2,
  RotateCcw,
  HardDrive,
  Clock,
  ShieldCheck,
  ShieldX,
  Database,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { listBackups, createBackup } from '@/lib/api';
import { useNavStore } from '@/lib/store';
import { formatBytes } from '@/lib/mock-data';
import { toast } from 'sonner';

// ============ Types ============
interface Backup {
  id: string;
  name: string;
  fileSize?: number;
  createdAt: string;
  isSuccessful?: boolean;
  [key: string]: any;
}

// ============ Component ============
export default function ServerBackups() {
  const { selectedServerId } = useNavStore();
  const [backups, setBackups] = useState<Backup[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [restoreDialogOpen, setRestoreDialogOpen] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<Backup | null>(null);

  const [autoBackup, setAutoBackup] = useState(true);
  const [backupFrequency, setBackupFrequency] = useState('6h');
  const [retentionCount, setRetentionCount] = useState('5');
  const [compressionEnabled, setCompressionEnabled] = useState(true);
  const [newBackupName, setNewBackupName] = useState('');
  const [createDialogOpen, setCreateDialogOpen] = useState(false);

  const fetchBackups = useCallback(async () => {
    if (!selectedServerId) { setLoading(false); return; }
    setLoading(true);
    try {
      const res = await listBackups(selectedServerId);
      if (res.success && Array.isArray(res.data)) {
        setBackups(res.data);
      } else {
        setBackups([]);
      }
    } catch {
      setBackups([]);
    } finally {
      setLoading(false);
    }
  }, [selectedServerId]);

  useEffect(() => { fetchBackups(); }, [fetchBackups]);

  const handleCreateBackup = async () => {
    if (!selectedServerId) return;
    setCreating(true);
    try {
      const name = newBackupName || `Manual Backup - ${new Date().toISOString().split('T')[0]}`;
      const res = await createBackup(selectedServerId, name);
      if (res.success) {
        toast.success('Backup created', { description: 'Your backup is being generated.' });
        setCreateDialogOpen(false);
        setNewBackupName('');
        fetchBackups();
      } else {
        toast.error(res.error || 'Failed to create backup');
      }
    } catch {
      toast.error('Failed to create backup');
    } finally {
      setCreating(false);
    }
  };

  const handleRestore = () => {
    if (!selectedBackup) return;
    setRestoreDialogOpen(false);
    toast.success('Restoring backup', { description: `${selectedBackup.name} is being restored.` });
    setSelectedBackup(null);
  };

  const handleDownload = (backup: Backup) => {
    toast.info('Downloading backup', { description: `${backup.name}` });
  };

  const handleDelete = async (id: string) => {
    toast.success('Backup deleted');
    setBackups((prev) => prev.filter((b) => b.id !== id));
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '—';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const totalSize = backups.reduce((acc, b) => acc + (b.fileSize || 0), 0);
  const storageUsed = +(totalSize / (1024 * 1024 * 1024)).toFixed(2);
  const storageTotal = 10;
  const storagePercent = Math.min(100, (storageUsed / storageTotal) * 100);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-brand-400 animate-spin" />
      </div>
    );
  }

  return (
    <TooltipProvider>
      <motion.div className="space-y-6" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: 'easeOut' }}>
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white">Backup Manager</h2>
            <p className="text-sm text-zinc-400 mt-1">{backups.length} backups · {storageUsed} GB used</p>
          </div>
          <Button className="bg-brand-600 hover:bg-brand-500 text-white" onClick={() => setCreateDialogOpen(true)}>
            <Plus className="w-4 h-4 mr-2" /> Create Backup
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Backup List */}
          <div className="lg:col-span-2">
            <motion.div className="glass-card overflow-hidden" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
              <div className="px-5 py-4 border-b border-zinc-800/50">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-md bg-brand-500/20"><Database className="w-4 h-4 text-brand-400" /></div>
                  <h3 className="text-sm font-semibold text-white">All Backups</h3>
                </div>
              </div>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-zinc-800 hover:bg-transparent">
                      <TableHead className="text-zinc-400 font-medium">Name</TableHead>
                      <TableHead className="text-zinc-400 font-medium hidden sm:table-cell">Size</TableHead>
                      <TableHead className="text-zinc-400 font-medium hidden md:table-cell">Date</TableHead>
                      <TableHead className="text-zinc-400 font-medium">Status</TableHead>
                      <TableHead className="text-zinc-400 font-medium text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <AnimatePresence>
                      {backups.map((backup, index) => (
                        <motion.tr key={backup.id} className="border-zinc-800 hover:bg-white/[0.02] transition-colors" initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 12 }} transition={{ delay: index * 0.04 }}>
                          <TableCell className="font-medium text-white py-3.5">{backup.name}</TableCell>
                          <TableCell className="text-zinc-300 font-mono text-sm hidden sm:table-cell">{backup.fileSize ? formatBytes(backup.fileSize) : '—'}</TableCell>
                          <TableCell className="text-zinc-400 text-sm hidden md:table-cell">{formatDate(backup.createdAt)}</TableCell>
                          <TableCell>
                            {backup.isSuccessful !== false ? (
                              <Badge className="bg-accent-500/20 text-accent-400 border-accent-500/30 hover:bg-accent-500/30"><ShieldCheck className="w-3 h-3 mr-1" /> Success</Badge>
                            ) : (
                              <Badge className="bg-red-500/20 text-red-400 border-red-500/30 hover:bg-red-500/30"><ShieldX className="w-3 h-3 mr-1" /> Failed</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center justify-end gap-1">
                              <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 text-zinc-400 hover:text-white hover:bg-white/5" onClick={() => { setSelectedBackup(backup); setRestoreDialogOpen(true); }} disabled={backup.isSuccessful === false}><RotateCcw className="w-3.5 h-3.5" /></Button></TooltipTrigger><TooltipContent>Restore</TooltipContent></Tooltip>
                              <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 text-zinc-400 hover:text-white hover:bg-white/5" onClick={() => handleDownload(backup)} disabled={backup.isSuccessful === false}><Download className="w-3.5 h-3.5" /></Button></TooltipTrigger><TooltipContent>Download</TooltipContent></Tooltip>
                              <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 text-red-400/70 hover:text-red-400 hover:bg-red-500/10" onClick={() => handleDelete(backup.id)}><Trash2 className="w-3.5 h-3.5" /></Button></TooltipTrigger><TooltipContent>Delete</TooltipContent></Tooltip>
                            </div>
                          </TableCell>
                        </motion.tr>
                      ))}
                    </AnimatePresence>
                  </TableBody>
                </Table>
              </div>
              {backups.length === 0 && (
                <div className="py-12 text-center"><Database className="w-10 h-10 text-zinc-600 mx-auto mb-3" /><p className="text-sm text-zinc-400">No backups yet</p></div>
              )}
            </motion.div>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            <motion.div className="glass-card p-5" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <div className="flex items-center gap-2 mb-4">
                <div className="p-1.5 rounded-md bg-emerald-500/20"><HardDrive className="w-4 h-4 text-emerald-400" /></div>
                <h3 className="text-sm font-semibold text-white">Storage Usage</h3>
              </div>
              <div className="space-y-3">
                <div className="flex items-end justify-between">
                  <span className="text-2xl font-bold text-white">{storageUsed} GB</span>
                  <span className="text-sm text-zinc-400">of {storageTotal} GB</span>
                </div>
                <Progress value={storagePercent} className="h-2 bg-white/5" />
                <p className="text-xs text-zinc-500">{(storageTotal - storageUsed).toFixed(2)} GB available</p>
              </div>
            </motion.div>

            <motion.div className="glass-card p-5" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
              <div className="flex items-center gap-2 mb-5">
                <div className="p-1.5 rounded-md bg-orange-500/20"><Clock className="w-4 h-4 text-orange-400" /></div>
                <h3 className="text-sm font-semibold text-white">Backup Settings</h3>
              </div>
              <div className="space-y-5">
                <div className="flex items-center justify-between"><Label className="text-zinc-300 text-sm">Auto-Backup</Label><Switch checked={autoBackup} onCheckedChange={setAutoBackup} className="data-[state=checked]:bg-brand-600" /></div>
                <Separator className="bg-zinc-800" />
                <div className="space-y-2"><Label className="text-zinc-300 text-sm">Frequency</Label><Select value={backupFrequency} onValueChange={setBackupFrequency}><SelectTrigger className="bg-white/5 border-zinc-700 text-white"><SelectValue /></SelectTrigger><SelectContent className="bg-zinc-900 border-zinc-800"><SelectItem value="1h">Every 1 hour</SelectItem><SelectItem value="3h">Every 3 hours</SelectItem><SelectItem value="6h">Every 6 hours</SelectItem><SelectItem value="12h">Every 12 hours</SelectItem><SelectItem value="1d">Every day</SelectItem><SelectItem value="1w">Every week</SelectItem></SelectContent></Select></div>
                <div className="space-y-2"><Label className="text-zinc-300 text-sm">Retention Count</Label><Input type="number" value={retentionCount} onChange={(e) => setRetentionCount(e.target.value)} className="bg-white/5 border-zinc-700 text-white" min={1} max={50} /><p className="text-xs text-zinc-500">Maximum backups to keep</p></div>
                <Separator className="bg-zinc-800" />
                <div className="flex items-center justify-between"><div><Label className="text-zinc-300 text-sm">Compression</Label><p className="text-xs text-zinc-500 mt-0.5">Use gzip compression</p></div><Switch checked={compressionEnabled} onCheckedChange={setCompressionEnabled} className="data-[state=checked]:bg-brand-600" /></div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Restore Confirmation Dialog */}
        <Dialog open={restoreDialogOpen} onOpenChange={setRestoreDialogOpen}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-md">
            <DialogHeader><DialogTitle>Restore Backup</DialogTitle><DialogDescription className="text-zinc-400">This will replace your current server data with the backup.</DialogDescription></DialogHeader>
            {selectedBackup && (
              <div className="py-4">
                <div className="rounded-lg border border-zinc-800 bg-white/[0.02] p-4 space-y-2">
                  <div className="flex justify-between"><span className="text-sm text-zinc-400">Backup</span><span className="text-sm text-white font-medium">{selectedBackup.name}</span></div>
                  {selectedBackup.fileSize && <div className="flex justify-between"><span className="text-sm text-zinc-400">Size</span><span className="text-sm text-white font-mono">{formatBytes(selectedBackup.fileSize)}</span></div>}
                  <div className="flex justify-between"><span className="text-sm text-zinc-400">Created</span><span className="text-sm text-white">{formatDate(selectedBackup.createdAt)}</span></div>
                </div>
                <div className="mt-4 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20"><p className="text-sm text-yellow-400">⚠️ The server will be stopped and restarted during restore. Current data will be overwritten.</p></div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white" onClick={() => setRestoreDialogOpen(false)}>Cancel</Button>
              <Button className="bg-yellow-600 hover:bg-yellow-500 text-white" onClick={handleRestore}>Restore Backup</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Create Backup Dialog */}
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-md">
            <DialogHeader><DialogTitle>Create Backup</DialogTitle></DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2"><Label className="text-zinc-300 text-sm">Backup Name</Label><Input value={newBackupName} onChange={(e) => setNewBackupName(e.target.value)} placeholder="Auto-generated if empty" className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600" /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white" onClick={() => { setCreateDialogOpen(false); setNewBackupName(''); }}>Cancel</Button>
              <Button className="bg-brand-600 hover:bg-brand-500 text-white" onClick={handleCreateBackup} disabled={creating}>
                {creating && <Loader2 className="w-4 h-4 mr-2 animate-spin" />} Create Backup
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>
    </TooltipProvider>
  );
}