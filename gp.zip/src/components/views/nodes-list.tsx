'use client';
import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { useNavStore } from '@/lib/store';
import {
  HardDrive,
  Server,
  Cpu,
  MemoryStick,
  Globe,
  Activity,
  Zap,
  Plus,
  Loader2,
  Trash2,
  RefreshCw,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { getNodeInfo, listNodes, createNode, deleteNode, syncNode, type NodeInfo } from '@/lib/api';
import {
  getStatusDotClass,
  getStatusLabel,
  formatMemory,
  formatBytes,
  getResourceBarClass,
} from '@/lib/mock-data';

// ─── Animation Variants ───
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.06, delayChildren: 0.05 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.97 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { type: 'spring', stiffness: 260, damping: 24, mass: 0.8 },
  },
};

const cardHover = {
  rest: { y: 0, boxShadow: '0 0 0 0 rgba(92,124,250,0)' },
  hover: {
    y: -3,
    boxShadow: '0 8px 32px rgba(92,124,250,0.15), 0 0 0 1px rgba(92,124,250,0.2)',
    transition: { type: 'spring', stiffness: 400, damping: 25 },
  },
};

// ─── Types ───
interface DbNode {
  id: string;
  name: string;
  fqdn: string;
  daemonPort: number;
  daemonToken?: string;
  totalMemory: number;
  totalCpu: number;
  totalDisk: number;
  status?: string;
}

// ─── Node Card Component ───
function NodeCard({ node, onDelete, onSync }: { node: NodeInfo; onDelete?: () => void; onSync?: () => void }) {
  const isOnline = true;
  const cpuPercent = node.cpuCount > 0 ? Math.min(100, (node.serverCount / node.cpuCount) * 25) : 0;
  const usedMemory = node.totalMemory - node.freeMemory;
  const memPercent = node.totalMemory > 0 ? (usedMemory / node.totalMemory) * 100 : 0;
  const diskPercent = node.totalDisk > 0 ? (node.usedDisk / node.totalDisk) * 100 : 0;

  return (
    <motion.div variants={itemVariants} whileHover="hover" initial="rest" animate="rest">
      <motion.div
        variants={cardHover}
        className="glass-card cursor-pointer h-full !p-0 overflow-hidden group"
      >
        {/* Header */}
        <div className="px-5 pt-5 pb-3">
          <div className="flex items-start justify-between mb-2">
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  isOnline ? 'bg-accent-500/15' : 'bg-white/5'
                }`}
              >
                <HardDrive
                  className={`w-4 h-4 ${isOnline ? 'text-accent-400' : 'text-muted-foreground/50'}`}
                />
              </div>
              <div className="min-w-0">
                <h3 className="text-sm font-semibold text-foreground truncate">{node.hostname}</h3>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="status-dot status-dot-online" />
                  <span className="text-[11px] text-muted-foreground">Online</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <Badge
                variant="outline"
                className="text-[10px] px-2 py-0 h-5 border-brand-500/20 text-brand-400 bg-brand-500/5"
              >
                v{node.daemonVersion}
              </Badge>
            </div>
          </div>

          {/* Platform Info */}
          <div className="flex items-center gap-1.5 mb-1">
            <Globe className="w-3 h-3 text-muted-foreground/50" />
            <span className="text-[11px] text-muted-foreground font-mono truncate">{node.platform} ({node.arch})</span>
          </div>

          {/* CPU Model */}
          <div className="flex items-center gap-1.5 mb-1">
            <Cpu className="w-3 h-3 text-muted-foreground/50" />
            <span className="text-[11px] text-muted-foreground truncate">{node.cpuModel}</span>
          </div>

          {/* Server Count */}
          <div className="flex items-center gap-1.5 mb-4">
            <Server className="w-3 h-3 text-muted-foreground/50" />
            <span className="text-[11px] text-muted-foreground">
              <span className="text-foreground font-medium">{node.serverCount}</span> servers
              <span className="text-muted-foreground/50 mx-1">·</span>
              <span className="text-accent-400 font-medium">{node.runningServers}</span> running
            </span>
          </div>
        </div>

        {/* Resource Bars */}
        <div className="px-5 space-y-2.5 pb-4">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <Cpu className="w-3 h-3 text-muted-foreground/50" />
                <span className="text-[11px] text-muted-foreground">CPU Cores</span>
              </div>
              <span className="text-[11px] text-muted-foreground font-mono">
                {node.cpuCount} cores
              </span>
            </div>
            <div className="resource-bar">
              <div
                className={`resource-bar-fill ${getResourceBarClass(cpuPercent)}`}
                style={{ width: `${cpuPercent}%` }}
              />
            </div>
          </div>
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <MemoryStick className="w-3 h-3 text-muted-foreground/50" />
                <span className="text-[11px] text-muted-foreground">Memory</span>
              </div>
              <span className="text-[11px] text-muted-foreground font-mono">
                {formatMemory(usedMemory)} / {formatMemory(node.totalMemory)}
              </span>
            </div>
            <div className="resource-bar">
              <div
                className={`resource-bar-fill ${getResourceBarClass(memPercent)}`}
                style={{ width: `${memPercent}%` }}
              />
            </div>
          </div>
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <HardDrive className="w-3 h-3 text-muted-foreground/50" />
                <span className="text-[11px] text-muted-foreground">Disk</span>
              </div>
              <span className="text-[11px] text-muted-foreground font-mono">
                {formatBytes(node.usedDisk)} / {formatBytes(node.totalDisk)}
              </span>
            </div>
            <div className="resource-bar">
              <div
                className={`resource-bar-fill ${getResourceBarClass(diskPercent)}`}
                style={{ width: `${diskPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="px-5 pb-4 pt-1 border-t border-white/[0.04] flex items-center gap-1">
          {onSync && (
            <Button variant="ghost" size="sm" className="h-7 px-2 text-[11px] gap-1 text-brand-400/80 hover:text-brand-300 hover:bg-brand-500/10" onClick={(e) => { e.stopPropagation(); onSync(); }}>
              <RefreshCw className="w-3 h-3" /> Sync
            </Button>
          )}
          {onDelete && (
            <Button variant="ghost" size="sm" className="h-7 px-2 text-[11px] gap-1 text-red-400/50 hover:text-red-300 hover:bg-red-500/10 ml-auto" onClick={(e) => { e.stopPropagation(); onDelete(); }}>
              <Trash2 className="w-3 h-3" />
            </Button>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── Cluster Stats ───
function ClusterStats({ node }: { node: NodeInfo | null }) {
  const usedMemory = node ? node.totalMemory - node.freeMemory : 0;

  const stats = [
    { label: 'Node Status', value: node ? 'Online' : '—', sub: node ? node.daemonVersion : 'No data', icon: HardDrive, iconBg: 'bg-brand-500/15', iconColor: 'text-brand-400' },
    { label: 'CPU', value: node ? `${node.cpuCount} cores` : '—', sub: node ? node.cpuModel : 'No data', icon: Cpu, iconBg: 'bg-purple-500/15', iconColor: 'text-purple-400' },
    { label: 'Total Memory', value: node ? formatMemory(node.totalMemory) : '—', sub: node ? `${formatMemory(usedMemory)} used` : 'No data', icon: MemoryStick, iconBg: 'bg-accent-500/15', iconColor: 'text-accent-400' },
    { label: 'Total Disk', value: node ? formatBytes(node.totalDisk) : '—', sub: node ? `${formatBytes(node.usedDisk)} used` : 'No data', icon: Zap, iconBg: 'bg-amber-500/15', iconColor: 'text-amber-400' },
    { label: 'Servers', value: node ? `${node.runningServers}/${node.serverCount}` : '—', sub: node ? `${node.runningServers} running` : 'No data', icon: Server, iconBg: 'bg-pink-500/15', iconColor: 'text-pink-400' },
  ];

  return (
    <motion.div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3" variants={containerVariants}>
      {stats.map((stat) => (
        <motion.div key={stat.label} variants={itemVariants}>
          <Card className="glass-card !p-0">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${stat.iconBg}`}>
                  <stat.icon className={`w-4 h-4 ${stat.iconColor}`} />
                </div>
              </div>
              <p className="text-lg font-bold text-foreground tracking-tight">{stat.value}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">{stat.label}</p>
              <p className="text-[10px] text-muted-foreground/50 mt-1">{stat.sub}</p>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </motion.div>
  );
}

// ─── Main Nodes List ───
export default function NodesList() {
  const [nodeInfo, setNodeInfo] = useState<NodeInfo | null>(null);
  const [dbNodes, setDbNodes] = useState<DbNode[]>([]);
  const [loading, setLoading] = useState(true);
  const [addOpen, setAddOpen] = useState(false);
  const [creating, setCreating] = useState(false);

  // Add node form
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newFqdn, setNewFqdn] = useState('');
  const [newPort, setNewPort] = useState(8080);
  const [newToken, setNewToken] = useState('');
  const [newCpu, setNewCpu] = useState(800);
  const [newMemory, setNewMemory] = useState(16384);
  const [newDisk, setNewDisk] = useState(51200);
  const [newPublic, setNewPublic] = useState(true);

  const fetchData = useCallback(async () => {
    try {
      const [nodeRes, dbRes] = await Promise.all([
        getNodeInfo(),
        listNodes(),
      ]);
      if (nodeRes.success && nodeRes.data) {
        setNodeInfo(nodeRes.data);
      }
      if (dbRes.success && Array.isArray(dbRes.data)) {
        setDbNodes(dbRes.data);
      }
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const handleAdd = async () => {
    if (!newName.trim()) {
      toast.error('Node name is required');
      return;
    }
    if (!newFqdn.trim()) {
      toast.error('FQDN is required');
      return;
    }
    setCreating(true);
    try {
      const res = await createNode({
        name: newName.trim(),
        description: newDesc,
        fqdn: newFqdn.trim(),
        daemonPort: newPort,
        daemonToken: newToken || undefined,
        totalCpu: newCpu,
        totalMemory: newMemory,
        totalDisk: newDisk,
        isPublic: newPublic,
      });
      if (res.success) {
        toast.success(`Node "${newName}" created successfully`);
        setAddOpen(false);
        setNewName(''); setNewDesc(''); setNewFqdn(''); setNewPort(8080); setNewToken('');
        setNewCpu(800); setNewMemory(16384); setNewDisk(51200); setNewPublic(true);
        fetchData();
      } else {
        toast.error(res.error || 'Failed to create node');
      }
    } catch {
      toast.error('Failed to create node');
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteNode = async (id: string, name: string) => {
    try {
      const res = await deleteNode(id);
      if (res.success) {
        toast.success(`Node "${name}" deleted`);
        fetchData();
      } else {
        toast.error(res.error || 'Failed to delete node');
      }
    } catch {
      toast.error('Failed to delete node');
    }
  };

  const handleSyncNode = async (id: string) => {
    try {
      const res = await syncNode(id);
      if (res.success) {
        toast.success('Node synced');
        fetchData();
      } else {
        toast.error(res.error || 'Failed to sync node');
      }
    } catch {
      toast.error('Failed to sync node');
    }
  };

  return (
    <motion.div className="space-y-6" variants={containerVariants} initial="hidden" animate="visible">
      {/* Page Header */}
      <motion.div variants={itemVariants} className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Nodes</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Manage your game server infrastructure
          </p>
        </div>
        <Button
          onClick={() => setAddOpen(true)}
          className="gap-2 gradient-brand text-white border-0 shadow-lg shadow-brand-600/20 hover:shadow-brand-600/30"
        >
          <Plus className="w-4 h-4" />
          Add Node
        </Button>
      </motion.div>

      {/* Cluster Stats */}
      <ClusterStats node={nodeInfo} />

      {/* Nodes Grid */}
      <motion.div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4" variants={containerVariants}>
        {loading ? (
          <div className="col-span-full flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-brand-400 animate-spin" />
          </div>
        ) : nodeInfo ? (
          <NodeCard
            node={nodeInfo}
            onSync={() => handleSyncNode('local')}
          />
        ) : dbNodes.length > 0 ? (
          dbNodes.map((n) => (
            <NodeCard
              key={n.id}
              node={{
                uuid: n.id,
                hostname: n.name,
                platform: 'Linux',
                arch: 'x64',
                totalMemory: n.totalMemory,
                freeMemory: n.totalMemory,
                cpuCount: Math.floor(n.totalCpu / 100),
                cpuModel: 'Unknown',
                daemonVersion: '1.0.0',
                totalDisk: n.totalDisk,
                usedDisk: 0,
                serverCount: 0,
                runningServers: 0,
              }}
              onDelete={() => handleDeleteNode(n.id, n.name)}
              onSync={() => handleSyncNode(n.id)}
            />
          ))
        ) : (
          <div className="col-span-full flex flex-col items-center justify-center py-20">
            <div className="w-16 h-16 rounded-2xl bg-white/[0.03] flex items-center justify-center mb-4">
              <Activity className="w-7 h-7 text-muted-foreground/30" />
            </div>
            <h3 className="text-base font-semibold text-foreground mb-1">No node connected</h3>
            <p className="text-sm text-muted-foreground text-center max-w-xs">
              Unable to connect to the daemon. Make sure the daemon is running and reachable.
            </p>
          </div>
        )}
      </motion.div>

      {/* Add Node Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="glass-card !rounded-2xl max-w-lg border-white/[0.08] bg-[#0c0c1a]/95 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold text-foreground">Add New Node</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Node Name</Label>
              <Input placeholder="US-West-2" value={newName} onChange={(e) => setNewName(e.target.value)} className="glass-input h-10 text-sm bg-transparent" />
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Description</Label>
              <Textarea placeholder="Optional node description" value={newDesc} onChange={(e) => setNewDesc(e.target.value)} className="glass-input min-h-[60px] text-sm bg-transparent resize-none" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">FQDN</Label>
                <Input placeholder="node.example.com" value={newFqdn} onChange={(e) => setNewFqdn(e.target.value)} className="glass-input h-10 text-sm bg-transparent font-mono" />
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Daemon Port</Label>
                <Input type="number" value={newPort} onChange={(e) => setNewPort(Number(e.target.value))} min={1024} max={65535} className="glass-input h-10 text-sm bg-transparent" />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Daemon Token</Label>
              <Input placeholder="ogultra-daemon-secret-token" value={newToken} onChange={(e) => setNewToken(e.target.value)} className="glass-input h-10 text-sm bg-transparent font-mono" />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">CPU Cores (%)</Label>
                <Input type="number" value={newCpu} onChange={(e) => setNewCpu(Number(e.target.value))} min={100} max={6400} className="glass-input h-10 text-sm bg-transparent" />
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Memory (MB)</Label>
                <Input type="number" value={newMemory} onChange={(e) => setNewMemory(Number(e.target.value))} min={1024} className="glass-input h-10 text-sm bg-transparent" />
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Disk (MB)</Label>
                <Input type="number" value={newDisk} onChange={(e) => setNewDisk(Number(e.target.value))} min={1024} className="glass-input h-10 text-sm bg-transparent" />
              </div>
            </div>
            <div className="flex items-center justify-between py-2">
              <div>
                <Label className="text-sm text-foreground">Public Node</Label>
                <p className="text-[11px] text-muted-foreground mt-0.5">Allow users to deploy servers on this node</p>
              </div>
              <Switch checked={newPublic} onCheckedChange={setNewPublic} />
            </div>
          </div>
          <DialogFooter className="gap-2 pt-2">
            <Button variant="ghost" onClick={() => setAddOpen(false)} className="text-muted-foreground hover:text-foreground" disabled={creating}>Cancel</Button>
            <Button onClick={handleAdd} className="gradient-brand text-white border-0 shadow-lg shadow-brand-600/20" disabled={creating}>
              {creating && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Add Node
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}