'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Plus,
  Database,
  Eye,
  EyeOff,
  RefreshCw,
  Trash2,
  Copy,
  AlertCircle,
  ShieldCheck,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { useNavStore } from '@/lib/store';
import { toast } from 'sonner';

// ============ Types ============
interface DatabaseEntry {
  id: string;
  name: string;
  username: string;
  host: string;
  port: number;
  password: string;
  allowedConnections: string;
}

// ============ Component ============
export default function ServerDatabases() {
  const { selectedServerId } = useNavStore();
  const [databases, setDatabases] = useState<DatabaseEntry[]>([]);
  const [showPassword, setShowPassword] = useState<Record<string, boolean>>({});

  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deletingDb, setDeletingDb] = useState<DatabaseEntry | null>(null);

  const [formDbName, setFormDbName] = useState('');
  const [formUsername, setFormUsername] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formAllowedConn, setFormAllowedConn] = useState('%');

  const generatePassword = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let pass = '';
    for (let i = 0; i < 24; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setFormPassword(pass);
    toast.success('Password generated');
  };

  const handleCreate = () => {
    if (!formDbName.trim()) { toast.error('Database name is required'); return; }
    if (!formUsername.trim()) { toast.error('Username is required'); return; }
    if (!formPassword.trim()) { toast.error('Password is required'); return; }

    const newDb: DatabaseEntry = {
      id: `db_${Date.now()}`,
      name: formDbName,
      username: formUsername,
      host: 'localhost',
      port: 3306,
      password: formPassword,
      allowedConnections: formAllowedConn || '%',
    };

    setDatabases((prev) => [...prev, newDb]);
    setCreateDialogOpen(false);
    setFormDbName('');
    setFormUsername('');
    setFormPassword('');
    setFormAllowedConn('%');
    toast.success('Database created', { description: `"${formDbName}" has been recorded. Note: actual DB provisioning requires a database host configuration.`, duration: 5000 });
  };

  const handleResetPassword = (id: string) => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let pass = '';
    for (let i = 0; i < 24; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setDatabases((prev) => prev.map((db) => (db.id === id ? { ...db, password: pass } : db)));
    toast.success('Password reset', { description: 'A new password has been generated.' });
  };

  const handleDeleteDb = () => {
    if (!deletingDb) return;
    setDatabases((prev) => prev.filter((db) => db.id !== deletingDb.id));
    setDeleteDialogOpen(false);
    setDeletingDb(null);
    toast.success('Database deleted', { description: `"${deletingDb.name}" has been removed.` });
  };

  const toggleShowPassword = (id: string) => {
    setShowPassword((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopyField = (text: string, label: string) => {
    navigator.clipboard?.writeText(text);
    toast.success(`${label} copied`);
  };

  return (
    <TooltipProvider>
      <motion.div className="space-y-6" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: 'easeOut' }}>
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white">Databases</h2>
            <p className="text-sm text-zinc-400 mt-1">Manage MySQL databases for server {selectedServerId || ''}</p>
          </div>
          <Button className="bg-brand-600 hover:bg-brand-500 text-white" onClick={() => setCreateDialogOpen(true)}>
            <Plus className="w-4 h-4 mr-2" /> Create Database
          </Button>
        </div>

        {/* Empty State */}
        {databases.length === 0 && !createDialogOpen && (
          <motion.div className="glass-card p-16 flex flex-col items-center justify-center text-center" initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }}>
            <div className="p-5 rounded-2xl bg-white/5 mb-5"><Database className="w-12 h-12 text-zinc-600" /></div>
            <h3 className="text-lg font-semibold text-white mb-2">No databases configured</h3>
            <p className="text-sm text-zinc-400 max-w-md mb-6">Create a MySQL database to store plugin data, player stats, or any other persistent data for your server.</p>
            <Button variant="outline" className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white" onClick={() => setCreateDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" /> Create Your First Database
            </Button>
          </motion.div>
        )}

        {/* Database Table */}
        {databases.length > 0 && (
          <motion.div className="glass-card overflow-hidden" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
            <div className="px-5 py-4 border-b border-zinc-800/50">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-md bg-brand-500/20"><Database className="w-4 h-4 text-brand-400" /></div>
                <h3 className="text-sm font-semibold text-white">Your Databases</h3>
                <Badge variant="outline" className="border-zinc-700 text-zinc-400 text-xs">{databases.length}</Badge>
              </div>
            </div>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-zinc-800 hover:bg-transparent">
                    <TableHead className="text-zinc-400 font-medium">Database</TableHead>
                    <TableHead className="text-zinc-400 font-medium">Username</TableHead>
                    <TableHead className="text-zinc-400 font-medium hidden sm:table-cell">Host</TableHead>
                    <TableHead className="text-zinc-400 font-medium hidden md:table-cell">Connection From</TableHead>
                    <TableHead className="text-zinc-400 font-medium text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {databases.map((db) => (
                    <TableRow key={db.id} className="border-zinc-800 hover:bg-white/[0.02] transition-colors">
                      <TableCell><div className="flex items-center gap-2"><span className="text-sm font-medium text-white font-mono">{db.name}</span></div></TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm text-zinc-300 font-mono">{db.username}</span>
                          <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-6 w-6 text-zinc-500 hover:text-zinc-300" onClick={() => toggleShowPassword(db.id)}>{showPassword[db.id] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}</Button></TooltipTrigger><TooltipContent>{showPassword[db.id] ? 'Hide password' : 'Show password'}</TooltipContent></Tooltip>
                        </div>
                        {showPassword[db.id] && (
                          <div className="flex items-center gap-1.5 mt-1">
                            <code className="text-xs font-mono text-zinc-400 bg-white/5 px-1.5 py-0.5 rounded">{db.password}</code>
                            <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-5 w-5 text-zinc-500 hover:text-zinc-300" onClick={() => handleCopyField(db.password, 'Password')}><Copy className="w-2.5 h-2.5" /></Button></TooltipTrigger><TooltipContent>Copy</TooltipContent></Tooltip>
                          </div>
                        )}
                      </TableCell>
                      <TableCell className="hidden sm:table-cell">
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm text-zinc-300 font-mono">{db.host}:{db.port}</span>
                          <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-6 w-6 text-zinc-500 hover:text-zinc-300" onClick={() => handleCopyField(`${db.host}:${db.port}`, 'Host')}><Copy className="w-3 h-3" /></Button></TooltipTrigger><TooltipContent>Copy</TooltipContent></Tooltip>
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell"><Badge variant="outline" className="border-zinc-700 text-zinc-400 text-xs font-mono">{db.allowedConnections}</Badge></TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 text-zinc-400 hover:text-white hover:bg-white/5" onClick={() => handleResetPassword(db.id)}><RefreshCw className="w-3.5 h-3.5" /></Button></TooltipTrigger><TooltipContent>Reset Password</TooltipContent></Tooltip>
                          <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 text-red-400/70 hover:text-red-400 hover:bg-red-500/10" onClick={() => { setDeletingDb(db); setDeleteDialogOpen(true); }}><Trash2 className="w-3.5 h-3.5" /></Button></TooltipTrigger><TooltipContent>Delete</TooltipContent></Tooltip>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </motion.div>
        )}

        {/* Connection Info Notice */}
        <motion.div className="glass-card p-4" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <div className="flex items-start gap-3">
            <div className="p-1.5 rounded-md bg-yellow-500/20 shrink-0 mt-0.5"><AlertCircle className="w-4 h-4 text-yellow-400" /></div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold text-white">Database Limitations</h3>
              <ul className="text-xs text-zinc-400 mt-2 space-y-1 list-disc list-inside">
                <li>Each server is limited to <span className="text-white font-medium">5 databases</span> and <span className="text-white font-medium">5 database users</span>.</li>
                <li>Database records are stored locally in the panel. Actual MySQL provisioning requires a database host.</li>
                <li>Backups do not include database contents. Use <code className="text-brand-400 bg-white/5 px-1 rounded">mysqldump</code> for database backups.</li>
              </ul>
            </div>
          </div>
        </motion.div>

        {/* Connection Info Card */}
        {databases.length > 0 && (
          <motion.div className="glass-card p-5" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <div className="flex items-center gap-2 mb-4">
              <div className="p-1.5 rounded-md bg-emerald-500/20"><ShieldCheck className="w-4 h-4 text-emerald-400" /></div>
              <h3 className="text-sm font-semibold text-white">Connection Info</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="rounded-lg bg-white/[0.03] border border-zinc-800 p-3">
                <span className="text-xs text-zinc-500 uppercase tracking-wider block mb-1">Host</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-mono text-white">localhost</span>
                  <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-6 w-6 text-zinc-500 hover:text-zinc-300" onClick={() => handleCopyField('localhost', 'Host')}><Copy className="w-3 h-3" /></Button></TooltipTrigger><TooltipContent>Copy</TooltipContent></Tooltip>
                </div>
              </div>
              <div className="rounded-lg bg-white/[0.03] border border-zinc-800 p-3">
                <span className="text-xs text-zinc-500 uppercase tracking-wider block mb-1">Port</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-mono text-white">3306</span>
                  <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-6 w-6 text-zinc-500 hover:text-zinc-300" onClick={() => handleCopyField('3306', 'Port')}><Copy className="w-3 h-3" /></Button></TooltipTrigger><TooltipContent>Copy</TooltipContent></Tooltip>
                </div>
              </div>
              <div className="rounded-lg bg-white/[0.03] border border-zinc-800 p-3">
                <span className="text-xs text-zinc-500 uppercase tracking-wider block mb-1">Available DBs</span>
                <div className="flex items-center gap-2 flex-wrap">
                  {databases.map((db) => (
                    <Tooltip key={db.id}><TooltipTrigger asChild><button className="text-xs font-mono text-brand-400 bg-brand-500/10 px-2 py-1 rounded hover:bg-brand-500/20 transition-colors" onClick={() => handleCopyField(db.name, 'Database name')}>{db.name}</button></TooltipTrigger><TooltipContent>Click to copy</TooltipContent></Tooltip>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Create Database Dialog */}
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-md">
            <DialogHeader><DialogTitle>Create Database</DialogTitle></DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2"><Label className="text-zinc-300 text-sm">Database Name</Label><Input value={formDbName} onChange={(e) => setFormDbName(e.target.value)} placeholder="s3_main" className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600 font-mono" /></div>
              <div className="space-y-2"><Label className="text-zinc-300 text-sm">Username</Label><Input value={formUsername} onChange={(e) => setFormUsername(e.target.value)} placeholder="s3_user" className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600 font-mono" /></div>
              <div className="space-y-2">
                <Label className="text-zinc-300 text-sm flex items-center justify-between"><span>Password</span><Button type="button" variant="ghost" size="sm" className="h-7 text-xs text-brand-400 hover:text-brand-300 hover:bg-brand-500/10 px-2" onClick={generatePassword}><RefreshCw className="w-3 h-3 mr-1" /> Generate</Button></Label>
                <Input type="password" value={formPassword} onChange={(e) => setFormPassword(e.target.value)} placeholder="Enter or generate a password" className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600 font-mono" />
              </div>
              <div className="space-y-2"><Label className="text-zinc-300 text-sm">Allowed Connections</Label><Input value={formAllowedConn} onChange={(e) => setFormAllowedConn(e.target.value)} placeholder="%" className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600 font-mono" /><p className="text-xs text-zinc-500">Use <code className="text-zinc-300">%</code> for any connection, or specify an IP/CIDR.</p></div>
            </div>
            <DialogFooter>
              <Button variant="outline" className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white" onClick={() => setCreateDialogOpen(false)}>Cancel</Button>
              <Button className="bg-brand-600 hover:bg-brand-500 text-white" onClick={handleCreate}>Create Database</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Database Dialog */}
        <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-md">
            <DialogHeader><DialogTitle className="text-red-400">Delete Database</DialogTitle><DialogDescription className="text-zinc-400">This will permanently delete the database record and all its data.</DialogDescription></DialogHeader>
            {deletingDb && (
              <div className="py-4">
                <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20"><p className="text-sm text-red-400">⚠️ You are about to delete <code className="font-mono font-bold">{deletingDb.name}</code>. All data will be permanently lost.</p></div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white" onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
              <Button className="bg-red-600 hover:bg-red-500 text-white" onClick={handleDeleteDb}>Delete Database</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>
    </TooltipProvider>
  );
}