'use client';
import { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  Plus,
  Settings,
  RefreshCw,
  Trash2,
  Download,
  Puzzle,
  Filter,
  Upload,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { listFiles, deleteFile } from '@/lib/api';
import { useNavStore } from '@/lib/store';
import { formatBytes, formatMemory } from '@/lib/mock-data';
import { toast } from 'sonner';

// ============ Types ============
interface PluginEntry {
  name: string;
  size: number;
  modified: string;
}

// ============ Component ============
export default function ServerPlugins() {
  const { selectedServerId } = useNavStore();
  const [plugins, setPlugins] = useState<PluginEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showEnabledOnly, setShowEnabledOnly] = useState(false);
  const [installDialogOpen, setInstallDialogOpen] = useState(false);
  const [installSearch, setInstallSearch] = useState('');

  const fetchPlugins = useCallback(async () => {
    if (!selectedServerId) { setLoading(false); return; }
    setLoading(true);
    try {
      const res = await listFiles(selectedServerId, 'plugins');
      if (res.success && res.data) {
        const jars = res.data
          .filter((f: any) => f.type === 'file' && f.name.endsWith('.jar'))
          .map((f: any) => ({ name: f.name, size: f.size, modified: f.modified }));
        setPlugins(jars);
      } else {
        setPlugins([]);
      }
    } catch {
      setPlugins([]);
    } finally {
      setLoading(false);
    }
  }, [selectedServerId]);

  useEffect(() => { fetchPlugins(); }, [fetchPlugins]);

  const filteredPlugins = useMemo(() => {
    let result = plugins;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter((p) => p.name.toLowerCase().includes(q));
    }
    return result;
  }, [plugins, searchQuery]);

  const handleReload = (name: string) => {
    toast.success(`Reloading ${name}`, { description: 'Plugin reload command has been sent.' });
  };

  const handleUninstall = async (name: string) => {
    if (!selectedServerId) return;
    try {
      const res = await deleteFile(selectedServerId, `plugins/${name}`);
      if (res.success) {
        toast.success(`${name} uninstalled`);
        fetchPlugins();
      } else {
        toast.error(res.error || 'Failed to delete plugin');
      }
    } catch {
      toast.error('Failed to delete plugin');
    }
  };

  const handleUpload = () => {
    toast.info('File upload coming soon', { description: 'Plugin upload will be available in a future update.' });
  };

  const handleInstallPlugin = () => {
    toast.info('Plugin marketplace coming soon', { description: 'Direct plugin installation from SpigotMC/Modrinth will be available soon.' });
    setInstallDialogOpen(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-brand-400 animate-spin" />
      </div>
    );
  }

  return (
    <TooltipProvider>
      <motion.div className="space-y-6" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: 'easeOut' }}>
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white">Plugin Manager</h2>
            <p className="text-sm text-zinc-400 mt-1">{plugins.length} plugins in plugins/ directory</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white" onClick={handleUpload}>
              <Upload className="w-4 h-4 mr-2" /> Upload
            </Button>
            <Button className="bg-brand-600 hover:bg-brand-500 text-white" onClick={() => setInstallDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" /> Install Plugin
            </Button>
          </div>
        </div>

        {/* Search & Filter Bar */}
        <motion.div className="glass-card p-4" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
              <Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search plugins..." className="pl-9 bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600" />
            </div>
          </div>
        </motion.div>

        {/* Plugin Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          <AnimatePresence mode="popLayout">
            {filteredPlugins.map((plugin, index) => (
              <motion.div key={plugin.name} className="glass-card p-5 flex flex-col" initial={{ opacity: 0, y: 12, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, scale: 0.95, y: -8 }} transition={{ delay: index * 0.04, duration: 0.25 }} layout>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="p-2 rounded-lg bg-brand-500/20 shrink-0"><Puzzle className="w-4 h-4 text-brand-400" /></div>
                    <div className="min-w-0">
                      <h3 className="text-sm font-semibold text-white truncate">{plugin.name.replace('.jar', '')}</h3>
                      <Badge variant="outline" className="border-brand-500/30 text-brand-400 text-xs mt-0.5">{plugin.name}</Badge>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 mb-4 text-xs text-zinc-500">
                  <div className="flex items-center gap-1.5">
                    <Download className="w-3 h-3" />
                    <span>{formatBytes(plugin.size)}</span>
                  </div>
                  <span className="text-zinc-600">·</span>
                  <span>{plugin.modified}</span>
                </div>

                <Separator className="bg-zinc-800 mb-4" />

                <div className="flex items-center gap-2 mt-auto">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 text-zinc-400 hover:text-white hover:bg-white/5 flex-1" onClick={() => handleReload(plugin.name)}>
                        <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Reload
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Reload plugin</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 text-red-400/70 hover:text-red-400 hover:bg-red-500/10" onClick={() => handleUninstall(plugin.name)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Delete plugin file</TooltipContent>
                  </Tooltip>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredPlugins.length === 0 && (
          <motion.div className="glass-card p-12 flex flex-col items-center justify-center text-center" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="p-4 rounded-2xl bg-white/5 mb-4"><Puzzle className="w-10 h-10 text-zinc-600" /></div>
            <h3 className="text-lg font-semibold text-white mb-2">No plugins found</h3>
            <p className="text-sm text-zinc-400 max-w-sm">
              {searchQuery ? `No plugins match "${searchQuery}".` : 'No .jar files found in the plugins/ directory.'}
            </p>
          </motion.div>
        )}

        {/* Install Plugin Dialog */}
        <Dialog open={installDialogOpen} onOpenChange={setInstallDialogOpen}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-md">
            <DialogHeader><DialogTitle>Install Plugin</DialogTitle></DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm text-zinc-300">Plugin Name</label>
                <Input value={installSearch} onChange={(e) => setInstallSearch(e.target.value)} placeholder="e.g. EssentialsX" className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600" onKeyDown={(e) => e.key === 'Enter' && handleInstallPlugin()} />
              </div>
              <p className="text-xs text-zinc-500">Enter the plugin name or slug from SpigotMC / Modrinth / Hangar.</p>
            </div>
            <DialogFooter>
              <Button variant="outline" className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white" onClick={() => setInstallDialogOpen(false)}>Cancel</Button>
              <Button className="bg-brand-600 hover:bg-brand-500 text-white" onClick={handleInstallPlugin}>Install</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>
    </TooltipProvider>
  );
}