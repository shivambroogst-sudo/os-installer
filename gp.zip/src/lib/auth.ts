import { db } from './db';
import { headers } from 'next/headers';

export async function getAuthUser() {
  try {
    const headersList = await headers();
    const authHeader = headersList.get('authorization');

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return null;
    }

    const token = authHeader.replace('Bearer ', '');

    if (!token) {
      return null;
    }

    // Look up user by API token
    const apiToken = await db.apiToken.findUnique({
      where: { token },
      include: { user: true },
    });

    if (apiToken && apiToken.user && apiToken.user.isActive) {
      // Check if token is expired
      if (apiToken.expiresAt && apiToken.expiresAt < new Date()) {
        return null;
      }

      // Update last used
      await db.apiToken.update({
        where: { id: apiToken.id },
        data: { lastUsedAt: new Date() },
      });

      const { passwordHash, totpSecret, ...userWithoutSecrets } = apiToken.user;
      return userWithoutSecrets;
    }

    // Fallback: simple token-based auth (for login session tokens)
    // In production, this should be replaced with proper JWT verification
    const user = await db.user.findFirst({
      where: { isActive: true },
    });

    // We can't reliably match a sha256 token back to a user without storing it.
    // For now, the API token approach above is the primary mechanism.
    // Session-based auth should be implemented via JWT in a future iteration.

    return null;
  } catch {
    return null;
  }
}

export async function requireAdmin() {
  const user = await getAuthUser();
  if (!user) {
    return { user: null, error: 'Unauthorized', status: 401 };
  }
  if (user.role !== 'admin' && user.role !== 'owner' && !user.isRootAdmin) {
    return { user: null, error: 'Forbidden: admin access required', status: 403 };
  }
  return { user, error: null, status: 0 };
}