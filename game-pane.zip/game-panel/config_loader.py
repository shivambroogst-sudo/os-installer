"""
Config loader - config.json aur daemon-config.json ko load karta hai.
Agar config file nahi mili toh defaults use hote hain.
"""
import json
import os

_BASE = os.path.dirname(os.path.abspath(__file__))


def _load(filename):
    path = os.path.join(_BASE, filename)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            raw = f.read()
        # Remove _comment keys before parsing (they're just documentation)
        data = json.loads(raw)
        return data
    except (json.JSONDecodeError, IOError) as e:
        print(f"[Config] Warning: {filename} load failed: {e}")
        return {}


def _get(data, *keys, default=None):
    """Nested key fetch with fallback."""
    cur = data
    for k in keys:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(k, None)
        if cur is None:
            return default
    return cur if cur is not None else default


def load_panel_config():
    """
    panel/config.json se panel settings load karta hai.
    Env vars config.json se override karte hain (env vars ki priority zyada hai).
    Returns a flat dict of config values.
    """
    d = _load('config.json')

    def ev(env_key, *json_keys, default=None, cast=None):
        """env var > config.json > default"""
        val = os.environ.get(env_key)
        if val is None:
            val = _get(d, *json_keys, default=default)
        if val is None:
            val = default
        if cast and val is not None:
            try:
                val = cast(val)
            except (ValueError, TypeError):
                val = default
        return val

    return {
        'host':               ev('PANEL_HOST',       'panel', 'host',         default='0.0.0.0'),
        'port':               int(os.environ.get('PORT') or os.environ.get('PANEL_PORT') or _get(d, 'panel', 'port') or 3000),
        'debug':              ev('FLASK_DEBUG',      'panel', 'debug',        default=False),
        'secret_key':         ev('SECRET_KEY',       'panel', 'secret_key',   default=None),
        'jwt_secret_key':     ev('JWT_SECRET_KEY',   'panel', 'jwt_secret_key', default=None),
        'db_url':             ev('PANEL_DATABASE_URL', 'database', 'url',     default=None),
        'daemon_secret':      ev('DAEMON_SECRET',    'daemon', 'secret',      default='daemon-secret-change-me'),
        'daemon_url':         ev('DAEMON_URL',       'daemon', 'default_url', default='http://127.0.0.1:3001'),
        'daemon_timeout':     ev('DAEMON_TIMEOUT',   'daemon', 'timeout_seconds', default=10, cast=int),
        'panel_name':         ev('PANEL_NAME',       'panel_settings', 'name',        default='GamePanel'),
        'panel_description':  ev('PANEL_DESCRIPTION','panel_settings', 'description', default='Game Server Management Panel'),
        'java_path':          ev('DEFAULT_JAVA_PATH','panel_settings', 'default_java_path', default='java'),
        'max_servers_per_user': ev('MAX_SERVERS_PER_USER', 'panel_settings', 'max_servers_per_user', default=5, cast=int),
        'registration_enabled': ev('REGISTRATION_ENABLED', 'panel_settings', 'registration_enabled', default=True),
        'maintenance_mode':   ev('MAINTENANCE_MODE', 'panel_settings', 'maintenance_mode', default=False),
        'maintenance_message': ev('MAINTENANCE_MESSAGE', 'panel_settings', 'maintenance_message', default='Panel maintenance chal rahi hai.'),
        'max_upload_mb':      ev('MAX_UPLOAD_MB',    'uploads', 'max_size_mb', default=512, cast=int),
        'servers_folder':     ev('SERVERS_FOLDER',   'uploads', 'servers_folder', default='servers'),
        'session_secure':     ev('SESSION_SECURE',   'security', 'session_cookie_secure', default=False),
        'csrf_time_limit':    ev('CSRF_TIME_LIMIT',  'security', 'csrf_time_limit_seconds', default=3600, cast=int),
        'log_level':          ev('LOG_LEVEL',        'logging', 'level', default='INFO'),
        'socketio_cors':      ev('SOCKETIO_CORS',    'socketio', 'cors_allowed_origins', default='*'),
    }


def load_daemon_config():
    """
    daemon-config.json se daemon settings load karta hai.
    Env vars daemon-config.json se override karte hain.
    Returns a flat dict of config values.
    """
    d = _load('daemon-config.json')

    def ev(env_key, *json_keys, default=None, cast=None):
        val = os.environ.get(env_key)
        if val is None:
            val = _get(d, *json_keys, default=default)
        if val is None:
            val = default
        if cast and val is not None:
            try:
                val = cast(val)
            except (ValueError, TypeError):
                val = default
        return val

    _base = os.path.dirname(os.path.abspath(__file__))

    servers_folder = ev('SERVERS_FOLDER', 'servers', 'base_folder', default='servers')
    backups_folder = ev('BACKUPS_FOLDER', 'backups', 'backup_folder', default='backups')

    return {
        'host':              ev('DAEMON_HOST',      'daemon', 'host',   default='0.0.0.0'),
        'port':              ev('DAEMON_PORT',      'daemon', 'port',   default=3001, cast=int),
        'debug':             ev('FLASK_DEBUG',      'daemon', 'debug',  default=False),
        'secret':            ev('DAEMON_SECRET',    'daemon', 'secret', default='daemon-secret-change-me'),
        'panel_url':         ev('PANEL_URL',        'panel',  'url',    default='http://127.0.0.1:3000'),
        'heartbeat_interval': ev('HEARTBEAT_INTERVAL', 'panel', 'heartbeat_interval_seconds', default=30, cast=int),
        'java_path':         ev('JAVA_PATH',        'java',   'default_path', default='java'),
        'servers_dir':       os.path.join(_base, servers_folder),
        'backups_dir':       os.path.join(_base, backups_folder),
        'max_ram_mb':        ev('MAX_RAM_MB',       'servers', 'max_ram_mb',   default=8192, cast=int),
        'max_cpu_percent':   ev('MAX_CPU_PERCENT',  'servers', 'max_cpu_percent', default=400, cast=int),
        'max_backups':       ev('MAX_BACKUPS',      'backups', 'max_backups_per_server', default=10, cast=int),
        'monitor_interval':  ev('MONITOR_INTERVAL', 'resources', 'monitor_interval_seconds', default=5, cast=int),
        'log_level':         ev('LOG_LEVEL',        'logging', 'level', default='INFO'),
    }


def print_config_summary(cfg, label='Config'):
    """Debug ke liye config summary print karta hai."""
    safe = {k: v for k, v in cfg.items()
            if 'secret' not in k.lower() and 'key' not in k.lower()}
    print(f"[{label}] Loaded configuration:")
    for k, v in safe.items():
        print(f"  {k}: {v}")
