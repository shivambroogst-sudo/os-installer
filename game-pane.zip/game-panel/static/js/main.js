'use strict';

// Toast notifications
const Toast = {
  container: null,
  init() {
    this.container = document.getElementById('toast-container');
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.className = 'toast-container';
      this.container.id = 'toast-container';
      document.body.appendChild(this.container);
    }
  },
  show(message, type = 'info', duration = 4000) {
    this.init();
    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<span>${icons[type] || ''}</span><span>${message}</span>`;
    this.container.appendChild(toast);
    setTimeout(() => {
      toast.style.animation = 'none';
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = '0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  },
  success(msg) { this.show(msg, 'success'); },
  error(msg) { this.show(msg, 'error'); },
  warning(msg) { this.show(msg, 'warning'); },
  info(msg) { this.show(msg, 'info'); }
};

// Modal
function openModal(id) {
  const overlay = document.getElementById(id);
  if (overlay) {
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}
function closeModal(id) {
  const overlay = typeof id === 'string' ? document.getElementById(id) : id.closest('.modal-overlay');
  if (overlay) {
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }
}
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    closeModal(e.target);
  }
});

// CSRF token
function getCsrfToken() {
  const meta = document.querySelector('meta[name="csrf-token"]');
  return meta ? meta.getAttribute('content') : '';
}

// API fetch wrapper
async function apiFetch(url, options = {}) {
  const defaults = {
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': getCsrfToken()
    },
    credentials: 'same-origin'
  };
  const merged = { ...defaults, ...options };
  if (options.headers) {
    merged.headers = { ...defaults.headers, ...options.headers };
  }
  const response = await fetch(url, merged);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || `HTTP ${response.status}`);
  }
  return data;
}

// Confirm dialog
function confirmAction(message, callback) {
  if (confirm(message)) callback();
}

// Format bytes
function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  while (bytes >= 1024 && i < units.length - 1) { bytes /= 1024; i++; }
  return `${bytes.toFixed(1)} ${units[i]}`;
}

// Format date
function formatDate(ts) {
  return new Date(ts * 1000).toLocaleString();
}

// Status badge helper
function statusBadge(status) {
  return `<span class="badge badge-${status}">${status}</span>`;
}

// Sidebar toggle
const sidebarToggle = document.getElementById('sidebar-toggle');
const sidebar = document.querySelector('.sidebar');
if (sidebarToggle && sidebar) {
  sidebarToggle.addEventListener('click', () => {
    sidebar.classList.toggle('open');
  });
}

// Active sidebar item
(function() {
  const path = window.location.pathname;
  document.querySelectorAll('.sidebar-item').forEach(item => {
    const href = item.getAttribute('href');
    if (href && path.startsWith(href) && href !== '/') {
      item.classList.add('active');
    }
  });
})();

// Server power actions
async function serverPower(serverId, action, btn) {
  const labels = { start: 'Starting...', stop: 'Stopping...', restart: 'Restarting...', kill: 'Killing...' };
  const original = btn ? btn.textContent : '';
  if (btn) { btn.disabled = true; btn.textContent = labels[action] || action; }
  try {
    await apiFetch(`/server/${serverId}/power/${action}`, { method: 'POST' });
    Toast.success(`Server ${action} command sent.`);
  } catch(e) {
    Toast.error(e.message);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = original; }
  }
}

// Delete with confirmation
async function deleteItem(url, message, onSuccess) {
  if (!confirm(message || 'Are you sure? This cannot be undone.')) return;
  try {
    await apiFetch(url, { method: 'POST' });
    Toast.success('Deleted successfully.');
    if (onSuccess) onSuccess();
  } catch(e) {
    Toast.error(e.message);
  }
}

// Admin server power
async function adminServerPower(serverId, action) {
  try {
    await apiFetch(`/admin/servers/${serverId}/power/${action}`, { method: 'POST' });
    Toast.success(`${action} sent to server.`);
  } catch(e) {
    Toast.error(e.message);
  }
}

// Auto-refresh stats
function startStatsRefresh(serverId, intervalMs = 5000) {
  const updateStats = async () => {
    try {
      const data = await apiFetch(`/server/${serverId}/stats`);
      const ramEl = document.getElementById('stat-ram');
      const cpuEl = document.getElementById('stat-cpu');
      const diskEl = document.getElementById('stat-disk');
      const statusEl = document.getElementById('stat-status');
      if (ramEl) ramEl.textContent = `${data.ram_used || 0} MB / ${data.ram_limit || '?'} MB`;
      if (cpuEl) cpuEl.textContent = `${(data.cpu_used || 0).toFixed(1)}%`;
      if (diskEl) diskEl.textContent = formatBytes((data.disk_used || 0) * 1024 * 1024);
      if (statusEl) {
        statusEl.className = `badge badge-${data.status}`;
        statusEl.textContent = data.status;
      }
      const ramBar = document.getElementById('bar-ram');
      const cpuBar = document.getElementById('bar-cpu');
      if (ramBar && data.ram_limit) {
        const pct = Math.min(100, (data.ram_used / data.ram_limit) * 100);
        ramBar.style.width = pct + '%';
        ramBar.className = `progress-bar ${pct > 90 ? 'red' : pct > 70 ? 'yellow' : 'green'}`;
      }
      if (cpuBar) {
        const pct = Math.min(100, data.cpu_used || 0);
        cpuBar.style.width = pct + '%';
        cpuBar.className = `progress-bar ${pct > 90 ? 'red' : pct > 70 ? 'yellow' : 'green'}`;
      }
    } catch(_) {}
  };
  updateStats();
  return setInterval(updateStats, intervalMs);
}

// Copy to clipboard
function copyToClipboard(text, btn) {
  navigator.clipboard.writeText(text).then(() => {
    const orig = btn ? btn.textContent : '';
    if (btn) { btn.textContent = 'Copied!'; }
    setTimeout(() => { if (btn) btn.textContent = orig; }, 1500);
  });
}

// Notification badge
(function() {
  const badge = document.getElementById('notif-badge');
  if (badge) {
    const count = parseInt(badge.textContent, 10);
    if (!count) badge.style.display = 'none';
  }
})();

// Flash messages auto-dismiss
document.querySelectorAll('.alert').forEach(el => {
  setTimeout(() => {
    el.style.transition = '0.5s ease';
    el.style.opacity = '0';
    el.style.maxHeight = '0';
    el.style.padding = '0';
    setTimeout(() => el.remove(), 500);
  }, 5000);
});

window.Toast = Toast;
window.openModal = openModal;
window.closeModal = closeModal;
window.apiFetch = apiFetch;
window.serverPower = serverPower;
window.deleteItem = deleteItem;
window.adminServerPower = adminServerPower;
window.startStatsRefresh = startStatsRefresh;
window.copyToClipboard = copyToClipboard;
window.formatBytes = formatBytes;
