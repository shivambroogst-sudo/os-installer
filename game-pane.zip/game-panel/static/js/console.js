'use strict';

class GameConsole {
  constructor(serverId, socketUrl) {
    this.serverId = serverId;
    this.socket = null;
    this.history = [];
    this.historyIndex = -1;
    this.outputEl = document.getElementById('console-output');
    this.inputEl = document.getElementById('console-input');
    this.connectSocket(socketUrl);
    this.bindInput();
  }

  connectSocket(socketUrl) {
    this.socket = io(socketUrl, { transports: ['websocket', 'polling'] });
    this.socket.on('connect', () => {
      this.appendOutput('\x1b[32m[Console] Connected to panel.\x1b[0m\r\n');
      this.socket.emit('join_console', { server_id: this.serverId });
    });
    this.socket.on('disconnect', () => {
      this.appendOutput('\x1b[33m[Console] Disconnected.\x1b[0m\r\n');
    });
    this.socket.on('console_output', data => {
      this.appendOutput(data.output || '');
    });
    this.socket.on('server_status', data => {
      const statusEl = document.getElementById('server-status');
      if (statusEl) {
        statusEl.className = `badge badge-${data.status}`;
        statusEl.textContent = data.status;
      }
      const startBtn = document.getElementById('btn-start');
      const stopBtn = document.getElementById('btn-stop');
      const restartBtn = document.getElementById('btn-restart');
      const killBtn = document.getElementById('btn-kill');
      const running = ['running', 'starting'].includes(data.status);
      if (startBtn) startBtn.disabled = running;
      if (stopBtn) stopBtn.disabled = !running;
      if (restartBtn) restartBtn.disabled = !running;
      if (killBtn) killBtn.disabled = !running;
    });
    this.socket.on('console_joined', () => {
      this.appendOutput('\x1b[36m[Console] Joined server console.\x1b[0m\r\n');
    });
    this.socket.on('error', data => {
      this.appendOutput(`\x1b[31m[Error] ${data.message}\x1b[0m\r\n`);
    });
  }

  appendOutput(text) {
    if (!this.outputEl) return;
    const formatted = this.ansiToHtml(text);
    const pre = document.createElement('span');
    pre.innerHTML = formatted;
    this.outputEl.appendChild(pre);
    this.outputEl.scrollTop = this.outputEl.scrollHeight;
  }

  ansiToHtml(text) {
    const escapeHtml = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    const ansiCodes = {
      '0': '</span><span>',
      '1': '<span class="ansi-bold">',
      '30': '<span class="ansi-black">', '31': '<span class="ansi-red">',
      '32': '<span class="ansi-green">', '33': '<span class="ansi-yellow">',
      '34': '<span class="ansi-blue">', '35': '<span class="ansi-magenta">',
      '36': '<span class="ansi-cyan">', '37': '<span class="ansi-white">',
      '90': '<span class="ansi-bright-black">', '91': '<span class="ansi-bright-red">',
      '92': '<span class="ansi-bright-green">', '93': '<span class="ansi-bright-yellow">',
      '94': '<span class="ansi-bright-blue">', '95': '<span class="ansi-bright-magenta">',
      '96': '<span class="ansi-bright-cyan">', '97': '<span class="ansi-bright-white">',
    };
    let result = '';
    let openSpans = 0;
    const parts = text.split(/\x1b\[([0-9;]*)m/);
    for (let i = 0; i < parts.length; i++) {
      if (i % 2 === 0) {
        result += escapeHtml(parts[i]).replace(/\r?\n/g, '<br>');
      } else {
        const codes = parts[i].split(';');
        for (const code of codes) {
          if (code === '0' || code === '') {
            while (openSpans-- > 0) result += '</span>';
            openSpans = 0;
          } else if (ansiCodes[code]) {
            result += ansiCodes[code];
            openSpans++;
          }
        }
      }
    }
    while (openSpans-- > 0) result += '</span>';
    return result;
  }

  sendCommand(command) {
    if (!command.trim()) return;
    this.history.unshift(command);
    if (this.history.length > 50) this.history.pop();
    this.historyIndex = -1;
    this.appendOutput(`\x1b[90m> ${command}\x1b[0m\r\n`);
    this.socket.emit('send_command', {
      server_id: this.serverId,
      command: command
    });
  }

  bindInput() {
    if (!this.inputEl) return;
    this.inputEl.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const cmd = this.inputEl.value.trim();
        if (cmd) {
          this.sendCommand(cmd);
          this.inputEl.value = '';
        }
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (this.historyIndex < this.history.length - 1) {
          this.historyIndex++;
          this.inputEl.value = this.history[this.historyIndex] || '';
        }
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (this.historyIndex > 0) {
          this.historyIndex--;
          this.inputEl.value = this.history[this.historyIndex] || '';
        } else {
          this.historyIndex = -1;
          this.inputEl.value = '';
        }
      }
    });
    const sendBtn = document.getElementById('btn-send');
    if (sendBtn) {
      sendBtn.addEventListener('click', () => {
        const cmd = this.inputEl.value.trim();
        if (cmd) { this.sendCommand(cmd); this.inputEl.value = ''; }
      });
    }
  }

  clearConsole() {
    if (this.outputEl) this.outputEl.innerHTML = '';
  }

  powerAction(action) {
    fetch(`/server/${this.serverId}/power/${action}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRFToken': document.querySelector('meta[name="csrf-token"]').content
      }
    }).then(r => r.json()).then(d => {
      if (d.error) Toast.error(d.error);
      else this.appendOutput(`\x1b[36m[Panel] ${action} command sent.\x1b[0m\r\n`);
    }).catch(e => Toast.error(e.message));
  }
}

window.GameConsole = GameConsole;
