import os
import subprocess
import signal
import psutil
import threading
import time
import logging
import requests

logger = logging.getLogger(__name__)


class ServerProcess:
    def __init__(self, server_id: int, folder: str, startup_command: str,
                 java_path: str, ip: str, port: int, ram: int, cpu: float,
                 panel_url: str, daemon_secret: str,
                 auto_restart: bool = False):
        self.server_id = server_id
        self.folder = folder
        self.startup_command = startup_command
        self.java_path = java_path
        self.ip = ip
        self.port = port
        self.ram = ram
        self.cpu = cpu
        self.panel_url = panel_url
        self.daemon_secret = daemon_secret
        self.auto_restart = auto_restart
        self.process = None
        self.pid = None
        self._monitor_thread = None
        self._output_thread = None
        self._running = False
        self._stopping = False

    def _build_command(self) -> list:
        cmd_parts = self.startup_command.split()
        if 'java' in cmd_parts[0].lower() or cmd_parts[0] == self.java_path:
            return cmd_parts
        return [self.java_path] + cmd_parts

    def start(self, servers_dir: str) -> dict:
        server_path = os.path.join(servers_dir, str(self.folder))
        os.makedirs(server_path, exist_ok=True)

        if self.process and self.process.poll() is None:
            return {'error': 'Server already running'}

        self._stopping = False
        cmd = self._build_command()

        try:
            self.process = subprocess.Popen(
                cmd,
                cwd=server_path,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                env={**os.environ, 'JAVA_HOME': os.path.dirname(self.java_path)}
            )
            self.pid = self.process.pid
            self._running = True
            self._report_status('starting', self.pid)
            self._output_thread = threading.Thread(target=self._read_output, daemon=True)
            self._output_thread.start()
            self._monitor_thread = threading.Thread(target=self._monitor, daemon=True)
            self._monitor_thread.start()
            return {'success': True, 'pid': self.pid}
        except FileNotFoundError as e:
            return {'error': f'Command not found: {e}'}
        except Exception as e:
            return {'error': str(e)}

    def stop(self, timeout: int = 30):
        self._stopping = True
        self.auto_restart = False
        if self.process and self.process.poll() is None:
            self.send_command('stop')
            try:
                self.process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                self.kill()
        self._running = False
        self._report_status('offline', None)

    def restart(self, servers_dir: str):
        self.stop()
        time.sleep(2)
        self._stopping = False
        self.auto_restart = True
        return self.start(servers_dir)

    def kill(self):
        self._stopping = True
        if self.process and self.process.poll() is None:
            try:
                os.kill(self.process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        self._running = False
        self._report_status('offline', None)

    def send_command(self, command: str):
        if self.process and self.process.poll() is None and self.process.stdin:
            try:
                self.process.stdin.write(command + '\n')
                self.process.stdin.flush()
                return True
            except Exception:
                return False
        return False

    def get_stats(self) -> dict:
        stats = {
            'status': 'running' if self._running and self.process and self.process.poll() is None else 'offline',
            'pid': self.pid,
            'ram_used': 0,
            'cpu_used': 0.0,
            'disk_used': 0
        }
        if self.pid:
            try:
                proc = psutil.Process(self.pid)
                mem = proc.memory_info()
                stats['ram_used'] = mem.rss // (1024 * 1024)
                stats['cpu_used'] = proc.cpu_percent(interval=0.1)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        return stats

    def _read_output(self):
        if not self.process or not self.process.stdout:
            return
        for line in iter(self.process.stdout.readline, ''):
            if line:
                self._send_console_output(line.rstrip())
        self.process.stdout.close()

    def _monitor(self):
        time.sleep(3)
        if self.process:
            if self.process.poll() is None:
                self._report_status('running', self.pid)
        while self._running:
            if self.process and self.process.poll() is not None:
                self._running = False
                if not self._stopping and self.auto_restart:
                    self._report_crash()
                    logger.info(f'[Daemon] Server {self.server_id} crashed, auto-restarting...')
                    time.sleep(5)
                    self._stopping = False
                    self._running = True
                    self.process = None
                    from .server_manager import ServerManager
                    time.sleep(3)
                else:
                    self._report_status('offline', None)
                break
            time.sleep(2)

    def _report_status(self, status: str, pid):
        try:
            requests.post(
                f'{self.panel_url}/api/daemon/server-status',
                json={'server_id': self.server_id, 'status': status, 'pid': pid},
                headers={'X-Daemon-Secret': self.daemon_secret},
                timeout=5
            )
        except Exception:
            pass

    def _report_crash(self):
        try:
            requests.post(
                f'{self.panel_url}/api/daemon/crash',
                json={'server_id': self.server_id},
                headers={'X-Daemon-Secret': self.daemon_secret},
                timeout=5
            )
        except Exception:
            pass

    def _send_console_output(self, output: str):
        try:
            requests.post(
                f'{self.panel_url}/api/daemon/console-output',
                json={'server_id': self.server_id, 'output': output + '\r\n'},
                headers={'X-Daemon-Secret': self.daemon_secret},
                timeout=3
            )
        except Exception:
            pass
