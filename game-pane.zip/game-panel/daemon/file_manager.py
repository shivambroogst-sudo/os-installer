import os
import shutil
import zipfile
import mimetypes
import logging

logger = logging.getLogger(__name__)

TEXT_EXTENSIONS = {
    '.txt', '.log', '.yml', '.yaml', '.json', '.xml', '.properties',
    '.sh', '.bat', '.cfg', '.conf', '.config', '.py', '.js', '.html',
    '.css', '.java', '.kt', '.lua', '.toml', '.ini', '.env', '.md'
}

MAX_EDIT_SIZE = 5 * 1024 * 1024


def _safe_path(servers_dir: str, folder: str, path: str) -> str:
    server_dir = os.path.realpath(os.path.join(servers_dir, str(folder)))
    full = os.path.realpath(os.path.join(server_dir, path.lstrip('/')))
    if not full.startswith(server_dir):
        raise PermissionError('Path traversal not allowed')
    return full


def list_files(servers_dir: str, folder: str, path: str = '/') -> list:
    full_path = _safe_path(servers_dir, folder, path)
    if not os.path.isdir(full_path):
        raise FileNotFoundError(f'Directory not found: {path}')
    entries = []
    for name in sorted(os.listdir(full_path)):
        entry_path = os.path.join(full_path, name)
        stat = os.stat(entry_path)
        entries.append({
            'name': name,
            'path': os.path.join(path, name).replace('\\', '/'),
            'is_dir': os.path.isdir(entry_path),
            'size': stat.st_size if not os.path.isdir(entry_path) else 0,
            'modified': stat.st_mtime,
            'mime': mimetypes.guess_type(name)[0] or 'application/octet-stream'
        })
    return sorted(entries, key=lambda x: (not x['is_dir'], x['name'].lower()))


def read_file(servers_dir: str, folder: str, path: str) -> str:
    full_path = _safe_path(servers_dir, folder, path)
    if not os.path.isfile(full_path):
        raise FileNotFoundError(f'File not found: {path}')
    size = os.path.getsize(full_path)
    if size > MAX_EDIT_SIZE:
        raise ValueError('File too large to edit (max 5MB)')
    ext = os.path.splitext(path)[1].lower()
    if ext not in TEXT_EXTENSIONS:
        raise ValueError('File type not supported for text editing')
    with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()


def write_file(servers_dir: str, folder: str, path: str, content: str):
    full_path = _safe_path(servers_dir, folder, path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, 'w', encoding='utf-8') as f:
        f.write(content)


def create_directory(servers_dir: str, folder: str, path: str, name: str):
    parent = _safe_path(servers_dir, folder, path)
    new_dir = os.path.join(parent, name)
    safe_new = os.path.realpath(new_dir)
    server_dir = os.path.realpath(os.path.join(servers_dir, str(folder)))
    if not safe_new.startswith(server_dir):
        raise PermissionError('Path traversal not allowed')
    os.makedirs(safe_new, exist_ok=True)


def delete_paths(servers_dir: str, folder: str, paths: list):
    for path in paths:
        full = _safe_path(servers_dir, folder, path)
        if os.path.isdir(full):
            shutil.rmtree(full)
        elif os.path.isfile(full):
            os.remove(full)


def rename_path(servers_dir: str, folder: str, from_path: str, to_path: str):
    src = _safe_path(servers_dir, folder, from_path)
    dst = _safe_path(servers_dir, folder, to_path)
    os.rename(src, dst)


def extract_archive(servers_dir: str, folder: str, archive_path: str, destination: str = '/'):
    src = _safe_path(servers_dir, folder, archive_path)
    dst = _safe_path(servers_dir, folder, destination)
    os.makedirs(dst, exist_ok=True)
    if zipfile.is_zipfile(src):
        with zipfile.ZipFile(src, 'r') as zf:
            zf.extractall(dst)
    else:
        raise ValueError('Only ZIP archives are supported')


def save_upload(servers_dir: str, folder: str, path: str, file_stream, filename: str):
    dest_dir = _safe_path(servers_dir, folder, path)
    os.makedirs(dest_dir, exist_ok=True)
    dest_file = _safe_path(servers_dir, folder, os.path.join(path, filename))
    file_stream.save(dest_file)
    return dest_file


def search_files(servers_dir: str, folder: str, query: str, path: str = '/') -> list:
    results = []
    server_dir = os.path.realpath(os.path.join(servers_dir, str(folder)))
    search_root = _safe_path(servers_dir, folder, path)
    query_lower = query.lower()
    for dirpath, dirnames, filenames in os.walk(search_root):
        for fname in filenames:
            if query_lower in fname.lower():
                rel = os.path.relpath(os.path.join(dirpath, fname), server_dir)
                results.append({
                    'name': fname,
                    'path': '/' + rel.replace('\\', '/'),
                    'is_dir': False
                })
        for dname in dirnames:
            if query_lower in dname.lower():
                rel = os.path.relpath(os.path.join(dirpath, dname), server_dir)
                results.append({
                    'name': dname,
                    'path': '/' + rel.replace('\\', '/'),
                    'is_dir': True
                })
        if len(results) >= 100:
            break
    return results


def create_backup(servers_dir: str, folder: str, backup_path: str, filename: str) -> int:
    server_dir = _safe_path(servers_dir, folder, '/')
    os.makedirs(backup_path, exist_ok=True)
    zip_path = os.path.join(backup_path, filename)
    total_size = 0
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for dirpath, dirnames, filenames in os.walk(server_dir):
            dirnames[:] = [d for d in dirnames if not d.startswith('.')]
            for fname in filenames:
                fpath = os.path.join(dirpath, fname)
                arcname = os.path.relpath(fpath, server_dir)
                zf.write(fpath, arcname)
                total_size += os.path.getsize(fpath)
    return os.path.getsize(zip_path)


def restore_backup(servers_dir: str, folder: str, backup_path: str, filename: str):
    server_dir = _safe_path(servers_dir, folder, '/')
    zip_path = os.path.join(backup_path, filename)
    shutil.rmtree(server_dir, ignore_errors=True)
    os.makedirs(server_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path, 'r') as zf:
        zf.extractall(server_dir)
