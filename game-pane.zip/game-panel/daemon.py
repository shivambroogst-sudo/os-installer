import os
import logging
from dotenv import load_dotenv

load_dotenv()

# Config file se settings load karo
from config_loader import load_daemon_config
cfg = load_daemon_config()

# Logging setup
logging.basicConfig(
    level=getattr(logging, cfg['log_level'].upper(), logging.INFO),
    format='[%(asctime)s] %(levelname)s %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

from daemon.app import create_daemon_app

app = create_daemon_app(cfg)

if __name__ == '__main__':
    host = cfg['host']
    port = cfg['port']
    debug = str(cfg['debug']).lower() == 'true' if isinstance(cfg['debug'], str) else bool(cfg['debug'])

    print(f"[Daemon] ==========================================")
    print(f"[Daemon] Game Server Daemon")
    print(f"[Daemon] URL   : http://{host}:{port}")
    print(f"[Daemon] Config: daemon-config.json")
    print(f"[Daemon] ==========================================")

    app.run(host=host, port=port, debug=debug, use_reloader=False)
