import requests
from flask import request
from flask_login import current_user
from flask_socketio import join_room, leave_room, emit, disconnect
from .extensions import db
from .models.server import Server


def register_events(socketio):

    @socketio.on('connect')
    def on_connect():
        if not current_user.is_authenticated:
            disconnect()
            return False

    @socketio.on('disconnect')
    def on_disconnect():
        pass

    @socketio.on('join_console')
    def on_join_console(data):
        server_id = data.get('server_id')
        if not server_id:
            return
        server = db.session.get(Server, int(server_id))
        if not server:
            return
        if current_user.role not in ('owner', 'admin') and server.owner_id != current_user.id:
            emit('error', {'message': 'Access denied'})
            return
        join_room(f'console_{server_id}')
        emit('console_joined', {'server_id': server_id})

    @socketio.on('leave_console')
    def on_leave_console(data):
        server_id = data.get('server_id')
        if server_id:
            leave_room(f'console_{server_id}')

    @socketio.on('send_command')
    def on_send_command(data):
        server_id = data.get('server_id')
        command = data.get('command', '').strip()
        if not server_id or not command:
            return
        server = db.session.get(Server, int(server_id))
        if not server:
            return
        if current_user.role not in ('owner', 'admin') and server.owner_id != current_user.id:
            emit('error', {'message': 'Access denied'})
            return
        node = server.node
        if not node:
            emit('console_output', {'output': '\r\n[Panel] Node not found.\r\n'})
            return
        try:
            resp = requests.post(
                f"{node.daemon_url}/api/servers/{server_id}/command",
                json={'command': command},
                headers={'X-Daemon-Secret': node.daemon_secret},
                timeout=5
            )
            if resp.status_code != 200:
                emit('console_output', {'output': f'\r\n[Panel] Failed to send command.\r\n'})
        except Exception as e:
            emit('console_output', {'output': f'\r\n[Panel] Error: {e}\r\n'})

    @socketio.on('join_node_stats')
    def on_join_node_stats(data):
        if current_user.role not in ('owner', 'admin'):
            return
        node_id = data.get('node_id')
        if node_id:
            join_room(f'node_stats_{node_id}')

    @socketio.on('leave_node_stats')
    def on_leave_node_stats(data):
        node_id = data.get('node_id')
        if node_id:
            leave_room(f'node_stats_{node_id}')
