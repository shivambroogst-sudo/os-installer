import os
import logging
from flask import Flask, render_template
from .extensions import db, login_manager, socketio, csrf, limiter, jwt


def create_app(cfg=None):
    cfg = cfg or {}

    app = Flask(__name__,
                template_folder='../templates',
                static_folder='../static')

    _rnd = lambda: os.urandom(32).hex()
    secret_key = cfg.get('secret_key') or _rnd()
    jwt_secret  = cfg.get('jwt_secret_key') or _rnd()
    if secret_key in ('CHANGE-THIS-TO-A-RANDOM-SECRET', '', None):
        secret_key = _rnd()
    if jwt_secret in ('CHANGE-THIS-TO-ANOTHER-RANDOM-SECRET', '', None):
        jwt_secret = _rnd()

    app.config['SECRET_KEY']     = secret_key
    app.config['JWT_SECRET_KEY'] = jwt_secret

    _base_dir    = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    _sqlite_path = f"sqlite:///{os.path.join(_base_dir, 'panel.db')}"
    db_url = cfg.get('db_url') or _sqlite_path
    if db_url and db_url.startswith('postgresql'):
        db_url = _sqlite_path
    app.config['SQLALCHEMY_DATABASE_URI']  = db_url
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = False

    app.config['WTF_CSRF_TIME_LIMIT']      = int(cfg.get('csrf_time_limit', 3600))
    session_secure = cfg.get('session_secure', False)
    if isinstance(session_secure, str):
        session_secure = session_secure.lower() == 'true'
    app.config['SESSION_COOKIE_SECURE']    = bool(session_secure)
    app.config['SESSION_COOKIE_HTTPONLY']  = True
    app.config['SESSION_COOKIE_SAMESITE']  = 'Lax'
    app.config['REMEMBER_COOKIE_HTTPONLY'] = True

    daemon_secret = cfg.get('daemon_secret', 'daemon-secret-change-me')
    if daemon_secret == 'CHANGE-THIS-DAEMON-SECRET':
        daemon_secret = 'daemon-secret-change-me'
    app.config['DAEMON_URL']    = cfg.get('daemon_url', 'http://127.0.0.1:3001')
    app.config['DAEMON_SECRET'] = daemon_secret
    app.config['DAEMON_TIMEOUT'] = int(cfg.get('daemon_timeout', 10))

    servers_folder = cfg.get('servers_folder', 'servers')
    app.config['UPLOAD_FOLDER']      = os.path.join(_base_dir, servers_folder)
    app.config['MAX_CONTENT_LENGTH'] = int(cfg.get('max_upload_mb', 512)) * 1024 * 1024

    app.config['PANEL_NAME']        = cfg.get('panel_name', 'GamePanel')
    app.config['PANEL_DESCRIPTION'] = cfg.get('panel_description', 'Game Server Management Panel')

    db.init_app(app)
    login_manager.init_app(app)
    socketio.init_app(app,
                      async_mode='eventlet',
                      cors_allowed_origins=cfg.get('socketio_cors', '*'),
                      logger=False, engineio_logger=False)
    csrf.init_app(app)
    limiter.init_app(app)
    jwt.init_app(app)

    login_manager.login_view         = 'auth.login'
    login_manager.login_message      = 'Please log in to access this page.'
    login_manager.login_message_category = 'warning'

    from .models.user import User

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    @app.context_processor
    def inject_panel_settings():
        from .models.setting import Setting
        try:
            return dict(
                panel_name=Setting.get('panel_name', app.config.get('PANEL_NAME', 'GamePanel')),
                panel_logo_url=Setting.get('panel_logo_url', ''),
                panel_favicon_url=Setting.get('panel_favicon_url', ''),
                login_bg_video=Setting.get('login_bg_video', ''),
                register_bg_video=Setting.get('register_bg_video', ''),
                dashboard_bg_video=Setting.get('dashboard_bg_video', ''),
                admin_bg_video=Setting.get('admin_bg_video', ''),
            )
        except Exception:
            return dict(
                panel_name=app.config.get('PANEL_NAME', 'GamePanel'),
                panel_logo_url='', panel_favicon_url='',
                login_bg_video='', register_bg_video='',
                dashboard_bg_video='', admin_bg_video='',
            )

    @app.route('/healthz')
    def healthz():
        from flask import jsonify
        return jsonify({'ok': True, 'panel': app.config.get('PANEL_NAME', 'GamePanel')})

    with app.app_context():
        _register_blueprints(app)
        _register_error_handlers(app)
        db.create_all()
        _seed_owner(app, cfg)
        _seed_settings(app, cfg)
        _register_socket_events(app)

    return app


def _register_blueprints(app):
    from .routes.auth import auth_bp
    from .routes.admin.dashboard import admin_dashboard_bp
    from .routes.admin.users import admin_users_bp
    from .routes.admin.servers import admin_servers_bp
    from .routes.admin.nodes import admin_nodes_bp
    from .routes.admin.allocations import admin_allocations_bp
    from .routes.admin.settings import admin_settings_bp
    from .routes.admin.backups import admin_backups_bp
    from .routes.admin.databases import admin_databases_bp
    from .routes.user.dashboard import user_dashboard_bp
    from .routes.user.console import user_console_bp
    from .routes.user.files import user_files_bp
    from .routes.user.backups import user_backups_bp
    from .routes.user.databases import user_databases_bp
    from .routes.user.network import user_network_bp
    from .routes.user.server_settings import user_server_settings_bp
    from .api.v1.nodes import api_nodes_bp
    from .api.v1.servers import api_servers_bp
    from .api.v1.daemon import api_daemon_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_dashboard_bp)
    app.register_blueprint(admin_users_bp)
    app.register_blueprint(admin_servers_bp)
    app.register_blueprint(admin_nodes_bp)
    app.register_blueprint(admin_allocations_bp)
    app.register_blueprint(admin_settings_bp)
    app.register_blueprint(admin_backups_bp)
    app.register_blueprint(admin_databases_bp)
    app.register_blueprint(user_dashboard_bp)
    app.register_blueprint(user_console_bp)
    app.register_blueprint(user_files_bp)
    app.register_blueprint(user_backups_bp)
    app.register_blueprint(user_databases_bp)
    app.register_blueprint(user_network_bp)
    app.register_blueprint(user_server_settings_bp)
    app.register_blueprint(api_nodes_bp)
    app.register_blueprint(api_servers_bp)
    app.register_blueprint(api_daemon_bp)

    csrf.exempt(api_nodes_bp)
    csrf.exempt(api_servers_bp)
    csrf.exempt(api_daemon_bp)


def _register_error_handlers(app):
    @app.errorhandler(403)
    def forbidden(e):
        return render_template('errors/403.html'), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def server_error(e):
        return render_template('errors/500.html'), 500

    @app.errorhandler(429)
    def too_many_requests(e):
        return render_template('errors/429.html'), 429


def _seed_owner(app, cfg):
    from .models.user import User
    from .extensions import db
    import bcrypt

    if User.query.count() == 0:
        hashed = bcrypt.hashpw('Admin@123'.encode(), bcrypt.gensalt()).decode()
        owner = User(
            username='admin',
            email='admin@panel.local',
            password_hash=hashed,
            role='owner',
            is_active=True
        )
        db.session.add(owner)
        db.session.commit()
        print('[Panel] ✅ Default owner created: admin / Admin@123')
        print('[Panel] ⚠️  Please change the password after first login!')


def _seed_settings(app, cfg):
    from .models.setting import Setting

    defaults = {
        'panel_name':           cfg.get('panel_name', 'GamePanel'),
        'panel_description':    cfg.get('panel_description', 'Game Server Management Panel'),
        'default_java_path':    cfg.get('java_path', 'java'),
        'max_servers_per_user': str(cfg.get('max_servers_per_user', 5)),
        'registration_enabled': 'true' if cfg.get('registration_enabled', True) else 'false',
        'maintenance_mode':     'true' if cfg.get('maintenance_mode', False) else 'false',
        'maintenance_message':  cfg.get('maintenance_message', 'Panel maintenance chal rahi hai.'),
        'panel_logo_url':       '',
        'panel_favicon_url':    '',
        'login_bg_video':       '',
        'register_bg_video':    '',
        'dashboard_bg_video':   '',
        'admin_bg_video':       '',
    }
    for key, value in defaults.items():
        if Setting.get(key) is None:
            Setting.set(key, value)


def _register_socket_events(app):
    from .sockets import register_events
    register_events(socketio)
