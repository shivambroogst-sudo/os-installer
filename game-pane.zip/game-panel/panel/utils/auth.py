import bcrypt
import secrets
from datetime import datetime
from flask import request
from flask_login import current_user
from ..extensions import db
from ..models.user import User
from ..models.activity import ActivityLog


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')


def check_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))


def generate_api_token() -> str:
    return secrets.token_hex(32)


def log_activity(action: str, description: str = None, level: str = 'info',
                 server_id: int = None, user_id: int = None):
    try:
        uid = user_id or (current_user.id if current_user.is_authenticated else None)
        entry = ActivityLog(
            user_id=uid,
            server_id=server_id,
            action=action,
            description=description,
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent', '')[:500],
            level=level
        )
        db.session.add(entry)
        db.session.commit()
    except Exception:
        pass


def validate_password_strength(password: str) -> tuple[bool, str]:
    if len(password) < 8:
        return False, 'Password must be at least 8 characters.'
    if not any(c.isupper() for c in password):
        return False, 'Password must contain at least one uppercase letter.'
    if not any(c.islower() for c in password):
        return False, 'Password must contain at least one lowercase letter.'
    if not any(c.isdigit() for c in password):
        return False, 'Password must contain at least one number.'
    return True, ''
