import os
import re
import requests
from datetime import datetime, timedelta
from flask import current_app


EXPIRY_OPTIONS = {
    '1': 1,
    '7': 7,
    '15': 15,
    '30': 30,
    '60': 60,
    '90': 90,
    '180': 180,
    '365': 365,
}


def get_expiry_date(days_str: str, custom_date: str = None):
    if days_str == 'custom' and custom_date:
        try:
            return datetime.strptime(custom_date, '%Y-%m-%d')
        except ValueError:
            return None
    days = EXPIRY_OPTIONS.get(days_str)
    if days:
        return datetime.utcnow() + timedelta(days=days)
    return None


def get_next_folder_number() -> int:
    from ..models.server import Server
    from ..extensions import db
    servers_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'servers')
    os.makedirs(servers_dir, exist_ok=True)
    last = db.session.query(db.func.max(Server.folder_number)).scalar()
    return (last or 0) + 1


def format_bytes(b: int) -> str:
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if b < 1024:
            return f"{b:.1f} {unit}"
        b /= 1024
    return f"{b:.1f} PB"


def validate_ip(ip: str) -> bool:
    ipv4_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
    ipv6_pattern = r'^([0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}$'
    if re.match(ipv4_pattern, ip):
        parts = ip.split('.')
        return all(0 <= int(p) <= 255 for p in parts)
    return bool(re.match(ipv6_pattern, ip))


def validate_port(port: int) -> bool:
    return 1 <= port <= 65535


def parse_port_range(port_range: str) -> list[int]:
    ports = []
    try:
        if '-' in port_range:
            start, end = port_range.strip().split('-')
            start, end = int(start.strip()), int(end.strip())
            if start > end or end - start > 1000:
                return []
            ports = list(range(start, end + 1))
        else:
            ports = [int(port_range.strip())]
    except (ValueError, AttributeError):
        return []
    return [p for p in ports if validate_port(p)]


def call_daemon(node, method: str, path: str, data: dict = None, timeout: int = 10):
    url = f"{node.daemon_url}{path}"
    headers = {
        'X-Daemon-Secret': node.daemon_secret,
        'Content-Type': 'application/json'
    }
    try:
        if method.upper() == 'GET':
            resp = requests.get(url, headers=headers, timeout=timeout)
        elif method.upper() == 'POST':
            resp = requests.post(url, json=data or {}, headers=headers, timeout=timeout)
        elif method.upper() == 'PUT':
            resp = requests.put(url, json=data or {}, headers=headers, timeout=timeout)
        elif method.upper() == 'DELETE':
            resp = requests.delete(url, headers=headers, timeout=timeout)
        else:
            return None, 'Invalid method'
        resp.raise_for_status()
        return resp.json(), None
    except requests.exceptions.ConnectionError:
        return None, 'Daemon is offline or unreachable'
    except requests.exceptions.Timeout:
        return None, 'Daemon request timed out'
    except requests.exceptions.HTTPError as e:
        try:
            err = e.response.json().get('error', str(e))
        except Exception:
            err = str(e)
        return None, err
    except Exception as e:
        return None, str(e)


def notify_user(user_id: int, title: str, message: str, notif_type: str = 'info', link: str = None):
    from ..models.notification import Notification
    from ..extensions import db
    n = Notification(
        user_id=user_id,
        title=title,
        message=message,
        type=notif_type,
        link=link
    )
    db.session.add(n)
    db.session.commit()
