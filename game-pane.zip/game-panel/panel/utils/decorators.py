from functools import wraps
from flask import abort, request, jsonify, current_app
from flask_login import current_user
from ..models.user import User


def owner_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'owner':
            abort(403)
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role not in ('owner', 'admin'):
            abort(403)
        return f(*args, **kwargs)
    return decorated


def permission_required(permission):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if not current_user.is_authenticated:
                abort(403)
            if not current_user.has_permission(permission):
                abort(403)
            return f(*args, **kwargs)
        return decorated
    return decorator


def server_access_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        from ..models.server import Server
        server_id = kwargs.get('server_id')
        if not server_id:
            abort(404)
        server = Server.query.get_or_404(server_id)
        if current_user.role not in ('owner', 'admin'):
            if server.owner_id != current_user.id:
                abort(403)
        kwargs['server'] = server
        return f(*args, **kwargs)
    return decorated


def api_token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('X-API-Token') or request.args.get('api_token')
        if not token:
            return jsonify({'error': 'API token required'}), 401
        user = User.query.filter_by(api_token=token, is_active=True).first()
        if not user:
            return jsonify({'error': 'Invalid or expired token'}), 401
        kwargs['api_user'] = user
        return f(*args, **kwargs)
    return decorated


def daemon_secret_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        secret = request.headers.get('X-Daemon-Secret')
        expected = current_app.config.get('DAEMON_SECRET', '')
        if not secret or secret != expected:
            return jsonify({'error': 'Unauthorized'}), 401
        return f(*args, **kwargs)
    return decorated
