from datetime import datetime
from ..extensions import db


class Server(db.Model):
    __tablename__ = 'servers'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    icon = db.Column(db.String(256), nullable=True)
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    node_id = db.Column(db.Integer, db.ForeignKey('nodes.id'), nullable=False)
    folder_number = db.Column(db.Integer, nullable=False)

    ram_limit = db.Column(db.Integer, default=1024)
    cpu_limit = db.Column(db.Float, default=100.0)
    disk_limit = db.Column(db.Integer, default=10240)

    java_version = db.Column(db.String(50), default='java')
    java_path = db.Column(db.String(256), default='java')
    startup_command = db.Column(db.Text, default='java -jar server.jar')
    jar_file = db.Column(db.String(256), default='server.jar')

    auto_start = db.Column(db.Boolean, default=False)
    auto_restart = db.Column(db.Boolean, default=False)

    status = db.Column(db.String(20), default='offline')
    pid = db.Column(db.Integer, nullable=True)

    is_suspended = db.Column(db.Boolean, default=False)
    suspension_reason = db.Column(db.String(255), nullable=True)

    expiry_date = db.Column(db.DateTime, nullable=True)
    expiry_days = db.Column(db.Integer, nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    allocations = db.relationship('Allocation', backref='server', lazy='dynamic',
                                  foreign_keys='Allocation.server_id')
    backups = db.relationship('Backup', backref='server', lazy='dynamic',
                              cascade='all, delete-orphan')
    databases = db.relationship('ServerDatabase', backref='server', lazy='dynamic',
                                cascade='all, delete-orphan')

    @property
    def primary_allocation(self):
        return self.allocations.filter_by(is_primary=True).first()

    @property
    def folder_path(self):
        import os
        base = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'servers')
        return os.path.join(base, str(self.folder_number))

    @property
    def is_expired(self):
        if not self.expiry_date:
            return False
        return datetime.utcnow() > self.expiry_date

    @property
    def remaining_days(self):
        if not self.expiry_date:
            return None
        delta = self.expiry_date - datetime.utcnow()
        return max(0, delta.days)

    @property
    def is_running(self):
        return self.status in ('running', 'starting')

    def __repr__(self):
        return f'<Server {self.name}>'
