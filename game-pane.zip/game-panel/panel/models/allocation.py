from datetime import datetime
from ..extensions import db


class Allocation(db.Model):
    __tablename__ = 'allocations'

    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.Integer, db.ForeignKey('nodes.id'), nullable=False)
    server_id = db.Column(db.Integer, db.ForeignKey('servers.id'), nullable=True)
    ip_address = db.Column(db.String(45), nullable=False)
    ip_alias = db.Column(db.String(100), nullable=True)
    port = db.Column(db.Integer, nullable=False)
    is_primary = db.Column(db.Boolean, default=False)
    notes = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint('node_id', 'ip_address', 'port', name='uq_node_ip_port'),
    )

    @property
    def is_assigned(self):
        return self.server_id is not None

    @property
    def display(self):
        return f"{self.ip_alias or self.ip_address}:{self.port}"

    def __repr__(self):
        return f'<Allocation {self.ip_address}:{self.port}>'
