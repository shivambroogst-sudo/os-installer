from datetime import datetime
from flask_login import UserMixin
from ..extensions import db
import secrets


class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='user')
    is_active = db.Column(db.Boolean, default=True)
    api_token = db.Column(db.String(64), unique=True, nullable=True, index=True)
    reset_token = db.Column(db.String(128), nullable=True)
    reset_token_expires = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    avatar = db.Column(db.String(256), nullable=True)
    two_factor_enabled = db.Column(db.Boolean, default=False)

    admin_permissions = db.relationship('AdminPermission', backref='user',
                                        uselist=False, cascade='all, delete-orphan')
    servers = db.relationship('Server', backref='owner', lazy='dynamic',
                              foreign_keys='Server.owner_id')
    activity_logs = db.relationship('ActivityLog', backref='user', lazy='dynamic',
                                    cascade='all, delete-orphan')
    notifications = db.relationship('Notification', backref='user', lazy='dynamic',
                                    cascade='all, delete-orphan')

    def generate_api_token(self):
        self.api_token = secrets.token_hex(32)
        return self.api_token

    def generate_reset_token(self):
        self.reset_token = secrets.token_urlsafe(48)
        from datetime import timedelta
        self.reset_token_expires = datetime.utcnow() + timedelta(hours=1)
        return self.reset_token

    @property
    def is_owner(self):
        return self.role == 'owner'

    @property
    def is_admin(self):
        return self.role in ('owner', 'admin')

    def has_permission(self, permission):
        if self.role == 'owner':
            return True
        if self.role == 'admin' and self.admin_permissions:
            return getattr(self.admin_permissions, permission, False)
        return False

    def __repr__(self):
        return f'<User {self.username}>'


class AdminPermission(db.Model):
    __tablename__ = 'admin_permissions'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True, nullable=False)

    can_manage_users = db.Column(db.Boolean, default=False)
    can_manage_servers = db.Column(db.Boolean, default=False)
    can_manage_nodes = db.Column(db.Boolean, default=False)
    can_manage_allocations = db.Column(db.Boolean, default=False)
    can_manage_settings = db.Column(db.Boolean, default=False)
    can_manage_backups = db.Column(db.Boolean, default=False)
    can_manage_databases = db.Column(db.Boolean, default=False)
    can_view_analytics = db.Column(db.Boolean, default=False)
    can_view_logs = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f'<AdminPermission user_id={self.user_id}>'
