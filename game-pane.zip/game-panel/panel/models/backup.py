from datetime import datetime
from ..extensions import db


class Backup(db.Model):
    __tablename__ = 'backups'

    id = db.Column(db.Integer, primary_key=True)
    server_id = db.Column(db.Integer, db.ForeignKey('servers.id'), nullable=False)
    name = db.Column(db.String(255), nullable=False)
    filename = db.Column(db.String(512), nullable=False)
    size = db.Column(db.BigInteger, default=0)
    status = db.Column(db.String(20), default='pending')
    checksum = db.Column(db.String(64), nullable=True)
    is_scheduled = db.Column(db.Boolean, default=False)
    schedule_cron = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)

    @property
    def size_mb(self):
        return round(self.size / (1024 * 1024), 2) if self.size else 0

    def __repr__(self):
        return f'<Backup {self.name}>'
