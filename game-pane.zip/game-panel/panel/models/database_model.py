from datetime import datetime
from ..extensions import db


class ServerDatabase(db.Model):
    __tablename__ = 'server_databases'

    id = db.Column(db.Integer, primary_key=True)
    server_id = db.Column(db.Integer, db.ForeignKey('servers.id'), nullable=False)
    db_name = db.Column(db.String(100), nullable=False)
    db_type = db.Column(db.String(20), default='sqlite')
    db_host = db.Column(db.String(255), default='127.0.0.1')
    db_port = db.Column(db.Integer, default=3306)
    db_user = db.Column(db.String(100), nullable=True)
    db_password = db.Column(db.String(256), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<ServerDatabase {self.db_name}>'
