from datetime import datetime
from ..extensions import db


class Node(db.Model):
    __tablename__ = 'nodes'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    fqdn = db.Column(db.String(255), nullable=False)
    scheme = db.Column(db.String(10), default='http')
    daemon_port = db.Column(db.Integer, default=3001)
    daemon_secret = db.Column(db.String(128), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    is_public = db.Column(db.Boolean, default=True)
    memory_limit = db.Column(db.Integer, default=0)
    memory_overallocate = db.Column(db.Integer, default=0)
    disk_limit = db.Column(db.Integer, default=0)
    disk_overallocate = db.Column(db.Integer, default=0)
    upload_size = db.Column(db.Integer, default=512)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    last_heartbeat = db.Column(db.DateTime, nullable=True)
    cpu_percent = db.Column(db.Float, default=0.0)
    memory_used = db.Column(db.BigInteger, default=0)
    memory_total = db.Column(db.BigInteger, default=0)
    disk_used = db.Column(db.BigInteger, default=0)
    disk_total = db.Column(db.BigInteger, default=0)
    java_version = db.Column(db.String(50), nullable=True)
    os_info = db.Column(db.String(100), nullable=True)
    ping_ms = db.Column(db.Integer, default=0)

    allocations = db.relationship('Allocation', backref='node', lazy='dynamic',
                                  cascade='all, delete-orphan')
    servers = db.relationship('Server', backref='node', lazy='dynamic')

    @property
    def daemon_url(self):
        return f"{self.scheme}://{self.fqdn}:{self.daemon_port}"

    @property
    def is_online(self):
        if not self.last_heartbeat:
            return False
        delta = (datetime.utcnow() - self.last_heartbeat).total_seconds()
        return delta < 60

    @property
    def status(self):
        return 'online' if self.is_online else 'offline'

    def __repr__(self):
        return f'<Node {self.name}>'
