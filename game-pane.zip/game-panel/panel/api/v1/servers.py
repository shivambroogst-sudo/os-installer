from flask import Blueprint, request, jsonify
from ...models.server import Server
from ...models.allocation import Allocation
from ...utils.decorators import api_token_required
from ...utils.helpers import call_daemon

api_servers_bp = Blueprint('api_servers', __name__, url_prefix='/api/v1/servers')


@api_servers_bp.route('/', methods=['GET'])
@api_token_required
def list_servers(api_user=None):
    if api_user.role in ('owner', 'admin'):
        servers = Server.query.all()
    else:
        servers = Server.query.filter_by(owner_id=api_user.id).all()
    return jsonify([{
        'id': s.id, 'name': s.name, 'status': s.status,
        'node_id': s.node_id, 'owner_id': s.owner_id,
        'ram_limit': s.ram_limit, 'cpu_limit': s.cpu_limit,
        'disk_limit': s.disk_limit, 'is_suspended': s.is_suspended,
        'expiry_date': s.expiry_date.isoformat() if s.expiry_date else None,
        'remaining_days': s.remaining_days
    } for s in servers])


@api_servers_bp.route('/<int:server_id>', methods=['GET'])
@api_token_required
def get_server(server_id, api_user=None):
    server = Server.query.get_or_404(server_id)
    if api_user.role not in ('owner', 'admin') and server.owner_id != api_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    alloc = server.primary_allocation
    return jsonify({
        'id': server.id, 'name': server.name, 'status': server.status,
        'node_id': server.node_id, 'owner_id': server.owner_id,
        'ram_limit': server.ram_limit, 'cpu_limit': server.cpu_limit,
        'disk_limit': server.disk_limit, 'is_suspended': server.is_suspended,
        'startup_command': server.startup_command,
        'java_path': server.java_path,
        'auto_start': server.auto_start,
        'auto_restart': server.auto_restart,
        'expiry_date': server.expiry_date.isoformat() if server.expiry_date else None,
        'remaining_days': server.remaining_days,
        'allocation': {
            'ip': alloc.ip_address, 'port': alloc.port
        } if alloc else None
    })


@api_servers_bp.route('/<int:server_id>/power/<action>', methods=['POST'])
@api_token_required
def power_action(server_id, action, api_user=None):
    server = Server.query.get_or_404(server_id)
    if api_user.role not in ('owner', 'admin') and server.owner_id != api_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    if action not in ('start', 'stop', 'restart', 'kill'):
        return jsonify({'error': 'Invalid action'}), 400
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    data, err = call_daemon(node, 'POST', f'/api/servers/{server_id}/{action}', {})
    if err:
        return jsonify({'error': err}), 500
    return jsonify({'success': True})
