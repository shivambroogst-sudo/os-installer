from datetime import datetime
from flask import Blueprint, request, jsonify
from ...extensions import db
from ...models.node import Node
from ...models.server import Server
from ...utils.decorators import api_token_required, daemon_secret_required

api_nodes_bp = Blueprint('api_nodes', __name__, url_prefix='/api/v1/nodes')


@api_nodes_bp.route('/', methods=['GET'])
@api_token_required
def list_nodes(**kwargs):
    nodes = Node.query.filter_by(is_active=True).all()
    return jsonify([{
        'id': n.id, 'name': n.name, 'fqdn': n.fqdn,
        'daemon_port': n.daemon_port, 'status': n.status,
        'online': n.is_online, 'cpu': n.cpu_percent,
        'memory_used': n.memory_used, 'memory_total': n.memory_total,
        'disk_used': n.disk_used, 'disk_total': n.disk_total,
        'java_version': n.java_version, 'os_info': n.os_info,
        'ping_ms': n.ping_ms
    } for n in nodes])


@api_nodes_bp.route('/<int:node_id>', methods=['GET'])
@api_token_required
def get_node(node_id, **kwargs):
    node = Node.query.get_or_404(node_id)
    return jsonify({
        'id': node.id, 'name': node.name, 'fqdn': node.fqdn,
        'daemon_port': node.daemon_port, 'status': node.status,
        'online': node.is_online, 'cpu': node.cpu_percent,
        'memory_used': node.memory_used, 'memory_total': node.memory_total,
        'disk_used': node.disk_used, 'disk_total': node.disk_total,
        'java_version': node.java_version, 'os_info': node.os_info,
        'ping_ms': node.ping_ms, 'servers': node.servers.count()
    })
