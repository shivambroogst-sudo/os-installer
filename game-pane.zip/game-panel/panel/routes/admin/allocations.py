from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required
from ...extensions import db
from ...models.node import Node
from ...models.allocation import Allocation
from ...models.server import Server
from ...utils.decorators import admin_required
from ...utils.auth import log_activity
from ...utils.helpers import validate_ip, validate_port, parse_port_range

admin_allocations_bp = Blueprint('admin_allocations', __name__, url_prefix='/admin/allocations')


@admin_allocations_bp.route('/')
@login_required
@admin_required
def list_allocations():
    node_id = request.args.get('node_id', type=int)
    nodes = Node.query.filter_by(is_active=True).all()
    query = Allocation.query
    if node_id:
        query = query.filter_by(node_id=node_id)
    allocations = query.order_by(Allocation.ip_address, Allocation.port).all()
    return render_template('admin/allocations.html',
                           allocations=allocations, nodes=nodes, node_id=node_id)


@admin_allocations_bp.route('/add', methods=['POST'])
@login_required
@admin_required
def add_allocation():
    node_id = request.form.get('node_id', type=int)
    ip_address = request.form.get('ip_address', '').strip()
    ip_alias = request.form.get('ip_alias', '').strip() or None
    port_input = request.form.get('port', '').strip()
    notes = request.form.get('notes', '').strip() or None

    node = Node.query.get_or_404(node_id)

    if not validate_ip(ip_address):
        return jsonify({'error': f'Invalid IP address: {ip_address}'}), 400

    ports = parse_port_range(port_input)
    if not ports:
        ports_single = []
        try:
            p = int(port_input)
            if validate_port(p):
                ports_single = [p]
        except ValueError:
            pass
        if not ports_single:
            return jsonify({'error': 'Invalid port or port range'}), 400
        ports = ports_single

    added = 0
    skipped = 0
    for port in ports:
        existing = Allocation.query.filter_by(
            node_id=node_id, ip_address=ip_address, port=port
        ).first()
        if existing:
            skipped += 1
            continue
        alloc = Allocation(
            node_id=node_id,
            ip_address=ip_address,
            ip_alias=ip_alias,
            port=port,
            notes=notes
        )
        db.session.add(alloc)
        added += 1

    db.session.commit()
    log_activity('allocation_added', f'Added {added} allocations on {node.name} ({ip_address})')
    return jsonify({'success': True, 'added': added, 'skipped': skipped})


@admin_allocations_bp.route('/<int:alloc_id>/edit', methods=['POST'])
@login_required
@admin_required
def edit_allocation(alloc_id):
    alloc = Allocation.query.get_or_404(alloc_id)
    ip_address = request.form.get('ip_address', alloc.ip_address).strip()
    ip_alias = request.form.get('ip_alias', '').strip() or None
    port = request.form.get('port', type=int)
    notes = request.form.get('notes', '').strip() or None

    if not validate_ip(ip_address):
        return jsonify({'error': 'Invalid IP address'}), 400
    if port and not validate_port(port):
        return jsonify({'error': 'Invalid port'}), 400

    conflict = Allocation.query.filter(
        Allocation.node_id == alloc.node_id,
        Allocation.ip_address == ip_address,
        Allocation.port == (port or alloc.port),
        Allocation.id != alloc_id
    ).first()
    if conflict:
        return jsonify({'error': 'Allocation already exists'}), 400

    alloc.ip_address = ip_address
    alloc.ip_alias = ip_alias
    if port:
        alloc.port = port
    alloc.notes = notes
    db.session.commit()
    log_activity('allocation_updated', f'Updated allocation {alloc.display}')
    return jsonify({'success': True})


@admin_allocations_bp.route('/<int:alloc_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_allocation(alloc_id):
    alloc = Allocation.query.get_or_404(alloc_id)
    if alloc.server_id:
        return jsonify({'error': 'Cannot delete allocation assigned to a server'}), 400
    db.session.delete(alloc)
    db.session.commit()
    log_activity('allocation_deleted', f'Deleted allocation {alloc.display}')
    return jsonify({'success': True})


@admin_allocations_bp.route('/<int:alloc_id>/assign', methods=['POST'])
@login_required
@admin_required
def assign_allocation(alloc_id):
    alloc = Allocation.query.get_or_404(alloc_id)
    server_id = request.form.get('server_id', type=int)
    is_primary = request.form.get('is_primary') == 'true'

    if server_id:
        server = Server.query.get_or_404(server_id)
        if is_primary:
            Allocation.query.filter_by(server_id=server_id, is_primary=True).update({'is_primary': False})
        alloc.server_id = server_id
        alloc.is_primary = is_primary
        db.session.commit()
        return jsonify({'success': True, 'message': f'Assigned to {server.name}'})
    return jsonify({'error': 'Server ID required'}), 400


@admin_allocations_bp.route('/<int:alloc_id>/unassign', methods=['POST'])
@login_required
@admin_required
def unassign_allocation(alloc_id):
    alloc = Allocation.query.get_or_404(alloc_id)
    if alloc.is_primary:
        return jsonify({'error': 'Cannot unassign primary allocation. Assign a new primary first.'}), 400
    alloc.server_id = None
    alloc.is_primary = False
    db.session.commit()
    log_activity('allocation_unassigned', f'Unassigned allocation {alloc.display}')
    return jsonify({'success': True})


@admin_allocations_bp.route('/free')
@login_required
@admin_required
def free_allocations():
    node_id = request.args.get('node_id', type=int)
    query = Allocation.query.filter_by(server_id=None)
    if node_id:
        query = query.filter_by(node_id=node_id)
    allocs = query.all()
    return jsonify([{
        'id': a.id,
        'ip': a.ip_address,
        'alias': a.ip_alias,
        'port': a.port,
        'display': a.display,
        'node_id': a.node_id
    } for a in allocs])
