from functools import wraps
from flask import Blueprint, render_template, request, flash, redirect, url_for, abort
from flask_login import login_required, current_user
from ...extensions import db
from ...models.setting import Setting
from ...models.user import User
from ...utils.decorators import owner_required
from ...utils.auth import log_activity, hash_password, validate_password_strength, check_password

admin_settings_bp = Blueprint('admin_settings', __name__, url_prefix='/admin/settings')

DEFAULT_SETTINGS = {
    'panel_name':           'GamePanel',
    'panel_description':    'Game Server Management Panel',
    'registration_enabled': 'true',
    'max_servers_per_user': '5',
    'default_java_path':    'java',
    'maintenance_mode':     'false',
    'maintenance_message':  'We are under maintenance. Please check back later.',
    'panel_logo_url':       '',
    'panel_favicon_url':    '',
    'login_bg_video':       '',
    'register_bg_video':    '',
    'dashboard_bg_video':   '',
    'admin_bg_video':       '',
}


def admin_required_local(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role not in ('owner', 'admin'):
            abort(403)
        return f(*args, **kwargs)
    return decorated


@admin_settings_bp.route('/')
@login_required
@owner_required
def settings():
    settings_dict = {}
    for key, default in DEFAULT_SETTINGS.items():
        settings_dict[key] = Setting.get(key, default)
    return render_template('admin/settings.html', settings=settings_dict)


@admin_settings_bp.route('/save', methods=['POST'])
@login_required
@owner_required
def save_settings():
    for key in DEFAULT_SETTINGS:
        value = request.form.get(key)
        if value is not None:
            Setting.set(key, value)

    checkbox_keys = ['registration_enabled', 'maintenance_mode']
    for key in checkbox_keys:
        Setting.set(key, 'true' if request.form.get(key) == 'on' else 'false')

    log_activity('settings_updated', 'Panel settings updated')
    flash('Settings saved successfully.', 'success')
    return redirect(url_for('admin_settings.settings'))


@admin_settings_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        action = request.form.get('action')
        user = User.query.get(current_user.id)

        if action == 'update_profile':
            new_email = request.form.get('email', '').strip().lower()
            if new_email and new_email != user.email:
                if User.query.filter(User.email == new_email, User.id != user.id).first():
                    flash('Email already in use.', 'danger')
                    return redirect(url_for('admin_settings.profile'))
                user.email = new_email
            db.session.commit()
            flash('Profile updated.', 'success')

        elif action == 'change_password':
            old_pass = request.form.get('old_password', '')
            new_pass = request.form.get('new_password', '')
            confirm  = request.form.get('confirm_password', '')
            if not check_password(old_pass, user.password_hash):
                flash('Current password is incorrect.', 'danger')
                return redirect(url_for('admin_settings.profile'))
            if new_pass != confirm:
                flash('Passwords do not match.', 'danger')
                return redirect(url_for('admin_settings.profile'))
            ok, msg = validate_password_strength(new_pass)
            if not ok:
                flash(msg, 'danger')
                return redirect(url_for('admin_settings.profile'))
            user.password_hash = hash_password(new_pass)
            db.session.commit()
            flash('Password changed.', 'success')

        elif action == 'generate_token':
            token = user.generate_api_token()
            db.session.commit()
            flash(f'New API token: {token}', 'success')

        return redirect(url_for('admin_settings.profile'))

    return render_template('admin/profile.html', user=current_user)


@admin_settings_bp.route('/logs')
@login_required
@admin_required_local
def activity_logs():
    from ...models.activity import ActivityLog
    page   = request.args.get('page', 1, type=int)
    level  = request.args.get('level', '')
    search = request.args.get('search', '')
    query  = ActivityLog.query
    if level:
        query = query.filter_by(level=level)
    if search:
        query = query.filter(
            (ActivityLog.action.ilike(f'%{search}%')) |
            (ActivityLog.description.ilike(f'%{search}%'))
        )
    logs = query.order_by(ActivityLog.created_at.desc()).paginate(page=page, per_page=50)
    return render_template('admin/activity_logs.html', logs=logs, level=level, search=search)
