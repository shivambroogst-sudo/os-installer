from datetime import datetime, timedelta
from flask import Blueprint, render_template
from flask_login import login_required
from ...extensions import db
from ...models.user import User
from ...models.server import Server
from ...models.node import Node
from ...models.activity import ActivityLog
from ...models.notification import Notification
from ...utils.decorators import admin_required

admin_dashboard_bp = Blueprint('admin_dashboard', __name__, url_prefix='/admin')


@admin_dashboard_bp.route('/dashboard')
@login_required
@admin_required
def dashboard():
    total_users = User.query.count()
    total_servers = Server.query.count()
    total_nodes = Node.query.count()
    active_servers = Server.query.filter_by(status='running').count()
    suspended_servers = Server.query.filter_by(is_suspended=True).count()
    online_nodes = [n for n in Node.query.filter_by(is_active=True).all() if n.is_online]

    expiring_soon = Server.query.filter(
        Server.expiry_date.isnot(None),
        Server.expiry_date <= datetime.utcnow() + timedelta(days=7),
        Server.expiry_date > datetime.utcnow(),
        Server.is_suspended == False
    ).all()

    recent_activity = ActivityLog.query.order_by(
        ActivityLog.created_at.desc()
    ).limit(10).all()

    unread_notifications = Notification.query.filter_by(
        user_id=1, is_read=False
    ).count()

    nodes = Node.query.filter_by(is_active=True).all()
    node_stats = []
    for node in nodes:
        node_stats.append({
            'node': node,
            'online': node.is_online,
            'servers': Server.query.filter_by(node_id=node.id).count()
        })

    return render_template('admin/dashboard.html',
                           total_users=total_users,
                           total_servers=total_servers,
                           total_nodes=total_nodes,
                           active_servers=active_servers,
                           suspended_servers=suspended_servers,
                           online_nodes=len(online_nodes),
                           expiring_soon=expiring_soon,
                           recent_activity=recent_activity,
                           node_stats=node_stats,
                           unread_notifications=unread_notifications)
