import secrets
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required
from ...extensions import db
from ...models.node import Node
from ...models.server import Server
from ...models.allocation import Allocation
from ...utils.decorators import admin_required
from ...utils.auth import log_activity
from ...utils.helpers import call_daemon

admin_nodes_bp = Blueprint('admin_nodes', __name__, url_prefix='/admin/nodes')


@admin_nodes_bp.route('/')
@login_required
@admin_required
def list_nodes():
    nodes = Node.query.all()
    return render_template('admin/nodes.html', nodes=nodes)


@admin_nodes_bp.route('/create', methods=['GET', 'POST'])
@login_required
@admin_required
def create_node():
    if request.method == 'POST':
        daemon_secret = secrets.token_hex(32)
        node = Node(
            name=request.form.get('name', '').strip(),
            description=request.form.get('description', ''),
            fqdn=request.form.get('fqdn', '').strip(),
            scheme=request.form.get('scheme', 'http'),
            daemon_port=int(request.form.get('daemon_port', 3001)),
            daemon_secret=daemon_secret,
            is_active=request.form.get('is_active') == 'on',
            is_public=request.form.get('is_public') == 'on',
            memory_limit=int(request.form.get('memory_limit', 0)),
            disk_limit=int(request.form.get('disk_limit', 0)),
        )
        db.session.add(node)
        db.session.commit()
        log_activity('node_created', f'Created node: {node.name}')
        flash(f'Node "{node.name}" created. Daemon secret: {daemon_secret}', 'success')
        return redirect(url_for('admin_nodes.list_nodes'))
    return render_template('admin/node_form.html', action='Create', node=None)


@admin_nodes_bp.route('/<int:node_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_node(node_id):
    node = Node.query.get_or_404(node_id)
    if request.method == 'POST':
        node.name = request.form.get('name', node.name).strip()
        node.description = request.form.get('description', '')
        node.fqdn = request.form.get('fqdn', node.fqdn).strip()
        node.scheme = request.form.get('scheme', 'http')
        node.daemon_port = int(request.form.get('daemon_port', node.daemon_port))
        node.is_active = request.form.get('is_active') == 'on'
        node.is_public = request.form.get('is_public') == 'on'
        node.memory_limit = int(request.form.get('memory_limit', 0))
        node.disk_limit = int(request.form.get('disk_limit', 0))
        if request.form.get('regenerate_secret') == 'on':
            node.daemon_secret = secrets.token_hex(32)
            flash(f'New daemon secret: {node.daemon_secret}', 'warning')
        db.session.commit()
        log_activity('node_updated', f'Updated node: {node.name}')
        flash('Node updated.', 'success')
        return redirect(url_for('admin_nodes.list_nodes'))
    return render_template('admin/node_form.html', action='Edit', node=node)


@admin_nodes_bp.route('/<int:node_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_node(node_id):
    node = Node.query.get_or_404(node_id)
    if Server.query.filter_by(node_id=node_id).first():
        return jsonify({'error': 'Cannot delete node with active servers'}), 400
    name = node.name
    db.session.delete(node)
    db.session.commit()
    log_activity('node_deleted', f'Deleted node: {name}')
    return jsonify({'success': True})


@admin_nodes_bp.route('/<int:node_id>/heartbeat')
@login_required
@admin_required
def node_heartbeat(node_id):
    node = Node.query.get_or_404(node_id)
    data, err = call_daemon(node, 'GET', '/api/stats')
    if err:
        return jsonify({'online': False, 'error': err})
    return jsonify({'online': True, **data})


@admin_nodes_bp.route('/<int:node_id>')
@login_required
@admin_required
def node_detail(node_id):
    node = Node.query.get_or_404(node_id)
    servers = Server.query.filter_by(node_id=node_id).all()
    allocations = Allocation.query.filter_by(node_id=node_id).all()
    return render_template('admin/node_detail.html',
                           node=node, servers=servers, allocations=allocations)
