from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required
from ...extensions import db
from ...models.backup import Backup
from ...models.server import Server
from ...utils.decorators import admin_required
from ...utils.auth import log_activity
from ...utils.helpers import call_daemon

admin_backups_bp = Blueprint('admin_backups', __name__, url_prefix='/admin/backups')


@admin_backups_bp.route('/')
@login_required
@admin_required
def list_backups():
    page = request.args.get('page', 1, type=int)
    server_id = request.args.get('server_id', type=int)
    query = Backup.query
    if server_id:
        query = query.filter_by(server_id=server_id)
    backups = query.order_by(Backup.created_at.desc()).paginate(page=page, per_page=20)
    servers = Server.query.all()
    return render_template('admin/backups.html', backups=backups, servers=servers, server_id=server_id)


@admin_backups_bp.route('/create', methods=['POST'])
@login_required
@admin_required
def create_backup():
    server_id = request.form.get('server_id', type=int)
    backup_name = request.form.get('name', '').strip()
    server = Server.query.get_or_404(server_id)
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    backup = Backup(
        server_id=server_id,
        name=backup_name or f'backup_{server.folder_number}',
        filename=f'backup_{server.folder_number}_{int(__import__("time").time())}.zip',
        status='pending'
    )
    db.session.add(backup)
    db.session.commit()
    data, err = call_daemon(node, 'POST', f'/api/servers/{server_id}/backups/create', {
        'backup_id': backup.id,
        'name': backup.name,
        'filename': backup.filename
    })
    if err:
        backup.status = 'failed'
        db.session.commit()
        return jsonify({'error': err}), 500
    log_activity('backup_created', f'Backup created for {server.name}', server_id=server_id)
    return jsonify({'success': True, 'backup_id': backup.id})


@admin_backups_bp.route('/<int:backup_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_backup(backup_id):
    backup = Backup.query.get_or_404(backup_id)
    server = backup.server
    node = server.node if server else None
    if node:
        call_daemon(node, 'DELETE', f'/api/servers/{backup.server_id}/backups/{backup_id}', {})
    db.session.delete(backup)
    db.session.commit()
    log_activity('backup_deleted', f'Deleted backup: {backup.name}')
    return jsonify({'success': True})


@admin_backups_bp.route('/<int:backup_id>/restore', methods=['POST'])
@login_required
@admin_required
def restore_backup(backup_id):
    backup = Backup.query.get_or_404(backup_id)
    server = backup.server
    node = server.node if server else None
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    data, err = call_daemon(node, 'POST', f'/api/servers/{backup.server_id}/backups/{backup_id}/restore', {})
    if err:
        return jsonify({'error': err}), 500
    log_activity('backup_restored', f'Restored backup: {backup.name}', server_id=backup.server_id)
    return jsonify({'success': True})
