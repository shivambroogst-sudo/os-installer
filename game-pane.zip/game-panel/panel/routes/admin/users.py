from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from ...extensions import db
from ...models.user import User, AdminPermission
from ...models.server import Server
from ...models.activity import ActivityLog
from ...utils.auth import hash_password, validate_password_strength, log_activity
from ...utils.decorators import admin_required, permission_required

admin_users_bp = Blueprint('admin_users', __name__, url_prefix='/admin/users')


@admin_users_bp.route('/')
@login_required
@admin_required
def list_users():
    if not current_user.has_permission('can_manage_users'):
        from flask import abort
        abort(403)
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    query = User.query
    if search:
        query = query.filter(
            (User.username.ilike(f'%{search}%')) |
            (User.email.ilike(f'%{search}%'))
        )
    users = query.order_by(User.created_at.desc()).paginate(page=page, per_page=20)
    return render_template('admin/users.html', users=users, search=search)


@admin_users_bp.route('/create', methods=['GET', 'POST'])
@login_required
@admin_required
def create_user():
    if not current_user.has_permission('can_manage_users'):
        from flask import abort
        abort(403)
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        role = request.form.get('role', 'user')

        if current_user.role != 'owner' and role in ('owner', 'admin'):
            flash('You cannot assign owner or admin roles.', 'danger')
            return redirect(url_for('admin_users.create_user'))

        errors = []
        if User.query.filter_by(username=username).first():
            errors.append('Username already taken.')
        if User.query.filter_by(email=email).first():
            errors.append('Email already registered.')
        ok, msg = validate_password_strength(password)
        if not ok:
            errors.append(msg)

        if errors:
            for e in errors:
                flash(e, 'danger')
            return render_template('admin/user_form.html', action='Create', user=None)

        user = User(username=username, email=email,
                    password_hash=hash_password(password),
                    role=role, is_active=True)
        db.session.add(user)
        db.session.flush()

        if role == 'admin':
            perms = AdminPermission(
                user_id=user.id,
                can_manage_users=request.form.get('perm_users') == 'on',
                can_manage_servers=request.form.get('perm_servers') == 'on',
                can_manage_nodes=request.form.get('perm_nodes') == 'on',
                can_manage_allocations=request.form.get('perm_allocations') == 'on',
                can_manage_settings=request.form.get('perm_settings') == 'on',
                can_manage_backups=request.form.get('perm_backups') == 'on',
                can_manage_databases=request.form.get('perm_databases') == 'on',
                can_view_analytics=request.form.get('perm_analytics') == 'on',
                can_view_logs=request.form.get('perm_logs') == 'on',
            )
            db.session.add(perms)

        db.session.commit()
        log_activity('user_created', f'Created user: {username}')
        flash(f'User {username} created successfully.', 'success')
        return redirect(url_for('admin_users.list_users'))

    return render_template('admin/user_form.html', action='Create', user=None)


@admin_users_bp.route('/<int:user_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_user(user_id):
    if not current_user.has_permission('can_manage_users'):
        from flask import abort
        abort(403)
    user = User.query.get_or_404(user_id)

    if user.role == 'owner' and current_user.role != 'owner':
        flash('Cannot edit owner account.', 'danger')
        return redirect(url_for('admin_users.list_users'))

    if request.method == 'POST':
        user.email = request.form.get('email', user.email).strip().lower()
        new_role = request.form.get('role', user.role)
        if current_user.role == 'owner':
            user.role = new_role
        user.is_active = request.form.get('is_active') == 'on'

        new_pass = request.form.get('password', '')
        if new_pass:
            ok, msg = validate_password_strength(new_pass)
            if not ok:
                flash(msg, 'danger')
                return render_template('admin/user_form.html', action='Edit', user=user)
            user.password_hash = hash_password(new_pass)

        if user.role == 'admin':
            if not user.admin_permissions:
                perms = AdminPermission(user_id=user.id)
                db.session.add(perms)
                db.session.flush()
            else:
                perms = user.admin_permissions
            perms.can_manage_users = request.form.get('perm_users') == 'on'
            perms.can_manage_servers = request.form.get('perm_servers') == 'on'
            perms.can_manage_nodes = request.form.get('perm_nodes') == 'on'
            perms.can_manage_allocations = request.form.get('perm_allocations') == 'on'
            perms.can_manage_settings = request.form.get('perm_settings') == 'on'
            perms.can_manage_backups = request.form.get('perm_backups') == 'on'
            perms.can_manage_databases = request.form.get('perm_databases') == 'on'
            perms.can_view_analytics = request.form.get('perm_analytics') == 'on'
            perms.can_view_logs = request.form.get('perm_logs') == 'on'

        db.session.commit()
        log_activity('user_updated', f'Updated user: {user.username}')
        flash('User updated successfully.', 'success')
        return redirect(url_for('admin_users.list_users'))

    return render_template('admin/user_form.html', action='Edit', user=user)


@admin_users_bp.route('/<int:user_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_user(user_id):
    if not current_user.has_permission('can_manage_users'):
        from flask import abort
        abort(403)
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        return jsonify({'error': 'Cannot delete yourself'}), 400
    if user.role == 'owner':
        return jsonify({'error': 'Cannot delete owner'}), 400
    username = user.username
    db.session.delete(user)
    db.session.commit()
    log_activity('user_deleted', f'Deleted user: {username}')
    return jsonify({'success': True})


@admin_users_bp.route('/<int:user_id>/generate-token', methods=['POST'])
@login_required
@admin_required
def generate_token(user_id):
    user = User.query.get_or_404(user_id)
    token = user.generate_api_token()
    db.session.commit()
    return jsonify({'token': token})


@admin_users_bp.route('/<int:user_id>/servers')
@login_required
@admin_required
def user_servers(user_id):
    user = User.query.get_or_404(user_id)
    servers = Server.query.filter_by(owner_id=user_id).all()
    return jsonify({'servers': [{'id': s.id, 'name': s.name} for s in servers]})
