from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required
from ...extensions import db
from ...models.database_model import ServerDatabase
from ...models.server import Server
from ...utils.decorators import admin_required
from ...utils.auth import log_activity
import secrets
import string

admin_databases_bp = Blueprint('admin_databases', __name__, url_prefix='/admin/databases')


def generate_db_password(length=16):
    chars = string.ascii_letters + string.digits
    return ''.join(secrets.choice(chars) for _ in range(length))


@admin_databases_bp.route('/')
@login_required
@admin_required
def list_databases():
    page = request.args.get('page', 1, type=int)
    server_id = request.args.get('server_id', type=int)
    query = ServerDatabase.query
    if server_id:
        query = query.filter_by(server_id=server_id)
    databases = query.order_by(ServerDatabase.created_at.desc()).paginate(page=page, per_page=20)
    servers = Server.query.all()
    return render_template('admin/databases.html', databases=databases, servers=servers, server_id=server_id)


@admin_databases_bp.route('/create', methods=['POST'])
@login_required
@admin_required
def create_database():
    server_id = request.form.get('server_id', type=int)
    db_name = request.form.get('db_name', '').strip()
    db_type = request.form.get('db_type', 'sqlite')
    db_host = request.form.get('db_host', '127.0.0.1').strip()
    db_port = request.form.get('db_port', 3306, type=int)
    db_user = request.form.get('db_user', '').strip() or None
    notes = request.form.get('notes', '').strip() or None

    if not db_name or not server_id:
        return jsonify({'error': 'Name and server required'}), 400

    server = Server.query.get_or_404(server_id)
    database = ServerDatabase(
        server_id=server_id,
        db_name=db_name,
        db_type=db_type,
        db_host=db_host,
        db_port=db_port,
        db_user=db_user,
        db_password=generate_db_password(),
        notes=notes
    )
    db.session.add(database)
    db.session.commit()
    log_activity('database_created', f'Database {db_name} created for {server.name}', server_id=server_id)
    return jsonify({'success': True, 'db_id': database.id})


@admin_databases_bp.route('/<int:db_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_database(db_id):
    database = ServerDatabase.query.get_or_404(db_id)
    name = database.db_name
    db.session.delete(database)
    db.session.commit()
    log_activity('database_deleted', f'Database {name} deleted')
    return jsonify({'success': True})


@admin_databases_bp.route('/<int:db_id>/reset-password', methods=['POST'])
@login_required
@admin_required
def reset_password(db_id):
    database = ServerDatabase.query.get_or_404(db_id)
    new_pass = generate_db_password()
    database.db_password = new_pass
    db.session.commit()
    return jsonify({'success': True, 'password': new_pass})
