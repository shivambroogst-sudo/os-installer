from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from flask_login import login_user, logout_user, login_required, current_user
from ..extensions import db, limiter
from ..models.user import User
from ..utils.auth import hash_password, check_password, validate_password_strength, log_activity

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/')
def index():
    if current_user.is_authenticated:
        if current_user.role in ('owner', 'admin'):
            return redirect(url_for('admin_dashboard.dashboard'))
        return redirect(url_for('user_dashboard.dashboard'))
    return redirect(url_for('auth.login'))


@auth_bp.route('/auth/login', methods=['GET', 'POST'])
@limiter.limit('20 per minute')
def login():
    if current_user.is_authenticated:
        return redirect(url_for('auth.index'))

    if request.method == 'POST':
        identifier = request.form.get('identifier', '').strip()
        password = request.form.get('password', '')
        remember = request.form.get('remember') == 'on'

        user = User.query.filter(
            (User.username == identifier) | (User.email == identifier)
        ).first()

        if not user or not check_password(password, user.password_hash):
            flash('Invalid username/email or password.', 'danger')
            log_activity('login_failed', f'Failed login for: {identifier}', 'warning')
            return render_template('auth/login.html')

        if not user.is_active:
            flash('Your account has been suspended. Contact an administrator.', 'danger')
            return render_template('auth/login.html')

        login_user(user, remember=remember)
        user.last_login = datetime.utcnow()
        db.session.commit()
        log_activity('login', f'User logged in: {user.username}')

        next_page = request.args.get('next')
        if next_page and next_page.startswith('/'):
            return redirect(next_page)

        if user.role in ('owner', 'admin'):
            return redirect(url_for('admin_dashboard.dashboard'))
        return redirect(url_for('user_dashboard.dashboard'))

    return render_template('auth/login.html')


@auth_bp.route('/auth/register', methods=['GET', 'POST'])
@limiter.limit('10 per hour')
def register():
    if current_user.is_authenticated:
        return redirect(url_for('auth.index'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')

        errors = []
        if not username or len(username) < 3:
            errors.append('Username must be at least 3 characters.')
        if not email or '@' not in email:
            errors.append('Invalid email address.')
        if password != confirm:
            errors.append('Passwords do not match.')

        ok, msg = validate_password_strength(password)
        if not ok:
            errors.append(msg)

        if User.query.filter_by(username=username).first():
            errors.append('Username already taken.')
        if User.query.filter_by(email=email).first():
            errors.append('Email already registered.')

        if errors:
            for e in errors:
                flash(e, 'danger')
            return render_template('auth/register.html')

        user = User(
            username=username,
            email=email,
            password_hash=hash_password(password),
            role='user',
            is_active=True
        )
        db.session.add(user)
        db.session.commit()
        log_activity('register', f'New user registered: {username}', user_id=user.id)
        flash('Account created! Please log in.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('auth/register.html')


@auth_bp.route('/auth/logout')
@login_required
def logout():
    log_activity('logout', f'User logged out: {current_user.username}')
    logout_user()
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))


@auth_bp.route('/auth/forgot-password', methods=['GET', 'POST'])
@limiter.limit('5 per hour')
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        user = User.query.filter_by(email=email).first()
        if user:
            token = user.generate_reset_token()
            db.session.commit()
            reset_url = url_for('auth.reset_password', token=token, _external=True)
            flash(f'Password reset link: {reset_url}', 'info')
        else:
            flash('If that email exists, a reset link has been sent.', 'info')
        return redirect(url_for('auth.login'))
    return render_template('auth/forgot_password.html')


@auth_bp.route('/auth/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    user = User.query.filter_by(reset_token=token).first()
    if not user or not user.reset_token_expires or datetime.utcnow() > user.reset_token_expires:
        flash('Invalid or expired reset link.', 'danger')
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')
        if password != confirm:
            flash('Passwords do not match.', 'danger')
            return render_template('auth/reset_password.html', token=token)
        ok, msg = validate_password_strength(password)
        if not ok:
            flash(msg, 'danger')
            return render_template('auth/reset_password.html', token=token)
        user.password_hash = hash_password(password)
        user.reset_token = None
        user.reset_token_expires = None
        db.session.commit()
        log_activity('password_reset', f'Password reset for: {user.username}', user_id=user.id)
        flash('Password reset successfully. Please log in.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('auth/reset_password.html', token=token)
