import os
from flask import Blueprint, render_template, request, jsonify, send_file
from flask_login import login_required
from ...models.server import Server
from ...utils.helpers import call_daemon
from ...utils.decorators import server_access_required
from ...utils.auth import log_activity

user_files_bp = Blueprint('user_files', __name__, url_prefix='/server')


@user_files_bp.route('/<int:server_id>/files')
@login_required
@server_access_required
def file_manager(server_id, server=None):
    if server.is_suspended:
        return render_template('user/suspended.html', server=server)
    path = request.args.get('path', '/')
    return render_template('user/files.html', server=server, current_path=path)


@user_files_bp.route('/<int:server_id>/files/list')
@login_required
@server_access_required
def list_files(server_id, server=None):
    path = request.args.get('path', '/')
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    data, err = call_daemon(node, 'GET',
                            f'/api/servers/{server_id}/files/list?path={path}')
    if err:
        return jsonify({'error': err}), 500
    return jsonify(data)


@user_files_bp.route('/<int:server_id>/files/read')
@login_required
@server_access_required
def read_file(server_id, server=None):
    path = request.args.get('path', '')
    if not path:
        return jsonify({'error': 'Path required'}), 400
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    data, err = call_daemon(node, 'GET',
                            f'/api/servers/{server_id}/files/read?path={path}')
    if err:
        return jsonify({'error': err}), 500
    return jsonify(data)


@user_files_bp.route('/<int:server_id>/files/write', methods=['POST'])
@login_required
@server_access_required
def write_file(server_id, server=None):
    path = request.json.get('path', '')
    content = request.json.get('content', '')
    if not path:
        return jsonify({'error': 'Path required'}), 400
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    data, err = call_daemon(node, 'POST',
                            f'/api/servers/{server_id}/files/write',
                            {'path': path, 'content': content})
    if err:
        return jsonify({'error': err}), 500
    log_activity('file_write', f'Edited file: {path}', server_id=server_id)
    return jsonify({'success': True})


@user_files_bp.route('/<int:server_id>/files/create-folder', methods=['POST'])
@login_required
@server_access_required
def create_folder(server_id, server=None):
    path = request.json.get('path', '')
    name = request.json.get('name', '')
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    data, err = call_daemon(node, 'POST',
                            f'/api/servers/{server_id}/files/mkdir',
                            {'path': path, 'name': name})
    if err:
        return jsonify({'error': err}), 500
    return jsonify({'success': True})


@user_files_bp.route('/<int:server_id>/files/delete', methods=['POST'])
@login_required
@server_access_required
def delete_file(server_id, server=None):
    paths = request.json.get('paths', [])
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    data, err = call_daemon(node, 'POST',
                            f'/api/servers/{server_id}/files/delete',
                            {'paths': paths})
    if err:
        return jsonify({'error': err}), 500
    log_activity('file_delete', f'Deleted files: {paths}', server_id=server_id)
    return jsonify({'success': True})


@user_files_bp.route('/<int:server_id>/files/rename', methods=['POST'])
@login_required
@server_access_required
def rename_file(server_id, server=None):
    from_path = request.json.get('from', '')
    to_path = request.json.get('to', '')
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    data, err = call_daemon(node, 'POST',
                            f'/api/servers/{server_id}/files/rename',
                            {'from': from_path, 'to': to_path})
    if err:
        return jsonify({'error': err}), 500
    return jsonify({'success': True})


@user_files_bp.route('/<int:server_id>/files/upload', methods=['POST'])
@login_required
@server_access_required
def upload_file(server_id, server=None):
    path = request.form.get('path', '/')
    files = request.files.getlist('files')
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    results = []
    for f in files:
        import requests as req
        try:
            resp = req.post(
                f"{node.daemon_url}/api/servers/{server_id}/files/upload",
                params={'path': path},
                files={'file': (f.filename, f.stream, f.mimetype)},
                headers={'X-Daemon-Secret': node.daemon_secret},
                timeout=60
            )
            results.append({'name': f.filename, 'success': resp.status_code == 200})
        except Exception as e:
            results.append({'name': f.filename, 'success': False, 'error': str(e)})
    log_activity('file_upload', f'Uploaded {len(files)} file(s)', server_id=server_id)
    return jsonify({'results': results})


@user_files_bp.route('/<int:server_id>/files/extract', methods=['POST'])
@login_required
@server_access_required
def extract_archive(server_id, server=None):
    path = request.json.get('path', '')
    destination = request.json.get('destination', '/')
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    data, err = call_daemon(node, 'POST',
                            f'/api/servers/{server_id}/files/extract',
                            {'path': path, 'destination': destination})
    if err:
        return jsonify({'error': err}), 500
    return jsonify({'success': True})


@user_files_bp.route('/<int:server_id>/files/search')
@login_required
@server_access_required
def search_files(server_id, server=None):
    query = request.args.get('q', '')
    path = request.args.get('path', '/')
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    data, err = call_daemon(node, 'GET',
                            f'/api/servers/{server_id}/files/search?q={query}&path={path}')
    if err:
        return jsonify({'error': err}), 500
    return jsonify(data)
