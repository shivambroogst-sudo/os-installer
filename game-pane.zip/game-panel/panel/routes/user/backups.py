from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required
from ...extensions import db
from ...models.backup import Backup
from ...models.server import Server
from ...utils.helpers import call_daemon
from ...utils.decorators import server_access_required
from ...utils.auth import log_activity
import time

user_backups_bp = Blueprint('user_backups', __name__, url_prefix='/server')


@user_backups_bp.route('/<int:server_id>/backups')
@login_required
@server_access_required
def list_backups(server_id, server=None):
    backups = Backup.query.filter_by(server_id=server_id).order_by(Backup.created_at.desc()).all()
    return render_template('user/backups.html', server=server, backups=backups)


@user_backups_bp.route('/<int:server_id>/backups/create', methods=['POST'])
@login_required
@server_access_required
def create_backup(server_id, server=None):
    if server.is_suspended:
        return jsonify({'error': 'Server is suspended'}), 403
    name = request.form.get('name', f'backup_{int(time.time())}')
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400

    backup = Backup(
        server_id=server_id,
        name=name,
        filename=f'backup_{server.folder_number}_{int(time.time())}.zip',
        status='pending'
    )
    db.session.add(backup)
    db.session.commit()

    data, err = call_daemon(node, 'POST', f'/api/servers/{server_id}/backups/create', {
        'backup_id': backup.id,
        'name': backup.name,
        'filename': backup.filename
    })
    if err:
        backup.status = 'failed'
        db.session.commit()
        return jsonify({'error': err}), 500
    log_activity('backup_created', f'Backup: {name}', server_id=server_id)
    return jsonify({'success': True, 'backup_id': backup.id})


@user_backups_bp.route('/<int:server_id>/backups/<int:backup_id>/delete', methods=['POST'])
@login_required
@server_access_required
def delete_backup(server_id, backup_id, server=None):
    backup = Backup.query.filter_by(id=backup_id, server_id=server_id).first_or_404()
    node = server.node
    if node:
        call_daemon(node, 'DELETE', f'/api/servers/{server_id}/backups/{backup_id}', {})
    db.session.delete(backup)
    db.session.commit()
    return jsonify({'success': True})


@user_backups_bp.route('/<int:server_id>/backups/<int:backup_id>/restore', methods=['POST'])
@login_required
@server_access_required
def restore_backup(server_id, backup_id, server=None):
    backup = Backup.query.filter_by(id=backup_id, server_id=server_id).first_or_404()
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    data, err = call_daemon(node, 'POST',
                            f'/api/servers/{server_id}/backups/{backup_id}/restore', {})
    if err:
        return jsonify({'error': err}), 500
    log_activity('backup_restored', f'Restored backup: {backup.name}', server_id=server_id)
    return jsonify({'success': True})
