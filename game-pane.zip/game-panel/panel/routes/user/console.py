from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from ...models.server import Server
from ...utils.helpers import call_daemon
from ...utils.decorators import server_access_required
from ...utils.auth import log_activity

user_console_bp = Blueprint('user_console', __name__, url_prefix='/server')


@user_console_bp.route('/<int:server_id>/console')
@login_required
@server_access_required
def console(server_id, server=None):
    if server.is_suspended:
        return render_template('user/suspended.html', server=server)
    alloc = server.primary_allocation
    return render_template('user/console.html', server=server, allocation=alloc)


@user_console_bp.route('/<int:server_id>/power/<action>', methods=['POST'])
@login_required
@server_access_required
def power_action(server_id, action, server=None):
    if action not in ('start', 'stop', 'restart', 'kill'):
        return jsonify({'error': 'Invalid action'}), 400
    if server.is_suspended:
        return jsonify({'error': 'Server is suspended'}), 403
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    if not node.is_online:
        return jsonify({'error': 'Node is offline'}), 503
    data, err = call_daemon(node, 'POST', f'/api/servers/{server_id}/{action}', {})
    if err:
        return jsonify({'error': err}), 500
    log_activity(f'server_{action}', f'{action} server: {server.name}', server_id=server_id)
    return jsonify({'success': True})


@user_console_bp.route('/<int:server_id>/stats')
@login_required
@server_access_required
def server_stats(server_id, server=None):
    node = server.node
    if not node or not node.is_online:
        return jsonify({'status': server.status, 'online': False})
    data, err = call_daemon(node, 'GET', f'/api/servers/{server_id}/stats')
    if err:
        return jsonify({'status': server.status, 'online': False, 'error': err})
    return jsonify({**data, 'online': True, 'status': server.status})


@user_console_bp.route('/<int:server_id>/send-command', methods=['POST'])
@login_required
@server_access_required
def send_command(server_id, server=None):
    command = request.json.get('command', '').strip()
    if not command:
        return jsonify({'error': 'Command required'}), 400
    node = server.node
    if not node or not node.is_online:
        return jsonify({'error': 'Node offline'}), 503
    data, err = call_daemon(node, 'POST', f'/api/servers/{server_id}/command', {'command': command})
    if err:
        return jsonify({'error': err}), 500
    return jsonify({'success': True})
