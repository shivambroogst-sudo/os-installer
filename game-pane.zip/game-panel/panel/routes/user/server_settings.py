from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import login_required, current_user
from ...extensions import db
from ...models.server import Server
from ...utils.decorators import server_access_required
from ...utils.auth import log_activity

user_server_settings_bp = Blueprint('user_server_settings', __name__, url_prefix='/server')


@user_server_settings_bp.route('/<int:server_id>/settings', methods=['GET', 'POST'])
@login_required
@server_access_required
def server_settings(server_id, server=None):
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'rename':
            new_name = request.form.get('name', '').strip()
            if new_name and len(new_name) >= 2:
                old_name = server.name
                server.name = new_name[:64]
                db.session.commit()
                log_activity('server_renamed', f'Renamed server: {old_name} → {new_name}',
                             server_id=server.id)
                flash('Server renamed successfully.', 'success')
            else:
                flash('Name must be at least 2 characters.', 'danger')
        return redirect(url_for('user_server_settings.server_settings', server_id=server_id))

    return render_template('user/server_settings.html', server=server)
