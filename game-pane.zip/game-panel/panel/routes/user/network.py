from flask import Blueprint, render_template
from flask_login import login_required
from ...utils.decorators import server_access_required

user_network_bp = Blueprint('user_network', __name__, url_prefix='/server')


@user_network_bp.route('/<int:server_id>/network')
@login_required
@server_access_required
def network(server_id, server=None):
    allocations = server.allocations if server.allocations else []
    primary = server.primary_allocation
    return render_template('user/network.html',
                           server=server,
                           allocations=allocations,
                           primary=primary)
