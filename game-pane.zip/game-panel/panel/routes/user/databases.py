from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required
from ...extensions import db
from ...models.database_model import ServerDatabase
from ...utils.decorators import server_access_required
from ...utils.auth import log_activity
import secrets
import string

user_databases_bp = Blueprint('user_databases', __name__, url_prefix='/server')


def gen_password(length=16):
    chars = string.ascii_letters + string.digits
    return ''.join(secrets.choice(chars) for _ in range(length))


@user_databases_bp.route('/<int:server_id>/databases')
@login_required
@server_access_required
def list_databases(server_id, server=None):
    databases = ServerDatabase.query.filter_by(server_id=server_id).all()
    return render_template('user/databases.html', server=server, databases=databases)


@user_databases_bp.route('/<int:server_id>/databases/create', methods=['POST'])
@login_required
@server_access_required
def create_database(server_id, server=None):
    db_name = request.form.get('db_name', '').strip()
    if not db_name:
        return jsonify({'error': 'Database name required'}), 400
    database = ServerDatabase(
        server_id=server_id,
        db_name=db_name,
        db_type='sqlite',
        db_password=gen_password()
    )
    db.session.add(database)
    db.session.commit()
    log_activity('db_created', f'Database {db_name} created', server_id=server_id)
    return jsonify({'success': True})


@user_databases_bp.route('/<int:server_id>/databases/<int:db_id>/delete', methods=['POST'])
@login_required
@server_access_required
def delete_database(server_id, db_id, server=None):
    database = ServerDatabase.query.filter_by(id=db_id, server_id=server_id).first_or_404()
    name = database.db_name
    db.session.delete(database)
    db.session.commit()
    log_activity('db_deleted', f'Database {name} deleted', server_id=server_id)
    return jsonify({'success': True})


@user_databases_bp.route('/<int:server_id>/databases/<int:db_id>/reset-password', methods=['POST'])
@login_required
@server_access_required
def reset_password(server_id, db_id, server=None):
    database = ServerDatabase.query.filter_by(id=db_id, server_id=server_id).first_or_404()
    new_pass = gen_password()
    database.db_password = new_pass
    db.session.commit()
    return jsonify({'success': True, 'password': new_pass})
