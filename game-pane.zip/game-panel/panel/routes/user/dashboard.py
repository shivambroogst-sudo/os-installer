from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user
from ...extensions import db
from ...models.server import Server
from ...models.notification import Notification
from ...utils.helpers import call_daemon

user_dashboard_bp = Blueprint('user_dashboard', __name__, url_prefix='/user')


@user_dashboard_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role in ('owner', 'admin'):
        return redirect(url_for('admin_dashboard.dashboard'))

    servers = Server.query.filter_by(owner_id=current_user.id).all()
    server_stats = []
    for server in servers:
        stat = {
            'server': server,
            'status': server.status,
            'ram_used': 0,
            'cpu_used': 0.0,
            'disk_used': 0
        }
        if server.node and server.node.is_online and server.status == 'running':
            data, _ = call_daemon(server.node, 'GET', f'/api/servers/{server.id}/stats')
            if data:
                stat['ram_used'] = data.get('ram_used', 0)
                stat['cpu_used'] = data.get('cpu_used', 0.0)
                stat['disk_used'] = data.get('disk_used', 0)
        server_stats.append(stat)

    unread_notifs = Notification.query.filter_by(
        user_id=current_user.id, is_read=False
    ).order_by(Notification.created_at.desc()).limit(5).all()

    expired_servers = [s for s in servers if s.is_expired]

    return render_template('user/dashboard.html',
                           server_stats=server_stats,
                           unread_notifs=unread_notifs,
                           expired_servers=expired_servers)


@user_dashboard_bp.route('/notifications/mark-read', methods=['POST'])
@login_required
def mark_notifications_read():
    Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
    db.session.commit()
    return redirect(url_for('user_dashboard.dashboard'))
