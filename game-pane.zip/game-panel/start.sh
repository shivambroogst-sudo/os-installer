#!/bin/bash
# Start both Game Daemon and Game Panel together
set -e

BASE="$(cd "$(dirname "$0")" && pwd)"

echo "[Start] =========================================="
echo "[Start] Starting Game Daemon on port 3001..."
echo "[Start] =========================================="
cd "$BASE"
python3 daemon.py &
DAEMON_PID=$!
echo "[Start] Daemon PID: $DAEMON_PID"

# Wait a moment for daemon to initialize
sleep 2

echo "[Start] =========================================="
echo "[Start] Starting Game Panel on port ${PORT:-3000}..."
echo "[Start] =========================================="
python3 panel.py

# If panel exits, kill daemon too
kill $DAEMON_PID 2>/dev/null || true
