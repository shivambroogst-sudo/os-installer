# GamePanel — Game Server Management Panel

Pterodactyl-inspired game server management panel built in Python (Flask + Flask-SocketIO + SQLite + SQLAlchemy). No Docker. Two services: a web panel (port 3000) and a daemon (port 3001) that manages Java game servers via direct subprocess.

## Run & Operate

- **Panel** (port 3000): `cd game-panel && python3 panel.py`
- **Daemon** (port 3001): `cd game-panel && python3 daemon.py`
- Both are configured as Replit workflows ("Game Panel" and "Game Daemon")
- Default owner: `admin` / `Admin@123` (created on first run)

## Stack

- Python 3.11, Flask 3.x, Flask-SocketIO 5.x (eventlet async mode)
- SQLite via SQLAlchemy + Flask-SQLAlchemy
- Auth: bcrypt passwords + Flask-Login sessions + Flask-JWT-Extended tokens
- CSRF: Flask-WTF (API routes exempt)
- Rate limiting: Flask-Limiter (in-memory, dev mode)
- WebSocket console: Socket.IO 4.x
- Frontend: Jinja2 templates, dark theme CSS, vanilla JS + Socket.IO

## Where Things Live

```
game-panel/
├── panel.py              # Panel entry point (port 3000)
├── daemon.py             # Daemon entry point (port 3001)
├── panel.db              # SQLite database (auto-created)
├── servers/              # Server files (auto-created, e.g. servers/1/)
├── panel/                # Panel Flask app
│   ├── __init__.py       # App factory (create_app)
│   ├── extensions.py     # Shared Flask extensions
│   ├── sockets.py        # Socket.IO event handlers
│   ├── models/           # SQLAlchemy models
│   ├── routes/           # Blueprints (admin/, user/, auth.py)
│   ├── api/v1/           # API routes (nodes, servers, daemon callbacks)
│   └── utils/            # Auth helpers, decorators, helpers
├── daemon/               # Daemon Flask app
│   ├── app.py            # Daemon Flask routes + heartbeat thread
│   ├── process_manager.py  # Java subprocess runner
│   ├── server_manager.py  # Singleton server state
│   └── file_manager.py   # Safe file ops + zip backup
├── static/               # CSS, JS (main.js, console.js, files.js)
└── templates/            # Jinja2 templates (base, admin, user, errors, auth)
```

## Architecture Decisions

- **SQLite only** — uses `PANEL_DATABASE_URL` env var (not global `DATABASE_URL`) to avoid the Replit PostgreSQL env var collision.
- **Direct Java subprocess** — daemon runs `java -Xmx<RAM>M -jar <jar> nogui` via `subprocess.Popen`, piping stdout/stderr.
- **Daemon ↔ Panel comms** — daemon sends POST callbacks to panel (`/api/daemon/heartbeat`, `/api/daemon/server-status`, etc.) with `X-Daemon-Secret` header. Panel API routes are CSRF-exempt.
- **Socket.IO console** — browser connects directly to panel Socket.IO, joins `server_{id}` room. Daemon pushes console lines to panel which emits them to the room.
- **Server folders** — servers live at `servers/{folder_number}/` (auto-numbered integers).
- **Roles** — Owner > Admin (with granular permissions) > User. Owner is seeded on first startup.

## Roles & Permissions

| Role  | Capabilities |
|-------|-------------|
| Owner | Full access to everything, including system settings |
| Admin | Granular per-permission flags (users, servers, nodes, etc.) |
| User  | Access only to their own servers (console, files, backups, databases) |

## API Authentication

- Web UI: Flask-Login sessions + CSRF tokens
- REST API (`/api/v1/*`): `X-API-Token` header (per-user token)
- Daemon callbacks (`/api/daemon/*`): `X-Daemon-Secret` header

## Gotchas

- `PANEL_DATABASE_URL` overrides SQLite path; do NOT set `DATABASE_URL` for this panel (it conflicts with Replit's Postgres).
- Daemon must be restarted when node `daemon_secret` is regenerated.
- All admin route templates use `csrf_token()` — always pass the CSRF token in forms.
- `admin_required_local` decorator in `settings.py` must be defined BEFORE it's used as a decorator.
- Server process cleanup: killing Java via `process.kill()` on SIGKILL; stdout thread cleans up on process exit.

## User Preferences

_None set yet._
