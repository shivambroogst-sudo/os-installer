import os
import sys
import logging
from dotenv import load_dotenv

load_dotenv()

# Config file se settings load karo
from config_loader import load_panel_config, print_config_summary
cfg = load_panel_config()

# Logging setup
logging.basicConfig(
    level=getattr(logging, cfg['log_level'].upper(), logging.INFO),
    format='[%(asctime)s] %(levelname)s %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

from panel import create_app, socketio

app = create_app(cfg)

if __name__ == '__main__':
    host = cfg['host']
    port = cfg['port']
    debug = str(cfg['debug']).lower() == 'true' if isinstance(cfg['debug'], str) else bool(cfg['debug'])

    print(f"[Panel] ==========================================")
    print(f"[Panel] Game Server Management Panel")
    print(f"[Panel] URL   : http://{host}:{port}")
    print(f"[Panel] Debug : {debug}")
    print(f"[Panel] Config: config.json")
    print(f"[Panel] ==========================================")

    socketio.run(app, host=host, port=port, debug=debug,
                 use_reloader=False, log_output=True,
                 allow_unsafe_werkzeug=True)
