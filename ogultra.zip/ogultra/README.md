# ogultra Panel

Production-ready game server hosting panel built with **Node.js 20 + Express + EJS + MySQL**. No Docker, HTTP/HTTPS only, PRoot Ubuntu 20/22 compatible.

Inspired by [Skyport Panel](https://github.com/skyport-team/panel) and [skyportd](https://github.com/skyport-team/skyportd) architecture.

## Features

- **Node.js 20+** - Pure JavaScript, no Python
- **Express + EJS** - Server-rendered, fast, simple
- **MySQL** - Production database
- **JWT auth** - httpOnly cookies, secure
- **CSRF protection** - Form + header tokens
- **WebSocket console** - Live server logs via WS proxy
- **child_process.spawn()** - Daemon runs servers, no Docker
- **HTTP/HTTPS only** - No TCP, no Docker daemon
- **Egg system** - Pterodactyl-like server templates
- **File manager** - Upload (file + URL), download, zip, edit, drag-drop
- **Backups** - Create/restore/download (zip)
- **Scheduler** - Cron-based task scheduling
- **Multi-node** - Multiple daemon nodes
- **Admin panel** - Users, eggs, logs, settings, branding
- **REST API** - Bearer token auth, OpenAPI at /api/v1/

## Quick Start

### 1. Install Node.js 20

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node --version  # should be v20.x
```

### 2. Install MySQL

```bash
sudo apt install -y mysql-server
sudo mysql_secure_installation
```

### 3. Setup Database

```bash
mysql -u root -p < scripts/setup-db.sql
```

### 4. Configure

```bash
cp .env.example .env
# Edit .env - set DB_PASSWORD, JWT_SECRET, SESSION_SECRET
nano .env
```

### 5. Install & Run Panel

```bash
npm install
npm start
# Panel running on http://localhost:3000
# Login: admin / admin12345
```

### 6. Run Daemon (on node VPS)

```bash
# Copy ogultra folder to node VPS
# Then:
npm install
node daemon.js --host 0.0.0.0 --port 3001 --token YOUR_NODE_AUTH_TOKEN \
  --panel-url http://PANEL_IP:3000 --node-uuid YOUR_NODE_UUID --node-api-key YOUR_NODE_API_KEY
```

Or with PM2 (recommended):
```bash
npm install -g pm2
pm2 start daemon.js --name ogultra-daemon -- --host 0.0.0.0 --port 3001 --token YOUR_TOKEN \
  --panel-url http://PANEL_IP:3000 --node-uuid YOUR_UUID --node-api-key YOUR_KEY
pm2 save
pm2 startup
```

## Architecture

```
┌─────────────────────────────┐         ┌─────────────────────────────┐
│      PANEL (Express)        │         │     DAEMON (Express)        │
│  - EJS templates            │         │  - child_process.spawn()    │
│  - JWT auth (httpOnly)      │  HTTP   │  - File manager             │
│  - MySQL                    │ ◄─────► │  - Backups (zip)            │
│  - WebSocket console proxy  │   WS    │  - Resource monitoring      │
│  - REST API                 │         │  - Auto-restart on crash    │
└─────────────────────────────┘         └─────────────────────────────┘
                                                  │
                                                  ▼
                                        ┌─────────────────────┐
                                        │   Game Servers      │
                                        │  (Java/Minecraft)   │
                                        └─────────────────────┘
```

## Project Structure

```
ogultra/
├── panel.js              # Main Express app
├── daemon.js             # Daemon Express app
├── db.js                 # MySQL pool
├── auth.js               # JWT + middleware
├── helpers.js            # Daemon client, audit, settings
├── mc-installers.js      # Minecraft downloaders
├── eggs.js               # Egg definitions
├── scheduler.js          # Cron scheduler
├── routes/
│   ├── auth.js           # Login/register/logout
│   ├── dashboard.js      # User + admin dashboard
│   ├── servers.js        # Server CRUD + actions
│   ├── files.js          # File manager
│   ├── console.js        # WebSocket proxy
│   ├── backups.js        # Backup routes
│   ├── scheduler.js      # Schedule UI
│   ├── nodes.js          # Node management
│   ├── admin.js          # Users, eggs, logs
│   ├── settings.js       # User + admin settings
│   └── api.js            # REST API
├── views/                # EJS templates
│   ├── layout.ejs        # Master layout
│   ├── auth/             # login, register, reset
│   ├── dashboard/        # index, admin, settings, notifications
│   ├── servers/          # list, create, manage, backups, schedules
│   ├── files/            # manager
│   ├── admin/            # users, eggs, settings, logs
│   ├── nodes/            # list, create, detail
│   └── errors/           # 404, 500, maintenance
├── public/               # Static assets
│   ├── css/app.css
│   ├── js/app.js
│   └── branding/         # Uploaded logos/favicons
├── scripts/
│   └── setup-db.sql      # MySQL schema
├── servers_data/         # Server files (daemon)
├── backups/              # Backup zips (daemon)
├── logs/                 # Server logs (daemon)
├── package.json
├── .env.example
└── README.md
```

## Default Eggs

- Paper, Vanilla, Purpur, Spigot, Forge, Fabric (Minecraft)
- Velocity, Waterfall, BungeeCord (Proxies)
- Custom (upload your own jar)

## API Usage

```bash
# Create API key in Settings → API Keys
curl -H "Authorization: Bearer og_xxxx" http://localhost:3000/api/v1/servers
curl -H "Authorization: Bearer og_xxxx" http://localhost:3000/api/v1/nodes
```

## Node Setup Commands

Node detail page shows 3 options:
1. **Direct (node)** - `node daemon.js --host 0.0.0.0 --port 3001 --token XXX`
2. **PM2** - `pm2 start daemon.js --name ogultra-daemon -- --host 0.0.0.0 --port 3001 --token XXX`
3. **With heartbeat** - Add `--panel-url`, `--node-uuid`, `--node-api-key` for auto-status updates

## License

MIT
