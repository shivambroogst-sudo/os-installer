/**
 * scheduler.js - Cron-based scheduler for scheduled tasks.
 * Uses node-cron for cron expression parsing.
 */
const cron = require('node-cron');
const { query, execute } = require('./db');
const { getDaemonClient } = require('./helpers');

let started = false;
const activeJobs = new Map();

async function runSchedule(schedule) {
  try {
    const [server, node] = await Promise.all([
      query('SELECT * FROM servers WHERE id = ?', [schedule.server_id]),
      query('SELECT n.* FROM nodes n JOIN servers s ON s.node_id = n.id WHERE s.id = ?', [schedule.server_id]),
    ]);
    if (!server.length || !node.length) return;
    const srv = server[0];
    const n = node[0];
    const client = getDaemonClient(n);

    if (schedule.action === 'start') {
      await client.startServer(srv.uuid, { install_path: srv.install_path, command: srv.startup_command, memory_limit: srv.memory_limit });
    } else if (schedule.action === 'stop') {
      await client.stopServer(srv.uuid);
    } else if (schedule.action === 'restart') {
      await client.restartServer(srv.uuid);
    } else if (schedule.action === 'kill') {
      await client.killServer(srv.uuid);
    } else if (schedule.action === 'command' && schedule.command) {
      await client.sendCommand(srv.uuid, schedule.command);
    }

    await execute('UPDATE schedules SET last_run_at = NOW() WHERE id = ?', [schedule.id]);
    console.log(`[scheduler] ran "${schedule.name}" (${schedule.action}) on server ${srv.uuid}`);
  } catch (e) {
    console.error(`[scheduler] schedule ${schedule.id} failed:`, e.message);
  }
}

function refreshJobs() {
  // Clear existing
  for (const [id, job] of activeJobs) {
    job.stop();
  }
  activeJobs.clear();

  query('SELECT * FROM schedules WHERE is_enabled = 1').then((schedules) => {
    for (const s of schedules) {
      if (!cron.validate(s.cron_expression)) continue;
      try {
        const job = cron.schedule(s.cron_expression, () => runSchedule(s));
        activeJobs.set(s.id, job);
      } catch (e) {
        console.error(`[scheduler] invalid cron for schedule ${s.id}:`, e.message);
      }
    }
    console.log(`[scheduler] loaded ${activeJobs.size} active schedules`);
  }).catch((e) => console.error('[scheduler] load error:', e));
}

function start() {
  if (started) return;
  started = true;
  refreshJobs();
  // Refresh every 5 minutes
  setInterval(refreshJobs, 5 * 60 * 1000);
  console.log('[scheduler] started');
}

module.exports = { start, refreshJobs, runSchedule };
