/**
 * panel.js - ogultra Panel main Express app
 * - EJS templates
 * - JWT auth in httpOnly cookie
 * - CSRF protection
 * - Routes: auth, dashboard, servers, files, console, backups, scheduler, nodes, admin, api
 */
require('dotenv').config();

const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const expressLayouts = require('express-ejs-layouts');
const http = require('http');

const { pool, query, execute, queryOne, uuid } = require('./db');
const auth = require('./auth');
const { logAudit, getBranding, isMaintenanceMode, buildContext } = require('./helpers');
const { ensureDefaultEggs } = require('./eggs');

const app = express();
const server = http.createServer(app);

// ---- View engine ----
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('layout', 'layout');
app.use(expressLayouts);

// ---- Middleware ----
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(morgan('combined'));
app.use(cookieParser());
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Auth + CSRF middleware (loadUser first, then CSRF)
app.use(auth.loadUser);
app.use(auth.csrfProtection);

// Ensure CSRF cookie set on every request
app.use((req, res, next) => {
  if (!req.cookies[auth.CSRF_COOKIE]) {
    const token = auth.generateCsrfToken();
    auth.setCsrfCookie(res, token);
    req.csrfToken = token;
  }
  next();
});

// Maintenance mode check (allow admin)
app.use(async (req, res, next) => {
  if (req.path.startsWith('/api/') || req.path === '/health' || req.path.startsWith('/login') || req.path.startsWith('/logout')) {
    return next();
  }
  try {
    const maint = await isMaintenanceMode();
    if (maint && (!req.user || !req.user.is_admin)) {
      const ctx = await buildContext(req);
      return res.status(503).render('errors/maintenance', ctx);
    }
  } catch (e) {
    // DB not ready yet, skip
  }
  next();
});

// ---- Routes ----
app.use('/', require('./routes/auth'));
app.use('/', require('./routes/dashboard'));
app.use('/', require('./routes/servers'));
app.use('/', require('./routes/files'));
app.use('/', require('./routes/backups'));
app.use('/', require('./routes/scheduler'));
app.use('/', require('./routes/nodes'));
app.use('/', require('./routes/admin'));
app.use('/', require('./routes/settings'));
app.use('/api', require('./routes/api'));

// Console WebSocket (attach to same server)
const { setupConsoleWebSocket } = require('./routes/console');
setupConsoleWebSocket(server, app);

// ---- Health check ----
app.get('/health', (req, res) => res.json({ status: 'ok', service: 'panel' }));

// ---- Error handlers ----
app.use((req, res) => {
  res.status(404).render('errors/404', { user: req.user, csrfToken: req.csrfToken, branding: { app_name: process.env.APP_NAME || 'ogultra' }, unreadCount: 0 });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[panel] error:', err);
  if (req.path.startsWith('/api/') || req.headers.accept?.includes('application/json')) {
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
  res.status(500).render('errors/500', { user: req.user, csrfToken: req.csrfToken, branding: { app_name: process.env.APP_NAME || 'ogultra' }, unreadCount: 0, error: err.message });
});

// ---- Init ----
async function init() {
  // Test DB connection
  try {
    const conn = await pool.getConnection();
    conn.release();
    console.log('[panel] MySQL connected');
  } catch (e) {
    console.error('[panel] MySQL connection failed:', e.message);
    console.error('[panel] Run: mysql -u root -p < scripts/setup-db.sql');
    process.exit(1);
  }

  // Ensure default eggs
  const eggCount = await ensureDefaultEggs();
  if (eggCount > 0) console.log(`[panel] Created ${eggCount} default eggs`);

  // Ensure superadmin
  const adminExists = await queryOne('SELECT id FROM users WHERE role = "superadmin" LIMIT 1');
  if (!adminExists) {
    const bcrypt = require('bcryptjs');
    const hash = await bcrypt.hash('admin12345', 10);
    await execute(
      'INSERT INTO users (uuid, username, email, password_hash, role, is_email_verified) VALUES (?, ?, ?, ?, "superadmin", 1)',
      [uuid(), 'admin', 'admin@ogultra.local', hash]
    );
    console.log('============================================================');
    console.log('  Default superadmin created:');
    console.log('    Username: admin');
    console.log('    Password: admin12345');
    console.log('  CHANGE THIS PASSWORD IMMEDIATELY!');
    console.log('============================================================');
  }

  const PORT = process.env.PORT || 3000;
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`\n╔══════════════════════════════════════════════════╗`);
    console.log(`║   ogultra Panel - running on port ${PORT}          ║`);
    console.log(`║   http://0.0.0.0:${PORT}                          ║`);
    console.log(`║   Default login: admin / admin12345              ║`);
    console.log(`╚══════════════════════════════════════════════════╝\n`);
  });
}

// Start scheduler
require('./scheduler').start();

init().catch((e) => {
  console.error('[panel] init failed:', e);
  process.exit(1);
});
