/**
 * eggs.js - Egg definitions (Pterodactyl-like)
 * Each egg has: install script, startup command, variables, default resources.
 */
const { query, execute, queryOne, uuid } = require('./db');

const DEFAULT_EGGS = [
  {
    name: 'Paper', description: 'High performance fork of Spigot', category: 'minecraft',
    icon: '📄', tags: 'minecraft,java,paper',
    startup_command: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    default_memory: 1024, default_disk: 5120, default_cpu: 100,
    install_script: `#!/bin/bash
cd "{{INSTALL_PATH}}"
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then
  VERSION=$(curl -s 'https://api.papermc.io/v2/projects/paper' | python3 -c "import sys,json; print(json.load(sys.stdin)['versions'][-1])")
fi
BUILD=$(curl -s "https://api.papermc.io/v2/projects/paper/versions/$VERSION" | python3 -c "import sys,json; print(json.load(sys.stdin)['builds'][-1]['build'])")
FILENAME=$(curl -s "https://api.papermc.io/v2/projects/paper/versions/$VERSION/builds/$BUILD" | python3 -c "import sys,json; print(json.load(sys.stdin)['downloads']['application']['name'])")
curl -o paper.jar "https://api.papermc.io/v2/projects/paper/versions/$VERSION/builds/$BUILD/downloads/$FILENAME"
ln -sf paper.jar server.jar
echo "eula=true" > eula.txt
echo "Paper $VERSION installed"`,
    variables: [
      { name: 'Server Jar File', env_variable: 'SERVER_JARFILE', default_value: 'server.jar', description: 'The jar file to run', required: true, user_viewable: true, user_editable: false },
      { name: 'Server Version', env_variable: 'SERVER_VERSION', default_value: 'latest', description: 'Paper version', required: true, user_viewable: true, user_editable: true },
    ],
    features: ['eula', 'java_version'], is_default: true,
  },
  {
    name: 'Vanilla', description: 'Official Mojang Minecraft server', category: 'minecraft',
    icon: '🎮', tags: 'minecraft,java,vanilla',
    startup_command: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    default_memory: 1024, default_disk: 5120, default_cpu: 100,
    install_script: `#!/bin/bash
cd "{{INSTALL_PATH}}"
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then
  VERSION=$(curl -s 'https://launchermeta.mojang.com/mc/game/version_manifest.json' | python3 -c "import sys,json; print(json.load(sys.stdin)['latest']['release'])")
fi
URL=$(curl -s 'https://launchermeta.mojang.com/mc/game/version_manifest.json' | python3 -c "import sys,json; vs={v['id']:v for v in json.load(sys.stdin)['versions']}; print(vs['$VERSION']['url'])")
URL=$(curl -s "$URL" | python3 -c "import sys,json; print(json.load(sys.stdin)['downloads']['server']['url'])")
curl -o server.jar "$URL"
echo "eula=true" > eula.txt
echo "Vanilla $VERSION installed"`,
    variables: [
      { name: 'Server Jar File', env_variable: 'SERVER_JARFILE', default_value: 'server.jar', required: true, user_viewable: true, user_editable: false },
      { name: 'Server Version', env_variable: 'SERVER_VERSION', default_value: 'latest', required: true, user_viewable: true, user_editable: true },
    ],
    features: ['eula'], is_default: true,
  },
  {
    name: 'Purpur', description: 'Paper fork with extra optimizations', category: 'minecraft',
    icon: '📜', tags: 'minecraft,purpur',
    startup_command: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    default_memory: 1024, default_disk: 5120, default_cpu: 100,
    install_script: `#!/bin/bash
cd "{{INSTALL_PATH}}"
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then
  VERSION=$(curl -s 'https://api.purpurmc.org/v2/purpur' | python3 -c "import sys,json; print(json.load(sys.stdin)['version'])")
fi
curl -o purpur.jar "https://api.purpurmc.org/v2/purpur/$VERSION/latest/download"
ln -sf purpur.jar server.jar
echo "eula=true" > eula.txt`,
    variables: [
      { name: 'Server Jar File', env_variable: 'SERVER_JARFILE', default_value: 'server.jar', required: true, user_viewable: true, user_editable: false },
      { name: 'Server Version', env_variable: 'SERVER_VERSION', default_value: 'latest', required: true, user_viewable: true, user_editable: true },
    ],
    features: ['eula'], is_default: false,
  },
  {
    name: 'Spigot', description: 'Popular Bukkit-compatible server', category: 'minecraft',
    icon: '🪵', tags: 'minecraft,spigot',
    startup_command: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    default_memory: 1024, default_disk: 5120, default_cpu: 100,
    install_script: `#!/bin/bash
cd "{{INSTALL_PATH}}"
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then VERSION="1.20.4"; fi
curl -L -o spigot.jar "https://download.getbukkit.org/spigot/spigot-$VERSION.jar"
ln -sf spigot.jar server.jar
echo "eula=true" > eula.txt`,
    variables: [
      { name: 'Server Jar File', env_variable: 'SERVER_JARFILE', default_value: 'server.jar', required: true, user_viewable: true, user_editable: false },
      { name: 'Server Version', env_variable: 'SERVER_VERSION', default_value: 'latest', required: true, user_viewable: true, user_editable: true },
    ],
    features: ['eula'], is_default: false,
  },
  {
    name: 'Forge', description: 'Minecraft Forge modding platform', category: 'minecraft',
    icon: '🔨', tags: 'minecraft,forge,mods',
    startup_command: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    default_memory: 2048, default_disk: 10240, default_cpu: 200,
    install_script: `#!/bin/bash
cd "{{INSTALL_PATH}}"
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then VERSION="1.20.1"; fi
curl -L -o forge.jar "https://maven.minecraftforge.net/net/minecraftforge/forge/$VERSION-$VERSION-universal/forge-$VERSION-$VERSION-universal.jar" || \\
curl -L -o forge.jar "https://maven.minecraftforge.net/net/minecraftforge/forge/$VERSION-$VERSION/forge-$VERSION-$VERSION-installer.jar"
ln -sf forge.jar server.jar
echo "eula=true" > eula.txt`,
    variables: [
      { name: 'Server Jar File', env_variable: 'SERVER_JARFILE', default_value: 'server.jar', required: true, user_viewable: true, user_editable: false },
      { name: 'Server Version', env_variable: 'SERVER_VERSION', default_value: '1.20.1', required: true, user_viewable: true, user_editable: true },
    ],
    features: ['eula'], is_default: false,
  },
  {
    name: 'Fabric', description: 'Lightweight modding platform', category: 'minecraft',
    icon: '🧵', tags: 'minecraft,fabric,mods',
    startup_command: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    default_memory: 1024, default_disk: 5120, default_cpu: 100,
    install_script: `#!/bin/bash
cd "{{INSTALL_PATH}}"
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then
  VERSION=$(curl -s 'https://meta.fabricmc.net/v2/versions/game' | python3 -c "import sys,json; d=json.load(sys.stdin); s=[v for v in d if v.get('stable')]; print(s[-1]['version'] if s else '1.20.4')")
fi
LOADER=$(curl -s 'https://meta.fabricmc.net/v2/versions/loader' | python3 -c "import sys,json; print(json.load(sys.stdin)[0]['version'])")
INSTALLER=$(curl -s 'https://meta.fabricmc.net/v2/versions/installer' | python3 -c "import sys,json; print(json.load(sys.stdin)[0]['version'])")
curl -o fabric-server.jar "https://meta.fabricmc.net/v2/versions/loader/$VERSION/$LOADER/$INSTALLER/server/jar"
ln -sf fabric-server.jar server.jar
echo "eula=true" > eula.txt`,
    variables: [
      { name: 'Server Jar File', env_variable: 'SERVER_JARFILE', default_value: 'server.jar', required: true, user_viewable: true, user_editable: false },
      { name: 'Server Version', env_variable: 'SERVER_VERSION', default_value: 'latest', required: true, user_viewable: true, user_editable: true },
    ],
    features: ['eula'], is_default: false,
  },
  {
    name: 'Velocity', description: 'Modern Minecraft proxy', category: 'proxy',
    icon: '⚡', tags: 'minecraft,proxy,velocity',
    startup_command: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}',
    default_memory: 512, default_disk: 1024, default_cpu: 100,
    install_script: `#!/bin/bash
cd "{{INSTALL_PATH}}"
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then
  VERSION=$(curl -s 'https://api.papermc.io/v2/projects/velocity' | python3 -c "import sys,json; print(json.load(sys.stdin)['versions'][-1])")
fi
BUILD=$(curl -s "https://api.papermc.io/v2/projects/velocity/versions/$VERSION" | python3 -c "import sys,json; print(json.load(sys.stdin)['builds'][-1]['build'])")
FILENAME=$(curl -s "https://api.papermc.io/v2/projects/velocity/versions/$VERSION/builds/$BUILD" | python3 -c "import sys,json; print(json.load(sys.stdin)['downloads']['application']['name'])")
curl -o velocity.jar "https://api.papermc.io/v2/projects/velocity/versions/$VERSION/builds/$BUILD/downloads/$FILENAME"
ln -sf velocity.jar server.jar`,
    variables: [
      { name: 'Server Jar File', env_variable: 'SERVER_JARFILE', default_value: 'server.jar', required: true, user_viewable: true, user_editable: false },
      { name: 'Server Version', env_variable: 'SERVER_VERSION', default_value: 'latest', required: true, user_viewable: true, user_editable: true },
    ],
    features: [], is_default: false,
  },
  {
    name: 'Waterfall', description: 'BungeeCord fork proxy', category: 'proxy',
    icon: '💧', tags: 'minecraft,proxy,waterfall',
    startup_command: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}',
    default_memory: 512, default_disk: 1024, default_cpu: 100,
    install_script: `#!/bin/bash
cd "{{INSTALL_PATH}}"
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then
  VERSION=$(curl -s 'https://api.papermc.io/v2/projects/waterfall' | python3 -c "import sys,json; print(json.load(sys.stdin)['versions'][-1])")
fi
BUILD=$(curl -s "https://api.papermc.io/v2/projects/waterfall/versions/$VERSION" | python3 -c "import sys,json; print(json.load(sys.stdin)['builds'][-1]['build'])")
FILENAME=$(curl -s "https://api.papermc.io/v2/projects/waterfall/versions/$VERSION/builds/$BUILD" | python3 -c "import sys,json; print(json.load(sys.stdin)['downloads']['application']['name'])")
curl -o waterfall.jar "https://api.papermc.io/v2/projects/waterfall/versions/$VERSION/builds/$BUILD/downloads/$FILENAME"
ln -sf waterfall.jar server.jar`,
    variables: [
      { name: 'Server Jar File', env_variable: 'SERVER_JARFILE', default_value: 'server.jar', required: true, user_viewable: true, user_editable: false },
      { name: 'Server Version', env_variable: 'SERVER_VERSION', default_value: 'latest', required: true, user_viewable: true, user_editable: true },
    ],
    features: [], is_default: false,
  },
  {
    name: 'BungeeCord', description: 'Classic Minecraft proxy', category: 'proxy',
    icon: '🔗', tags: 'minecraft,proxy,bungeecord',
    startup_command: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}',
    default_memory: 512, default_disk: 1024, default_cpu: 100,
    install_script: `#!/bin/bash
cd "{{INSTALL_PATH}}"
curl -o BungeeCord.jar "https://ci.md-5.net/job/BungeeCord/lastSuccessfulBuild/artifact/bootstrap/target/BungeeCord.jar"
ln -sf BungeeCord.jar server.jar`,
    variables: [
      { name: 'Server Jar File', env_variable: 'SERVER_JARFILE', default_value: 'server.jar', required: true, user_viewable: true, user_editable: false },
    ],
    features: [], is_default: false,
  },
  {
    name: 'Custom', description: 'Upload your own server jar', category: 'custom',
    icon: '⚙️', tags: 'custom',
    startup_command: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    default_memory: 1024, default_disk: 5120, default_cpu: 100,
    install_script: `#!/bin/bash
cd "{{INSTALL_PATH}}"
echo "Custom server - upload your jar via File Manager"
echo "eula=true" > eula.txt`,
    variables: [
      { name: 'Server Jar File', env_variable: 'SERVER_JARFILE', default_value: 'server.jar', required: true, user_viewable: true, user_editable: true },
    ],
    features: ['eula'], is_default: false,
  },
];

/**
 * Ensure default eggs exist in DB.
 */
async function ensureDefaultEggs() {
  const existing = await queryOne('SELECT COUNT(*) as cnt FROM eggs');
  if (existing.cnt > 0) return 0;
  let count = 0;
  for (const egg of DEFAULT_EGGS) {
    await execute(
      `INSERT INTO eggs (uuid, name, description, category, author, install_script, startup_command, default_memory, default_disk, default_cpu, variables, features, tags, icon, is_active, is_default)
       VALUES (?, ?, ?, ?, 'ogultra', ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
      [uuid(), egg.name, egg.description, egg.category, egg.install_script, egg.startup_command,
       egg.default_memory, egg.default_disk, egg.default_cpu, JSON.stringify(egg.variables),
       JSON.stringify(egg.features || []), egg.tags, egg.icon, egg.is_default ? 1 : 0]
    );
    count++;
  }
  return count;
}

/**
 * Get egg by ID.
 */
async function getEgg(id) {
  return queryOne('SELECT * FROM eggs WHERE id = ?', [id]);
}

/**
 * List eggs.
 */
async function listEggs(activeOnly = true, category = null) {
  let sql = 'SELECT * FROM eggs';
  const params = [];
  const where = [];
  if (activeOnly) where.push('is_active = 1');
  if (category) where.push('category = ?');
  if (where.length) sql += ' WHERE ' + where.join(' AND ');
  if (category) params.push(category);
  sql += ' ORDER BY category, name';
  return query(sql, params);
}

module.exports = { DEFAULT_EGGS, ensureDefaultEggs, getEgg, listEggs };
