/**
 * auth.js - JWT authentication + middleware
 * - JWT in httpOnly cookie
 * - bcryptjs for password hashing
 * - CSRF token via separate cookie + header
 */
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { queryOne } = require('./db');

const JWT_SECRET = process.env.JWT_SECRET || 'change-me-min-32-chars-secret-key!!';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';
const SESSION_COOKIE = 'ogultra_session';
const CSRF_COOKIE = 'ogultra_csrf';

/**
 * Hash a password using bcrypt.
 */
async function hashPassword(password) {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

/**
 * Verify password against hash.
 */
async function verifyPassword(password, hash) {
  return bcrypt.compare(password, hash);
}

/**
 * Create JWT token for user.
 */
function createToken(user) {
  return jwt.sign(
    { sub: user.id, username: user.username, role: user.role },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

/**
 * Verify JWT token, return payload or null.
 */
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (e) {
    return null;
  }
}

/**
 * Generate CSRF token.
 */
function generateCsrfToken() {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Set session cookie on response.
 */
function setSessionCookie(res, token) {
  const isProd = process.env.NODE_ENV === 'production';
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: isProd,
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    path: '/',
  });
}

/**
 * Set CSRF cookie on response (readable by JS).
 */
function setCsrfCookie(res, token) {
  const isProd = process.env.NODE_ENV === 'production';
  res.cookie(CSRF_COOKIE, token, {
    httpOnly: false,
    secure: isProd,
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: '/',
  });
}

/**
 * Clear auth cookies.
 */
function clearCookies(res) {
  res.clearCookie(SESSION_COOKIE, { path: '/' });
  res.clearCookie(CSRF_COOKIE, { path: '/' });
}

/**
 * Middleware: load current user from cookie.
 * Sets req.user (or null) and req.csrfToken.
 */
async function loadUser(req, res, next) {
  req.user = null;
  const token = req.cookies[SESSION_COOKIE];
  if (token) {
    const payload = verifyToken(token);
    if (payload) {
      try {
        const user = await queryOne('SELECT * FROM users WHERE id = ? AND is_active = 1', [payload.sub]);
        if (user) {
          user.is_admin = (user.role === 'admin' || user.role === 'superadmin');
          req.user = user;
        }
      } catch (e) {
        console.error('[auth] loadUser error:', e.message);
      }
    }
  }
  // CSRF token from cookie
  req.csrfToken = req.cookies[CSRF_COOKIE] || '';
  next();
}

/**
 * Middleware: require authentication.
 */
function requireAuth(req, res, next) {
  if (!req.user) {
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    return res.redirect('/login');
  }
  next();
}

/**
 * Middleware: require admin role.
 */
function requireAdmin(req, res, next) {
  if (!req.user || !req.user.is_admin) {
    if (req.path.startsWith('/api/')) {
      return res.status(403).json({ error: 'Admin access required' });
    }
    return res.status(403).send('Admin access required');
  }
  next();
}

/**
 * Middleware: require server ownership (or admin).
 * Expects req.params.serverUuid
 */
async function requireServerAccess(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Auth required' });
  const serverUuid = req.params.serverUuid || req.params.uuid;
  if (!serverUuid) return res.status(400).json({ error: 'Server UUID required' });
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [serverUuid]);
    if (!server) return res.status(404).json({ error: 'Server not found' });
    if (server.owner_id !== req.user.id && !req.user.is_admin) {
      return res.status(403).json({ error: 'Access denied' });
    }
    req.server = server;
    next();
  } catch (e) {
    console.error('[auth] requireServerAccess error:', e);
    res.status(500).json({ error: 'Database error' });
  }
}

/**
 * CSRF protection middleware for state-changing requests.
 * Checks X-CSRF-Token header against cookie. Skips API Bearer auth.
 */
function csrfProtection(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  // Skip API requests with Bearer token (separate auth)
  const authHeader = req.headers.authorization || '';
  if (authHeader.startsWith('Bearer ')) return next();
  // Skip auth endpoints (login/register) - no session yet
  const exemptPaths = ['/login', '/register', '/logout', '/reset-password', '/reset-password/confirm', '/verify-email'];
  if (exemptPaths.some(p => req.path === p || req.path.startsWith(p + '/'))) return next();

  const cookieToken = req.cookies[CSRF_COOKIE];
  const headerToken = req.headers['x-csrf-token'] || req.headers['x-csrftoken'] || req.body?.csrf_token;

  if (!cookieToken || !headerToken) {
    return res.status(403).json({ error: 'CSRF token missing - refresh the page' });
  }
  if (cookieToken !== headerToken) {
    return res.status(403).json({ error: 'CSRF token invalid' });
  }
  next();
}

module.exports = {
  hashPassword,
  verifyPassword,
  createToken,
  verifyToken,
  generateCsrfToken,
  setSessionCookie,
  setCsrfCookie,
  clearCookies,
  loadUser,
  requireAuth,
  requireAdmin,
  requireServerAccess,
  csrfProtection,
  SESSION_COOKIE,
  CSRF_COOKIE,
};
