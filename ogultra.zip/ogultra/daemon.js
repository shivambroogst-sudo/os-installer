/**
 * daemon.js - ogultra Daemon (skyportd-like)
 * - Pure Node.js, no Docker
 * - child_process.spawn() to run game servers
 * - HTTP/HTTPS only (Express)
 * - WebSocket for live console
 * - Ubuntu 20/22 PRoot compatible
 *
 * Usage:
 *   node daemon.js --host 0.0.0.0 --port 3001 --token YOUR_SECRET
 *   node daemon.js --host 0.0.0.0 --port 3001 --token YOUR_SECRET --panel-url http://panel:3000 --node-uuid xxx --node-api-key yyy
 */
require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn, spawnSync } = require('child_process');
const WebSocket = require('ws');
const axios = require('axios');
const multer = require('multer');
const archiver = require('archiver');
const unzipper = require('unzipper');
const si = require('systeminformation');

// Parse CLI args
const args = process.argv.slice(2);
function getArg(name) {
  const idx = args.indexOf(`--${name}`);
  return idx >= 0 ? args[idx + 1] : null;
}
const HOST = getArg('host') || process.env.DAEMON_HOST || '0.0.0.0';
const PORT = parseInt(getArg('port') || process.env.DAEMON_PORT || '3001');
const TOKEN = getArg('token') || process.env.DAEMON_TOKEN || 'change-me';
const PANEL_URL = getArg('panel-url');
const NODE_UUID = getArg('node-uuid');
const NODE_API_KEY = getArg('node-api-key');

const BASE_DIR = __dirname;
const SERVERS_DIR = path.join(BASE_DIR, 'servers_data');
const BACKUPS_DIR = path.join(BASE_DIR, 'backups');
const LOGS_DIR = path.join(BASE_DIR, 'logs');
[SERVERS_DIR, BACKUPS_DIR, LOGS_DIR].forEach((d) => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

const app = express();
const server = http.createServer(app);
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Auth middleware
function authReq(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const xToken = req.headers['x-daemon-token'];
  let token = '';
  if (authHeader.startsWith('Bearer ')) token = authHeader.substring(7);
  else if (xToken) token = xToken;
  if (token !== TOKEN) return res.status(401).json({ detail: 'Invalid token' });
  next();
}

// ---- Server process manager ----
class ServerProcess {
  constructor(serverUuid, installPath) {
    this.uuid = serverUuid;
    this.installPath = installPath;
    this.process = null;
    this.logBuffer = [];
    this.maxLogs = 5000;
    this.logFile = null;
    this.wsClients = new Set();
    this.startupTime = null;
    this.crashCount = 0;
    this.autoRestart = true;
    this.stopping = false;
  }

  start(command, env = {}, autoRestart = true) {
    if (this.process && !this.process.killed) throw new Error('Server already running');
    this.autoRestart = autoRestart;
    if (!fs.existsSync(this.installPath)) fs.mkdirSync(this.installPath, { recursive: true });

    // Setup log file
    const logDir = path.join(LOGS_DIR, this.uuid);
    if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
    const logFile = path.join(logDir, `${Date.now()}.log`);
    this.logFile = fs.createWriteStream(logFile, { flags: 'a' });

    this._appendLog(`[daemon] starting: ${command}`);
    const parts = command.split(/\s+/).filter(Boolean);
    const cmd = parts[0];
    const cmdArgs = parts.slice(1);

    this.process = spawn(cmd, cmdArgs, {
      cwd: this.installPath,
      env: { ...process.env, ...env },
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    this.startupTime = Date.now();
    this.stopping = false;

    this.process.stdout.on('data', (data) => this._appendLog(data.toString()));
    this.process.stderr.on('data', (data) => this._appendLog(data.toString()));
    this.process.on('exit', (code, signal) => {
      this._appendLog(`[daemon] process exited with code ${code} signal ${signal}`);
      if (this.logFile) { this.logFile.end(); this.logFile = null; }
      // Auto-restart on crash
      if (!this.stopping && this.autoRestart && this.crashCount < 5) {
        this.crashCount++;
        this._appendLog(`[daemon] auto-restarting (crash #${this.crashCount}) in 5 seconds...`);
        setTimeout(() => {
          try { this.start(command, env, this.autoRestart); }
          catch (e) { this._appendLog(`[daemon] auto-restart failed: ${e.message}`); }
        }, 5000);
      }
    });

    return this.process.pid;
  }

  sendCommand(cmd) {
    if (!this.process || this.process.killed) return false;
    try {
      this.process.stdin.write(cmd + '\n');
      this._appendLog(`[console] ${cmd}`);
      return true;
    } catch (e) {
      this._appendLog(`[daemon] command send failed: ${e.message}`);
      return false;
    }
  }

  stop(timeout = 15000) {
    return new Promise((resolve) => {
      if (!this.process || this.process.killed) return resolve(true);
      this.stopping = true;
      // Try graceful stop command first (Minecraft)
      this.sendCommand('stop');
      let stopped = false;
      const done = () => { if (!stopped) { stopped = true; resolve(true); } };
      this.process.once('exit', done);
      setTimeout(() => {
        if (this.process && !this.process.killed) {
          try { this.process.kill('SIGTERM'); } catch (_) {}
          setTimeout(() => {
            if (this.process && !this.process.killed) {
              try { this.process.kill('SIGKILL'); } catch (_) {}
            }
            done();
          }, 5000);
        } else done();
      }, timeout);
    });
  }

  kill() {
    if (!this.process || this.process.killed) return true;
    this.stopping = true;
    try {
      this.process.kill('SIGKILL');
      this._appendLog('[daemon] process killed');
    } catch (e) {
      this._appendLog(`[daemon] kill failed: ${e.message}`);
    }
    if (this.logFile) { this.logFile.end(); this.logFile = null; }
    return true;
  }

  _appendLog(line) {
    line = line.replace(/\r?\n$/, '');
    this.logBuffer.push(line);
    if (this.logBuffer.length > this.maxLogs) this.logBuffer.shift();
    if (this.logFile) this.logFile.write(line + '\n');
    for (const ws of this.wsClients) {
      try { ws.send(line); } catch (_) {}
    }
  }

  getLogs(lines = 200) {
    return this.logBuffer.slice(-lines);
  }

  getStatus() {
    const running = !!(this.process && !this.process.killed);
    return {
      uuid: this.uuid,
      running,
      pid: running ? this.process.pid : null,
      uptime: running && this.startupTime ? Math.floor((Date.now() - this.startupTime) / 1000) : 0,
      crash_count: this.crashCount,
    };
  }

  async getResources() {
    if (!this.process || this.process.killed) return { uuid: this.uuid, cpu_percent: 0, memory_mb: 0, disk_mb: 0 };
    try {
      const pid = this.process.pid;
      // CPU and memory via /proc
      const cpu = await getCpuUsage(pid);
      const mem = await getMemoryUsage(pid);
      // Disk via du command
      let diskMb = 0;
      try {
        const result = spawnSync('du', ['-sm', this.installPath], { encoding: 'utf8' });
        if (result.status === 0) diskMb = parseInt(result.stdout.split('\t')[0]) || 0;
      } catch (_) {}
      return { uuid: this.uuid, cpu_percent: cpu, memory_mb: mem, disk_mb: diskMb };
    } catch (e) {
      return { uuid: this.uuid, cpu_percent: 0, memory_mb: 0, disk_mb: 0 };
    }
  }
}

// CPU/Memory helpers
async function getCpuUsage(pid) {
  return new Promise((resolve) => {
    try {
      const start = process.hrtime();
      let startTime, startUtime;
      try {
        const stat = fs.readFileSync(`/proc/${pid}/stat`, 'utf8').split(' ');
        startTime = parseInt(stat[13]); // utime
        startUtime = parseInt(stat[14]); // stime
      } catch (_) { return resolve(0); }
      setTimeout(() => {
        try {
          const stat = fs.readFileSync(`/proc/${pid}/stat`, 'utf8').split(' ');
          const endTime = parseInt(stat[13]);
          const endUtime = parseInt(stat[14]);
          const elapsed = (endTime + endUtime) - (startTime + startUtime);
          const ticksPerSec = 100; // typical
          resolve(Math.min(100, (elapsed / ticksPerSec) * 100));
        } catch (_) { resolve(0); }
      }, 500);
    } catch (_) { resolve(0); }
  });
}

async function getMemoryUsage(pid) {
  try {
    const status = fs.readFileSync(`/proc/${pid}/status`, 'utf8');
    const line = status.split('\n').find((l) => l.startsWith('VmRSS:'));
    if (line) {
      const kb = parseInt(line.split(/\s+/)[1]);
      return kb / 1024; // MB
    }
  } catch (_) {}
  return 0;
}

// Process registry
const servers = new Map();
function getServer(uuid, installPath) {
  if (!servers.has(uuid)) {
    servers.set(uuid, new ServerProcess(uuid, installPath));
  }
  return servers.get(uuid);
}

// ---- Path safety ----
function safePath(installPath, requested) {
  const base = path.resolve(installPath);
  const target = path.resolve(installPath, requested || '.');
  if (!target.startsWith(base)) throw new Error('Path traversal detected');
  return target;
}

// ---- Routes ----
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    platform: os.platform(),
    arch: os.arch(),
    uptime: process.uptime(),
    servers: servers.size,
  });
});

// Install server
app.post('/servers/install', authReq, async (req, res) => {
  const { uuid: serverUuid, type, version, install_path: installPath, memory_limit } = req.body;
  if (!fs.existsSync(installPath)) fs.mkdirSync(installPath, { recursive: true });
  try {
    const { installServer } = require('./mc-installers');
    const jar = await installServer(type, version || 'latest', installPath);
    res.json({ success: true, jar });
  } catch (e) {
    res.status(500).json({ detail: `Install failed: ${e.message}` });
  }
});

// Start server
app.post('/servers/:uuid/start', authReq, async (req, res) => {
  const { install_path: installPath, command, memory_limit, env, auto_restart } = req.body;
  const srv = getServer(req.params.uuid, installPath);
  try {
    const pid = srv.start(command, env || {}, auto_restart !== false);
    res.json({ success: true, pid });
  } catch (e) {
    res.status(500).json({ detail: e.message });
  }
});

// Stop server
app.post('/servers/:uuid/stop', authReq, async (req, res) => {
  const srv = servers.get(req.params.uuid);
  if (!srv) return res.status(404).json({ detail: 'Server not found' });
  await srv.stop();
  res.json({ success: true });
});

// Restart server
app.post('/servers/:uuid/restart', authReq, async (req, res) => {
  const srv = servers.get(req.params.uuid);
  if (!srv) return res.status(404).json({ detail: 'Server not found' });
  await srv.stop();
  await new Promise((r) => setTimeout(r, 2000));
  // Note: caller should re-send start with command
  res.json({ success: true, note: 'Server stopped. Re-send start to run again.' });
});

// Kill server
app.post('/servers/:uuid/kill', authReq, (req, res) => {
  const srv = servers.get(req.params.uuid);
  if (!srv) return res.status(404).json({ detail: 'Server not found' });
  srv.kill();
  res.json({ success: true });
});

// Send command
app.post('/servers/:uuid/command', authReq, (req, res) => {
  const srv = servers.get(req.params.uuid);
  if (!srv) return res.status(404).json({ detail: 'Server not found' });
  const ok = srv.sendCommand(req.body.command);
  res.json({ success: ok });
});

// Status
app.get('/servers/:uuid/status', authReq, (req, res) => {
  const srv = servers.get(req.params.uuid);
  if (!srv) return res.json({ uuid: req.params.uuid, running: false, pid: null });
  res.json(srv.getStatus());
});

// Logs
app.get('/servers/:uuid/logs', authReq, (req, res) => {
  const srv = servers.get(req.params.uuid);
  if (!srv) return res.json({ logs: [] });
  res.json({ logs: srv.getLogs(parseInt(req.query.lines) || 200) });
});

// Resources
app.get('/servers/:uuid/resources', authReq, async (req, res) => {
  const srv = servers.get(req.params.uuid);
  if (!srv) return res.json({ uuid: req.params.uuid, cpu_percent: 0, memory_mb: 0, disk_mb: 0 });
  res.json(await srv.getResources());
});

// Delete server files
app.delete('/servers/:uuid', authReq, (req, res) => {
  const srv = servers.get(req.params.uuid);
  if (srv) srv.kill();
  servers.delete(req.params.uuid);
  const { install_path: installPath } = req.body || {};
  if (installPath && fs.existsSync(installPath)) {
    try {
      const real = path.resolve(installPath);
      const base = path.resolve(SERVERS_DIR);
      if (real.startsWith(base)) {
        fs.rmSync(real, { recursive: true, force: true });
      }
    } catch (e) {
      return res.status(500).json({ detail: e.message });
    }
  }
  res.json({ success: true });
});

// ---- File Manager ----
app.get('/servers/:uuid/files', authReq, (req, res) => {
  const installPath = req.query.install_path;
  const srv = servers.get(req.params.uuid);
  const basePath = srv ? srv.installPath : installPath;
  if (!basePath) return res.status(400).json({ detail: 'install_path required' });
  try {
    const target = safePath(basePath, req.query.path || '.');
    if (!fs.existsSync(target)) return res.status(404).json({ detail: 'Path not found' });
    if (fs.statSync(target).isFile()) {
      const stat = fs.statSync(target);
      return res.json({
        path: req.query.path, is_dir: false,
        files: [{ name: path.basename(target), size: stat.size, is_dir: false, mode: (stat.mode & 0o777).toString(8), modified: stat.mtime.toISOString() }],
      });
    }
    const items = fs.readdirSync(target).sort((a, b) => {
      const aDir = fs.statSync(path.join(target, a)).isDirectory();
      const bDir = fs.statSync(path.join(target, b)).isDirectory();
      if (aDir !== bDir) return aDir ? -1 : 1;
      return a.localeCompare(b);
    }).map((name) => {
      try {
        const stat = fs.statSync(path.join(target, name));
        return { name, size: stat.size, is_dir: stat.isDirectory(), is_symlink: stat.isSymbolicLink(), mode: (stat.mode & 0o777).toString(8), modified: stat.mtime.toISOString() };
      } catch (_) { return null; }
    }).filter(Boolean);
    res.json({ path: req.query.path, is_dir: true, files: items });
  } catch (e) {
    res.status(400).json({ detail: e.message });
  }
});

app.get('/servers/:uuid/files/read', authReq, (req, res) => {
  const installPath = req.query.install_path;
  const srv = servers.get(req.params.uuid);
  const basePath = srv ? srv.installPath : installPath;
  try {
    const target = safePath(basePath, req.query.path);
    if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) return res.status(404).json({ detail: 'File not found' });
    if (fs.statSync(target).size > 10 * 1024 * 1024) return res.status(413).json({ detail: 'File too large' });
    const content = fs.readFileSync(target, 'utf8');
    res.json({ path: req.query.path, content, size: fs.statSync(target).size });
  } catch (e) {
    res.status(400).json({ detail: e.message });
  }
});

app.post('/servers/:uuid/files/write', authReq, (req, res) => {
  const { path: filePath, content, install_path: installPath } = req.body;
  const srv = servers.get(req.params.uuid);
  const basePath = srv ? srv.installPath : installPath;
  try {
    const target = safePath(basePath, filePath);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, content, 'utf8');
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ detail: e.message });
  }
});

app.post('/servers/:uuid/files/folder', authReq, (req, res) => {
  const { path: folderPath, name, install_path: installPath } = req.body;
  const srv = servers.get(req.params.uuid);
  const basePath = srv ? srv.installPath : installPath;
  try {
    const target = safePath(basePath, path.join(folderPath, name));
    fs.mkdirSync(target, { recursive: true });
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ detail: e.message });
  }
});

app.post('/servers/:uuid/files/rename', authReq, (req, res) => {
  const { path: filePath, new_name: newName, install_path: installPath } = req.body;
  const srv = servers.get(req.params.uuid);
  const basePath = srv ? srv.installPath : installPath;
  try {
    const target = safePath(basePath, filePath);
    const newPath = path.join(path.dirname(target), newName);
    fs.renameSync(target, newPath);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ detail: e.message });
  }
});

app.post('/servers/:uuid/files/delete', authReq, (req, res) => {
  const { paths, install_path: installPath } = req.body;
  const srv = servers.get(req.params.uuid);
  const basePath = srv ? srv.installPath : installPath;
  try {
    for (const p of paths) {
      const target = safePath(basePath, p);
      if (fs.existsSync(target)) {
        if (fs.statSync(target).isDirectory()) fs.rmSync(target, { recursive: true });
        else fs.unlinkSync(target);
      }
    }
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ detail: e.message });
  }
});

const fileUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 1024 * 1024 * 1024 } });
app.post('/servers/:uuid/files/upload', authReq, fileUpload.single('file'), (req, res) => {
  const installPath = req.body.install_path;
  const srv = servers.get(req.params.uuid);
  const basePath = srv ? srv.installPath : installPath;
  try {
    const dir = safePath(basePath, req.body.path || '.');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const dest = path.join(dir, req.file.originalname);
    fs.writeFileSync(dest, req.file.buffer);
    res.json({ success: true, filename: req.file.originalname, size: req.file.size });
  } catch (e) {
    res.status(500).json({ detail: e.message });
  }
});

// URL upload (background download)
app.post('/servers/:uuid/files/upload-url', authReq, async (req, res) => {
  const { url, path: filePath, filename, install_path: installPath } = req.body;
  if (!url || !url.startsWith('http')) return res.status(400).json({ detail: 'Valid URL required' });
  const srv = servers.get(req.params.uuid);
  const basePath = srv ? srv.installPath : installPath;
  const name = filename || url.split('/').pop().split('?')[0] || 'downloaded_file';
  const safeName = name.replace(/[\/\\]/g, '_');
  try {
    const dir = safePath(basePath, filePath || '.');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const dest = path.join(dir, safeName);
    const { downloadFile } = require('./mc-installers');
    const size = await downloadFile(url, dest);
    res.json({ success: true, filename: safeName, size });
  } catch (e) {
    res.status(500).json({ detail: e.message });
  }
});

// Archive (zip/unzip)
app.post('/servers/:uuid/files/archive', authReq, async (req, res) => {
  const { action, path: filePath, name, install_path: installPath } = req.body;
  const srv = servers.get(req.params.uuid);
  const basePath = srv ? srv.installPath : installPath;
  try {
    const target = safePath(basePath, filePath);
    if (action === 'zip') {
      if (!fs.existsSync(target)) return res.status(404).json({ detail: 'Path not found' });
      const zipName = name || (path.basename(target) + '.zip');
      const zipPath = path.join(path.dirname(target), zipName);
      const archive = archiver('zip', { zlib: { level: 9 } });
      const out = fs.createWriteStream(zipPath);
      archive.pipe(out);
      if (fs.statSync(target).isFile()) archive.file(target, { name: path.basename(target) });
      else archive.directory(target, path.basename(target));
      await archive.finalize();
      res.json({ success: true, archive: zipPath });
    } else if (action === 'unzip') {
      if (!target.endsWith('.zip')) return res.status(400).json({ detail: 'Not a zip file' });
      const extractDir = path.join(path.dirname(target), path.basename(target, '.zip') + '_extracted');
      fs.mkdirSync(extractDir, { recursive: true });
      fs.createReadStream(target).pipe(unzipper.Extract({ path: extractDir })).on('close', () => {
        res.json({ success: true, extracted_to: extractDir });
      }).on('error', (e) => res.status(500).json({ detail: e.message }));
    } else {
      res.status(400).json({ detail: 'Invalid action' });
    }
  } catch (e) {
    res.status(500).json({ detail: e.message });
  }
});

// Download file
app.get('/servers/:uuid/files/download', authReq, (req, res) => {
  const installPath = req.query.install_path;
  const srv = servers.get(req.params.uuid);
  const basePath = srv ? srv.installPath : installPath;
  try {
    const target = safePath(basePath, req.query.path);
    if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) return res.status(404).json({ detail: 'File not found' });
    res.download(target, path.basename(target));
  } catch (e) {
    res.status(400).json({ detail: e.message });
  }
});

// ---- Backups ----
app.post('/servers/:uuid/backups', authReq, async (req, res) => {
  const { name, install_path: installPath } = req.body;
  const srv = servers.get(req.params.uuid);
  const basePath = srv ? srv.installPath : installPath;
  if (!basePath || !fs.existsSync(basePath)) return res.status(404).json({ detail: 'Install path not found' });
  const backupUuid = require('crypto').randomBytes(16).toString('hex');
  const backupDir = path.join(BACKUPS_DIR, req.params.uuid);
  if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
  const safeName = (name || 'backup').replace(/[^a-zA-Z0-9_-]/g, '').substring(0, 64);
  const fileName = `${backupUuid}_${safeName}.zip`;
  const backupPath = path.join(backupDir, fileName);

  try {
    await new Promise((resolve, reject) => {
      const archive = archiver('zip', { zlib: { level: 5 } });
      const out = fs.createWriteStream(backupPath);
      archive.pipe(out);
      // Walk directory, skip backups/logs/cache
      const walk = (dir, base = '') => {
        const items = fs.readdirSync(dir);
        for (const item of items) {
          if (['.backup', 'logs', 'cache'].includes(item)) continue;
          const full = path.join(dir, item);
          const rel = base ? path.join(base, item) : item;
          if (fs.statSync(full).isDirectory()) {
            archive.directory(full, rel);
          } else {
            archive.file(full, { name: rel });
          }
        }
      };
      walk(basePath);
      archive.on('error', reject);
      out.on('close', resolve);
      archive.finalize();
    });
    const size = fs.statSync(backupPath).size;
    res.json({ success: true, uuid: backupUuid, file_name: fileName, file_path: backupPath, size_bytes: size });
  } catch (e) {
    res.status(500).json({ detail: e.message });
  }
});

app.get('/servers/:uuid/backups', authReq, (req, res) => {
  const backupDir = path.join(BACKUPS_DIR, req.params.uuid);
  if (!fs.existsSync(backupDir)) return res.json({ backups: [] });
  const backups = fs.readdirSync(backupDir).filter((f) => f.endsWith('.zip')).map((f) => {
    const stat = fs.statSync(path.join(backupDir, f));
    const parts = f.replace('.zip', '').split('_', 2);
    return { uuid: parts[0], name: parts[1] || 'backup', file_name: f, size_bytes: stat.size, created_at: stat.mtime.toISOString() };
  }).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  res.json({ backups });
});

app.post('/servers/:uuid/backups/:backupUuid/restore', authReq, async (req, res) => {
  const backupDir = path.join(BACKUPS_DIR, req.params.uuid);
  const { install_path: installPath } = req.body;
  const srv = servers.get(req.params.uuid);
  const basePath = srv ? srv.installPath : installPath;
  const backupFile = fs.readdirSync(backupDir).find((f) => f.startsWith(req.params.backupUuid + '_'));
  if (!backupFile) return res.status(404).json({ detail: 'Backup not found' });
  // Backup current
  if (fs.existsSync(basePath)) {
    const oldPath = basePath + '.restore_old';
    if (fs.existsSync(oldPath)) fs.rmSync(oldPath, { recursive: true });
    fs.renameSync(basePath, oldPath);
    fs.mkdirSync(basePath, { recursive: true });
  }
  fs.createReadStream(path.join(backupDir, backupFile))
    .pipe(unzipper.Extract({ path: basePath }))
    .on('close', () => res.json({ success: true }))
    .on('error', (e) => res.status(500).json({ detail: e.message }));
});

app.delete('/servers/:uuid/backups/:backupUuid', authReq, (req, res) => {
  const backupDir = path.join(BACKUPS_DIR, req.params.uuid);
  const backupFile = fs.readdirSync(backupDir).find((f) => f.startsWith(req.params.backupUuid + '_'));
  if (!backupFile) return res.status(404).json({ detail: 'Backup not found' });
  fs.unlinkSync(path.join(backupDir, backupFile));
  res.json({ success: true });
});

app.get('/servers/:uuid/backups/:backupUuid/download', authReq, (req, res) => {
  const backupDir = path.join(BACKUPS_DIR, req.params.uuid);
  const backupFile = fs.readdirSync(backupDir).find((f) => f.startsWith(req.params.backupUuid + '_'));
  if (!backupFile) return res.status(404).json({ detail: 'Backup not found' });
  res.download(path.join(backupDir, backupFile));
});

// ---- Node resources ----
app.get('/resources', authReq, async (req, res) => {
  try {
    const mem = await si.mem();
    const disk = await si.fsSize();
    const cpu = await si.currentLoad();
    const cpuCores = cpu.cpus.length;
    const diskMain = disk[0] || {};
    res.json({
      cpu_percent: Math.round(cpu.currentLoad, 2),
      cpu_cores: cpuCores,
      memory_total_mb: Math.round(mem.total / 1024 / 1024),
      memory_used_mb: Math.round(mem.active / 1024 / 1024),
      memory_free_mb: Math.round((mem.total - mem.active) / 1024 / 1024),
      disk_total_mb: Math.round((diskMain.size || 0) / 1024 / 1024),
      disk_used_mb: Math.round((diskMain.used || 0) / 1024 / 1024),
      disk_free_mb: Math.round(((diskMain.size || 0) - (diskMain.used || 0)) / 1024 / 1024),
      servers_running: Array.from(servers.values()).filter((s) => s.process && !s.process.killed).length,
    });
  } catch (e) {
    res.status(500).json({ detail: e.message });
  }
});

// ---- WebSocket console ----
const wss = new WebSocket.Server({ server, path: /\/servers\/[^/]+\/ws$/ });
wss.on('connection', (ws, req) => {
  const url = new URL(req.url, 'http://localhost');
  const parts = url.pathname.split('/');
  const serverUuid = parts[2];
  const token = url.searchParams.get('token') || '';
  if (token !== TOKEN) {
    ws.send('[error] Invalid token');
    ws.close(4401, 'Unauthorized');
    return;
  }
  const srv = servers.get(serverUuid);
  if (!srv) {
    ws.send('[error] Server not found on daemon');
    ws.close(4404, 'Not found');
    return;
  }
  srv.wsClients.add(ws);
  // Send last logs
  for (const line of srv.getLogs(200)) {
    try { ws.send(line); } catch (_) {}
  }
  ws.on('message', (data) => {
    srv.sendCommand(data.toString());
  });
  ws.on('close', () => {
    srv.wsClients.delete(ws);
  });
});

console.log(`[daemon] ogultra daemon starting on ${HOST}:${PORT}`);
console.log(`[daemon] Servers dir: ${SERVERS_DIR}`);
console.log(`[daemon] Backups dir: ${BACKUPS_DIR}`);
console.log(`[daemon] Platform: ${os.platform()} ${os.arch()}`);

server.listen(PORT, HOST, () => {
  console.log(`[daemon] Running on http://${HOST}:${PORT}`);
  // Start heartbeat if panel URL configured
  if (PANEL_URL && NODE_UUID && NODE_API_KEY) {
    startHeartbeat();
  }
});

// Heartbeat to panel
function startHeartbeat() {
  setInterval(async () => {
    try {
      const mem = await si.mem();
      const disk = await si.fsSize();
      const cpu = await si.currentLoad();
      await axios.post(
        `${PANEL_URL}/api/nodes/${NODE_UUID}/heartbeat`,
        {
          memory_used: Math.round(mem.active / 1024 / 1024),
          disk_used: Math.round((disk[0]?.used || 0) / 1024 / 1024),
          cpu_used: Math.round(cpu.currentLoad, 2),
          status: 'online',
        },
        { headers: { Authorization: `Bearer ${NODE_API_KEY}`, 'X-Node-Key': NODE_API_KEY }, timeout: 10000 }
      );
    } catch (e) {
      console.error('[daemon] heartbeat failed:', e.message);
    }
  }, 30000);
  console.log('[daemon] heartbeat to panel started');
}
