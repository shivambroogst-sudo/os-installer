/**
 * mc-installers.js - Minecraft server downloaders
 * Real download scripts for all supported server types.
 * Used by daemon to install servers.
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

/**
 * Download a URL to a file. Returns bytes written.
 */
function downloadFile(url, destPath, maxSize = 1024 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);
    let total = 0;
    let aborted = false;

    const client = url.startsWith('https') ? https : http;
    const req = client.get(url, { headers: { 'User-Agent': 'ogultra/1.0' } }, (resp) => {
      // Handle redirects
      if (resp.statusCode >= 300 && resp.statusCode < 400 && resp.headers.location) {
        file.close();
        fs.unlinkSync(destPath);
        return resolve(downloadFile(resp.headers.location, destPath, maxSize));
      }
      if (resp.statusCode !== 200) {
        file.close();
        fs.unlinkSync(destPath);
        return reject(new Error(`HTTP ${resp.statusCode} for ${url}`));
      }
      resp.on('data', (chunk) => {
        total += chunk.length;
        if (total > maxSize) {
          aborted = true;
          file.close();
          fs.unlinkSync(destPath);
          req.destroy();
          reject(new Error('File too large'));
        }
      });
      resp.pipe(file);
      file.on('finish', () => {
        if (!aborted) {
          file.close();
          resolve(total);
        }
      });
    });
    req.on('error', (e) => {
      if (!aborted) {
        try { fs.unlinkSync(destPath); } catch (_) {}
        reject(e);
      }
    });
  });
}

/**
 * Fetch JSON from URL.
 */
function fetchJson(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const req = client.get(url, { headers: { 'User-Agent': 'ogultra/1.0', Accept: 'application/json' } }, (resp) => {
      if (resp.statusCode >= 300 && resp.statusCode < 400 && resp.headers.location) {
        return resolve(fetchJson(resp.headers.location));
      }
      if (resp.statusCode !== 200) {
        return reject(new Error(`HTTP ${resp.statusCode}`));
      }
      let data = '';
      resp.on('data', (c) => (data += c));
      resp.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
  });
}

// ---- PaperMC (Paper, Waterfall, Velocity) ----

async function installPaperMC(project, version, installPath) {
  if (version === 'latest' || !version) {
    const data = await fetchJson(`https://api.papermc.io/v2/projects/${project}`);
    version = data.versions[data.versions.length - 1];
  }
  const buildData = await fetchJson(`https://api.papermc.io/v2/projects/${project}/versions/${version}`);
  const build = buildData.builds[buildData.builds.length - 1];
  const filename = build.downloads.application.name;
  const downloadUrl = `https://api.papermc.io/v2/projects/${project}/versions/${version}/builds/${build.build}/downloads/${filename}`;
  const canonical = { paper: 'paper.jar', waterfall: 'waterfall.jar', velocity: 'velocity.jar' }[project] || `${project}.jar`;
  const dest = path.join(installPath, filename);
  await downloadFile(downloadUrl, dest);
  // Copy to canonical name
  fs.copyFileSync(dest, path.join(installPath, canonical));
  // EULA
  const eulaPath = path.join(installPath, 'eula.txt');
  if (!fs.existsSync(eulaPath)) fs.writeFileSync(eulaPath, 'eula=true\n');
  return canonical;
}

// ---- Purpur ----

async function installPurpur(version, installPath) {
  if (version === 'latest' || !version) {
    const data = await fetchJson('https://api.purpurmc.org/v2/purpur');
    version = data.version;
  }
  const downloadUrl = `https://api.purpurmc.org/v2/purpur/${version}/latest/download`;
  const dest = path.join(installPath, 'purpur.jar');
  await downloadFile(downloadUrl, dest);
  const eulaPath = path.join(installPath, 'eula.txt');
  if (!fs.existsSync(eulaPath)) fs.writeFileSync(eulaPath, 'eula=true\n');
  return 'purpur.jar';
}

// ---- Vanilla (Mojang) ----

async function installVanilla(version, installPath) {
  if (version === 'latest' || !version) {
    const manifest = await fetchJson('https://launchermeta.mojang.com/mc/game/version_manifest.json');
    version = manifest.latest.release;
  }
  const manifest = await fetchJson('https://launchermeta.mojang.com/mc/game/version_manifest.json');
  const versionInfo = manifest.versions.find((v) => v.id === version);
  if (!versionInfo) throw new Error(`Vanilla version ${version} not found`);
  const versionData = await fetchJson(versionInfo.url);
  if (!versionData.downloads || !versionData.downloads.server) {
    throw new Error(`No server download for ${version}`);
  }
  const dest = path.join(installPath, 'server.jar');
  await downloadFile(versionData.downloads.server.url, dest);
  const eulaPath = path.join(installPath, 'eula.txt');
  if (!fs.existsSync(eulaPath)) fs.writeFileSync(eulaPath, 'eula=true\n');
  return 'server.jar';
}

// ---- Fabric ----

async function installFabric(version, installPath) {
  if (version === 'latest' || !version) {
    const gameData = await fetchJson('https://meta.fabricmc.net/v2/versions/game');
    const stable = gameData.filter((v) => v.stable);
    version = (stable[stable.length - 1] || gameData[0]).version;
  }
  const loaderData = await fetchJson('https://meta.fabricmc.net/v2/versions/loader');
  const loaderVersion = loaderData[0].version;
  const installerData = await fetchJson('https://meta.fabricmc.net/v2/versions/installer');
  const installerVersion = installerData[0].version;
  const downloadUrl = `https://meta.fabricmc.net/v2/versions/loader/${version}/${loaderVersion}/${installerVersion}/server/jar`;
  const dest = path.join(installPath, 'fabric-server.jar');
  await downloadFile(downloadUrl, dest);
  const eulaPath = path.join(installPath, 'eula.txt');
  if (!fs.existsSync(eulaPath)) fs.writeFileSync(eulaPath, 'eula=true\n');
  return 'fabric-server.jar';
}

// ---- Forge ----

async function installForge(version, installPath) {
  if (version === 'latest' || !version) version = '1.20.1';
  const mavenXml = await new Promise((resolve, reject) => {
    https.get('https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml', (resp) => {
      let d = '';
      resp.on('data', (c) => (d += c));
      resp.on('end', () => resolve(d));
    }).on('error', reject);
  });
  const re = new RegExp(`(${version.replace(/\./g, '\\.')}-\\d+\\.\\d+\\.\\d+(?:-\\d+)?)`, 'g');
  const matches = mavenXml.match(re);
  if (!matches) throw new Error(`No Forge builds for ${version}`);
  const forgeVersion = matches[matches.length - 1];
  const dest = path.join(installPath, 'forge.jar');
  try {
    await downloadFile(`https://maven.minecraftforge.net/net/minecraftforge/forge/${forgeVersion}/forge-${forgeVersion}-universal.jar`, dest);
  } catch (e) {
    await downloadFile(`https://maven.minecraftforge.net/net/minecraftforge/forge/${forgeVersion}/forge-${forgeVersion}-installer.jar`, dest);
  }
  const eulaPath = path.join(installPath, 'eula.txt');
  if (!fs.existsSync(eulaPath)) fs.writeFileSync(eulaPath, 'eula=true\n');
  return 'forge.jar';
}

// ---- BungeeCord ----

async function installBungeeCord(version, installPath) {
  const dest = path.join(installPath, 'BungeeCord.jar');
  await downloadFile('https://ci.md-5.net/job/BungeeCord/lastSuccessfulBuild/artifact/bootstrap/target/BungeeCord.jar', dest);
  return 'BungeeCord.jar';
}

// ---- Spigot ----

async function installSpigot(version, installPath) {
  if (version === 'latest' || !version) version = '1.20.4';
  const dest = path.join(installPath, 'spigot.jar');
  try {
    await downloadFile(`https://download.getbukkit.org/spigot/spigot-${version}.jar`, dest);
  } catch (e) {
    throw new Error('Spigot download failed. Please upload spigot.jar manually.');
  }
  const eulaPath = path.join(installPath, 'eula.txt');
  if (!fs.existsSync(eulaPath)) fs.writeFileSync(eulaPath, 'eula=true\n');
  return 'spigot.jar';
}

// ---- Dispatcher ----

const INSTALLERS = {
  paper: (v, p) => installPaperMC('paper', v, p),
  waterfall: (v, p) => installPaperMC('waterfall', v, p),
  velocity: (v, p) => installPaperMC('velocity', v, p),
  purpur: installPurpur,
  vanilla: installVanilla,
  fabric: installFabric,
  forge: installForge,
  bungeecord: installBungeeCord,
  spigot: installSpigot,
};

async function installServer(serverType, version, installPath) {
  const installer = INSTALLERS[serverType.toLowerCase()];
  if (!installer) throw new Error(`Unknown server type: ${serverType}`);
  if (!fs.existsSync(installPath)) fs.mkdirSync(installPath, { recursive: true });
  return installer(version, installPath);
}

module.exports = {
  installServer,
  downloadFile,
  fetchJson,
  INSTALLERS,
};
