/**
 * routes/api.js - REST API with API key auth (Bearer token)
 */
const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { query, queryOne } = require('../db');
const auth = require('../auth');

// API key auth middleware
async function apiAuth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  if (!authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Bearer token required' });
  }
  const token = authHeader.substring(7);
  if (!token.startsWith('og_')) {
    return res.status(401).json({ error: 'Invalid API key format' });
  }
  const keyHash = crypto.createHash('sha256').update(token).digest('hex');
  const apiKey = await queryOne('SELECT * FROM api_keys WHERE key_hash = ? AND is_active = 1', [keyHash]);
  if (!apiKey) return res.status(401).json({ error: 'Invalid API key' });
  if (apiKey.expires_at && new Date(apiKey.expires_at) < new Date()) {
    return res.status(401).json({ error: 'API key expired' });
  }
  const user = await queryOne('SELECT * FROM users WHERE id = ? AND is_active = 1', [apiKey.user_id]);
  if (!user) return res.status(401).json({ error: 'User not found' });
  user.is_admin = (user.role === 'admin' || user.role === 'superadmin');
  req.user = user;
  req.apiKey = apiKey;
  // Update last_used
  require('../db').execute('UPDATE api_keys SET last_used_at = NOW() WHERE id = ?', [apiKey.id]);
  next();
}

function requireApiAdmin(req, res, next) {
  if (!req.user.is_admin) return res.status(403).json({ error: 'Admin access required' });
  next();
}

// GET /api/v1/me
router.get('/v1/me', apiAuth, (req, res) => {
  res.json({ id: req.user.id, uuid: req.user.uuid, username: req.user.username, email: req.user.email, role: req.user.role });
});

// GET /api/v1/servers
router.get('/v1/servers', apiAuth, async (req, res) => {
  let servers;
  if (req.user.is_admin) {
    servers = await query('SELECT * FROM servers ORDER BY created_at DESC');
  } else {
    servers = await query('SELECT * FROM servers WHERE owner_id = ? ORDER BY created_at DESC', [req.user.id]);
  }
  res.json(servers);
});

// GET /api/v1/servers/:uuid
router.get('/v1/servers/:uuid', apiAuth, async (req, res) => {
  const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
  if (!server) return res.status(404).json({ error: 'Not found' });
  if (server.owner_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Access denied' });
  res.json(server);
});

// GET /api/v1/nodes (admin)
router.get('/v1/nodes', apiAuth, requireApiAdmin, async (req, res) => {
  const nodes = await query('SELECT * FROM nodes ORDER BY name');
  res.json(nodes);
});

// GET /api/v1/eggs
router.get('/v1/eggs', apiAuth, async (req, res) => {
  const eggs = await query('SELECT * FROM eggs WHERE is_active = 1 ORDER BY category, name');
  res.json(eggs);
});

// GET /api/v1/audit-logs (admin)
router.get('/v1/audit-logs', apiAuth, requireApiAdmin, async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 50, 200);
  const offset = parseInt(req.query.offset) || 0;
  const logs = await query('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT ? OFFSET ?', [limit, offset]);
  res.json(logs);
});

module.exports = router;
