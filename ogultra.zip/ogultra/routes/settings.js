/**
 * routes/settings.js - User settings + admin system settings + branding upload
 */
const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { query, queryOne, execute } = require('../db');
const auth = require('../auth');
const { buildContext, logAudit, getSetting, setSetting, getCategorySettings, getBranding } = require('../helpers');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
const ALLOWED_EXTS = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.ico'];
const BRANDING_DIR = path.join(__dirname, '..', 'public', 'branding');

// ---- User Settings ----
router.get('/settings', auth.requireAuth, async (req, res) => {
  const apiKeys = await query('SELECT * FROM api_keys WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
  res.render('dashboard/settings', await buildContext(req, { apiKeys, error: null, activePage: 'user_settings' }));
});

router.post('/settings/profile', auth.requireAuth, async (req, res) => {
  const { email, theme, language, timezone } = req.body;
  await execute('UPDATE users SET email = ?, theme = ? WHERE id = ?', [email, theme || 'dark', req.user.id]);
  res.redirect('/settings?tab=profile');
});

router.post('/settings/password', auth.requireAuth, async (req, res) => {
  const { current_password, new_password, new_password_confirm } = req.body;
  const user = await queryOne('SELECT * FROM users WHERE id = ?', [req.user.id]);
  const bcrypt = require('bcryptjs');
  if (!(await bcrypt.compare(current_password, user.password_hash))) {
    const apiKeys = await query('SELECT * FROM api_keys WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
    return res.render('dashboard/settings', await buildContext(req, { apiKeys, error: 'Current password is incorrect', activePage: 'user_settings' }));
  }
  if (new_password !== new_password_confirm) {
    const apiKeys = await query('SELECT * FROM api_keys WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
    return res.render('dashboard/settings', await buildContext(req, { apiKeys, error: 'Passwords do not match', activePage: 'user_settings' }));
  }
  const hash = await bcrypt.hash(new_password, 10);
  await execute('UPDATE users SET password_hash = ? WHERE id = ?', [hash, req.user.id]);
  res.redirect('/settings?tab=password');
});

// ---- API Keys ----
router.post('/settings/api-keys', auth.requireAuth, async (req, res) => {
  const crypto = require('crypto');
  const fullKey = 'og_' + crypto.randomBytes(24).toString('hex');
  const prefix = fullKey.substring(0, 12);
  const keyHash = crypto.createHash('sha256').update(fullKey).digest('hex');
  await execute(
    'INSERT INTO api_keys (user_id, name, key_prefix, key_hash, expires_at) VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 365 DAY))',
    [req.user.id, req.body.name, prefix, keyHash]
  );
  res.json({ success: true, key: fullKey, prefix, message: 'Save this key - it will not be shown again' });
});

router.post('/settings/api-keys/:id/delete', auth.requireAuth, async (req, res) => {
  await execute('DELETE FROM api_keys WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
  res.redirect('/settings?tab=api-keys');
});

// ---- Admin: System Settings ----
router.get('/admin/settings', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const branding = await getCategorySettings('branding');
  const smtp = await getCategorySettings('smtp');
  const features = await getCategorySettings('features');
  const limits = await getCategorySettings('limits');
  res.render('admin/settings', await buildContext(req, { branding, smtp, features, limits, activePage: 'admin_settings' }));
});

router.post('/admin/settings/branding', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const { app_name, custom_footer } = req.body;
  await setSetting('app_name', app_name, 'branding');
  await setSetting('custom_footer', custom_footer, 'branding');
  await logAudit({ userId: req.user.id, action: 'settings.update', description: 'Updated branding', req });
  res.redirect('/admin/settings?tab=branding');
});

// Branding image upload (logo/favicon)
router.post('/admin/settings/branding/upload', auth.requireAuth, auth.requireAdmin, upload.single('file'), async (req, res) => {
  const type = req.body.type; // 'logo' or 'favicon'
  if (!['logo', 'favicon'].includes(type)) return res.status(400).json({ error: 'Invalid type' });
  const ext = path.extname(req.file.originalname).toLowerCase();
  if (!ALLOWED_EXTS.includes(ext)) return res.status(400).json({ error: 'Invalid file type' });

  if (!fs.existsSync(BRANDING_DIR)) fs.mkdirSync(BRANDING_DIR, { recursive: true });
  // Remove old files of this type
  for (const e of ALLOWED_EXTS) {
    const old = path.join(BRANDING_DIR, `${type}${e}`);
    if (fs.existsSync(old)) fs.unlinkSync(old);
  }
  const filename = `${type}${ext}`;
  fs.writeFileSync(path.join(BRANDING_DIR, filename), req.file.buffer);
  const staticUrl = `/branding/${filename}`;
  await setSetting(`${type}_url`, staticUrl, 'branding');
  await logAudit({ userId: req.user.id, action: 'settings.branding_upload', description: `Uploaded ${type}`, req });
  res.json({ success: true, url: staticUrl, filename, message: `${type} uploaded successfully` });
});

router.post('/admin/settings/branding/remove', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const type = req.body.type;
  for (const e of ALLOWED_EXTS) {
    const f = path.join(BRANDING_DIR, `${type}${e}`);
    if (fs.existsSync(f)) fs.unlinkSync(f);
  }
  await setSetting(`${type}_url`, '', 'branding');
  res.json({ success: true, message: `${type} removed` });
});

router.post('/admin/settings/smtp', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const { smtp_enabled, smtp_host, smtp_port, smtp_user, smtp_password, smtp_from, smtp_tls } = req.body;
  await setSetting('smtp_enabled', smtp_enabled ? 'true' : 'false', 'smtp');
  await setSetting('smtp_host', smtp_host || '', 'smtp');
  await setSetting('smtp_port', smtp_port || '587', 'smtp');
  await setSetting('smtp_user', smtp_user || '', 'smtp');
  await setSetting('smtp_password', smtp_password || '', 'smtp');
  await setSetting('smtp_from', smtp_from || '', 'smtp');
  await setSetting('smtp_tls', smtp_tls ? 'true' : 'false', 'smtp');
  res.redirect('/admin/settings?tab=smtp');
});

router.post('/admin/settings/features', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const { maintenance_mode, registration_enabled, email_verification_required, password_reset_enabled } = req.body;
  await setSetting('maintenance_mode', maintenance_mode ? 'true' : 'false', 'features');
  await setSetting('registration_enabled', registration_enabled ? 'true' : 'false', 'features');
  await setSetting('email_verification_required', email_verification_required ? 'true' : 'false', 'features');
  await setSetting('password_reset_enabled', password_reset_enabled ? 'true' : 'false', 'features');
  res.redirect('/admin/settings?tab=features');
});

router.post('/admin/settings/limits', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const { max_servers_per_user, default_memory_mb, default_disk_mb, default_cpu_percent } = req.body;
  await setSetting('max_servers_per_user', max_servers_per_user, 'limits');
  await setSetting('default_memory_mb', default_memory_mb, 'limits');
  await setSetting('default_disk_mb', default_disk_mb, 'limits');
  await setSetting('default_cpu_percent', default_cpu_percent, 'limits');
  res.redirect('/admin/settings?tab=limits');
});

module.exports = router;
