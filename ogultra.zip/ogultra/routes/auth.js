/**
 * routes/auth.js - Authentication routes (login, register, logout, reset)
 */
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const { query, queryOne, execute, uuid } = require('../db');
const auth = require('../auth');
const { logAudit, buildContext, getBranding, getSetting } = require('../helpers');

const loginLimiter = rateLimit({ windowMs: 60 * 1000, max: 10, message: { error: 'Too many login attempts' } });
const registerLimiter = rateLimit({ windowMs: 60 * 1000, max: 5, message: { error: 'Too many registrations' } });

// GET /login
router.get('/login', async (req, res) => {
  if (req.user) return res.redirect('/dashboard');
  res.render('auth/login', await buildContext(req, { error: null, next: req.query.next || '/dashboard' }));
});

// POST /login
router.post('/login', loginLimiter, async (req, res) => {
  const { identifier, password, next } = req.body;
  if (!identifier || !password) {
    return res.render('auth/login', await buildContext(req, { error: 'Username and password required', next: next || '/dashboard' }));
  }
  try {
    const user = await queryOne('SELECT * FROM users WHERE username = ? OR email = ? AND is_active = 1', [identifier, identifier]);
    if (!user || !(await auth.verifyPassword(password, user.password_hash))) {
      return res.render('auth/login', await buildContext(req, { error: 'Invalid credentials', next: next || '/dashboard' }));
    }
    const token = auth.createToken(user);
    auth.setSessionCookie(res, token);
    if (!req.cookies[auth.CSRF_COOKIE]) auth.setCsrfCookie(res, auth.generateCsrfToken());
    await execute('UPDATE users SET last_login_at = NOW(), last_login_ip = ? WHERE id = ?', [req.ip, user.id]);
    await logAudit({ userId: user.id, action: 'auth.login', description: `User '${user.username}' logged in`, req });
    res.redirect(next || '/dashboard');
  } catch (e) {
    console.error('[login] error:', e);
    res.render('auth/login', await buildContext(req, { error: 'Server error', next: next || '/dashboard' }));
  }
});

// GET /register
router.get('/register', async (req, res) => {
  if (req.user) return res.redirect('/dashboard');
  const regEnabled = (await getSetting('registration_enabled', 'features'))?.value !== 'false';
  if (!regEnabled) {
    return res.render('auth/login', await buildContext(req, { error: 'Registration is disabled' }));
  }
  res.render('auth/register', await buildContext(req, { errors: null }));
});

// POST /register
router.post('/register', registerLimiter, async (req, res) => {
  const { username, email, password, password_confirm } = req.body;
  const errors = [];
  if (!username || username.length < 3) errors.push('Username must be at least 3 characters');
  if (!/^[a-zA-Z0-9_.-]+$/.test(username)) errors.push('Username contains invalid characters');
  if (!email || !/^[^@]+@[^@]+\.[^@]+$/.test(email)) errors.push('Valid email required');
  if (!password || password.length < 8) errors.push('Password must be at least 8 characters');
  if (password !== password_confirm) errors.push('Passwords do not match');

  if (errors.length) {
    return res.render('auth/register', await buildContext(req, { errors, username, email }));
  }
  try {
    const existing = await queryOne('SELECT id FROM users WHERE username = ? OR email = ?', [username, email]);
    if (existing) {
      return res.render('auth/register', await buildContext(req, { errors: ['Username or email already exists'], username, email }));
    }
    const hash = await auth.hashPassword(password);
    const userUuid = uuid();
    await execute(
      'INSERT INTO users (uuid, username, email, password_hash, role, is_email_verified) VALUES (?, ?, ?, ?, "user", 1)',
      [userUuid, username, email, hash]
    );
    const user = await queryOne('SELECT * FROM users WHERE uuid = ?', [userUuid]);
    const token = auth.createToken(user);
    auth.setSessionCookie(res, token);
    auth.setCsrfCookie(res, auth.generateCsrfToken());
    await logAudit({ userId: user.id, action: 'auth.register', description: `New user: ${username}`, req });
    res.redirect('/dashboard');
  } catch (e) {
    console.error('[register] error:', e);
    res.render('auth/register', await buildContext(req, { errors: ['Server error'], username, email }));
  }
});

// POST /logout
router.post('/logout', (req, res) => {
  if (req.user) {
    logAudit({ userId: req.user.id, action: 'auth.logout', description: `User '${req.user.username}' logged out`, req });
  }
  auth.clearCookies(res);
  res.redirect('/login');
});

// GET /reset-password
router.get('/reset-password', async (req, res) => {
  res.render('auth/reset', await buildContext(req, { error: null, success: null }));
});

// POST /reset-password
router.post('/reset-password', async (req, res) => {
  const { email } = req.body;
  // Always show same message
  res.render('auth/reset', await buildContext(req, { error: null, success: 'If that email exists, a reset link has been sent.' }));
});

module.exports = router;
