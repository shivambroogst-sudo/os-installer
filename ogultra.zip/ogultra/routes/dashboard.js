/**
 * routes/dashboard.js - User and admin dashboard
 */
const express = require('express');
const router = express.Router();
const { query, queryOne } = require('../db');
const auth = require('../auth');
const { buildContext, getUnreadCount } = require('../helpers');

// GET /dashboard
router.get('/dashboard', auth.requireAuth, async (req, res) => {
  try {
    const servers = await query('SELECT * FROM servers WHERE owner_id = ? ORDER BY created_at DESC', [req.user.id]);
    const stats = {
      total: servers.length,
      running: servers.filter((s) => s.status === 'running').length,
      suspended: servers.filter((s) => s.is_suspended).length,
      memory: servers.reduce((sum, s) => sum + s.memory_limit, 0),
    };
    const notifications = await query('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 5', [req.user.id]);
    res.render('dashboard/index', await buildContext(req, { servers, stats, notifications, activePage: 'dashboard' }));
  } catch (e) {
    console.error('[dashboard] error:', e);
    res.status(500).render('errors/500', await buildContext(req, { error: e.message }));
  }
});

// GET /admin (admin dashboard)
router.get('/admin', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  try {
    const [usersCount] = await query('SELECT COUNT(*) as cnt FROM users');
    const [serversCount] = await query('SELECT COUNT(*) as cnt FROM servers');
    const [nodesCount] = await query('SELECT COUNT(*) as cnt FROM nodes');
    const [runningCount] = await query('SELECT COUNT(*) as cnt FROM servers WHERE status = "running"');
    const nodes = await query('SELECT * FROM nodes ORDER BY name');
    const recentLogs = await query('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 20');
    const recentServers = await query('SELECT s.*, u.username as owner_name FROM servers s JOIN users u ON s.owner_id = u.id ORDER BY s.created_at DESC LIMIT 10');
    res.render('dashboard/admin', await buildContext(req, {
      stats: { users: usersCount.cnt, servers: serversCount.cnt, nodes: nodesCount.cnt, running: runningCount.cnt },
      nodes, recentLogs, recentServers, activePage: 'admin_dashboard',
    }));
  } catch (e) {
    console.error('[admin dashboard] error:', e);
    res.status(500).render('errors/500', await buildContext(req, { error: e.message }));
  }
});

// GET /notifications
router.get('/notifications', auth.requireAuth, async (req, res) => {
  const notifications = await query('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', [req.user.id]);
  res.render('dashboard/notifications', await buildContext(req, { notifications, activePage: 'notifications' }));
});

// POST /api/notifications/:id/read
router.post('/api/notifications/:id/read', auth.requireAuth, async (req, res) => {
  await require('../db').execute('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
  res.json({ success: true });
});

// POST /api/notifications/read-all
router.post('/api/notifications/read-all', auth.requireAuth, async (req, res) => {
  await require('../db').execute('UPDATE notifications SET is_read = 1 WHERE user_id = ?', [req.user.id]);
  res.json({ success: true });
});

// GET /api/ws-token - short-lived WS token
router.get('/api/ws-token', auth.requireAuth, (req, res) => {
  const jwt = require('jsonwebtoken');
  const token = jwt.sign(
    { sub: req.user.id, username: req.user.username, role: req.user.role, ws: true },
    process.env.JWT_SECRET || 'change-me',
    { expiresIn: '5m' }
  );
  res.json({ token, expires_in: 300 });
});

module.exports = router;
