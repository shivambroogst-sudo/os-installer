/**
 * routes/console.js - WebSocket console proxy
 * Panel WS <-> Daemon WS (browser <-> panel <-> daemon <-> server process)
 * Uses short-lived WS token fetched from /api/ws-token (since session cookie is HttpOnly).
 */
const WebSocket = require('ws');
const jwt = require('jsonwebtoken');
const { queryOne } = require('../db');

function setupConsoleWebSocket(server, app) {
  const wss = new WebSocket.Server({ server, path: /\/ws\/servers\/[^/]+\/console$/ });

  wss.on('connection', async (ws, req) => {
    // Parse URL: /ws/servers/:uuid/console?token=xxx
    const url = new URL(req.url, 'http://localhost');
    const parts = url.pathname.split('/');
    const serverUuid = parts[3];
    const token = url.searchParams.get('token') || '';

    // Auth
    let payload;
    try {
      payload = jwt.verify(token, process.env.JWT_SECRET || 'change-me');
    } catch (e) {
      ws.send('[error] Authentication failed. Please refresh the page.');
      ws.close(4401, 'Unauthorized');
      return;
    }

    const user = await queryOne('SELECT * FROM users WHERE id = ? AND is_active = 1', [payload.sub]);
    if (!user) {
      ws.send('[error] User not found.');
      ws.close(4401, 'Unauthorized');
      return;
    }

    const srv = await queryOne('SELECT * FROM servers WHERE uuid = ?', [serverUuid]);
    if (!srv) {
      ws.send('[error] Server not found.');
      ws.close(4404, 'Not found');
      return;
    }
    if (srv.owner_id !== user.id && !(user.role === 'admin' || user.role === 'superadmin')) {
      ws.send('[error] Access denied.');
      ws.close(4403, 'Denied');
      return;
    }

    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [srv.node_id]);
    if (!node) {
      ws.send('[error] Node not found.');
      ws.close(4404, 'Node not found');
      return;
    }

    // Status-based messages
    if (srv.status === 'failed') {
      ws.send('[warning] Server install failed. Click Reinstall to try again.');
      ws.send('[info] Console will be available once server is running.');
      ws.on('message', () => {});
      return;
    }
    if (srv.status === 'suspended') {
      ws.send('[warning] Server is suspended. Contact admin.');
      ws.on('message', () => {});
      return;
    }

    // Connect to daemon WS
    const daemonWsUrl = `ws://${node.daemon_host}:${node.daemon_port}/servers/${serverUuid}/ws?token=${node.auth_token}`;
    let daemonWs;
    try {
      daemonWs = new WebSocket(daemonWsUrl);
    } catch (e) {
      ws.send(`[error] Cannot connect to daemon: ${e.message}`);
      return;
    }

    let connected = false;
    const timeout = setTimeout(() => {
      if (!connected) {
        ws.send('[error] Daemon connection timeout.');
        try { daemonWs.close(); } catch (_) {}
      }
    }, 15000);

    daemonWs.on('open', () => {
      clearTimeout(timeout);
      connected = true;
      ws.send('[connected] Console live stream started.');
    });

    daemonWs.on('message', (data) => {
      try { ws.send(data.toString()); } catch (_) {}
    });

    daemonWs.on('close', () => {
      try { ws.send('[disconnected] Daemon closed connection.'); } catch (_) {}
      try { ws.close(); } catch (_) {}
    });

    daemonWs.on('error', (err) => {
      clearTimeout(timeout);
      try { ws.send(`[error] Daemon error: ${err.message}`); } catch (_) {}
    });

    // Browser -> daemon
    ws.on('message', (data) => {
      try { daemonWs.send(data.toString()); } catch (_) {}
    });

    ws.on('close', () => {
      clearTimeout(timeout);
      try { daemonWs.close(); } catch (_) {}
    });

    ws.on('error', () => {
      clearTimeout(timeout);
      try { daemonWs.close(); } catch (_) {}
    });
  });

  console.log('[panel] WebSocket console proxy ready at /ws/servers/:uuid/console');
}

module.exports = { setupConsoleWebSocket };
