/**
 * routes/backups.js - Backup routes
 */
const express = require('express');
const router = express.Router();
const { query, queryOne, execute, uuid } = require('../db');
const auth = require('../auth');
const { buildContext, getDaemonClient, logAudit } = require('../helpers');

async function getServerClient(serverUuid, user) {
  const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [serverUuid]);
  if (!server) throw Object.assign(new Error('Server not found'), { status: 404 });
  if (server.owner_id !== user.id && !user.is_admin) throw Object.assign(new Error('Access denied'), { status: 403 });
  const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
  return { server, client: getDaemonClient(node) };
}

// GET /servers/:uuid/backups
router.get('/servers/:uuid/backups', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    let backups = [];
    try {
      const resp = await client.listBackups(server.uuid);
      backups = resp.data.backups || [];
    } catch (_) {}
    res.render('servers/backups', await buildContext(req, { server, node, backups, activePage: 'backups' }));
  } catch (e) {
    res.status(500).render('errors/500', await buildContext(req, { error: e.message }));
  }
});

// POST /api/servers/:uuid/backups
router.post('/api/servers/:uuid/backups', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const resp = await client.createBackup(server.uuid, req.body.name || 'Backup');
    res.json(resp.data);
  } catch (e) {
    res.status(500).json({ error: e.response?.data?.detail || e.message });
  }
});

// POST /api/servers/:uuid/backups/:backupUuid/restore
router.post('/api/servers/:uuid/backups/:backupUuid/restore', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    await client.restoreBackup(server.uuid, req.params.backupUuid);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.response?.data?.detail || e.message });
  }
});

// DELETE /api/servers/:uuid/backups/:backupUuid
router.delete('/api/servers/:uuid/backups/:backupUuid', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    await client.deleteBackup(server.uuid, req.params.backupUuid);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.response?.data?.detail || e.message });
  }
});

// GET /api/servers/:uuid/backups/:backupUuid/download
router.get('/api/servers/:uuid/backups/:backupUuid/download', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const resp = await client.downloadBackup(server.uuid, req.params.backupUuid);
    res.setHeader('Content-Disposition', `attachment; filename="backup-${req.params.backupUuid}.zip"`);
    res.setHeader('Content-Type', 'application/zip');
    res.send(Buffer.from(resp.data));
  } catch (e) {
    res.status(500).json({ error: e.response?.data?.detail || e.message });
  }
});

module.exports = router;
