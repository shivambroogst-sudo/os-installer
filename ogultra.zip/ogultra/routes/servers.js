/**
 * routes/servers.js - Server management routes
 */
const express = require('express');
const router = express.Router();
const { query, queryOne, execute, uuid } = require('../db');
const auth = require('../auth');
const { buildContext, getDaemonClient, logAudit, createNotification } = require('../helpers');
const { listEggs, getEgg } = require('../eggs');

// GET /servers
router.get('/servers', auth.requireAuth, async (req, res) => {
  let servers;
  if (req.user.is_admin) {
    servers = await query('SELECT s.*, u.username as owner_name, n.name as node_name FROM servers s JOIN users u ON s.owner_id = u.id JOIN nodes n ON s.node_id = n.id ORDER BY s.created_at DESC');
  } else {
    servers = await query('SELECT s.*, n.name as node_name FROM servers s JOIN nodes n ON s.node_id = n.id WHERE s.owner_id = ? ORDER BY s.created_at DESC', [req.user.id]);
  }
  res.render('servers/list', await buildContext(req, { servers, activePage: 'servers' }));
});

// GET /servers/create
router.get('/servers/create', auth.requireAuth, async (req, res) => {
  const nodes = await query('SELECT * FROM nodes WHERE status = "online" ORDER BY name');
  const eggs = await listEggs(true);
  res.render('servers/create', await buildContext(req, { nodes, eggs, error: null, activePage: 'servers_create' }));
});

// POST /servers/create
router.post('/servers/create', auth.requireAuth, async (req, res) => {
  const { name, description, egg_id, version, node_id, memory_limit, disk_limit, cpu_limit, expires_in_days, auto_restart } = req.body;
  try {
    const node = await queryOne('SELECT * FROM nodes WHERE id = ? AND status = "online"', [node_id]);
    if (!node) {
      const nodes = await query('SELECT * FROM nodes WHERE status = "online" ORDER BY name');
      const eggs = await listEggs(true);
      return res.render('servers/create', await buildContext(req, { nodes, eggs, error: 'Node not found or offline', activePage: 'servers_create' }));
    }
    const egg = await getEgg(egg_id);
    if (!egg) {
      const nodes = await query('SELECT * FROM nodes WHERE status = "online" ORDER BY name');
      const eggs = await listEggs(true);
      return res.render('servers/create', await buildContext(req, { nodes, eggs, error: 'Invalid egg selected', activePage: 'servers_create' }));
    }

    // Allocate port
    const usedPorts = (await query('SELECT port FROM allocations WHERE node_id = ?', [node_id])).map((r) => r.port);
    let port = 25565;
    for (let p = 25565; p < 25600; p++) {
      if (!usedPorts.includes(p)) { port = p; break; }
    }
    const allocResult = await execute(
      'INSERT INTO allocations (node_id, ip, port, is_primary, is_assigned) VALUES (?, ?, ?, 1, 1)',
      [node_id, '0.0.0.0', port]
    );

    // Variables from egg + user overrides
    const eggVars = egg.variables ? (typeof egg.variables === 'string' ? JSON.parse(egg.variables) : egg.variables) : [];
    const variables = {};
    for (const v of eggVars) {
      variables[v.env_variable] = v.default_value;
    }
    if (version) variables.SERVER_VERSION = version;
    variables.SERVER_MEMORY = String(memory_limit || egg.default_memory);

    // Render startup command
    let startupCommand = egg.startup_command;
    for (const [k, v] of Object.entries(variables)) {
      startupCommand = startupCommand.replace(new RegExp(`\\{\\{${k}\\}\\}`, 'g'), v);
    }

    const serverUuid = uuid();
    const installPath = `/srv/ogultra/servers/${serverUuid}`;
    const expiresAt = expires_in_days && parseInt(expires_in_days) > 0
      ? new Date(Date.now() + parseInt(expires_in_days) * 86400000)
      : null;

    await execute(
      `INSERT INTO servers (uuid, name, description, owner_id, node_id, allocation_id, egg_id, server_type, version, status, memory_limit, disk_limit, cpu_limit, startup_command, startup_variables, auto_restart, install_path, expires_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'installing', ?, ?, ?, ?, ?, ?, ?, ?)`,
      [serverUuid, name, description || null, req.user.id, node_id, allocResult.insertId, egg_id,
       egg.category === 'proxy' ? egg.name.toLowerCase() : egg.name.toLowerCase(),
       version || 'latest', memory_limit || egg.default_memory, disk_limit || egg.default_disk,
       cpu_limit || egg.default_cpu, startupCommand, JSON.stringify(variables),
       auto_restart ? 1 : 0, installPath, expiresAt]
    );

    // Update allocation
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [serverUuid]);
    await execute('UPDATE allocations SET server_id = ? WHERE id = ?', [server.id, allocResult.insertId]);

    await logAudit({ userId: req.user.id, serverId: server.id, action: 'server.create', description: `Created server '${name}'`, req });
    await createNotification(req.user.id, 'Server Created', `Your server '${name}' is being installed.`, 'info', `/servers/${serverUuid}`);

    // Trigger install on daemon (best-effort)
    try {
      const client = getDaemonClient(node);
      await client.installServer({
        uuid: serverUuid,
        type: egg.name.toLowerCase(),
        version: version || 'latest',
        install_path: installPath,
        memory_limit: memory_limit || egg.default_memory,
      });
      await execute('UPDATE servers SET status = "installed" WHERE id = ?', [server.id]);
    } catch (e) {
      console.error('[server create] install failed:', e.message);
      await execute('UPDATE servers SET status = "failed" WHERE id = ?', [server.id]);
      await createNotification(req.user.id, 'Install Failed', `Server '${name}' install failed: ${e.message}`, 'error', `/servers/${serverUuid}`);
    }

    res.redirect(`/servers/${serverUuid}`);
  } catch (e) {
    console.error('[server create] error:', e);
    const nodes = await query('SELECT * FROM nodes WHERE status = "online" ORDER BY name');
    const eggs = await listEggs(true);
    res.render('servers/create', await buildContext(req, { nodes, eggs, error: e.message, activePage: 'servers_create' }));
  }
});

// GET /servers/:uuid
router.get('/servers/:uuid', auth.requireAuth, async (req, res) => {
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
    if (!server) return res.status(404).render('errors/404', await buildContext(req));
    if (server.owner_id !== req.user.id && !req.user.is_admin) {
      return res.status(403).render('errors/403', await buildContext(req));
    }
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    const alloc = server.allocation_id ? await queryOne('SELECT * FROM allocations WHERE id = ?', [server.allocation_id]) : null;
    const egg = server.egg_id ? await queryOne('SELECT * FROM eggs WHERE id = ?', [server.egg_id]) : null;
    const tab = req.query.tab || 'overview';
    res.render('servers/manage', await buildContext(req, { server, node, alloc, egg, tab, activePage: 'server_detail' }));
  } catch (e) {
    console.error('[server view] error:', e);
    res.status(500).render('errors/500', await buildContext(req, { error: e.message }));
  }
});

// POST /servers/:uuid/start
router.post('/servers/:uuid/start', auth.requireAuth, async (req, res) => {
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
    if (!server) return res.status(404).json({ error: 'Not found' });
    if (server.owner_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Access denied' });
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    const client = getDaemonClient(node);
    const variables = server.startup_variables ? (typeof server.startup_variables === 'string' ? JSON.parse(server.startup_variables) : server.startup_variables) : {};
    variables.SERVER_MEMORY = String(server.memory_limit);
    let command = server.startup_command;
    for (const [k, v] of Object.entries(variables)) {
      command = command.replace(new RegExp(`\\{\\{${k}\\}\\}`, 'g'), v);
    }
    await client.startServer(server.uuid, { install_path: server.install_path, command, memory_limit: server.memory_limit, env: variables, auto_restart: server.auto_restart });
    await execute('UPDATE servers SET status = "running", last_started_at = NOW() WHERE id = ?', [server.id]);
    await logAudit({ userId: req.user.id, serverId: server.id, action: 'server.start', description: `Started '${server.name}'`, req });
    res.json({ success: true, status: 'running' });
  } catch (e) {
    console.error('[server start] error:', e.message);
    res.status(500).json({ error: e.response?.data?.detail || e.message });
  }
});

// POST /servers/:uuid/stop
router.post('/servers/:uuid/stop', auth.requireAuth, async (req, res) => {
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
    if (!server) return res.status(404).json({ error: 'Not found' });
    if (server.owner_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Access denied' });
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    const client = getDaemonClient(node);
    await client.stopServer(server.uuid);
    await execute('UPDATE servers SET status = "stopped", last_stopped_at = NOW() WHERE id = ?', [server.id]);
    await logAudit({ userId: req.user.id, serverId: server.id, action: 'server.stop', description: `Stopped '${server.name}'`, req });
    res.json({ success: true, status: 'stopped' });
  } catch (e) {
    res.status(500).json({ error: e.response?.data?.detail || e.message });
  }
});

// POST /servers/:uuid/restart
router.post('/servers/:uuid/restart', auth.requireAuth, async (req, res) => {
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
    if (!server) return res.status(404).json({ error: 'Not found' });
    if (server.owner_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Access denied' });
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    const client = getDaemonClient(node);
    await client.restartServer(server.uuid);
    await execute('UPDATE servers SET status = "running", last_started_at = NOW() WHERE id = ?', [server.id]);
    res.json({ success: true, status: 'running' });
  } catch (e) {
    res.status(500).json({ error: e.response?.data?.detail || e.message });
  }
});

// POST /servers/:uuid/kill
router.post('/servers/:uuid/kill', auth.requireAuth, async (req, res) => {
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
    if (!server) return res.status(404).json({ error: 'Not found' });
    if (server.owner_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Access denied' });
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    const client = getDaemonClient(node);
    await client.killServer(server.uuid);
    await execute('UPDATE servers SET status = "stopped", last_stopped_at = NOW() WHERE id = ?', [server.id]);
    res.json({ success: true, status: 'stopped' });
  } catch (e) {
    res.status(500).json({ error: e.response?.data?.detail || e.message });
  }
});

// POST /servers/:uuid/reinstall
router.post('/servers/:uuid/reinstall', auth.requireAuth, async (req, res) => {
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
    if (!server) return res.status(404).json({ error: 'Not found' });
    if (server.owner_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Access denied' });
    const egg = await getEgg(server.egg_id);
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    const client = getDaemonClient(node);
    await execute('UPDATE servers SET status = "installing" WHERE id = ?', [server.id]);
    await client.installServer({ uuid: server.uuid, type: egg.name.toLowerCase(), version: server.version, install_path: server.install_path, memory_limit: server.memory_limit });
    await execute('UPDATE servers SET status = "installed" WHERE id = ?', [server.id]);
    res.redirect(`/servers/${server.uuid}`);
  } catch (e) {
    await execute('UPDATE servers SET status = "failed" WHERE id = ?', [server.uuid]);
    res.redirect(`/servers/${server.uuid}`);
  }
});

// POST /servers/:uuid/delete
router.post('/servers/:uuid/delete', auth.requireAuth, async (req, res) => {
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
    if (!server) return res.status(404).json({ error: 'Not found' });
    if (server.owner_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Access denied' });
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    const client = getDaemonClient(node);
    try { await client.deleteServer(server.uuid, server.install_path); } catch (_) {}
    await execute('UPDATE allocations SET server_id = NULL, is_assigned = 0 WHERE server_id = ?', [server.id]);
    await execute('DELETE FROM servers WHERE id = ?', [server.id]);
    await logAudit({ userId: req.user.id, serverId: server.id, action: 'server.delete', description: `Deleted '${server.name}'`, req });
    res.redirect('/servers');
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /servers/:uuid/settings
router.post('/servers/:uuid/settings', auth.requireAuth, async (req, res) => {
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
    if (!server) return res.status(404).json({ error: 'Not found' });
    if (server.owner_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Access denied' });
    const { name, description, memory_limit, disk_limit, cpu_limit, startup_command, auto_restart } = req.body;
    await execute(
      'UPDATE servers SET name = ?, description = ?, memory_limit = ?, disk_limit = ?, cpu_limit = ?, startup_command = ?, auto_restart = ? WHERE id = ?',
      [name, description || null, memory_limit, disk_limit, cpu_limit, startup_command || server.startup_command, auto_restart ? 1 : 0, server.id]
    );
    await logAudit({ userId: req.user.id, serverId: server.id, action: 'server.update', description: `Updated '${name}'`, req });
    res.redirect(`/servers/${server.uuid}?tab=settings`);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/servers/:uuid/status
router.get('/api/servers/:uuid/status', auth.requireAuth, async (req, res) => {
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
    if (!server) return res.status(404).json({ error: 'Not found' });
    if (server.owner_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Access denied' });
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    const client = getDaemonClient(node);
    let live = null, resources = null;
    try {
      const statusResp = await client.getStatus(server.uuid);
      live = statusResp.data;
      const resResp = await client.getResources(server.uuid);
      resources = resResp.data;
    } catch (_) {}
    res.json({ db_status: server.status, is_suspended: server.is_suspended, live, resources });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/servers/:uuid/logs
router.get('/api/servers/:uuid/logs', auth.requireAuth, async (req, res) => {
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
    if (!server) return res.status(404).json({ error: 'Not found' });
    if (server.owner_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Access denied' });
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    const client = getDaemonClient(node);
    const resp = await client.getLogs(server.uuid, parseInt(req.query.lines) || 200);
    res.json(resp.data);
  } catch (e) {
    res.status(503).json({ error: e.message, logs: [] });
  }
});

// POST /api/servers/:uuid/command
router.post('/api/servers/:uuid/command', auth.requireAuth, async (req, res) => {
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
    if (!server) return res.status(404).json({ error: 'Not found' });
    if (server.owner_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Access denied' });
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    const client = getDaemonClient(node);
    await client.sendCommand(server.uuid, req.body.command);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /servers/:uuid/suspend (admin)
router.post('/servers/:uuid/suspend', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
  if (!server) return res.status(404).json({ error: 'Not found' });
  try {
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    const client = getDaemonClient(node);
    await client.stopServer(server.uuid);
  } catch (_) {}
  await execute('UPDATE servers SET is_suspended = 1, status = "suspended", suspension_reason = ? WHERE id = ?', [req.body.reason || null, server.id]);
  await createNotification(server.owner_id, 'Server Suspended', `Your server '${server.name}' has been suspended.`, 'warning', `/servers/${server.uuid}`);
  res.redirect(`/servers/${server.uuid}`);
});

// POST /servers/:uuid/unsuspend (admin)
router.post('/servers/:uuid/unsuspend', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
  if (!server) return res.status(404).json({ error: 'Not found' });
  await execute('UPDATE servers SET is_suspended = 0, status = "stopped", suspension_reason = NULL WHERE id = ?', [server.id]);
  await createNotification(server.owner_id, 'Server Unsuspended', `Your server '${server.name}' has been unsuspended.`, 'success', `/servers/${server.uuid}`);
  res.redirect(`/servers/${server.uuid}`);
});

module.exports = router;
