/**
 * routes/files.js - File manager routes (proxy to daemon)
 */
const express = require('express');
const router = express.Router();
const { queryOne } = require('../db');
const auth = require('../auth');
const { buildContext, getDaemonClient, logAudit } = require('../helpers');

// GET /servers/:uuid/files
router.get('/servers/:uuid/files', auth.requireAuth, async (req, res) => {
  try {
    const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [req.params.uuid]);
    if (!server) return res.status(404).render('errors/404', await buildContext(req));
    if (server.owner_id !== req.user.id && !req.user.is_admin) return res.status(403).render('errors/403', await buildContext(req));
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    res.render('files/manager', await buildContext(req, { server, node, currentPath: req.query.path || '.', activePage: 'files' }));
  } catch (e) {
    res.status(500).render('errors/500', await buildContext(req, { error: e.message }));
  }
});

// Helper: get daemon client for server
async function getServerClient(serverUuid, user) {
  const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [serverUuid]);
  if (!server) throw Object.assign(new Error('Server not found'), { status: 404 });
  if (server.owner_id !== user.id && !user.is_admin) throw Object.assign(new Error('Access denied'), { status: 403 });
  const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
  return { server, client: getDaemonClient(node) };
}

// GET /api/servers/:uuid/files
router.get('/api/servers/:uuid/files', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const resp = await client.listFiles(server.uuid, server.install_path, req.query.path || '.');
    res.json(resp.data);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.response?.data?.detail || e.message });
  }
});

// GET /api/servers/:uuid/files/read
router.get('/api/servers/:uuid/files/read', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const resp = await client.readFile(server.uuid, server.install_path, req.query.path);
    res.json(resp.data);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.response?.data?.detail || e.message });
  }
});

// POST /api/servers/:uuid/files/write
router.post('/api/servers/:uuid/files/write', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const resp = await client.writeFile(server.uuid, server.install_path, req.body.path, req.body.content);
    res.json(resp.data);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.response?.data?.detail || e.message });
  }
});

// POST /api/servers/:uuid/files/folder
router.post('/api/servers/:uuid/files/folder', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const resp = await client.createFolder(server.uuid, server.install_path, req.body.path, req.body.name);
    res.json(resp.data);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.response?.data?.detail || e.message });
  }
});

// POST /api/servers/:uuid/files/rename
router.post('/api/servers/:uuid/files/rename', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const resp = await client.renameFile(server.uuid, server.install_path, req.body.path, req.body.new_name);
    res.json(resp.data);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.response?.data?.detail || e.message });
  }
});

// POST /api/servers/:uuid/files/delete
router.post('/api/servers/:uuid/files/delete', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const resp = await client.deleteFiles(server.uuid, server.install_path, req.body.paths);
    await logAudit({ userId: req.user.id, serverId: server.id, action: 'file.delete', description: `Deleted files`, req });
    res.json(resp.data);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.response?.data?.detail || e.message });
  }
});

// POST /api/servers/:uuid/files/upload (multipart)
const multer = require('multer');
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 1024 * 1024 * 1024 } });

router.post('/api/servers/:uuid/files/upload', auth.requireAuth, upload.single('file'), async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const path = req.body.path || '.';
    const resp = await client.uploadFile(server.uuid, server.install_path, path, req.file.originalname, req.file.buffer);
    await logAudit({ userId: req.user.id, serverId: server.id, action: 'file.upload', description: `Uploaded ${req.file.originalname}`, req });
    res.json(resp.data);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.response?.data?.detail || e.message });
  }
});

// POST /api/servers/:uuid/files/upload-url (background URL upload)
router.post('/api/servers/:uuid/files/upload-url', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const { url, path, filename } = req.body;
    if (!url || !url.startsWith('http')) return res.status(400).json({ error: 'Valid URL required' });
    const resp = await client.uploadFromUrl(server.uuid, server.install_path, url, path || '.', filename || null);
    await logAudit({ userId: req.user.id, serverId: server.id, action: 'file.upload_url', description: `Downloaded from URL: ${url.substring(0, 100)}`, req });
    res.json(resp.data);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.response?.data?.detail || e.message });
  }
});

// POST /api/servers/:uuid/files/archive
router.post('/api/servers/:uuid/files/archive', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const resp = await client.archiveFiles(server.uuid, server.install_path, req.body.action, req.body.path, req.body.name);
    res.json(resp.data);
  } catch (e) {
    res.status(e.status || 500).json({ error: e.response?.data?.detail || e.message });
  }
});

// GET /api/servers/:uuid/files/download
router.get('/api/servers/:uuid/files/download', auth.requireAuth, async (req, res) => {
  try {
    const { server, client } = await getServerClient(req.params.uuid, req.user);
    const resp = await client.downloadFile(server.uuid, server.install_path, req.query.path);
    const filename = req.query.path.split('/').pop();
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'application/octet-stream');
    res.send(Buffer.from(resp.data));
  } catch (e) {
    res.status(e.status || 500).json({ error: e.response?.data?.detail || e.message });
  }
});

module.exports = router;
