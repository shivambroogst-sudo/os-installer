/**
 * routes/admin.js - Admin routes (users, eggs, logs, settings)
 */
const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { query, queryOne, execute, uuid } = require('../db');
const auth = require('../auth');
const { buildContext, logAudit, getSetting, setSetting, getCategorySettings } = require('../helpers');
const { listEggs, getEgg } = require('../eggs');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
const ALLOWED_EXTS = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.ico'];

// ---- Users ----
router.get('/admin/users', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const users = await query('SELECT *, (SELECT COUNT(*) FROM servers WHERE owner_id = users.id) as servers_count FROM users ORDER BY created_at DESC');
  res.render('admin/users', await buildContext(req, { users, activePage: 'admin_users' }));
});

router.get('/admin/users/create', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  res.render('admin/user_create', await buildContext(req, { error: null, activePage: 'admin_users' }));
});

router.post('/admin/users/create', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const { username, email, password, role, is_active } = req.body;
  try {
    const existing = await queryOne('SELECT id FROM users WHERE username = ? OR email = ?', [username, email]);
    if (existing) {
      return res.render('admin/user_create', await buildContext(req, { error: 'Username or email already exists', activePage: 'admin_users' }));
    }
    const bcrypt = require('bcryptjs');
    const hash = await bcrypt.hash(password, 10);
    await execute(
      'INSERT INTO users (uuid, username, email, password_hash, role, is_active, is_email_verified) VALUES (?, ?, ?, ?, ?, ?, 1)',
      [uuid(), username, email, hash, role || 'user', is_active ? 1 : 0]
    );
    await logAudit({ userId: req.user.id, action: 'user.create', description: `Created user '${username}' (${role})`, req });
    res.redirect('/admin/users');
  } catch (e) {
    res.render('admin/user_create', await buildContext(req, { error: e.message, activePage: 'admin_users' }));
  }
});

router.post('/admin/users/:id/role', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const { role } = req.body;
  if (!['user', 'admin', 'superadmin'].includes(role)) return res.status(400).json({ error: 'Invalid role' });
  await execute('UPDATE users SET role = ? WHERE id = ?', [role, req.params.id]);
  res.redirect('/admin/users');
});

router.post('/admin/users/:id/toggle-active', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const user = await queryOne('SELECT * FROM users WHERE id = ?', [req.params.id]);
  if (!user) return res.status(404).json({ error: 'Not found' });
  if (user.id === req.user.id) return res.status(400).json({ error: 'Cannot disable yourself' });
  await execute('UPDATE users SET is_active = NOT is_active WHERE id = ?', [req.params.id]);
  res.redirect('/admin/users');
});

router.post('/admin/users/:id/delete', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const user = await queryOne('SELECT * FROM users WHERE id = ?', [req.params.id]);
  if (!user) return res.status(404).json({ error: 'Not found' });
  if (user.id === req.user.id) return res.status(400).json({ error: 'Cannot delete yourself' });
  await execute('DELETE FROM users WHERE id = ?', [req.params.id]);
  await logAudit({ userId: req.user.id, action: 'user.delete', description: `Deleted user '${user.username}'`, req });
  res.redirect('/admin/users');
});

// ---- Eggs ----
router.get('/admin/eggs', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const eggs = await query('SELECT *, (SELECT COUNT(*) FROM servers WHERE egg_id = eggs.id) as servers_count FROM eggs ORDER BY category, name');
  res.render('admin/eggs', await buildContext(req, { eggs, activePage: 'admin_eggs' }));
});

router.get('/admin/eggs/create', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  res.render('admin/egg_edit', await buildContext(req, { egg: null, activePage: 'admin_eggs' }));
});

router.post('/admin/eggs/create', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const { name, description, category, icon, tags, startup_command, install_script, default_memory, default_disk, default_cpu, variables_json, is_active } = req.body;
  let variables = [];
  try { variables = JSON.parse(variables_json || '[]'); } catch (_) {}
  await execute(
    `INSERT INTO eggs (uuid, name, description, category, author, install_script, startup_command, default_memory, default_disk, default_cpu, variables, tags, icon, is_active)
     VALUES (?, ?, ?, ?, 'admin', ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [uuid(), name, description, category || 'custom', install_script, startup_command,
     default_memory || 1024, default_disk || 5120, default_cpu || 100, JSON.stringify(variables),
     tags, icon || '⚙️', is_active ? 1 : 0]
  );
  await logAudit({ userId: req.user.id, action: 'egg.create', description: `Created egg '${name}'`, req });
  res.redirect('/admin/eggs');
});

router.get('/admin/eggs/:uuid/edit', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const egg = await queryOne('SELECT * FROM eggs WHERE uuid = ?', [req.params.uuid]);
  if (!egg) return res.status(404).render('errors/404', await buildContext(req));
  res.render('admin/egg_edit', await buildContext(req, { egg, activePage: 'admin_eggs' }));
});

router.post('/admin/eggs/:uuid/edit', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const egg = await queryOne('SELECT * FROM eggs WHERE uuid = ?', [req.params.uuid]);
  if (!egg) return res.status(404).render('errors/404', await buildContext(req));
  const { name, description, category, icon, tags, startup_command, install_script, default_memory, default_disk, default_cpu, variables_json, is_active } = req.body;
  let variables = [];
  try { variables = JSON.parse(variables_json || '[]'); } catch (_) {}
  await execute(
    'UPDATE eggs SET name=?, description=?, category=?, icon=?, tags=?, startup_command=?, install_script=?, default_memory=?, default_disk=?, default_cpu=?, variables=?, is_active=? WHERE id=?',
    [name, description, category, icon, tags, startup_command, install_script, default_memory, default_disk, default_cpu, JSON.stringify(variables), is_active ? 1 : 0, egg.id]
  );
  res.redirect('/admin/eggs');
});

router.post('/admin/eggs/:uuid/delete', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const egg = await queryOne('SELECT * FROM eggs WHERE uuid = ?', [req.params.uuid]);
  if (!egg) return res.status(404).json({ error: 'Not found' });
  if (egg.is_default) return res.status(400).json({ error: 'Cannot delete default egg' });
  const servers = await query('SELECT id FROM servers WHERE egg_id = ?', [egg.id]);
  if (servers.length) return res.status(400).json({ error: 'Egg in use by servers' });
  await execute('DELETE FROM eggs WHERE id = ?', [egg.id]);
  res.redirect('/admin/eggs');
});

// ---- Audit Logs ----
router.get('/admin/logs', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const perPage = 50;
  const offset = (page - 1) * perPage;
  const [totalRow] = await query('SELECT COUNT(*) as cnt FROM audit_logs');
  const logs = await query('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT ? OFFSET ?', [perPage, offset]);
  const totalPages = Math.ceil(totalRow.cnt / perPage);
  res.render('admin/logs', await buildContext(req, { logs, page, totalPages, total: totalRow.cnt, activePage: 'admin_logs' }));
});

module.exports = router;
