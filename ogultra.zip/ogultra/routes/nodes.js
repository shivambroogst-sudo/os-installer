/**
 * routes/nodes.js - Node management (admin) + daemon heartbeat endpoint
 */
const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { query, queryOne, execute, uuid } = require('../db');
const auth = require('../auth');
const { buildContext, logAudit, getDaemonClient } = require('../helpers');

// GET /admin/nodes
router.get('/admin/nodes', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const nodes = await query('SELECT *, (SELECT COUNT(*) FROM servers WHERE node_id = nodes.id) as servers_count FROM nodes ORDER BY name');
  res.render('nodes/list', await buildContext(req, { nodes, activePage: 'admin_nodes' }));
});

// GET /admin/nodes/create
router.get('/admin/nodes/create', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  res.render('nodes/create', await buildContext(req, { activePage: 'admin_nodes' }));
});

// POST /admin/nodes/create
router.post('/admin/nodes/create', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const { name, fqdn, daemon_host, daemon_port, location, memory_total, disk_total, cpu_cores } = req.body;
  const apiKey = crypto.randomBytes(24).toString('hex');
  const authToken = crypto.randomBytes(32).toString('hex');
  await execute(
    `INSERT INTO nodes (uuid, name, fqdn, daemon_host, daemon_port, api_key, auth_token, status, location, memory_total, disk_total, cpu_cores)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'offline', ?, ?, ?, ?)`,
    [uuid(), name, fqdn, daemon_host, daemon_port || 3001, apiKey, authToken, location || null, memory_total || 4096, disk_total || 51200, cpu_cores || 2]
  );
  await logAudit({ userId: req.user.id, action: 'node.create', description: `Created node '${name}'`, req });
  res.redirect('/admin/nodes');
});

// GET /admin/nodes/:uuid
router.get('/admin/nodes/:uuid', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const node = await queryOne('SELECT * FROM nodes WHERE uuid = ?', [req.params.uuid]);
  if (!node) return res.status(404).render('errors/404', await buildContext(req));
  const allocations = await query('SELECT * FROM allocations WHERE node_id = ? ORDER BY port', [node.id]);
  const servers = await query('SELECT * FROM servers WHERE node_id = ?', [node.id]);
  let isOnline = false;
  let liveResources = null;
  try {
    isOnline = await getDaemonClient(node).ping();
    if (isOnline) liveResources = (await getDaemonClient(node).getNodeResources()).data;
  } catch (_) {}
  res.render('nodes/detail', await buildContext(req, { node, allocations, servers, isOnline, liveResources, activePage: 'admin_nodes' }));
});

// POST /admin/nodes/:uuid/delete
router.post('/admin/nodes/:uuid/delete', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const node = await queryOne('SELECT * FROM nodes WHERE uuid = ?', [req.params.uuid]);
  if (!node) return res.status(404).json({ error: 'Not found' });
  const servers = await query('SELECT id FROM servers WHERE node_id = ?', [node.id]);
  if (servers.length) return res.status(400).json({ error: 'Cannot delete node with active servers' });
  await execute('DELETE FROM nodes WHERE id = ?', [node.id]);
  await logAudit({ userId: req.user.id, action: 'node.delete', description: `Deleted node '${node.name}'`, req });
  res.redirect('/admin/nodes');
});

// POST /admin/nodes/:uuid/allocations
router.post('/admin/nodes/:uuid/allocations', auth.requireAuth, auth.requireAdmin, async (req, res) => {
  const node = await queryOne('SELECT * FROM nodes WHERE uuid = ?', [req.params.uuid]);
  if (!node) return res.status(404).json({ error: 'Not found' });
  const { ip, port, is_primary } = req.body;
  await execute('INSERT INTO allocations (node_id, ip, port, is_primary, is_assigned) VALUES (?, ?, ?, ?, 0)', [node.id, ip, port, is_primary ? 1 : 0]);
  res.redirect(`/admin/nodes/${req.params.uuid}`);
});

// POST /api/nodes/:uuid/heartbeat (daemon -> panel)
router.post('/api/nodes/:uuid/heartbeat', async (req, res) => {
  const node = await queryOne('SELECT * FROM nodes WHERE uuid = ?', [req.params.uuid]);
  if (!node) return res.status(404).json({ error: 'Node not found' });
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.substring(7) : req.headers['x-node-key'];
  if (token !== node.auth_token && token !== node.api_key) return res.status(401).json({ error: 'Invalid token' });
  const { memory_used, disk_used, cpu_used, status, metadata } = req.body;
  await execute(
    'UPDATE nodes SET memory_used = ?, disk_used = ?, cpu_used = ?, status = ?, last_heartbeat = NOW() WHERE id = ?',
    [memory_used || 0, disk_used || 0, cpu_used || 0, status || 'online', node.id]
  );
  res.json({ status: 'ok' });
});

module.exports = router;
