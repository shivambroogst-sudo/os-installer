/**
 * routes/scheduler.js - Scheduled tasks UI
 */
const express = require('express');
const router = express.Router();
const cron = require('node-cron');
const { query, queryOne, execute } = require('../db');
const auth = require('../auth');
const { buildContext, logAudit } = require('../helpers');

async function getServerForUser(serverUuid, user) {
  const server = await queryOne('SELECT * FROM servers WHERE uuid = ?', [serverUuid]);
  if (!server) return null;
  if (server.owner_id !== user.id && !user.is_admin) return null;
  return server;
}

// GET /servers/:uuid/schedules
router.get('/servers/:uuid/schedules', auth.requireAuth, async (req, res) => {
  try {
    const server = await getServerForUser(req.params.uuid, req.user);
    if (!server) return res.status(404).render('errors/404', await buildContext(req));
    const node = await queryOne('SELECT * FROM nodes WHERE id = ?', [server.node_id]);
    const schedules = await query('SELECT * FROM schedules WHERE server_id = ? ORDER BY created_at DESC', [server.id]);
    res.render('servers/schedules', await buildContext(req, { server, node, schedules, activePage: 'schedules' }));
  } catch (e) {
    res.status(500).render('errors/500', await buildContext(req, { error: e.message }));
  }
});

// POST /servers/:uuid/schedules
router.post('/servers/:uuid/schedules', auth.requireAuth, async (req, res) => {
  try {
    const server = await getServerForUser(req.params.uuid, req.user);
    if (!server) return res.status(404).json({ error: 'Not found' });
    const { name, action, cron_expression, command, is_enabled } = req.body;
    if (!cron.validate(cron_expression)) {
      return res.status(400).json({ error: 'Invalid cron expression' });
    }
    await execute(
      'INSERT INTO schedules (server_id, name, action, cron_expression, command, is_enabled) VALUES (?, ?, ?, ?, ?, ?)',
      [server.id, name, action, cron_expression, command || null, is_enabled ? 1 : 0]
    );
    require('../scheduler').refreshJobs();
    await logAudit({ userId: req.user.id, serverId: server.id, action: 'schedule.create', description: `Created schedule '${name}'`, req });
    res.redirect(`/servers/${req.params.uuid}/schedules`);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /servers/:uuid/schedules/:id/toggle
router.post('/servers/:uuid/schedules/:id/toggle', auth.requireAuth, async (req, res) => {
  const server = await getServerForUser(req.params.uuid, req.user);
  if (!server) return res.status(404).json({ error: 'Not found' });
  await execute('UPDATE schedules SET is_enabled = NOT is_enabled WHERE id = ? AND server_id = ?', [req.params.id, server.id]);
  require('../scheduler').refreshJobs();
  res.redirect(`/servers/${req.params.uuid}/schedules`);
});

// POST /servers/:uuid/schedules/:id/delete
router.post('/servers/:uuid/schedules/:id/delete', auth.requireAuth, async (req, res) => {
  const server = await getServerForUser(req.params.uuid, req.user);
  if (!server) return res.status(404).json({ error: 'Not found' });
  await execute('DELETE FROM schedules WHERE id = ? AND server_id = ?', [req.params.id, server.id]);
  require('../scheduler').refreshJobs();
  res.redirect(`/servers/${req.params.uuid}/schedules`);
});

module.exports = router;
