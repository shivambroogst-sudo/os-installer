-- ogultra Panel - MySQL Schema
-- Run: mysql -u root -p < scripts/setup-db.sql

CREATE DATABASE IF NOT EXISTS ogultra CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ogultra;

-- Users
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uuid VARCHAR(64) UNIQUE NOT NULL,
  username VARCHAR(32) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user','admin','superadmin') DEFAULT 'user',
  is_active BOOLEAN DEFAULT TRUE,
  is_email_verified BOOLEAN DEFAULT FALSE,
  email_verification_token VARCHAR(128) NULL,
  password_reset_token VARCHAR(128) NULL,
  password_reset_expires DATETIME NULL,
  last_login_at DATETIME NULL,
  last_login_ip VARCHAR(64) NULL,
  theme ENUM('dark','light') DEFAULT 'dark',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Nodes
CREATE TABLE IF NOT EXISTS nodes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uuid VARCHAR(64) UNIQUE NOT NULL,
  name VARCHAR(64) UNIQUE NOT NULL,
  fqdn VARCHAR(255) NOT NULL,
  daemon_host VARCHAR(255) NOT NULL,
  daemon_port INT DEFAULT 3001,
  api_key VARCHAR(128) NOT NULL,
  auth_token VARCHAR(128) NOT NULL,
  status ENUM('online','offline','maintenance') DEFAULT 'offline',
  is_public BOOLEAN DEFAULT TRUE,
  location VARCHAR(64) NULL,
  memory_total INT DEFAULT 4096,
  memory_used INT DEFAULT 0,
  disk_total INT DEFAULT 51200,
  disk_used INT DEFAULT 0,
  cpu_cores INT DEFAULT 2,
  cpu_used DECIMAL(5,2) DEFAULT 0,
  last_heartbeat DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Allocations
CREATE TABLE IF NOT EXISTS allocations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  node_id INT NOT NULL,
  server_id INT NULL,
  ip VARCHAR(64) NOT NULL,
  port INT NOT NULL,
  is_primary BOOLEAN DEFAULT FALSE,
  is_assigned BOOLEAN DEFAULT FALSE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_alloc (node_id, ip, port),
  FOREIGN KEY (node_id) REFERENCES nodes(id) ON DELETE CASCADE,
  FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Eggs
CREATE TABLE IF NOT EXISTS eggs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uuid VARCHAR(64) UNIQUE NOT NULL,
  name VARCHAR(128) NOT NULL,
  description TEXT NULL,
  category VARCHAR(64) DEFAULT 'minecraft',
  author VARCHAR(128) DEFAULT 'ogultra',
  version VARCHAR(32) DEFAULT '1.0',
  install_script TEXT,
  startup_command TEXT,
  default_memory INT DEFAULT 1024,
  default_disk INT DEFAULT 5120,
  default_cpu INT DEFAULT 100,
  variables JSON NULL,
  features JSON NULL,
  tags VARCHAR(255) NULL,
  icon VARCHAR(32) NULL,
  is_active BOOLEAN DEFAULT TRUE,
  is_default BOOLEAN DEFAULT FALSE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Servers
CREATE TABLE IF NOT EXISTS servers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uuid VARCHAR(64) UNIQUE NOT NULL,
  name VARCHAR(64) NOT NULL,
  description VARCHAR(255) NULL,
  owner_id INT NOT NULL,
  node_id INT NOT NULL,
  allocation_id INT NULL,
  egg_id INT NULL,
  server_type VARCHAR(32) DEFAULT 'paper',
  version VARCHAR(32) DEFAULT 'latest',
  egg_config JSON NULL,
  status ENUM('installing','installed','starting','running','stopping','stopped','crashed','suspended','failed') DEFAULT 'installing',
  pid INT NULL,
  memory_limit INT DEFAULT 1024,
  disk_limit INT DEFAULT 5120,
  cpu_limit INT DEFAULT 100,
  startup_command TEXT,
  java_arguments TEXT,
  startup_variables JSON NULL,
  auto_restart BOOLEAN DEFAULT TRUE,
  auto_startup BOOLEAN DEFAULT FALSE,
  crash_count INT DEFAULT 0,
  expires_at DATETIME NULL,
  is_suspended BOOLEAN DEFAULT FALSE,
  suspension_reason VARCHAR(255) NULL,
  install_path VARCHAR(512) DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  last_started_at DATETIME NULL,
  last_stopped_at DATETIME NULL,
  FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (node_id) REFERENCES nodes(id) ON DELETE RESTRICT,
  FOREIGN KEY (allocation_id) REFERENCES allocations(id) ON DELETE SET NULL,
  FOREIGN KEY (egg_id) REFERENCES eggs(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Backups
CREATE TABLE IF NOT EXISTS backups (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uuid VARCHAR(64) UNIQUE NOT NULL,
  server_id INT NOT NULL,
  name VARCHAR(128) NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  file_path VARCHAR(512) NOT NULL,
  size_bytes BIGINT DEFAULT 0,
  is_locked BOOLEAN DEFAULT FALSE,
  is_manual BOOLEAN DEFAULT TRUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Schedules
CREATE TABLE IF NOT EXISTS schedules (
  id INT AUTO_INCREMENT PRIMARY KEY,
  server_id INT NOT NULL,
  name VARCHAR(64) NOT NULL,
  action VARCHAR(20) NOT NULL,
  cron_expression VARCHAR(64) NOT NULL,
  command VARCHAR(512) NULL,
  is_enabled BOOLEAN DEFAULT TRUE,
  last_run_at DATETIME NULL,
  next_run_at DATETIME NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  server_id INT NULL,
  action VARCHAR(64) NOT NULL,
  resource_type VARCHAR(32) NULL,
  resource_id INT NULL,
  description TEXT NOT NULL,
  ip_address VARCHAR(64) NULL,
  user_agent VARCHAR(255) NULL,
  metadata JSON NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE SET NULL,
  INDEX idx_audit_created (created_at),
  INDEX idx_audit_user (user_id),
  INDEX idx_audit_action (action)
) ENGINE=InnoDB;

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(128) NOT NULL,
  message TEXT NOT NULL,
  level ENUM('info','success','warning','error') DEFAULT 'info',
  is_read BOOLEAN DEFAULT FALSE,
  link VARCHAR(255) NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- API Keys
CREATE TABLE IF NOT EXISTS api_keys (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  name VARCHAR(64) NOT NULL,
  key_prefix VARCHAR(16) NOT NULL,
  key_hash VARCHAR(255) UNIQUE NOT NULL,
  permissions JSON NULL,
  last_used_at DATETIME NULL,
  expires_at DATETIME NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- System Settings (key-value store)
CREATE TABLE IF NOT EXISTS system_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  `key` VARCHAR(64) UNIQUE NOT NULL,
  value TEXT,
  category VARCHAR(32) DEFAULT 'general',
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_settings_category (category)
) ENGINE=InnoDB;

-- Default settings
INSERT INTO system_settings (`key`, value, category) VALUES
  ('app_name', 'ogultra', 'branding'),
  ('logo_url', '', 'branding'),
  ('favicon_url', '', 'branding'),
  ('custom_footer', 'Powered by ogultra', 'branding'),
  ('smtp_enabled', 'false', 'smtp'),
  ('smtp_host', '', 'smtp'),
  ('smtp_port', '587', 'smtp'),
  ('smtp_user', '', 'smtp'),
  ('smtp_password', '', 'smtp'),
  ('smtp_from', 'noreply@ogultra.local', 'smtp'),
  ('smtp_tls', 'true', 'smtp'),
  ('maintenance_mode', 'false', 'features'),
  ('registration_enabled', 'true', 'features'),
  ('email_verification_required', 'false', 'features'),
  ('password_reset_enabled', 'true', 'features'),
  ('max_servers_per_user', '10', 'limits'),
  ('default_memory_mb', '1024', 'limits'),
  ('default_disk_mb', '5120', 'limits'),
  ('default_cpu_percent', '100', 'limits')
ON DUPLICATE KEY UPDATE value = VALUES(value);
