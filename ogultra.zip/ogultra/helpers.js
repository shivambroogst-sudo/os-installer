/**
 * helpers.js - Shared utilities: audit log, notifications, settings, daemon client.
 */
const axios = require('axios');
const { query, execute, queryOne } = require('./db');

// ---- Audit Log ----
async function logAudit({ userId = null, serverId = null, action, description, req = null, metadata = null }) {
  try {
    await execute(
      'INSERT INTO audit_logs (user_id, server_id, action, description, ip_address, user_agent, metadata) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [userId, serverId, action, description,
       req?.ip || null,
       (req?.headers['user-agent'] || '').substring(0, 255),
       metadata ? JSON.stringify(metadata) : null]
    );
  } catch (e) {
    console.error('[audit] log error:', e.message);
  }
}

// ---- Notifications ----
async function createNotification(userId, title, message, level = 'info', link = null) {
  await execute(
    'INSERT INTO notifications (user_id, title, message, level, link) VALUES (?, ?, ?, ?, ?)',
    [userId, title, message, level, link]
  );
}

async function getUnreadCount(userId) {
  const r = await queryOne('SELECT COUNT(*) as cnt FROM notifications WHERE user_id = ? AND is_read = 0', [userId]);
  return r.cnt;
}

// ---- Settings ----
async function getSetting(key, category = null) {
  if (category) {
    return queryOne('SELECT value FROM system_settings WHERE `key` = ? AND category = ?', [key, category]);
  }
  return queryOne('SELECT value FROM system_settings WHERE `key` = ?', [key]);
}

async function getCategorySettings(category) {
  const rows = await query('SELECT `key`, value FROM system_settings WHERE category = ?', [category]);
  const out = {};
  rows.forEach((r) => (out[r.key] = r.value));
  return out;
}

async function setSetting(key, value, category = 'general') {
  await execute(
    'INSERT INTO system_settings (`key`, value, category) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)',
    [key, value, category]
  );
}

async function getBranding() {
  return getCategorySettings('branding');
}

async function isMaintenanceMode() {
  const r = await getSetting('maintenance_mode', 'features');
  return r?.value === 'true';
}

// ---- Daemon Client ----
class DaemonClient {
  constructor(host, port, authToken) {
    this.baseURL = `http://${host}:${port}`;
    this.token = authToken;
  }

  _headers() {
    return { Authorization: `Bearer ${this.token}`, 'X-Daemon-Token': this.token };
  }

  async ping() {
    try {
      await axios.get(`${this.baseURL}/health`, { timeout: 5000 });
      return true;
    } catch (_) {
      return false;
    }
  }

  async installServer(data) {
    return axios.post(`${this.baseURL}/servers/install`, data, { headers: this._headers(), timeout: 300000 });
  }

  async startServer(serverUuid, data) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/start`, data, { headers: this._headers(), timeout: 30000 });
  }

  async stopServer(serverUuid) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/stop`, {}, { headers: this._headers(), timeout: 30000 });
  }

  async restartServer(serverUuid) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/restart`, {}, { headers: this._headers(), timeout: 30000 });
  }

  async killServer(serverUuid) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/kill`, {}, { headers: this._headers(), timeout: 10000 });
  }

  async sendCommand(serverUuid, command) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/command`, { command }, { headers: this._headers(), timeout: 10000 });
  }

  async getStatus(serverUuid) {
    return axios.get(`${this.baseURL}/servers/${serverUuid}/status`, { headers: this._headers(), timeout: 10000 });
  }

  async getLogs(serverUuid, lines = 200) {
    return axios.get(`${this.baseURL}/servers/${serverUuid}/logs`, { headers: this._headers(), params: { lines }, timeout: 10000 });
  }

  async getResources(serverUuid) {
    return axios.get(`${this.baseURL}/servers/${serverUuid}/resources`, { headers: this._headers(), timeout: 10000 });
  }

  async deleteServer(serverUuid, installPath) {
    return axios.delete(`${this.baseURL}/servers/${serverUuid}`, { headers: this._headers(), data: { install_path: installPath }, timeout: 30000 });
  }

  // File manager
  async listFiles(serverUuid, installPath, path = '.') {
    return axios.get(`${this.baseURL}/servers/${serverUuid}/files`, { headers: this._headers(), params: { path, install_path: installPath }, timeout: 15000 });
  }
  async readFile(serverUuid, installPath, path) {
    return axios.get(`${this.baseURL}/servers/${serverUuid}/files/read`, { headers: this._headers(), params: { path, install_path: installPath }, timeout: 15000 });
  }
  async writeFile(serverUuid, installPath, path, content) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/files/write`, { path, content, install_path: installPath }, { headers: this._headers(), timeout: 15000 });
  }
  async createFolder(serverUuid, installPath, path, name) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/files/folder`, { path, name, install_path: installPath }, { headers: this._headers() });
  }
  async renameFile(serverUuid, installPath, path, newName) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/files/rename`, { path, new_name: newName, install_path: installPath }, { headers: this._headers() });
  }
  async deleteFiles(serverUuid, installPath, paths) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/files/delete`, { paths, install_path: installPath }, { headers: this._headers() });
  }
  async uploadFile(serverUuid, installPath, path, fileName, content) {
    const FormData = require('form-data');
    const form = new FormData();
    form.append('file', content, fileName);
    form.append('path', path);
    form.append('install_path', installPath);
    return axios.post(`${this.baseURL}/servers/${serverUuid}/files/upload`, form, { headers: { ...this._headers(), ...form.getHeaders() }, timeout: 300000 });
  }
  async uploadFromUrl(serverUuid, installPath, url, path = '.', filename = null) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/files/upload-url`, { url, path, filename, install_path: installPath }, { headers: this._headers(), timeout: 600000 });
  }
  async archiveFiles(serverUuid, installPath, action, path, name = null) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/files/archive`, { action, path, name, install_path: installPath }, { headers: this._headers(), timeout: 60000 });
  }
  async downloadFile(serverUuid, installPath, path) {
    return axios.get(`${this.baseURL}/servers/${serverUuid}/files/download`, { headers: this._headers(), params: { path, install_path: installPath }, responseType: 'arraybuffer', timeout: 300000 });
  }
  // Backups
  async createBackup(serverUuid, name) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/backups`, { name }, { headers: this._headers(), timeout: 300000 });
  }
  async listBackups(serverUuid) {
    return axios.get(`${this.baseURL}/servers/${serverUuid}/backups`, { headers: this._headers(), timeout: 15000 });
  }
  async restoreBackup(serverUuid, backupUuid) {
    return axios.post(`${this.baseURL}/servers/${serverUuid}/backups/${backupUuid}/restore`, {}, { headers: this._headers(), timeout: 300000 });
  }
  async deleteBackup(serverUuid, backupUuid) {
    return axios.delete(`${this.baseURL}/servers/${serverUuid}/backups/${backupUuid}`, { headers: this._headers(), timeout: 30000 });
  }
  async downloadBackup(serverUuid, backupUuid) {
    return axios.get(`${this.baseURL}/servers/${serverUuid}/backups/${backupUuid}/download`, { headers: this._headers(), responseType: 'arraybuffer', timeout: 300000 });
  }
  // Node resources
  async getNodeResources() {
    return axios.get(`${this.baseURL}/resources`, { headers: this._headers(), timeout: 10000 });
  }
}

function getDaemonClient(node) {
  return new DaemonClient(node.daemon_host, node.daemon_port, node.auth_token);
}

// ---- Render template context ----
async function buildContext(req, extra = {}) {
  const branding = await getBranding();
  const unreadCount = req.user ? await getUnreadCount(req.user.id) : 0;
  return {
    user: req.user,
    csrfToken: req.csrfToken,
    branding,
    unreadCount,
    appName: branding.app_name || process.env.APP_NAME || 'ogultra',
    currentPath: req.path,
    query: req.query,
    ...extra,
  };
}

module.exports = {
  logAudit,
  createNotification,
  getUnreadCount,
  getSetting,
  getCategorySettings,
  setSetting,
  getBranding,
  isMaintenanceMode,
  DaemonClient,
  getDaemonClient,
  buildContext,
};
