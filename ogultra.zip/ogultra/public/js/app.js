// ogultra - client JS
(function() {
  const t = document.getElementById('theme-toggle');
  if (t) {
    t.addEventListener('click', () => {
      const isDark = document.documentElement.classList.toggle('dark');
      localStorage.setItem('theme', isDark ? 'dark' : 'light');
      fetch('/settings/profile', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-Token': getCsrf() }, body: `theme=${isDark?'dark':'light'}` }).catch(() => {});
    });
  }
  function getCsrf() { const m = document.cookie.match(/ogultra_csrf=([^;]+)/); return m ? m[1] : ''; }
})();
