"""
templates_setup.py - Shared Jinja2Templates instance with custom filters
Saare routers yahi use karte hain taaki filters consistently register ho.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from fastapi.templating import Jinja2Templates

from config import TEMPLATES_DIR


def _humanize_size(size_bytes) -> str:
    """Bytes ko human-readable size me convert karein."""
    try:
        size_bytes = float(size_bytes)
    except (TypeError, ValueError):
        return "0 B"
    if size_bytes < 0:
        return "0 B"
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(size_bytes) < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} PB"


def _humanize_time(dt) -> str:
    """Datetime ko 'X minutes ago' format me convert karein."""
    if not dt:
        return "Never"
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except ValueError:
            return dt
    if not isinstance(dt, datetime):
        return str(dt)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    diff = now - dt
    seconds = int(diff.total_seconds())
    if seconds < 0:
        return "just now"
    if seconds < 60:
        return f"{seconds}s ago"
    elif seconds < 3600:
        return f"{seconds // 60}m ago"
    elif seconds < 86400:
        return f"{seconds // 3600}h ago"
    elif seconds < 2592000:
        return f"{seconds // 86400}d ago"
    return dt.strftime("%Y-%m-%d %H:%M")


def _status_color(status: str) -> str:
    """Server status ke liye Tailwind color name return karein."""
    colors = {
        "running": "green",
        "stopped": "gray",
        "starting": "yellow",
        "stopping": "yellow",
        "installing": "blue",
        "installed": "blue",
        "crashed": "red",
        "failed": "red",
        "suspended": "orange",
    }
    return colors.get(status or "", "gray")


def get_templates() -> Jinja2Templates:
    """Shared Jinja2Templates instance with custom filters registered."""
    templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
    templates.env.filters["humanize_size"] = _humanize_size
    templates.env.filters["humanize_time"] = _humanize_time
    templates.env.filters["status_color"] = _status_color
    # Add global for branding access without passing
    templates.env.globals["now"] = datetime.now
    return templates


# Single shared instance
templates = get_templates()
