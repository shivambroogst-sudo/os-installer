"""
mc_installers.py - Minecraft server download/install scripts
Saare supported server types ke liye real download logic:
- Paper (PaperMC API)
- Purpur (Purpur API)
- Spigot (SpigotMC - BuildTools fallback)
- Vanilla (Mojang version manifest)
- Fabric (Fabric meta API)
- Forge (Maven metadata)
- Velocity (PaperMC API)
- Waterfall (PaperMC API)
- BungeeCord (Jenkins CI)

Yeh module daemon ke andar use hota hai. Internet access required.
Agar download fail ho jaye to user ko jar upload karne ka option milta hai.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import urllib.request
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse


# ---- HTTP fetch helper (sync, but called via run_in_executor) ----

def _http_get(url: str, headers: Optional[dict] = None) -> bytes:
    """Simple HTTP GET - urllib use karta hai (no external deps)."""
    req = urllib.request.Request(url, headers=headers or {"User-Agent": "PyroPanel/1.0"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        return resp.read()


def _http_get_json(url: str) -> dict:
    data = _http_get(url, headers={"Accept": "application/json"})
    return json.loads(data.decode("utf-8"))


def _download_to_file(url: str, dest: Path, chunk_size: int = 65536) -> int:
    """URL se file download karein. Returns bytes written."""
    req = urllib.request.Request(url, headers={"User-Agent": "PyroPanel/1.0"})
    with urllib.request.urlopen(req, timeout=300) as resp:
        total = 0
        with open(dest, "wb") as f:
            while True:
                chunk = resp.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                total += len(chunk)
    return total


# ---- PaperMC API ----

PAPERMC_API = "https://api.papermc.io/v2/projects"


def _papermc_versions(project: str) -> list[str]:
    """PaperMC project ke available versions fetch karein."""
    data = _http_get_json(f"{PAPERMC_API}/{project}")
    return data.get("versions", [])


def _papermc_latest_build(project: str, version: str) -> tuple[int, str]:
    """Specific version ka latest build number aur filename fetch karein."""
    data = _http_get_json(f"{PAPERMC_API}/{project}/versions/{version}")
    builds = data.get("builds", [])
    if not builds:
        raise ValueError(f"No builds for {project} {version}")
    latest = builds[-1]
    build_num = latest["build"]
    downloads = latest.get("downloads", {})
    if "application" not in downloads:
        raise ValueError(f"No download for {project} {version} build {build_num}")
    filename = downloads["application"]["name"]
    return build_num, filename


def install_paper(project: str, version: str, install_path: Path) -> Path:
    """Paper ya Waterfall ya Velocity install karein (PaperMC API)."""
    project = project.lower()
    if version == "latest":
        versions = _papermc_versions(project)
        if not versions:
            raise ValueError(f"No versions available for {project}")
        version = versions[-1]

    build, filename = _papermc_latest_build(project, version)
    url = f"{PAPERMC_API}/{project}/versions/{version}/builds/{build}/downloads/{filename}"

    install_path.mkdir(parents=True, exist_ok=True)
    jar_path = install_path / filename
    _download_to_file(url, jar_path)

    # Symlink to canonical name (server.jar / waterfall.jar / velocity.jar)
    canonical = {
        "paper": "paper.jar",
        "waterfall": "waterfall.jar",
        "velocity": "velocity.jar",
    }.get(project, f"{project}.jar")
    canonical_path = install_path / canonical
    if canonical_path.exists():
        canonical_path.unlink()
    shutil.copy2(jar_path, canonical_path)

    # EULA hint file
    eula_path = install_path / "eula.txt"
    if not eula_path.exists():
        eula_path.write_text("eula=true\n")

    return canonical_path


# ---- Purpur ----

PURPUR_API = "https://api.purpurmc.org/v2/purpur"


def install_purpur(version: str, install_path: Path) -> Path:
    """Purpur server install karein."""
    if version == "latest":
        data = _http_get_json(PURPUR_API)
        version = data.get("version", "1.20.4")

    data = _http_get_json(f"{PURPUR_API}/{version}")
    build = data.get("builds", {}).get("latest")
    if not build:
        raise ValueError(f"No build for Purpur {version}")

    url = f"{PURPUR_API}/{version}/{build}/download"
    install_path.mkdir(parents=True, exist_ok=True)
    jar_path = install_path / "purpur.jar"
    _download_to_file(url, jar_path)

    eula_path = install_path / "eula.txt"
    if not eula_path.exists():
        eula_path.write_text("eula=true\n")

    return jar_path


# ---- Vanilla (Mojang) ----

VANILLA_MANIFEST = "https://launchermeta.mojang.com/mc/game/version_manifest.json"


def install_vanilla(version: str, install_path: Path) -> Path:
    """Vanilla Minecraft server install karein Mojang manifest se."""
    manifest = _http_get_json(VANILLA_MANIFEST)
    versions = {v["id"]: v for v in manifest.get("versions", [])}

    if version == "latest":
        version = manifest.get("latest", {}).get("release", "1.20.4")

    if version not in versions:
        raise ValueError(f"Vanilla version {version} not found")

    version_url = versions[version]["url"]
    version_data = _http_get_json(version_url)
    server_info = version_data.get("downloads", {}).get("server")
    if not server_info:
        raise ValueError(f"No server download for {version}")

    install_path.mkdir(parents=True, exist_ok=True)
    jar_path = install_path / "server.jar"
    _download_to_file(server_info["url"], jar_path)

    eula_path = install_path / "eula.txt"
    if not eula_path.exists():
        eula_path.write_text("eula=true\n")

    return jar_path


# ---- Fabric ----

FABRIC_META = "https://meta.fabricmc.net/v2"


def install_fabric(version: str, install_path: Path) -> Path:
    """Fabric server install karein - fabric-server-launch.jar + fabric-loader."""
    if version == "latest":
        # Latest Minecraft version
        game_data = _http_get_json(f"{FABRIC_META}/versions/game")
        game_versions = [v for v in game_data if v.get("stable", False)]
        if not game_versions:
            game_versions = game_data
        version = game_versions[-1]["version"] if game_versions else "1.20.4"

    # Get loader version
    loader_data = _http_get_json(f"{FABRIC_META}/versions/loader")
    loader_version = loader_data[0]["version"] if loader_data else "0.15.7"

    # Get installer version
    installer_data = _http_get_json(f"{FABRIC_META}/versions/installer")
    installer_version = installer_data[0]["version"] if installer_data else "0.11.2"

    # Download fabric-installer.jar and run headless OR use direct server-launch
    # Direct approach: download fabric-server-mc.loader.jar (Fabric 0.11+ format)
    url = (
        f"{FABRIC_META}/versions/loader/{version}/{loader_version}/"
        f"{installer_version}/server/jar"
    )

    install_path.mkdir(parents=True, exist_ok=True)
    jar_path = install_path / "fabric-server.jar"
    _download_to_file(url, jar_path)

    eula_path = install_path / "eula.txt"
    if not eula_path.exists():
        eula_path.write_text("eula=true\n")

    return jar_path


# ---- Forge ----

FORGE_MAVEN = "https://maven.minecraftforge.net/net/minecraftforge/forge"


def install_forge(version: str, install_path: Path) -> Path:
    """Forge server install karein.
    Pehle recommended build dhundta hai phir installer download karta hai.
    Installer ko install mode me chalana padega for full setup, but for
    basic running we download the universal jar."""
    if version == "latest":
        # Use 1.20.1 as fallback default since Forge versions are MC-version-specific
        version = "1.20.1"

    # Fetch maven-metadata.xml for available forge versions
    maven_url = f"{FORGE_MAVEN}/maven-metadata.xml"
    xml_data = _http_get(maven_url).decode("utf-8")

    # Parse versions for this MC version - simple regex (avoid xml deps)
    pattern = rf"({re.escape(version)}-\d+\.\d+\.\d+(?:-\d+)?)"
    matches = re.findall(pattern, xml_data)
    if not matches:
        raise ValueError(f"No Forge builds for Minecraft {version}")
    # Latest = last in list
    forge_version = matches[-1]

    # Try universal jar first (no installer needed)
    jar_filename = f"forge-{forge_version}-universal.jar"
    url = f"{FORGE_MAVEN}/{forge_version}/{jar_filename}"

    install_path.mkdir(parents=True, exist_ok=True)
    jar_path = install_path / "forge.jar"

    try:
        _download_to_file(url, jar_path)
    except Exception:
        # Fallback to installer jar
        installer_filename = f"forge-{forge_version}-installer.jar"
        installer_url = f"{FORGE_MAVEN}/{forge_version}/{installer_filename}"
        _download_to_file(installer_url, jar_path)

    eula_path = install_path / "eula.txt"
    if not eula_path.exists():
        eula_path.write_text("eula=true\n")

    return jar_path


# ---- BungeeCord (Jenkins) ----

BUNGEE_JENKINS = "https://ci.md-5.net/job/BungeeCord"


def install_bungeecord(version: str, install_path: Path) -> Path:
    """BungeeCord install karein Jenkins CI se."""
    # version ignored - BungeeCord sirf latest stable hai
    data = _http_get_json(f"{BUNGEE_JENKINS}/lastSuccessfulBuild/api/json")
    artifacts = data.get("artifacts", [])
    if not artifacts:
        raise ValueError("No BungeeCord build available")

    artifact = artifacts[0]
    filename = artifact["fileName"]
    url = f"{BUNGEE_JENKINS}/lastSuccessfulBuild/artifact/{artifact['relativePath']}"

    install_path.mkdir(parents=True, exist_ok=True)
    jar_path = install_path / "BungeeCord.jar"
    _download_to_file(url, jar_path)
    return jar_path


# ---- Spigot (BuildTools) ----

def install_spigot(version: str, install_path: Path) -> Path:
    """Spigot install karein.
    Spigot ko build karna padta hai (BuildTools) - yeh heavy hai.
    Pehle try karein pre-built jar from getbukkit.org, warna BuildTools download karein.
    """
    # Try getbukkit.org (pre-built Spigot)
    if version == "latest":
        version = "1.20.4"

    try:
        url = f"https://download.getbukkit.org/spigot/spigot-{version}.jar"
        install_path.mkdir(parents=True, exist_ok=True)
        jar_path = install_path / "spigot.jar"
        _download_to_file(url, jar_path)

        eula_path = install_path / "eula.txt"
        if not eula_path.exists():
            eula_path.write_text("eula=true\n")
        return jar_path
    except Exception:
        pass

    # Fallback: BuildTools.jar download karein (user ko manually run karna padega)
    install_path.mkdir(parents=True, exist_ok=True)
    jar_path = install_path / "BuildTools.jar"
    url = "https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar"
    _download_to_file(url, jar_path)
    raise RuntimeError(
        "Spigot pre-built jar download nahi hua. BuildTools.jar download kar diya. "
        "Daemon pe 'java -jar BuildTools.jar --rev {version}' run karein manually."
    )


# ---- Dispatcher ----

INSTALLERS = {
    "paper": lambda v, p: install_paper("paper", v, p),
    "waterfall": lambda v, p: install_paper("waterfall", v, p),
    "velocity": lambda v, p: install_paper("velocity", v, p),
    "purpur": install_purpur,
    "vanilla": install_vanilla,
    "fabric": install_fabric,
    "forge": install_forge,
    "bungeecord": install_bungeecord,
    "spigot": install_spigot,
}


def install_server(server_type: str, version: str, install_path: Path) -> Path:
    """Server install karein - dispatcher. Returns path to installed jar."""
    installer = INSTALLERS.get(server_type.lower())
    if not installer:
        raise ValueError(f"Unknown server type: {server_type}")
    return installer(version, install_path)


def list_available_versions(server_type: str, limit: int = 50) -> list[str]:
    """Server type ke available versions fetch karein (for dropdown in UI)."""
    try:
        server_type = server_type.lower()
        if server_type in ("paper", "waterfall", "velocity"):
            return _papermc_versions(server_type)[-limit:]
        elif server_type == "purpur":
            data = _http_get_json(PURPUR_API)
            return [data.get("version", "1.20.4")]
        elif server_type == "vanilla":
            manifest = _http_get_json(VANILLA_MANIFEST)
            versions = [v["id"] for v in manifest.get("versions", [])]
            return versions[:limit]
        elif server_type == "fabric":
            game_data = _http_get_json(f"{FABRIC_META}/versions/game")
            return [v["version"] for v in game_data[:limit]]
        elif server_type == "forge":
            # Forge versions are MC versions - return common ones
            return ["1.20.4", "1.20.1", "1.19.4", "1.18.2", "1.17.1", "1.16.5", "1.12.2"]
        elif server_type == "bungeecord":
            return ["latest"]
        elif server_type == "spigot":
            return ["1.20.4", "1.20.1", "1.19.4", "1.18.2", "1.17.1", "1.16.5", "1.12.2", "1.8.8"]
    except Exception as e:
        print(f"[mc_installers] Failed to fetch versions for {server_type}: {e}")
    return []


def accept_user_jar(server_type: str, jar_path: Path, install_path: Path) -> Path:
    """User ke uploaded jar ko install location me rakhe with canonical name."""
    canonical_names = {
        "paper": "paper.jar",
        "purpur": "purpur.jar",
        "spigot": "spigot.jar",
        "vanilla": "server.jar",
        "fabric": "fabric-server.jar",
        "forge": "forge.jar",
        "velocity": "velocity.jar",
        "waterfall": "waterfall.jar",
        "bungeecord": "BungeeCord.jar",
        "custom": "server.jar",
    }
    canonical = canonical_names.get(server_type.lower(), "server.jar")
    install_path.mkdir(parents=True, exist_ok=True)
    dest = install_path / canonical
    shutil.copy2(jar_path, dest)

    if server_type.lower() not in ("velocity", "waterfall", "bungeecord"):
        eula_path = install_path / "eula.txt"
        if not eula_path.exists():
            eula_path.write_text("eula=true\n")

    return dest
