"""
auth.py - Authentication dependencies aur helpers
Current user fetch karna, login/logout, CSRF validation, audit logging.
"""
from __future__ import annotations

import hmac
import secrets
from datetime import datetime, timezone
from typing import Optional

from fastapi import Depends, Form, HTTPException, Request, Response, status
from fastapi.responses import RedirectResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings
from database import get_db
from models import AuditLog, User, UserRole
from security import (
    constant_time_compare,
    create_access_token,
    create_csrf_token,
    decode_token,
    generate_token,
    hash_password,
    needs_rehash,
    verify_password,
)


# ---- Cookie helpers ----

def set_session_cookie(response: Response, token: str) -> None:
    """JWT ko httpOnly cookie me set karein."""
    response.set_cookie(
        key=settings.SESSION_COOKIE_NAME,
        value=token,
        httponly=True,
        secure=settings.APP_ENV == "production",
        samesite="lax",
        max_age=settings.JWT_EXPIRE_MINUTES * 60,
        path="/",
    )


def clear_session_cookie(response: Response) -> None:
    response.delete_cookie(settings.SESSION_COOKIE_NAME, path="/")


def set_csrf_cookie(response: Response) -> str:
    """CSRF token cookie me set karein aur token return karein."""
    token = create_csrf_token()
    response.set_cookie(
        key=settings.CSRF_COOKIE_NAME,
        value=token,
        httponly=False,  # JS ko padhne ke liye
        secure=settings.APP_ENV == "production",
        samesite="lax",
        max_age=settings.JWT_EXPIRE_MINUTES * 60,
        path="/",
    )
    return token


def verify_csrf(request: Request) -> None:
    """CSRF token ko cookie aur header se match karein.
    Sirf state-changing requests (POST/PUT/DELETE/PATCH) pe check hota hai."""
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return

    cookie_token = request.cookies.get(settings.CSRF_COOKIE_NAME)
    header_token = request.headers.get("X-CSRF-Token") or request.headers.get("X-CSRFToken")

    # API requests Authorization header use karte hain, wo CSRF se exempt
    if request.headers.get("Authorization", "").startswith("Bearer "):
        return

    if not cookie_token:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="CSRF token missing - please refresh the page",
        )
    if not header_token:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="CSRF token missing - refresh and try again",
        )
    if not constant_time_compare(cookie_token, header_token):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="CSRF token invalid",
        )


# ---- Current user dependencies ----

async def get_current_user_optional(
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> Optional[User]:
    """Cookie ya Authorization header se user fetch karein. None if not logged in."""
    token: Optional[str] = None
    # Pehle cookie try karein
    token = request.cookies.get(settings.SESSION_COOKIE_NAME)
    auth_header = request.headers.get("Authorization", "")
    if not token and auth_header.startswith("Bearer "):
        token = auth_header[7:]

    if not token:
        return None

    payload = decode_token(token)
    if not payload or payload.get("type") != "access":
        return None

    user_id_str = payload.get("sub")
    if not user_id_str:
        return None

    try:
        user_id = int(user_id_str)
    except (ValueError, TypeError):
        return None

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user or not user.is_active:
        return None

    # Attach request state for templates
    request.state.current_user = user
    return user


async def get_current_user(
    user: Optional[User] = Depends(get_current_user_optional),
) -> User:
    """Require authentication - 401 if not logged in."""
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
            headers={"Location": "/auth/login"},
        )
    return user


async def get_admin_user(user: User = Depends(get_current_user)) -> User:
    """Require admin role."""
    if not user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required",
        )
    return user


# ---- Auth helpers ----

async def authenticate_user(
    db: AsyncSession,
    identifier: str,
    password: str,
) -> Optional[User]:
    """Username ya email se user dhundhe aur password verify karein."""
    identifier = identifier.strip()
    if "@" in identifier:
        result = await db.execute(select(User).where(User.email == identifier))
    else:
        result = await db.execute(select(User).where(User.username == identifier))
    user = result.scalar_one_or_none()

    if not user:
        # Timing attack se bachne ke liye dummy verify karein
        verify_password(password, "$argon2id$v=19$m=65536,t=3,p=2$c2FsdHNhbHQ$abc")
        return None

    if not verify_password(password, user.password_hash):
        return None

    # Rehash agar parameters purane hain
    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(password)
        await db.commit()

    return user


async def create_user(
    db: AsyncSession,
    username: str,
    email: str,
    password: str,
    role: str = UserRole.USER.value,
    is_email_verified: bool = False,
) -> User:
    """Naya user create karein."""
    user = User(
        username=username,
        email=email,
        password_hash=hash_password(password),
        role=role,
        is_email_verified=is_email_verified,
        email_verification_token=generate_token() if not is_email_verified else None,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


async def login_user(
    request: Request,
    response: Response,
    db: AsyncSession,
    user: User,
) -> str:
    """User ke liye session set karein - JWT token cookie me."""
    token = create_access_token(
        subject=user.id,
        extra_claims={
            "username": user.username,
            "role": user.role,
        },
    )
    set_session_cookie(response, token)
    set_csrf_cookie(response)

    # Update last login
    user.last_login_at = datetime.now(timezone.utc)
    user.last_login_ip = request.client.host if request.client else "unknown"

    # Audit log
    audit = AuditLog(
        user_id=user.id,
        action="auth.login",
        description=f"User '{user.username}' logged in",
        ip_address=user.last_login_ip,
        user_agent=request.headers.get("User-Agent", "")[:255],
    )
    db.add(audit)
    await db.commit()
    return token


async def logout_user(
    request: Request,
    response: Response,
    db: AsyncSession,
    user: Optional[User],
) -> None:
    """Session clear karein."""
    if user:
        audit = AuditLog(
            user_id=user.id,
            action="auth.logout",
            description=f"User '{user.username}' logged out",
            ip_address=request.client.host if request.client else "unknown",
            user_agent=request.headers.get("User-Agent", "")[:255],
        )
        db.add(audit)
        await db.commit()
    clear_session_cookie(response)
    response.delete_cookie(settings.CSRF_COOKIE_NAME, path="/")


def require_feature(feature: str):
    """Decorator-like dependency - check karein feature enabled hai ya nahi."""
    async def _check():
        if feature == "email_verification" and not settings.EMAIL_VERIFICATION_REQUIRED:
            return True
        if feature == "password_reset" and not settings.PASSWORD_RESET_ENABLED:
            raise HTTPException(status_code=404, detail="Password reset disabled")
        return True
    return _check
