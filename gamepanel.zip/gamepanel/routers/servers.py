"""
routers/servers.py - Server management routes
Create, list, view, edit, delete servers; start/stop/restart/kill actions;
reinstall, suspend/unsuspend, rename, expiry management.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from templates_setup import templates
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings, TEMPLATES_DIR
from database import get_db
from models import (
    Allocation,
    Node,
    NodeStatus,
    Server,
    ServerStatus,
    ServerType,
    User,
    UserRole,
)
from auth import get_current_user, get_admin_user
from schemas import ServerCreate, ServerUpdate
from services.template_context import build_context
from services.server_service import (
    create_server,
    trigger_install,
    start_server,
    stop_server,
    restart_server,
    kill_server,
    delete_server,
    suspend_server,
    unsuspend_server,
    reinstall_server,
    get_daemon_client,
    default_startup_command,
)
from services.daemon_client import DaemonError
from services.audit_service import log_action
from services.scheduler_service import CronPattern
from mc_installers import list_available_versions


router = APIRouter(tags=["servers"])


# ---- Server list ----

@router.get("/servers", response_class=HTMLResponse)
async def server_list(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """User ke saare servers list karein."""
    if user.is_admin:
        result = await db.execute(
            select(Server).order_by(Server.created_at.desc())
        )
    else:
        result = await db.execute(
            select(Server).where(Server.owner_id == user.id).order_by(Server.created_at.desc())
        )
    servers = list(result.scalars().all())
    ctx = await build_context(db, user, request=request, servers=servers, active_page="servers")
    return templates.TemplateResponse("servers/list.html", ctx)


# ---- Server create form ----

@router.get("/servers/create", response_class=HTMLResponse)
async def server_create_form(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Server creation form - nodes aur types list karein."""
    result = await db.execute(
        select(Node).where(Node.status == NodeStatus.ONLINE.value).order_by(Node.name)
    )
    nodes = list(result.scalars().all())

    server_types = [
        (ServerType.PAPER.value, "Paper", "High performance fork of Spigot"),
        (ServerType.PURPUR.value, "Purpur", "Paper fork with extra optimizations"),
        (ServerType.SPIGOT.value, "Spigot", "Popular Bukkit-compatible server"),
        (ServerType.VANILLA.value, "Vanilla", "Official Mojang server"),
        (ServerType.FABRIC.value, "Fabric", "Lightweight modding platform"),
        (ServerType.FORGE.value, "Forge", "Established modding platform"),
        (ServerType.VELOCITY.value, "Velocity", "Modern proxy server"),
        (ServerType.WATERFALL.value, "Waterfall", "BungeeCord fork proxy"),
        (ServerType.BUNGEECORD.value, "BungeeCord", "Classic proxy server"),
        (ServerType.CUSTOM.value, "Custom", "Upload your own server jar"),
    ]

    expiry_options = [
        (1, "1 day"),
        (7, "7 days"),
        (30, "30 days"),
        (90, "90 days"),
        (365, "1 year"),
        (0, "Never"),
    ]

    ctx = await build_context(
        db,
        user,
        request=request,
                nodes=nodes,
        server_types=server_types,
        expiry_options=expiry_options,
        default_memory=settings.DEFAULT_MEMORY_MB,
        default_disk=settings.DEFAULT_DISK_MB,
        default_cpu=settings.DEFAULT_CPU_PERCENT,
        active_page="servers_create",
    )
    return templates.TemplateResponse("servers/create.html", ctx)


# ---- Server create POST ----

@router.post("/servers/create")
async def server_create_submit(
    request: Request,
    name: str = Form(..., min_length=3, max_length=64),
    description: str = Form(""),
    server_type: str = Form(...),
    version: str = Form("latest"),
    node_id: int = Form(...),
    memory_limit: int = Form(settings.DEFAULT_MEMORY_MB),
    disk_limit: int = Form(settings.DEFAULT_DISK_MB),
    cpu_limit: int = Form(settings.DEFAULT_CPU_PERCENT),
    startup_command: str = Form(""),
    java_arguments: str = Form(""),
    expires_in_days: int = Form(0),
    auto_restart: bool = Form(False),
    auto_startup: bool = Form(False),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Server create karein aur install trigger karein."""
    payload = ServerCreate(
        name=name,
        description=description or None,
        server_type=server_type,
        version=version,
        node_id=node_id,
        memory_limit=memory_limit,
        disk_limit=disk_limit,
        cpu_limit=cpu_limit,
        startup_command=startup_command or None,
        java_arguments=java_arguments or None,
        expires_in_days=expires_in_days if expires_in_days > 0 else None,
        auto_restart=auto_restart,
        auto_startup=auto_startup,
    )

    try:
        server = await create_server(db, user, payload)
    except ValueError as e:
        nodes = list((await db.execute(select(Node).order_by(Node.name))).scalars().all())
        ctx = await build_context(
            db, user, request=request, nodes=nodes, error=str(e),
            server_types=[], expiry_options=[],
            default_memory=settings.DEFAULT_MEMORY_MB,
            default_disk=settings.DEFAULT_DISK_MB,
            default_cpu=settings.DEFAULT_CPU_PERCENT,
            active_page="servers_create",
        )
        return templates.TemplateResponse(
            "servers/create.html", ctx, status_code=400,
        )

    # Install trigger (best-effort async - background task would be better but for now sync)
    try:
        await trigger_install(db, server)
    except Exception as e:
        # Server created but install failed - user can retry later
        pass

    return RedirectResponse(url=f"/servers/{server.uuid}", status_code=303)


# ---- API endpoint for version list (AJAX) ----

@router.get("/api/server-types/{server_type}/versions")
async def get_server_type_versions(
    server_type: str,
    user: User = Depends(get_current_user),
):
    """AJAX endpoint - server type ke versions return karein."""
    versions = list_available_versions(server_type, limit=30)
    return {"versions": versions}


# ---- Server detail / manage ----

@router.get("/servers/{server_uuid}", response_class=HTMLResponse)
async def server_detail(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Server detail page - settings, console, files, backups, etc. tabs."""
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")

    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    # Get node
    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()

    # Get allocation
    allocation = None
    if server.allocation_id:
        alloc_result = await db.execute(
            select(Allocation).where(Allocation.id == server.allocation_id)
        )
        allocation = alloc_result.scalar_one_or_none()

    # Build connection info
    connection_info = {
        "ip": node.fqdn,
        "port": allocation.port if allocation else 25565,
    }

    ctx = await build_context(
        db,
        user,
        request=request,
                server=server,
        node=node,
        allocation=allocation,
        connection_info=connection_info,
        active_page="server_detail",
    )
    return templates.TemplateResponse("servers/manage.html", ctx)


# ---- Server update (rename, resources, startup) ----

@router.post("/servers/{server_uuid}/settings")
async def server_update_settings(
    request: Request,
    server_uuid: str,
    name: str = Form(..., min_length=3, max_length=64),
    description: str = Form(""),
    memory_limit: int = Form(...),
    disk_limit: int = Form(...),
    cpu_limit: int = Form(...),
    startup_command: str = Form(""),
    java_arguments: str = Form(""),
    auto_restart: bool = Form(False),
    auto_startup: bool = Form(False),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    server.name = name
    server.description = description or None
    server.memory_limit = memory_limit
    server.disk_limit = disk_limit
    server.cpu_limit = cpu_limit
    server.startup_command = startup_command or server.startup_command
    server.java_arguments = java_arguments or server.java_arguments
    server.auto_restart = auto_restart
    server.auto_startup = auto_startup

    await log_action(
        db,
        action="server.update",
        description=f"Updated settings for '{server.name}'",
        user=user,
        server_id=server.id,
    )
    await db.commit()

    return RedirectResponse(url=f"/servers/{server_uuid}?tab=settings", status_code=303)


# ---- Server lifecycle actions ----

@router.post("/servers/{server_uuid}/start")
async def server_start_action(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")
    if server.is_suspended:
        raise HTTPException(status_code=403, detail="Server is suspended")

    try:
        await start_server(db, server)
    except (ValueError, DaemonError) as e:
        return JSONResponse(
            status_code=500,
            content={"success": False, "message": str(e)},
        )
    await log_action(
        db, action="server.start", description=f"Started '{server.name}'", user=user, server_id=server.id
    )
    return JSONResponse(content={"success": True, "status": server.status})


@router.post("/servers/{server_uuid}/stop")
async def server_stop_action(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    try:
        await stop_server(db, server)
    except DaemonError as e:
        return JSONResponse(status_code=500, content={"success": False, "message": str(e)})
    await log_action(
        db, action="server.stop", description=f"Stopped '{server.name}'", user=user, server_id=server.id
    )
    return JSONResponse(content={"success": True, "status": server.status})


@router.post("/servers/{server_uuid}/restart")
async def server_restart_action(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    try:
        await restart_server(db, server)
    except DaemonError as e:
        return JSONResponse(status_code=500, content={"success": False, "message": str(e)})
    await log_action(
        db, action="server.restart", description=f"Restarted '{server.name}'", user=user, server_id=server.id
    )
    return JSONResponse(content={"success": True, "status": server.status})


@router.post("/servers/{server_uuid}/kill")
async def server_kill_action(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    try:
        await kill_server(db, server)
    except DaemonError as e:
        return JSONResponse(status_code=500, content={"success": False, "message": str(e)})
    await log_action(
        db, action="server.kill", description=f"Force killed '{server.name}'", user=user, server_id=server.id
    )
    return JSONResponse(content={"success": True, "status": server.status})


@router.post("/servers/{server_uuid}/reinstall")
async def server_reinstall_action(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    await reinstall_server(db, server)
    return RedirectResponse(url=f"/servers/{server_uuid}", status_code=303)


# ---- Suspend / Unsuspend (admin only) ----

@router.post("/servers/{server_uuid}/suspend")
async def server_suspend_action(
    request: Request,
    server_uuid: str,
    reason: str = Form(""),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    await suspend_server(db, server, reason=reason or None)
    return RedirectResponse(url=f"/servers/{server_uuid}", status_code=303)


@router.post("/servers/{server_uuid}/unsuspend")
async def server_unsuspend_action(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    await unsuspend_server(db, server)
    return RedirectResponse(url=f"/servers/{server_uuid}", status_code=303)


# ---- Delete ----

@router.post("/servers/{server_uuid}/delete")
async def server_delete_action(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    await delete_server(db, server)
    return RedirectResponse(url="/servers", status_code=303)


# ---- Server status AJAX ----

@router.get("/api/servers/{server_uuid}/status")
async def server_status_api(
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """AJAX endpoint - server status fetch karein."""
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    # Try live status from daemon
    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)

    live_status = None
    resources = None
    try:
        live_status = await client.get_server_status(server.uuid)
        resources = await client.get_server_resources(server.uuid)
    except DaemonError:
        pass

    return JSONResponse(content={
        "db_status": server.status,
        "is_suspended": server.is_suspended,
        "is_expired": server.is_expired,
        "live": live_status,
        "resources": resources,
        "allocation": {
            "ip": node.fqdn,
            "port": server.allocation.port if server.allocation else 25565,
        },
    })


# ---- Console logs AJAX ----

@router.get("/api/servers/{server_uuid}/logs")
async def server_logs_api(
    server_uuid: str,
    lines: int = 200,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """AJAX - server logs fetch karein from daemon."""
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        data = await client.get_server_logs(server.uuid, lines=lines)
        return JSONResponse(content=data)
    except DaemonError as e:
        return JSONResponse(status_code=503, content={"error": str(e), "logs": []})


# ---- Console command AJAX ----

@router.post("/api/servers/{server_uuid}/command")
async def server_command_api(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """AJAX - console command bheje."""
    from fastapi.encoders import jsonable_encode
    import json as _json
    body = await request.json()
    command = body.get("command", "").strip()

    if not command:
        return JSONResponse(content={"success": False, "message": "Empty command"})

    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    from services.server_service import send_command
    try:
        await send_command(db, server, command)
        return JSONResponse(content={"success": True})
    except DaemonError as e:
        return JSONResponse(status_code=503, content={"success": False, "message": str(e)})
