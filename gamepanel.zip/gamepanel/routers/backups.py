"""
routers/backups.py - Server backup routes
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse
from templates_setup import templates
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings, TEMPLATES_DIR, BACKUPS_DIR
from database import get_db
from models import Node, Server, User, Backup
from auth import get_current_user
from services.template_context import build_context
from services.daemon_client import DaemonError
from services.server_service import get_daemon_client
from services.audit_service import log_action


router = APIRouter(tags=["backups"])


@router.get("/servers/{server_uuid}/backups", response_class=HTMLResponse)
async def backups_page(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Backups page."""
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)

    # Fetch backups from daemon (file system)
    try:
        resp = await client._request("GET", f"/servers/{server.uuid}/backups")
        backups = resp.get("backups", [])
    except DaemonError:
        backups = []

    ctx = await build_context(
        db, user, request=request, server=server, node=node, backups=backups,
        active_page="backups",
    )
    return templates.TemplateResponse("backups/list.html", ctx)


@router.post("/api/servers/{server_uuid}/backups")
async def create_backup_api(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    body = await request.json()
    name = body.get("name", "Backup")
    if not name:
        return JSONResponse(status_code=400, content={"error": "Name required"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        result_data = await client.create_backup(server.uuid, name)
        await log_action(
            db, action="backup.create",
            description=f"Created backup '{name}'",
            user=user, server_id=server.id,
        )
        await db.commit()
        return JSONResponse(content=result_data)
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


@router.post("/api/servers/{server_uuid}/backups/{backup_uuid}/restore")
async def restore_backup_api(
    server_uuid: str,
    backup_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        await client.restore_backup(server.uuid, backup_uuid)
        await log_action(
            db, action="backup.restore",
            description=f"Restored backup {backup_uuid}",
            user=user, server_id=server.id,
        )
        await db.commit()
        return JSONResponse(content={"success": True})
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


@router.delete("/api/servers/{server_uuid}/backups/{backup_uuid}")
async def delete_backup_api(
    server_uuid: str,
    backup_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        await client.delete_backup(server.uuid, backup_uuid)
        await log_action(
            db, action="backup.delete",
            description=f"Deleted backup {backup_uuid}",
            user=user, server_id=server.id,
        )
        await db.commit()
        return JSONResponse(content={"success": True})
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


@router.get("/api/servers/{server_uuid}/backups/{backup_uuid}/download")
async def download_backup_api(
    server_uuid: str,
    backup_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        content = await client.download_backup(server.uuid, backup_uuid)
    except DaemonError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)

    return StreamingResponse(
        iter([content]),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="backup-{backup_uuid}.zip"'},
    )
