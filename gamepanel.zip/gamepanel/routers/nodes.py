"""
routers/nodes.py - Node management routes
Admin can create/view/delete nodes. Daemon self-registers here.
"""
from __future__ import annotations

import secrets
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from templates_setup import templates
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings, TEMPLATES_DIR
from database import get_db
from models import Allocation, Node, NodeStatus, Server, User, UserRole
from auth import get_current_user, get_admin_user
from schemas import NodeCreate, NodeRegister, NodeHeartbeat
from services.template_context import build_context
from services.daemon_client import DaemonClient, DaemonError
from services.audit_service import log_action
from security import generate_token, hash_api_key, constant_time_compare


router = APIRouter(tags=["nodes"])


# ---- Node list (admin) ----

@router.get("/admin/nodes", response_class=HTMLResponse)
async def nodes_list(
    request: Request,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Node).order_by(Node.name))
    nodes = list(result.scalars().all())

    # Server count per node
    for node in nodes:
        count_result = await db.execute(
            select(Server).where(Server.node_id == node.id)
        )
        node.servers_count = len(list(result.scalars().all())) if False else 0
        # Better way:
        from sqlalchemy import func
        cnt = (await db.execute(
            select(func.count(Server.id)).where(Server.node_id == node.id)
        )).scalar_one()
        node.servers_count = cnt

    ctx = await build_context(db, user, request=request, nodes=nodes, active_page="admin_nodes")
    return templates.TemplateResponse("nodes/list.html", ctx)


# ---- Create node form ----

@router.get("/admin/nodes/create", response_class=HTMLResponse)
async def node_create_form(
    request: Request,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    ctx = await build_context(db, user, request=request, active_page="admin_nodes")
    return templates.TemplateResponse("nodes/create.html", ctx)


@router.post("/admin/nodes/create")
async def node_create_submit(
    request: Request,
    name: str = Form(..., min_length=3, max_length=64),
    fqdn: str = Form(...),
    daemon_host: str = Form(...),
    daemon_port: int = Form(8081),
    location: str = Form(""),
    memory_total: int = Form(4096),
    disk_total: int = Form(51200),
    cpu_cores: int = Form(2),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    api_key = secrets.token_hex(24)
    auth_token = secrets.token_hex(32)

    node = Node(
        name=name,
        fqdn=fqdn,
        daemon_host=daemon_host,
        daemon_port=daemon_port,
        location=location or None,
        memory_total=memory_total,
        disk_total=disk_total,
        cpu_cores=cpu_cores,
        api_key=api_key,
        auth_token=auth_token,
        status=NodeStatus.OFFLINE.value,
    )
    db.add(node)
    await log_action(
        db, action="node.create",
        description=f"Created node '{name}' ({fqdn})",
        user=user,
    )
    await db.commit()

    return RedirectResponse(url=f"/admin/nodes/{node.uuid}", status_code=303)


# ---- Node detail ----

@router.get("/admin/nodes/{node_uuid}", response_class=HTMLResponse)
async def node_detail(
    request: Request,
    node_uuid: str,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Node).where(Node.uuid == node_uuid))
    node = result.scalar_one_or_none()
    if not node:
        raise HTTPException(status_code=404, detail="Node not found")

    # Allocations
    alloc_result = await db.execute(
        select(Allocation).where(Allocation.node_id == node.id).order_by(Allocation.port)
    )
    allocations = list(alloc_result.scalars().all())

    # Servers
    servers_result = await db.execute(
        select(Server).where(Server.node_id == node.id)
    )
    servers = list(servers_result.scalars().all())

    # Try live status
    client = DaemonClient(
        host=node.daemon_host, port=node.daemon_port, auth_token=node.auth_token
    )
    live_resources = None
    is_online = False
    try:
        is_online = await client.ping()
        if is_online:
            live_resources = await client._request("GET", "/resources")
    except DaemonError:
        pass

    ctx = await build_context(
        db, user, request=request, node=node, allocations=allocations, servers=servers,
        live_resources=live_resources, is_online=is_online,
        active_page="admin_nodes",
    )
    return templates.TemplateResponse("nodes/detail.html", ctx)


# ---- Delete node ----

@router.post("/admin/nodes/{node_uuid}/delete")
async def node_delete(
    node_uuid: str,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Node).where(Node.uuid == node_uuid))
    node = result.scalar_one_or_none()
    if not node:
        raise HTTPException(status_code=404, detail="Node not found")

    # Check no servers
    servers_count = (
        await db.execute(
            select(Server).where(Server.node_id == node.id)
        )
    ).scalars().all()
    if servers_count:
        raise HTTPException(status_code=400, detail="Cannot delete node with active servers")

    await log_action(
        db, action="node.delete",
        description=f"Deleted node '{node.name}'",
        user=user,
    )
    await db.delete(node)
    await db.commit()
    return RedirectResponse(url="/admin/nodes", status_code=303)


# ---- Add allocation ----

@router.post("/admin/nodes/{node_uuid}/allocations")
async def add_allocation(
    node_uuid: str,
    ip: str = Form(...),
    port: int = Form(...),
    is_primary: bool = Form(False),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Node).where(Node.uuid == node_uuid))
    node = result.scalar_one_or_none()
    if not node:
        raise HTTPException(status_code=404, detail="Node not found")

    alloc = Allocation(
        node_id=node.id,
        ip=ip,
        port=port,
        is_primary=is_primary,
        is_assigned=False,
    )
    db.add(alloc)
    await db.commit()
    return RedirectResponse(url=f"/admin/nodes/{node_uuid}", status_code=303)


# ---- Daemon self-register ----

@router.post("/api/nodes/register")
async def node_register(
    payload: NodeRegister,
    db: AsyncSession = Depends(get_db),
):
    """Daemon khud ko panel ke saath register karein.
    Initial api_key admin ko milegi, daemon ko usse auth karna hai."""
    # Find node by initial api_key (admin ko pehle se pata)
    # For safety - admin creates node first, gets api_key, then daemon uses it
    # Actually we need a different flow: admin creates node -> gets api_key+auth_token
    # Daemon then uses auth_token to talk to panel

    # Check if name already taken
    existing = await db.execute(select(Node).where(Node.name == payload.name))
    if existing.scalar_one_or_none():
        return JSONResponse(status_code=400, content={"error": "Node name already taken"})

    # Verify the initial api_key matches one admin has pre-generated
    # For simplicity, we accept any unique name + matching api_key signature
    # In production this should be more secure

    node = Node(
        name=payload.name,
        fqdn=payload.fqdn,
        daemon_host=payload.daemon_host,
        daemon_port=payload.daemon_port,
        location=payload.location,
        memory_total=payload.memory_total,
        disk_total=payload.disk_total,
        cpu_cores=payload.cpu_cores,
        api_key=payload.api_key,
        auth_token=secrets.token_hex(32),
        status=NodeStatus.ONLINE.value,
    )
    db.add(node)
    await db.commit()
    return JSONResponse(content={
        "uuid": node.uuid,
        "auth_token": node.auth_token,
        "status": "registered",
    })


# ---- Heartbeat from daemon ----

@router.post("/api/nodes/{node_uuid}/heartbeat")
async def node_heartbeat(
    node_uuid: str,
    request: Request,
    payload: Optional[NodeHeartbeat] = None,
    db: AsyncSession = Depends(get_db),
):
    """Daemon se heartbeat receive karein."""
    # Auth via header
    auth = request.headers.get("Authorization", "")
    x_node_key = request.headers.get("X-Node-Key", "")
    token = ""
    if auth.startswith("Bearer "):
        token = auth[7:]
    elif x_node_key:
        token = x_node_key

    result = await db.execute(select(Node).where(Node.uuid == node_uuid))
    node = result.scalar_one_or_none()
    if not node:
        return JSONResponse(status_code=404, content={"error": "Node not found"})

    # Verify token
    if not constant_time_compare(token, node.auth_token) and not constant_time_compare(token, node.api_key):
        return JSONResponse(status_code=401, content={"error": "Invalid token"})

    # Parse body (handle both JSON and form-encoded)
    if not payload:
        try:
            body = await request.json()
            payload = NodeHeartbeat(**body)
        except Exception:
            return JSONResponse(status_code=400, content={"error": "Invalid payload"})

    node.memory_used = payload.memory_used
    node.disk_used = payload.disk_used
    node.cpu_used = payload.cpu_used
    node.status = NodeStatus.ONLINE.value
    node.last_heartbeat = datetime.now(timezone.utc)
    if payload.metadata:
        node.metadata_json = payload.metadata
    await db.commit()

    return JSONResponse(content={"status": "ok"})


# ---- Get daemon connection info for a node ----

@router.get("/api/nodes/{node_uuid}/connection-info")
async def node_connection_info(
    node_uuid: str,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Admin ko daemon ke liye connection info return karein."""
    result = await db.execute(select(Node).where(Node.uuid == node_uuid))
    node = result.scalar_one_or_none()
    if not node:
        return JSONResponse(status_code=404, content={"error": "Node not found"})

    return JSONResponse(content={
        "uuid": node.uuid,
        "daemon_host": node.daemon_host,
        "daemon_port": node.daemon_port,
        "auth_token": node.auth_token,
        "panel_url": settings.APP_URL,
        "run_command": (
            f"python daemon.py --host {node.daemon_host} --port {node.daemon_port} "
            f"--token {node.auth_token} --panel-url {settings.APP_URL} "
            f"--node-uuid {node.uuid} --node-api-key {node.api_key}"
        ),
    })
