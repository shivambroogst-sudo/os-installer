"""
routers/auth.py - Authentication routes
Login, register, logout, email verification, password reset.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import (
    APIRouter,
    Depends,
    Form,
    HTTPException,
    Request,
    Response,
    status,
)
from fastapi.responses import HTMLResponse, RedirectResponse
from templates_setup import templates
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings, TEMPLATES_DIR
from database import get_db
from models import User, UserRole
from auth import (
    authenticate_user,
    create_user,
    get_current_user,
    get_current_user_optional,
    login_user,
    logout_user,
    verify_csrf,
)
from schemas import (
    LoginRequest,
    RegisterRequest,
    PasswordResetRequest,
    PasswordResetConfirm,
    EmailVerifyRequest,
)
from security import generate_token, verify_password
from services.email_service import email_service
from services.audit_service import log_action
from services.rate_limit import rate_limit
from services.settings_service import (
    is_registration_enabled,
    is_maintenance_mode,
    get_branding,
)

router = APIRouter(prefix="/auth", tags=["auth"])


# ---- Login ----

@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, next: str = "/dashboard", db: AsyncSession = Depends(get_db)):
    user = await get_current_user_optional(request, Depends(get_db))
    if user:
        return RedirectResponse(url=next or "/dashboard", status_code=303)
    branding = await get_branding(db)
    return templates.TemplateResponse(
        "auth/login.html",
        {"request": request, "next": next, "branding": branding, "settings": settings},
    )


@router.post("/login")
async def login_submit(
    request: Request,
    identifier: str = Form(...),
    password: str = Form(...),
    next: str = Form("/dashboard"),
    db: AsyncSession = Depends(get_db),
    _rl=Depends(rate_limit("login", settings.RATE_LIMIT_LOGIN_PER_MINUTE)),
):
    user = await authenticate_user(db, identifier, password)
    if not user:
        # Render with error
        branding = await get_branding(db)
        return templates.TemplateResponse(
            "auth/login.html",
            {
                "request": request,
                "next": next,
                "error": "Invalid username/email or password",
                "identifier": identifier,
                "branding": branding,
                "settings": settings,
            },
            status_code=401,
        )

    if not user.is_active:
        branding = await get_branding(db)
        return templates.TemplateResponse(
            "auth/login.html",
            {"request": request, "next": next, "error": "Account disabled", "branding": branding, "settings": settings},
            status_code=403,
        )

    response = RedirectResponse(url=next or "/dashboard", status_code=303)
    await login_user(request, response, db, user)
    return response


# ---- Register ----

@router.get("/register", response_class=HTMLResponse)
async def register_page(request: Request, db: AsyncSession = Depends(get_db)):
    user = await get_current_user_optional(request, Depends(get_db))
    if user:
        return RedirectResponse(url="/dashboard", status_code=303)

    if not await is_registration_enabled(db):
        branding = await get_branding(db)
        return templates.TemplateResponse(
            "auth/register.html",
            {"request": request, "error": "Registration is currently disabled", "branding": branding, "settings": settings},
            status_code=403,
        )

    branding = await get_branding(db)
    return templates.TemplateResponse(
        "auth/register.html",
        {"request": request, "branding": branding, "settings": settings},
    )


@router.post("/register")
async def register_submit(
    request: Request,
    username: str = Form(..., min_length=3, max_length=32),
    email: str = Form(...),
    password: str = Form(..., min_length=8),
    password_confirm: str = Form(...),
    db: AsyncSession = Depends(get_db),
    _rl=Depends(rate_limit("register", 5)),
):
    branding = await get_branding(db)
    errors = []

    if not await is_registration_enabled(db):
        errors.append("Registration is currently disabled")
    if password != password_confirm:
        errors.append("Passwords do not match")
    if len(password) < 8:
        errors.append("Password must be at least 8 characters")
    import re
    if not re.match(r"^[a-zA-Z0-9_.-]+$", username):
        errors.append("Username can only contain letters, numbers, dots, hyphens, underscores")

    # Check existing
    if not errors:
        existing = await db.execute(
            select(User).where((User.username == username) | (User.email == email))
        )
        if existing.scalar_one_or_none():
            errors.append("Username or email already registered")

    if errors:
        return templates.TemplateResponse(
            "auth/register.html",
            {"request": request, "errors": errors, "username": username, "email": email, "branding": branding, "settings": settings},
            status_code=400,
        )

    is_email_verified = not settings.EMAIL_VERIFICATION_REQUIRED
    user = await create_user(db, username, email, password, is_email_verified=is_email_verified)

    # Send verification email if required
    if settings.EMAIL_VERIFICATION_REQUIRED and settings.SMTP_ENABLED and user.email_verification_token:
        await email_service.send_verification_email(email, user.email_verification_token, username)

    await log_action(
        db,
        action="auth.register",
        description=f"New user registered: {username}",
        user=user,
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("User-Agent", "")[:255],
    )

    if settings.EMAIL_VERIFICATION_REQUIRED and not is_email_verified:
        return templates.TemplateResponse(
            "auth/login.html",
            {
                "request": request,
                "success": "Account created! Please check your email to verify your account.",
                "branding": branding,
                "settings": settings,
            },
        )

    # Auto-login
    response = RedirectResponse(url="/dashboard", status_code=303)
    await login_user(request, response, db, user)
    return response


# ---- Logout ----

@router.post("/logout")
async def logout(
    request: Request,
    response: Response,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await logout_user(request, response, db, user)
    return RedirectResponse(url="/auth/login", status_code=303)


# ---- Email verification ----

@router.get("/verify-email", response_class=HTMLResponse)
async def verify_email_page(
    request: Request,
    token: str = "",
    db: AsyncSession = Depends(get_db),
):
    branding = await get_branding(db)
    if not token:
        return templates.TemplateResponse(
            "auth/verify_email.html",
            {"request": request, "branding": branding, "settings": settings},
        )

    result = await db.execute(
        select(User).where(User.email_verification_token == token)
    )
    user = result.scalar_one_or_none()
    if not user:
        return templates.TemplateResponse(
            "auth/verify_email.html",
            {"request": request, "error": "Invalid or expired verification token", "branding": branding, "settings": settings},
            status_code=400,
        )

    user.is_email_verified = True
    user.email_verification_token = None
    await db.commit()

    return templates.TemplateResponse(
        "auth/verify_email.html",
        {"request": request, "success": "Email verified successfully! You can now log in.", "branding": branding, "settings": settings},
    )


# ---- Password reset ----

@router.get("/reset-password", response_class=HTMLResponse)
async def reset_password_request_page(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    branding = await get_branding(db)
    if not settings.PASSWORD_RESET_ENABLED:
        return templates.TemplateResponse(
            "errors/404.html",
            {"request": request, "settings": settings, "branding": branding},
            status_code=404,
        )
    return templates.TemplateResponse(
        "auth/reset_request.html",
        {"request": request, "branding": branding, "settings": settings},
    )


@router.post("/reset-password")
async def reset_password_request_submit(
    request: Request,
    email: str = Form(...),
    db: AsyncSession = Depends(get_db),
    _rl=Depends(rate_limit("password_reset", 5)),
):
    branding = await get_branding(db)
    if not settings.PASSWORD_RESET_ENABLED:
        return templates.TemplateResponse(
            "auth/reset_request.html",
            {"request": request, "error": "Password reset is disabled", "branding": branding, "settings": settings},
            status_code=403,
        )

    result = await db.execute(select(User).where(User.email == email))
    user = result.scalar_one_or_none()

    if user:
        token = generate_token()
        user.password_reset_token = token
        user.password_reset_expires = datetime.now(timezone.utc) + timedelta(hours=1)
        await db.commit()
        if settings.SMTP_ENABLED:
            await email_service.send_password_reset_email(email, token, user.username)

    # Always show same message (security - don't leak if email exists)
    return templates.TemplateResponse(
        "auth/reset_request.html",
        {
            "request": request,
            "success": "If that email exists, a reset link has been sent.",
            "branding": branding,
            "settings": settings,
        },
    )


@router.get("/reset-password/confirm", response_class=HTMLResponse)
async def reset_password_confirm_page(
    request: Request,
    token: str = "",
    db: AsyncSession = Depends(get_db),
):
    branding = await get_branding(db)
    if not token:
        return RedirectResponse(url="/auth/reset-password", status_code=303)

    result = await db.execute(select(User).where(User.password_reset_token == token))
    user = result.scalar_one_or_none()

    if not user or not user.password_reset_expires or user.password_reset_expires < datetime.now(timezone.utc):
        return templates.TemplateResponse(
            "auth/reset_confirm.html",
            {"request": request, "error": "Invalid or expired reset token", "branding": branding, "settings": settings},
            status_code=400,
        )

    return templates.TemplateResponse(
        "auth/reset_confirm.html",
        {"request": request, "token": token, "branding": branding, "settings": settings},
    )


@router.post("/reset-password/confirm")
async def reset_password_confirm_submit(
    request: Request,
    token: str = Form(...),
    password: str = Form(..., min_length=8),
    password_confirm: str = Form(...),
    db: AsyncSession = Depends(get_db),
):
    branding = await get_branding(db)
    if password != password_confirm:
        return templates.TemplateResponse(
            "auth/reset_confirm.html",
            {"request": request, "token": token, "error": "Passwords do not match", "branding": branding, "settings": settings},
            status_code=400,
        )

    result = await db.execute(select(User).where(User.password_reset_token == token))
    user = result.scalar_one_or_none()
    if not user or not user.password_reset_expires or user.password_reset_expires < datetime.now(timezone.utc):
        return templates.TemplateResponse(
            "auth/reset_confirm.html",
            {"request": request, "error": "Invalid or expired reset token", "branding": branding, "settings": settings},
            status_code=400,
        )

    from security import hash_password
    user.password_hash = hash_password(password)
    user.password_reset_token = None
    user.password_reset_expires = None
    await db.commit()

    await log_action(
        db,
        action="auth.password_reset",
        description=f"Password reset for {user.username}",
        user=user,
    )

    return templates.TemplateResponse(
        "auth/login.html",
        {
            "request": request,
            "success": "Password reset successfully. Please log in.",
            "branding": branding,
            "settings": settings,
        },
    )
