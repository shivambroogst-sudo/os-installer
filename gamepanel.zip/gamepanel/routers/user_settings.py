"""
routers/user_settings.py - User settings, profile, API keys
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from templates_setup import templates
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings, TEMPLATES_DIR
from database import get_db
from models import ApiKey, User
from auth import get_current_user
from services.template_context import build_context
from services.audit_service import log_action
from security import generate_api_key, hash_api_key, verify_password, hash_password


router = APIRouter(tags=["user"])


@router.get("/settings", response_class=HTMLResponse)
async def user_settings_page(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """User settings page - profile, theme, password, API keys."""
    result = await db.execute(select(ApiKey).where(ApiKey.user_id == user.id))
    api_keys = list(result.scalars().all())

    timezones = [
        "UTC", "Asia/Kolkata", "Asia/Dubai", "Asia/Singapore", "Asia/Tokyo",
        "Europe/London", "Europe/Berlin", "America/New_York", "America/Los_Angeles",
        "Australia/Sydney",
    ]

    ctx = await build_context(
        db, user, request=request, api_keys=api_keys, timezones=timezones,
        active_page="user_settings",
    )
    return templates.TemplateResponse("dashboard/settings.html", ctx)


@router.post("/settings/profile")
async def update_profile(
    request: Request,
    email: str = Form(...),
    theme: str = Form("dark"),
    language: str = Form("en"),
    timezone: str = Form("Asia/Kolkata"),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    user.email = email
    user.theme = theme if theme in ("dark", "light") else "dark"
    user.language = language
    user.timezone = timezone
    await db.commit()
    response = RedirectResponse(url="/settings?tab=profile", status_code=303)
    return response


@router.post("/settings/password")
async def change_password(
    request: Request,
    current_password: str = Form(...),
    new_password: str = Form(..., min_length=8),
    new_password_confirm: str = Form(...),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not verify_password(current_password, user.password_hash):
        return templates.TemplateResponse(
            "dashboard/settings.html",
            await build_context(db, user, request=request, error="Current password is incorrect",
                                api_keys=[], timezones=[], active_page="user_settings"),
            status_code=400,
        )
    if new_password != new_password_confirm:
        return templates.TemplateResponse(
            "dashboard/settings.html",
            await build_context(db, user, request=request, error="New passwords do not match",
                                api_keys=[], timezones=[], active_page="user_settings"),
            status_code=400,
        )

    user.password_hash = hash_password(new_password)
    await log_action(
        db, action="user.password_change",
        description="Password changed",
        user=user,
    )
    await db.commit()
    return RedirectResponse(url="/settings?tab=password", status_code=303)


# ---- API Keys ----

@router.post("/settings/api-keys")
async def create_api_key(
    request: Request,
    name: str = Form(..., min_length=1, max_length=64),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    full_key, prefix, key_hash = generate_api_key()
    api_key = ApiKey(
        user_id=user.id,
        name=name,
        key_prefix=prefix,
        key_hash=key_hash,
        expires_at=datetime.now(timezone.utc) + timedelta(days=365),
    )
    db.add(api_key)
    await log_action(
        db, action="api_key.create",
        description=f"Created API key '{name}'",
        user=user,
    )
    await db.commit()
    # Show full key once
    return JSONResponse(content={
        "success": True,
        "key": full_key,
        "prefix": prefix,
        "message": "Save this key - it won't be shown again",
    })


@router.post("/settings/api-keys/{key_id}/delete")
async def delete_api_key(
    key_id: int,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(ApiKey).where(ApiKey.id == key_id, ApiKey.user_id == user.id)
    )
    api_key = result.scalar_one_or_none()
    if not api_key:
        raise HTTPException(status_code=404, detail="API key not found")
    await db.delete(api_key)
    await db.commit()
    return RedirectResponse(url="/settings?tab=api-keys", status_code=303)


# ---- Notifications ----

@router.post("/api/notifications/{notif_id}/read")
async def mark_notification_read(
    notif_id: int,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from services.notification_service import mark_as_read
    ok = await mark_as_read(db, notif_id, user.id)
    return JSONResponse(content={"success": ok})


@router.post("/api/notifications/read-all")
async def mark_all_notifications_read(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from services.notification_service import mark_all_read
    count = await mark_all_read(db, user.id)
    return JSONResponse(content={"success": True, "count": count})


@router.get("/api/notifications")
async def notifications_api(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from services.notification_service import get_user_notifications
    notifications, unread = await get_user_notifications(db, user.id, limit=20)
    return JSONResponse(content={
        "notifications": [
            {
                "id": n.id, "title": n.title, "message": n.message,
                "level": n.level, "is_read": n.is_read, "link": n.link,
                "created_at": n.created_at.isoformat(),
            } for n in notifications
        ],
        "unread_count": unread,
    })
