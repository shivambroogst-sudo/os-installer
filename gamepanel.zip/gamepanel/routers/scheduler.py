"""
routers/scheduler.py - Scheduled tasks UI
"""
from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from templates_setup import templates
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings, TEMPLATES_DIR
from database import get_db
from models import Node, Schedule, ScheduleAction, Server, User
from auth import get_current_user
from services.template_context import build_context
from services.scheduler_service import CronPattern
from services.audit_service import log_action


router = APIRouter(tags=["scheduler"])


@router.get("/servers/{server_uuid}/schedules", response_class=HTMLResponse)
async def schedules_page(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()

    schedules_result = await db.execute(
        select(Schedule).where(Schedule.server_id == server.id).order_by(Schedule.created_at.desc())
    )
    schedules = list(schedules_result.scalars().all())

    actions = [
        (ScheduleAction.START.value, "Start"),
        (ScheduleAction.STOP.value, "Stop"),
        (ScheduleAction.RESTART.value, "Restart"),
        (ScheduleAction.KILL.value, "Kill"),
        (ScheduleAction.COMMAND.value, "Run Command"),
        (ScheduleAction.BACKUP.value, "Backup"),
    ]

    ctx = await build_context(
        db, user, request=request, server=server, node=node, schedules=schedules,
        actions=actions, active_page="schedules",
    )
    return templates.TemplateResponse("scheduler/list.html", ctx)


@router.post("/servers/{server_uuid}/schedules")
async def create_schedule(
    request: Request,
    server_uuid: str,
    name: str = Form(..., min_length=1, max_length=64),
    action: str = Form(...),
    cron_expression: str = Form(...),
    command: str = Form(""),
    is_enabled: bool = Form(False),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    # Validate cron
    try:
        cron = CronPattern(cron_expression)
        next_run = cron.next_run(datetime.now(timezone.utc))
    except ValueError as e:
        return JSONResponse(status_code=400, content={"error": str(e)})

    schedule = Schedule(
        server_id=server.id,
        name=name,
        action=action,
        cron_expression=cron_expression,
        command=command or None,
        is_enabled=is_enabled,
        next_run_at=next_run,
    )
    db.add(schedule)
    await log_action(
        db, action="schedule.create",
        description=f"Created schedule '{name}' ({action}) - {cron_expression}",
        user=user, server_id=server.id,
    )
    await db.commit()

    return RedirectResponse(url=f"/servers/{server_uuid}/schedules", status_code=303)


@router.post("/servers/{server_uuid}/schedules/{schedule_id}/toggle")
async def toggle_schedule(
    server_uuid: str,
    schedule_id: int,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    sched_result = await db.execute(
        select(Schedule).where(Schedule.id == schedule_id, Schedule.server_id == server.id)
    )
    schedule = sched_result.scalar_one_or_none()
    if not schedule:
        raise HTTPException(status_code=404, detail="Schedule not found")

    schedule.is_enabled = not schedule.is_enabled
    await db.commit()
    return RedirectResponse(url=f"/servers/{server_uuid}/schedules", status_code=303)


@router.post("/servers/{server_uuid}/schedules/{schedule_id}/delete")
async def delete_schedule(
    server_uuid: str,
    schedule_id: int,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    sched_result = await db.execute(
        select(Schedule).where(Schedule.id == schedule_id, Schedule.server_id == server.id)
    )
    schedule = sched_result.scalar_one_or_none()
    if not schedule:
        raise HTTPException(status_code=404, detail="Schedule not found")

    await db.delete(schedule)
    await log_action(
        db, action="schedule.delete",
        description=f"Deleted schedule '{schedule.name}'",
        user=user, server_id=server.id,
    )
    await db.commit()
    return RedirectResponse(url=f"/servers/{server_uuid}/schedules", status_code=303)
