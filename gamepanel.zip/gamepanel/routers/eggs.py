"""
routers/eggs.py - Egg management routes
Admin: create, edit, delete, import eggs
Users: view eggs (for server creation)
"""
from __future__ import annotations

import json
from typing import Optional

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings, TEMPLATES_DIR
from database import get_db
from models import Egg, Server, User
from auth import get_current_user, get_admin_user
from templates_setup import templates
from services.template_context import build_context
from services.egg_service import (
    ensure_default_eggs,
    get_egg,
    get_egg_by_uuid,
    list_eggs,
    create_egg,
    update_egg,
    delete_egg,
)
from services.audit_service import log_action


router = APIRouter(tags=["eggs"])


# ---- Admin: Egg Management ----

@router.get("/admin/eggs", response_class=HTMLResponse)
async def eggs_list(
    request: Request,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Admin eggs list page."""
    eggs = await list_eggs(db, active_only=False)

    # Server count per egg
    for egg in eggs:
        result = await db.execute(select(Server).where(Server.egg_id == egg.id))
        egg.servers_count = len(list(result.scalars().all()))

    ctx = await build_context(
        db, user, request=request, eggs=eggs, active_page="admin_eggs"
    )
    return templates.TemplateResponse("admin/eggs.html", ctx)


@router.get("/admin/eggs/create", response_class=HTMLResponse)
async def egg_create_form(
    request: Request,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Egg create form."""
    ctx = await build_context(db, user, request=request, active_page="admin_eggs")
    return templates.TemplateResponse("admin/egg_edit.html", ctx)


@router.post("/admin/eggs/create")
async def egg_create_submit(
    request: Request,
    name: str = Form(..., min_length=1, max_length=128),
    description: str = Form(""),
    category: str = Form("custom"),
    icon: str = Form("⚙️"),
    tags: str = Form(""),
    startup_command: str = Form(""),
    install_script: str = Form(""),
    default_memory: int = Form(1024),
    default_disk: int = Form(5120),
    default_cpu: int = Form(100),
    variables_json: str = Form("[]"),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Create custom egg."""
    try:
        variables = json.loads(variables_json) if variables_json else []
    except json.JSONDecodeError:
        variables = []

    egg_data = {
        "name": name,
        "description": description or None,
        "category": category,
        "icon": icon,
        "tags": tags or None,
        "startup_command": startup_command,
        "install_script": install_script,
        "default_memory": default_memory,
        "default_disk": default_disk,
        "default_cpu": default_cpu,
        "variables": variables,
        "author": user.username,
    }
    egg = await create_egg(db, egg_data)
    await log_action(
        db, action="egg.create",
        description=f"Created egg '{egg.name}'",
        user=user,
    )
    await db.commit()
    return RedirectResponse(url="/admin/eggs", status_code=303)


@router.get("/admin/eggs/{egg_uuid}/edit", response_class=HTMLResponse)
async def egg_edit_form(
    request: Request,
    egg_uuid: str,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Egg edit form."""
    egg = await get_egg_by_uuid(db, egg_uuid)
    if not egg:
        raise HTTPException(status_code=404, detail="Egg not found")
    ctx = await build_context(
        db, user, request=request, egg=egg, active_page="admin_eggs"
    )
    return templates.TemplateResponse("admin/egg_edit.html", ctx)


@router.post("/admin/eggs/{egg_uuid}/edit")
async def egg_edit_submit(
    request: Request,
    egg_uuid: str,
    name: str = Form(..., min_length=1, max_length=128),
    description: str = Form(""),
    category: str = Form("custom"),
    icon: str = Form("⚙️"),
    tags: str = Form(""),
    startup_command: str = Form(""),
    install_script: str = Form(""),
    default_memory: int = Form(1024),
    default_disk: int = Form(5120),
    default_cpu: int = Form(100),
    variables_json: str = Form("[]"),
    is_active: bool = Form(False),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Update egg."""
    egg = await get_egg_by_uuid(db, egg_uuid)
    if not egg:
        raise HTTPException(status_code=404, detail="Egg not found")

    try:
        variables = json.loads(variables_json) if variables_json else []
    except json.JSONDecodeError:
        variables = []

    egg_data = {
        "name": name,
        "description": description or None,
        "category": category,
        "icon": icon,
        "tags": tags or None,
        "startup_command": startup_command,
        "install_script": install_script,
        "default_memory": default_memory,
        "default_disk": default_disk,
        "default_cpu": default_cpu,
        "variables": variables,
        "is_active": is_active,
    }
    await update_egg(db, egg, egg_data)
    await log_action(
        db, action="egg.update",
        description=f"Updated egg '{egg.name}'",
        user=user,
    )
    await db.commit()
    return RedirectResponse(url="/admin/eggs", status_code=303)


@router.post("/admin/eggs/{egg_uuid}/delete")
async def egg_delete_action(
    request: Request,
    egg_uuid: str,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete egg (agar koi server use nahi kar raha)."""
    egg = await get_egg_by_uuid(db, egg_uuid)
    if not egg:
        raise HTTPException(status_code=404, detail="Egg not found")

    if egg.is_default:
        raise HTTPException(status_code=400, detail="Cannot delete default egg")

    # Check servers using this egg
    result = await db.execute(select(Server).where(Server.egg_id == egg.id))
    if list(result.scalars().all()):
        raise HTTPException(status_code=400, detail="Cannot delete egg - servers are using it")

    await log_action(
        db, action="egg.delete",
        description=f"Deleted egg '{egg.name}'",
        user=user,
    )
    await delete_egg(db, egg)
    return RedirectResponse(url="/admin/eggs", status_code=303)


# ---- Public: View Eggs (for server creation) ----

@router.get("/api/eggs")
async def api_list_eggs(
    category: Optional[str] = None,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """AJAX endpoint - eggs list karein."""
    eggs = await list_eggs(db, category=category, active_only=True)
    return {
        "eggs": [
            {
                "id": e.id,
                "uuid": e.uuid,
                "name": e.name,
                "description": e.description,
                "category": e.category,
                "icon": e.icon,
                "tags": e.tags,
                "default_memory": e.default_memory,
                "default_disk": e.default_disk,
                "default_cpu": e.default_cpu,
                "startup_command": e.startup_command,
                "variables": e.variables or [],
            }
            for e in eggs
        ]
    }


@router.get("/api/eggs/categories")
async def api_egg_categories(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get all egg categories."""
    eggs = await list_eggs(db, active_only=True)
    categories = {}
    for egg in eggs:
        if egg.category not in categories:
            categories[egg.category] = []
        categories[egg.category].append({
            "id": egg.id,
            "uuid": egg.uuid,
            "name": egg.name,
            "description": egg.description,
            "icon": egg.icon,
        })
    return {"categories": categories}
