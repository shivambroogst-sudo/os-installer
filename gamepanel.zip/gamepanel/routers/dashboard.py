"""
routers/dashboard.py - User aur admin dashboard routes
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from templates_setup import templates
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings, TEMPLATES_DIR
from database import get_db
from models import (
    AuditLog,
    Node,
    Notification,
    Server,
    ServerStatus,
    User,
    UserRole,
)
from auth import get_current_user, get_admin_user
from services.template_context import build_context
from services.notification_service import get_user_notifications


router = APIRouter(tags=["dashboard"])


@router.get("/dashboard", response_class=HTMLResponse)
async def user_dashboard(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """User dashboard - their servers summary."""
    # User's servers
    result = await db.execute(
        select(Server).where(Server.owner_id == user.id).order_by(Server.created_at.desc())
    )
    servers = result.scalars().all()

    # Stats
    total_servers = len(servers)
    running_servers = sum(1 for s in servers if s.status == ServerStatus.RUNNING.value)
    suspended_servers = sum(1 for s in servers if s.is_suspended)
    total_memory = sum(s.memory_limit for s in servers)

    # Recent notifications
    notifications, unread_count = await get_user_notifications(db, user.id, limit=5)

    ctx = await build_context(
        db,
        user,
        request=request,
                servers=servers,
        stats={
            "total_servers": total_servers,
            "running_servers": running_servers,
            "suspended_servers": suspended_servers,
            "total_memory_mb": total_memory,
        },
        notifications=notifications,
        active_page="dashboard",
    )
    return templates.TemplateResponse("dashboard/user.html", ctx)


@router.get("/admin", response_class=HTMLResponse)
async def admin_dashboard(
    request: Request,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Admin dashboard - system overview."""
    # Counts
    users_count = (await db.execute(select(func.count(User.id)))).scalar_one()
    servers_count = (await db.execute(select(func.count(Server.id)))).scalar_one()
    nodes_count = (await db.execute(select(func.count(Node.id)))).scalar_one()
    running_count = (
        await db.execute(
            select(func.count(Server.id)).where(Server.status == ServerStatus.RUNNING.value)
        )
    ).scalar_one()

    # Recent activity
    logs_result = await db.execute(
        select(AuditLog).order_by(AuditLog.created_at.desc()).limit(20)
    )
    recent_logs = list(logs_result.scalars().all())

    # Recent users
    users_result = await db.execute(
        select(User).order_by(User.created_at.desc()).limit(5)
    )
    recent_users = list(users_result.scalars().all())

    # Nodes
    nodes_result = await db.execute(select(Node))
    nodes = list(nodes_result.scalars().all())

    # Recent servers
    servers_result = await db.execute(
        select(Server).order_by(Server.created_at.desc()).limit(10)
    )
    recent_servers = list(servers_result.scalars().all())

    ctx = await build_context(
        db,
        user,
        request=request,
                stats={
            "users_count": users_count,
            "servers_count": servers_count,
            "nodes_count": nodes_count,
            "running_count": running_count,
        },
        recent_logs=recent_logs,
        recent_users=recent_users,
        nodes=nodes,
        recent_servers=recent_servers,
        active_page="admin_dashboard",
    )
    return templates.TemplateResponse("dashboard/admin.html", ctx)


@router.get("/notifications", response_class=HTMLResponse)
async def notifications_page(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """User ke saare notifications."""
    notifications, unread_count = await get_user_notifications(db, user.id, limit=50)
    ctx = await build_context(
        db, user, request=request, notifications=notifications, active_page="notifications"
    )
    return templates.TemplateResponse("dashboard/notifications.html", ctx)


@router.get("/activity", response_class=HTMLResponse)
async def activity_page(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """User ka activity log."""
    result = await db.execute(
        select(AuditLog)
        .where(AuditLog.user_id == user.id)
        .order_by(AuditLog.created_at.desc())
        .limit(100)
    )
    logs = list(result.scalars().all())
    ctx = await build_context(db, user, request=request, logs=logs, active_page="activity")
    return templates.TemplateResponse("dashboard/activity.html", ctx)
