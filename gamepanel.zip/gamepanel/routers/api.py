"""
routers/api.py - REST API for programmatic access
API key based authentication. Returns JSON.
Auto-documentation available at /api/docs (OpenAPI).
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings
from database import get_db
from models import (
    ApiKey,
    AuditLog,
    Node,
    NodeStatus,
    Notification,
    Server,
    ServerStatus,
    User,
    UserRole,
)
from schemas import (
    ServerCreate,
    ServerOut,
    ServerUpdate,
    NodeOut,
    AllocationOut,
    BackupOut,
    ScheduleCreate,
    ScheduleOut,
    UserOut,
    MessageResponse,
)
from security import hash_api_key
from services.server_service import (
    create_server,
    start_server,
    stop_server,
    restart_server,
    kill_server,
    delete_server,
    suspend_server,
    unsuspend_server,
    reinstall_server,
)
from services.daemon_client import DaemonError


router = APIRouter(prefix="/api", tags=["api"])


# ---- API key auth ----

async def get_api_user(
    request: Request,
    authorization: str = Header(default=""),
    db: AsyncSession = Depends(get_db),
) -> User:
    """API key se user identify karein."""
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Bearer token required")
    token = authorization[7:]
    if not token.startswith("pp_"):
        raise HTTPException(status_code=401, detail="Invalid API key format")

    key_hash = hash_api_key(token)
    result = await db.execute(
        select(ApiKey).where(ApiKey.key_hash == key_hash, ApiKey.is_active == True)  # noqa: E712
    )
    api_key = result.scalar_one_or_none()
    if not api_key:
        raise HTTPException(status_code=401, detail="Invalid API key")
    if api_key.expires_at and api_key.expires_at < datetime.now(timezone.utc):
        raise HTTPException(status_code=401, detail="API key expired")

    # Get user
    user_result = await db.execute(select(User).where(User.id == api_key.user_id))
    user = user_result.scalar_one_or_none()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="User not found or disabled")

    # Update last_used
    api_key.last_used_at = datetime.now(timezone.utc)
    await db.commit()
    return user


async def get_api_admin(user: User = Depends(get_api_user)) -> User:
    if not user.is_admin:
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


# ---- User API ----

@router.get("/v1/me", response_model=UserOut)
async def api_me(user: User = Depends(get_api_user)):
    return user


@router.get("/v1/users", response_model=list[UserOut])
async def api_list_users(
    admin: User = Depends(get_api_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).order_by(User.created_at.desc()))
    return list(result.scalars().all())


@router.get("/v1/users/{user_id}", response_model=UserOut)
async def api_get_user(
    user_id: int,
    admin: User = Depends(get_api_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


# ---- Servers API ----

@router.get("/v1/servers", response_model=list[ServerOut])
async def api_list_servers(
    user: User = Depends(get_api_user),
    db: AsyncSession = Depends(get_db),
):
    if user.is_admin:
        result = await db.execute(select(Server).order_by(Server.created_at.desc()))
    else:
        result = await db.execute(
            select(Server).where(Server.owner_id == user.id).order_by(Server.created_at.desc())
        )
    return list(result.scalars().all())


@router.get("/v1/servers/{server_uuid}", response_model=ServerOut)
async def api_get_server(
    server_uuid: str,
    user: User = Depends(get_api_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")
    return server


@router.post("/v1/servers", response_model=ServerOut, status_code=201)
async def api_create_server(
    payload: ServerCreate,
    user: User = Depends(get_api_user),
    db: AsyncSession = Depends(get_db),
):
    try:
        server = await create_server(db, user, payload)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return server


@router.patch("/v1/servers/{server_uuid}", response_model=ServerOut)
async def api_update_server(
    server_uuid: str,
    payload: ServerUpdate,
    user: User = Depends(get_api_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    update_data = payload.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(server, key, value)
    await db.commit()
    await db.refresh(server)
    return server


@router.delete("/v1/servers/{server_uuid}", response_model=MessageResponse)
async def api_delete_server(
    server_uuid: str,
    user: User = Depends(get_api_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")
    await delete_server(db, server)
    return MessageResponse(message="Server deleted")


# ---- Server actions ----

@router.post("/v1/servers/{server_uuid}/action", response_model=MessageResponse)
async def api_server_action(
    server_uuid: str,
    action: str,
    command: Optional[str] = None,
    user: User = Depends(get_api_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    try:
        if action == "start":
            await start_server(db, server)
        elif action == "stop":
            await stop_server(db, server)
        elif action == "restart":
            await restart_server(db, server)
        elif action == "kill":
            await kill_server(db, server)
        elif action == "suspend":
            if not user.is_admin:
                raise HTTPException(status_code=403, detail="Admin only")
            await suspend_server(db, server, reason="Via API")
        elif action == "unsuspend":
            if not user.is_admin:
                raise HTTPException(status_code=403, detail="Admin only")
            await unsuspend_server(db, server)
        elif action == "reinstall":
            await reinstall_server(db, server)
        elif action == "command" and command:
            from services.server_service import send_command
            await send_command(db, server, command)
        else:
            raise HTTPException(status_code=400, detail=f"Unknown action: {action}")
    except (ValueError, DaemonError) as e:
        raise HTTPException(status_code=500, detail=str(e))

    return MessageResponse(message=f"Action '{action}' executed", data={"status": server.status})


@router.get("/v1/servers/{server_uuid}/status")
async def api_server_status(
    server_uuid: str,
    user: User = Depends(get_api_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")
    return {
        "uuid": server.uuid,
        "status": server.status,
        "is_suspended": server.is_suspended,
        "is_expired": server.is_expired,
        "expires_at": server.expires_at.isoformat() if server.expires_at else None,
        "last_started_at": server.last_started_at.isoformat() if server.last_started_at else None,
    }


# ---- Nodes API (admin only) ----

@router.get("/v1/nodes", response_model=list[NodeOut])
async def api_list_nodes(
    admin: User = Depends(get_api_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Node).order_by(Node.name))
    return list(result.scalars().all())


@router.get("/v1/nodes/{node_uuid}", response_model=NodeOut)
async def api_get_node(
    node_uuid: str,
    admin: User = Depends(get_api_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Node).where(Node.uuid == node_uuid))
    node = result.scalar_one_or_none()
    if not node:
        raise HTTPException(status_code=404, detail="Node not found")
    return node


# ---- Notifications API ----

@router.get("/v1/notifications")
async def api_list_notifications(
    user: User = Depends(get_api_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Notification)
        .where(Notification.user_id == user.id)
        .order_by(Notification.created_at.desc())
        .limit(50)
    )
    notifications = list(result.scalars().all())
    return {
        "notifications": [
            {
                "id": n.id, "title": n.title, "message": n.message,
                "level": n.level, "is_read": n.is_read, "link": n.link,
                "created_at": n.created_at.isoformat(),
            } for n in notifications
        ],
    }


# ---- Audit logs API (admin only) ----

@router.get("/v1/audit-logs")
async def api_audit_logs(
    admin: User = Depends(get_api_admin),
    limit: int = Query(50, le=200),
    offset: int = Query(0),
    db: AsyncSession = Depends(get_db),
):
    from services.audit_service import get_recent_logs
    logs, total = await get_recent_logs(db, limit=limit, offset=offset)
    return {
        "logs": [
            {
                "id": l.id, "action": l.action, "description": l.description,
                "user_id": l.user_id, "server_id": l.server_id,
                "ip_address": l.ip_address,
                "created_at": l.created_at.isoformat(),
            } for l in logs
        ],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


# ---- OpenAPI tag info ----
router.tags = [
    {"name": "api", "description": "REST API for programmatic access. Use Bearer token with API key (pp_...)."},
]
