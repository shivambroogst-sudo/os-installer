"""
routers/console.py - WebSocket live console
Panel se daemon ke WebSocket ke beech proxy karta hai.
User browser <-> Panel WS <-> Daemon WS <-> Server process

Auth: Short-lived WS token fetched from /api/ws-token endpoint.
(Session cookie is HttpOnly so JS can't read it directly.)
"""
from __future__ import annotations

import asyncio
import time
from typing import Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query, Depends, Request
from sqlalchemy import select

from config import settings
from database import async_session_factory
from models import Node, NodeStatus, Server, ServerStatus, User
from auth import get_current_user, decode_token, create_access_token
from services.daemon_client import DaemonClient, DaemonError

router = APIRouter(tags=["console"])


@router.get("/api/ws-token")
async def get_ws_token(user: User = Depends(get_current_user)):
    """Short-lived WebSocket token generate karein.
    JS yeh endpoint se token fetch karke WebSocket URL me pass karta hai.
    Token 5 minute ke liye valid hai."""
    # Create a short-lived access token specifically for WS
    token = create_access_token(
        subject=user.id,
        extra_claims={
            "username": user.username,
            "role": user.role,
            "ws": True,  # mark as WS token
        },
        expires_minutes=5,
    )
    return {"token": token, "expires_in": 300}


async def _authenticate_ws(token: str, db) -> Optional[User]:
    """WebSocket connection ko authenticate karein."""
    if not token:
        return None
    payload = decode_token(token)
    if not payload or payload.get("type") != "access":
        return None
    user_id_str = payload.get("sub")
    if not user_id_str:
        return None
    try:
        user_id = int(user_id_str)
    except (ValueError, TypeError):
        return None
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user or not user.is_active:
        return None
    return user


@router.websocket("/ws/servers/{server_uuid}/console")
async def console_websocket(
    websocket: WebSocket,
    server_uuid: str,
    token: str = Query(default=""),
):
    """Live console WebSocket - browser ke liye endpoint."""
    # Auth
    async with async_session_factory() as db:
        user = await _authenticate_ws(token, db)
    if not user:
        await websocket.accept()
        await websocket.send_text("[error] Authentication failed. Please refresh the page.")
        try:
            await websocket.close(code=4401, reason="Unauthorized")
        except Exception:
            pass
        return

    # Get server + node
    async with async_session_factory() as db:
        result = await db.execute(select(Server).where(Server.uuid == server_uuid))
        server = result.scalar_one_or_none()
        if not server:
            await websocket.accept()
            await websocket.send_text("[error] Server not found.")
            try:
                await websocket.close(code=4404, reason="Server not found")
            except Exception:
                pass
            return
        if server.owner_id != user.id and not user.is_admin:
            await websocket.accept()
            await websocket.send_text("[error] Access denied.")
            try:
                await websocket.close(code=4403, reason="Access denied")
            except Exception:
                pass
            return
        node_result = await db.execute(select(Node).where(Node.id == server.node_id))
        node = node_result.scalar_one_or_none()
        if not node:
            await websocket.accept()
            await websocket.send_text("[error] Node not found for this server.")
            try:
                await websocket.close(code=4404, reason="Node not found")
            except Exception:
                pass
            return
        daemon_token = node.auth_token
        daemon_host = node.daemon_host
        daemon_port = node.daemon_port
        server_status = server.status

    await websocket.accept()

    # Helpful message based on server status
    if server_status == ServerStatus.FAILED.value:
        await websocket.send_text("[warning] Server install failed. Click 'Reinstall' to try again.")
        await websocket.send_text("[info] Console will be available once server is running.")
        try:
            while True:
                await websocket.receive_text()
        except WebSocketDisconnect:
            pass
        except Exception:
            pass
        return

    if server_status == ServerStatus.SUSPENDED.value:
        await websocket.send_text("[warning] Server is suspended. Contact admin.")
        try:
            while True:
                await websocket.receive_text()
        except WebSocketDisconnect:
            pass
        return

    if server_status == ServerStatus.INSTALLING.value:
        await websocket.send_text("[info] Server is installing. Please wait...")
        try:
            while True:
                await asyncio.sleep(5)
                async with async_session_factory() as db:
                    res = await db.execute(select(Server).where(Server.uuid == server_uuid))
                    s = res.scalar_one_or_none()
                    if s and s.status == ServerStatus.RUNNING.value:
                        await websocket.send_text("[info] Server is now running. Reconnecting console...")
                        break
                    elif s and s.status == ServerStatus.FAILED.value:
                        await websocket.send_text("[error] Install failed.")
                        try:
                            await websocket.close()
                        except Exception:
                            pass
                        return
                    elif s and s.status == ServerStatus.STOPPED.value:
                        await websocket.send_text("[info] Server installed but stopped. Click Start to run.")
                        # Continue to console connection
                        break
        except WebSocketDisconnect:
            return
        except Exception:
            pass

    # Try to connect to daemon WebSocket
    import websockets
    daemon_ws_url = f"ws://{daemon_host}:{daemon_port}/servers/{server_uuid}/ws?token={daemon_token}"

    daemon_ws = None
    try:
        daemon_ws = await asyncio.wait_for(
            websockets.connect(
                daemon_ws_url,
                ping_interval=20,
                ping_timeout=60,
                close_timeout=5,
                open_timeout=10,
            ),
            timeout=15.0,
        )
    except asyncio.TimeoutError:
        await websocket.send_text("[error] Daemon connection timeout. Check if daemon is running.")
        await _fallback_http_polling(websocket, server_uuid, daemon_host, daemon_port, daemon_token)
        return
    except Exception as e:
        await websocket.send_text(f"[error] Cannot connect to daemon: {type(e).__name__}")
        await websocket.send_text("[info] Trying HTTP log polling...")
        await _fallback_http_polling(websocket, server_uuid, daemon_host, daemon_port, daemon_token)
        return

    # Connected successfully - bidirectional proxy
    try:
        await websocket.send_text("[connected] Console live stream started.")

        async def panel_to_daemon():
            """Browser se command receive karke daemon ko bheje."""
            try:
                while True:
                    data = await websocket.receive_text()
                    try:
                        await daemon_ws.send(data)
                    except Exception as e:
                        await websocket.send_text(f"[error] Failed to send command: {e}")
                        break
            except WebSocketDisconnect:
                pass
            except Exception:
                pass

        async def daemon_to_panel():
            """Daemon se logs receive karke browser ko bheje."""
            try:
                async for msg in daemon_ws:
                    try:
                        await websocket.send_text(str(msg))
                    except Exception:
                        break
            except Exception as e:
                try:
                    await websocket.send_text(f"[error] Daemon stream error: {e}")
                except Exception:
                    pass

        done, pending = await asyncio.wait(
            [
                asyncio.create_task(panel_to_daemon()),
                asyncio.create_task(daemon_to_panel()),
            ],
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
            task.cancel()
    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await websocket.send_text(f"[error] Console error: {e}")
        except Exception:
            pass
    finally:
        if daemon_ws:
            try:
                await daemon_ws.close()
            except Exception:
                pass
        try:
            await websocket.close()
        except Exception:
            pass


async def _fallback_http_polling(
    websocket: WebSocket,
    server_uuid: str,
    daemon_host: str,
    daemon_port: int,
    daemon_token: str,
):
    """Fallback: agar WebSocket fail ho jaye to HTTP se logs poll kare."""
    client = DaemonClient(host=daemon_host, port=daemon_port, auth_token=daemon_token)
    last_log_count = 0
    try:
        while True:
            try:
                data = await client.get_server_logs(server_uuid, lines=50)
                logs = data.get("logs", [])
                new_logs = logs[last_log_count:] if last_log_count < len(logs) else logs
                for log in new_logs:
                    try:
                        await websocket.send_text(log)
                    except Exception:
                        return
                last_log_count = len(logs)
                if last_log_count > 200:
                    last_log_count = 100
                await asyncio.sleep(2)
            except WebSocketDisconnect:
                return
            except DaemonError as e:
                try:
                    await websocket.send_text(f"[error] Daemon error: {e.message}")
                except Exception:
                    return
                await asyncio.sleep(5)
            except Exception as e:
                try:
                    await websocket.send_text(f"[error] Polling error: {e}")
                except Exception:
                    return
                await asyncio.sleep(5)
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
