"""
routers/console.py - WebSocket live console
Panel se daemon ke WebSocket ke beech proxy karta hai.
User browser <-> Panel WS <-> Daemon WS <-> Server process
"""
from __future__ import annotations

import asyncio
import json
from typing import Optional

from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings
from database import get_db, async_session_factory
from models import Node, Server, User
from auth import decode_token
from services.daemon_client import DaemonClient, DaemonError


router = APIRouter(tags=["console"])


async def _authenticate_ws(token: str, db: AsyncSession) -> Optional[User]:
    """WebSocket connection ko authenticate karein - query param token se."""
    if not token:
        return None
    payload = decode_token(token)
    if not payload or payload.get("type") != "access":
        return None
    user_id_str = payload.get("sub")
    if not user_id_str:
        return None
    try:
        user_id = int(user_id_str)
    except (ValueError, TypeError):
        return None
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user or not user.is_active:
        return None
    return user


@router.websocket("/ws/servers/{server_uuid}/console")
async def console_websocket(
    websocket: WebSocket,
    server_uuid: str,
    token: str = Query(default=""),
):
    """Live console WebSocket - browser ke liye endpoint.
    Panel yah se daemon ke WebSocket se connect karta hai aur
    messages ko bidirectionally proxy karta hai.
    """
    # Auth
    async with async_session_factory() as db:
        user = await _authenticate_ws(token, db)
    if not user:
        await websocket.close(code=4401, reason="Unauthorized")
        return

    # Get server + node
    async with async_session_factory() as db:
        result = await db.execute(select(Server).where(Server.uuid == server_uuid))
        server = result.scalar_one_or_none()
        if not server:
            await websocket.close(code=4404, reason="Server not found")
            return
        if server.owner_id != user.id and not user.is_admin:
            await websocket.close(code=4403, reason="Access denied")
            return
        node_result = await db.execute(select(Node).where(Node.id == server.node_id))
        node = node_result.scalar_one()
        daemon_token = node.auth_token
        daemon_host = node.daemon_host
        daemon_port = node.daemon_port

    await websocket.accept()

    # Connect to daemon WebSocket
    import websockets
    daemon_ws_url = f"ws://{daemon_host}:{daemon_port}/servers/{server_uuid}/ws?token={daemon_token}"

    try:
        async with websockets.connect(daemon_ws_url, ping_interval=20, ping_timeout=60) as daemon_ws:
            # Two-way proxy
            async def panel_to_daemon():
                """Browser se command receive karke daemon ko bheje."""
                try:
                    while True:
                        data = await websocket.receive_text()
                        await daemon_ws.send(data)
                except WebSocketDisconnect:
                    pass
                except Exception:
                    pass

            async def daemon_to_panel():
                """Daemon se logs receive karke browser ko bheje."""
                try:
                    async for msg in daemon_ws:
                        await websocket.send_text(msg)
                except Exception:
                    pass

            await asyncio.gather(
                panel_to_daemon(),
                daemon_to_panel(),
            )
    except Exception as e:
        try:
            await websocket.send_text(f"[panel] WebSocket error: {e}")
        except Exception:
            pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass
