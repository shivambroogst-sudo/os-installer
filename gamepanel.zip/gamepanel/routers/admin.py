"""
routers/admin.py - Admin routes
User management, audit logs, system settings, maintenance mode.
"""
from __future__ import annotations

import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, File as FileParam, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from templates_setup import templates
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings, TEMPLATES_DIR, BASE_DIR
from database import get_db
from models import (
    AuditLog,
    ApiKey,
    Node,
    Notification,
    Server,
    User,
    UserRole,
)
from auth import get_admin_user, get_current_user
from services.template_context import build_context
from services.audit_service import get_recent_logs, log_action
from services.settings_service import (
    get_all_settings,
    set_category_settings,
    set_setting,
    get_branding,
)
from security import generate_api_key, hash_api_key


router = APIRouter(prefix="/admin", tags=["admin"])


# ---- Users management ----

@router.get("/users", response_class=HTMLResponse)
async def users_list(
    request: Request,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).order_by(User.created_at.desc()))
    users = list(result.scalars().all())

    # Server count per user
    for u in users:
        cnt = (await db.execute(
            select(func.count(Server.id)).where(Server.owner_id == u.id)
        )).scalar_one()
        u.servers_count = cnt

    ctx = await build_context(db, user, request=request, users=users, active_page="admin_users")
    return templates.TemplateResponse("admin/users.html", ctx)


@router.post("/users/{user_id}/role")
async def update_user_role(
    user_id: int,
    role: str = Form(...),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.id == user_id))
    target = result.scalar_one_or_none()
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if role not in (UserRole.USER.value, UserRole.ADMIN.value, UserRole.SUPERADMIN.value):
        raise HTTPException(status_code=400, detail="Invalid role")

    target.role = role
    await log_action(
        db, action="user.role_change",
        description=f"Changed role of '{target.username}' to {role}",
        user=user,
    )
    await db.commit()
    return RedirectResponse(url="/admin/users", status_code=303)


@router.post("/users/{user_id}/toggle-active")
async def toggle_user_active(
    user_id: int,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.id == user_id))
    target = result.scalar_one_or_none()
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.id == user.id:
        raise HTTPException(status_code=400, detail="Cannot disable yourself")

    target.is_active = not target.is_active
    await log_action(
        db, action="user.toggle_active",
        description=f"{'Enabled' if target.is_active else 'Disabled'} user '{target.username}'",
        user=user,
    )
    await db.commit()
    return RedirectResponse(url="/admin/users", status_code=303)


@router.post("/users/{user_id}/delete")
async def delete_user(
    user_id: int,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.id == user_id))
    target = result.scalar_one_or_none()
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.id == user.id:
        raise HTTPException(status_code=400, detail="Cannot delete yourself")

    await log_action(
        db, action="user.delete",
        description=f"Deleted user '{target.username}'",
        user=user,
    )
    await db.delete(target)
    await db.commit()
    return RedirectResponse(url="/admin/users", status_code=303)


# ---- Audit logs ----

@router.get("/logs", response_class=HTMLResponse)
async def audit_logs(
    request: Request,
    page: int = 1,
    action: str = "",
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    per_page = 50
    offset = (page - 1) * per_page
    logs, total = await get_recent_logs(
        db, limit=per_page, offset=offset, action_filter=action or None
    )
    total_pages = (total + per_page - 1) // per_page

    ctx = await build_context(
        db, user, request=request, logs=logs, page=page, total_pages=total_pages,
        total=total, action_filter=action, active_page="admin_logs",
    )
    return templates.TemplateResponse("admin/logs.html", ctx)


# ---- Settings ----

@router.get("/settings", response_class=HTMLResponse)
async def settings_page(
    request: Request,
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    all_settings = await get_all_settings(db)
    ctx = await build_context(
        db, user, request=request, all_settings=all_settings, active_page="admin_settings",
    )
    return templates.TemplateResponse("admin/settings.html", ctx)


@router.post("/settings/branding")
async def update_branding(
    request: Request,
    app_name: str = Form(...),
    custom_footer: str = Form(""),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    # Sirf app_name aur custom_footer update karein - logo/favicon file upload se
    await set_setting(db, "app_name", app_name, "branding")
    await set_setting(db, "custom_footer", custom_footer, "branding")
    await log_action(
        db, action="settings.update",
        description=f"Updated branding settings",
        user=user,
    )
    await db.commit()
    return RedirectResponse(url="/admin/settings?tab=branding", status_code=303)


@router.post("/settings/smtp")
async def update_smtp(
    request: Request,
    smtp_enabled: bool = Form(False),
    smtp_host: str = Form(""),
    smtp_port: int = Form(587),
    smtp_user: str = Form(""),
    smtp_password: str = Form(""),
    smtp_from: str = Form(""),
    smtp_tls: bool = Form(False),
    smtp_ssl: bool = Form(False),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    smtp = {
        "smtp_enabled": "true" if smtp_enabled else "false",
        "smtp_host": smtp_host,
        "smtp_port": str(smtp_port),
        "smtp_user": smtp_user,
        "smtp_password": smtp_password,
        "smtp_from": smtp_from,
        "smtp_tls": "true" if smtp_tls else "false",
        "smtp_ssl": "true" if smtp_ssl else "false",
    }
    await set_category_settings(db, "smtp", smtp)
    await log_action(
        db, action="settings.update",
        description="Updated SMTP settings",
        user=user,
    )
    await db.commit()
    return RedirectResponse(url="/admin/settings?tab=smtp", status_code=303)


@router.post("/settings/features")
async def update_features(
    request: Request,
    email_verification_required: bool = Form(False),
    password_reset_enabled: bool = Form(False),
    maintenance_mode: bool = Form(False),
    registration_enabled: bool = Form(False),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    features = {
        "email_verification_required": "true" if email_verification_required else "false",
        "password_reset_enabled": "true" if password_reset_enabled else "false",
        "maintenance_mode": "true" if maintenance_mode else "false",
        "registration_enabled": "true" if registration_enabled else "false",
    }
    await set_category_settings(db, "features", features)
    await log_action(
        db, action="settings.update",
        description="Updated feature flags",
        user=user,
    )
    await db.commit()
    return RedirectResponse(url="/admin/settings?tab=features", status_code=303)


@router.post("/settings/limits")
async def update_limits(
    request: Request,
    max_servers_per_user: int = Form(10),
    default_memory_mb: int = Form(1024),
    default_disk_mb: int = Form(5120),
    default_cpu_percent: int = Form(100),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    limits = {
        "max_servers_per_user": str(max_servers_per_user),
        "default_memory_mb": str(default_memory_mb),
        "default_disk_mb": str(default_disk_mb),
        "default_cpu_percent": str(default_cpu_percent),
    }
    await set_category_settings(db, "limits", limits)
    await log_action(
        db, action="settings.update",
        description="Updated default limits",
        user=user,
    )
    await db.commit()
    return RedirectResponse(url="/admin/settings?tab=limits", status_code=303)


# ---- Test SMTP ----

@router.post("/settings/smtp/test")
async def test_smtp(
    request: Request,
    test_email: str = Form(...),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    from services.email_service import email_service
    ok = await email_service.send_email(
        to_email=test_email,
        subject=f"ogultra SMTP Test - {datetime.now(timezone.utc).isoformat()}",
        body="This is a test email from ogultra. If you received this, SMTP is working correctly.",
    )
    return JSONResponse(content={"success": ok, "message": "Email sent" if ok else "Failed to send email"})


# ---- Branding Upload (logo/favicon) ----

BRANDING_DIR = BASE_DIR / "static" / "branding"
ALLOWED_IMAGE_TYPES = {
    "image/png", "image/jpeg", "image/jpg", "image/gif",
    "image/webp", "image/svg+xml", "image/x-icon", "image/vnd.microsoft.icon",
}
ALLOWED_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".ico"}
MAX_IMAGE_SIZE = 5 * 1024 * 1024  # 5MB


@router.post("/settings/branding/upload")
async def upload_branding_image(
    request: Request,
    type: str = Form(...),  # "logo" ya "favicon"
    file: UploadFile = FileParam(...),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Logo ya favicon image upload karein (file upload, no URL)."""
    if type not in ("logo", "favicon"):
        return JSONResponse(status_code=400, content={"error": "Type must be 'logo' or 'favicon'"})

    # Validate file type
    content_type = file.content_type or ""
    ext = Path(file.filename or "").suffix.lower()
    if content_type not in ALLOWED_IMAGE_TYPES and ext not in ALLOWED_IMAGE_EXTS:
        return JSONResponse(
            status_code=400,
            content={"error": f"Invalid file type. Allowed: {', '.join(ALLOWED_IMAGE_EXTS)}"},
        )

    # Read content
    content = await file.read()
    if len(content) > MAX_IMAGE_SIZE:
        return JSONResponse(
            status_code=400,
            content={"error": f"File too large. Max {MAX_IMAGE_SIZE // 1024 // 1024}MB"},
        )

    # Save file
    BRANDING_DIR.mkdir(parents=True, exist_ok=True)
    safe_filename = f"{type}{ext}"
    file_path = BRANDING_DIR / safe_filename

    with open(file_path, "wb") as f:
        f.write(content)

    # Update setting - URL pointing to static file
    static_url = f"/static/branding/{safe_filename}"
    await set_setting(db, f"{type}_url", static_url, "branding")
    await log_action(
        db, action="settings.branding_upload",
        description=f"Uploaded {type}: {safe_filename}",
        user=user,
    )
    await db.commit()

    return JSONResponse(content={
        "success": True,
        "url": static_url,
        "filename": safe_filename,
        "message": f"{type.capitalize()} uploaded successfully",
    })


@router.post("/settings/branding/remove")
async def remove_branding_image(
    request: Request,
    type: str = Form(...),
    user: User = Depends(get_admin_user),
    db: AsyncSession = Depends(get_db),
):
    """Logo ya favicon remove karein."""
    if type not in ("logo", "favicon"):
        return JSONResponse(status_code=400, content={"error": "Invalid type"})

    # Find and delete file
    BRANDING_DIR.mkdir(parents=True, exist_ok=True)
    for ext in ALLOWED_IMAGE_EXTS:
        file_path = BRANDING_DIR / f"{type}{ext}"
        if file_path.exists():
            file_path.unlink()

    # Clear setting
    await set_setting(db, f"{type}_url", "", "branding")
    await db.commit()

    return JSONResponse(content={"success": True, "message": f"{type.capitalize()} removed"})
