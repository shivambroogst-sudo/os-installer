"""
routers/files.py - File manager routes
Panel se daemon ko file operations ke liye forward karta hai.
Upload, download, edit, zip, unzip, rename, copy, move, delete, permissions.
"""
from __future__ import annotations

from typing import Optional

from fastapi import (
    APIRouter,
    Depends,
    File as FileParam,
    Form,
    HTTPException,
    Query,
    Request,
    UploadFile,
)
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse
from templates_setup import templates
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings, TEMPLATES_DIR
from database import get_db
from models import Node, Server, User
from auth import get_current_user
from services.template_context import build_context
from services.daemon_client import DaemonClient, DaemonError
from services.server_service import get_daemon_client
from services.audit_service import log_action


router = APIRouter(tags=["files"])


# ---- File manager page ----

@router.get("/servers/{server_uuid}/files", response_class=HTMLResponse)
async def file_manager_page(
    request: Request,
    server_uuid: str,
    path: str = ".",
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """File manager page open karein."""
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()

    ctx = await build_context(
        db, user, request=request, server=server, node=node,
        current_path=path, active_page="files",
    )
    return templates.TemplateResponse("files/manager.html", ctx)


# ---- List files (AJAX) ----

@router.get("/api/servers/{server_uuid}/files")
async def list_files_api(
    server_uuid: str,
    path: str = ".",
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        data = await client.list_files(server.uuid, path)
        return JSONResponse(content=data)
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


# ---- Read file (AJAX) ----

@router.get("/api/servers/{server_uuid}/files/read")
async def read_file_api(
    server_uuid: str,
    path: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        data = await client.read_file(server.uuid, path)
        return JSONResponse(content=data)
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


# ---- Write file (AJAX) ----

@router.post("/api/servers/{server_uuid}/files/write")
async def write_file_api(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    body = await request.json()
    path = body.get("path")
    content = body.get("content", "")
    if not path:
        return JSONResponse(status_code=400, content={"error": "Path required"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        await client.write_file(server.uuid, path, content)
        await log_action(
            db, action="file.write",
            description=f"Wrote file: {path}",
            user=user, server_id=server.id,
        )
        await db.commit()
        return JSONResponse(content={"success": True})
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


# ---- Create folder ----

@router.post("/api/servers/{server_uuid}/files/folder")
async def create_folder_api(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    body = await request.json()
    path = body.get("path", ".")
    name = body.get("name", "")
    if not name:
        return JSONResponse(status_code=400, content={"error": "Name required"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        await client.create_folder(server.uuid, path, name)
        return JSONResponse(content={"success": True})
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


# ---- Rename ----

@router.post("/api/servers/{server_uuid}/files/rename")
async def rename_file_api(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    body = await request.json()
    path = body.get("path")
    new_name = body.get("new_name")
    if not path or not new_name:
        return JSONResponse(status_code=400, content={"error": "path and new_name required"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        await client.rename_file(server.uuid, path, new_name)
        return JSONResponse(content={"success": True})
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


# ---- Move / Copy ----

@router.post("/api/servers/{server_uuid}/files/move")
async def move_file_api(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    body = await request.json()
    src = body.get("src_path")
    dest = body.get("dest_path")
    if not src or not dest:
        return JSONResponse(status_code=400, content={"error": "src_path and dest_path required"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        await client.move_file(server.uuid, src, dest)
        return JSONResponse(content={"success": True})
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


# ---- Delete ----

@router.post("/api/servers/{server_uuid}/files/delete")
async def delete_files_api(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    body = await request.json()
    paths = body.get("paths", [])
    if not paths:
        return JSONResponse(status_code=400, content={"error": "paths required"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        await client.delete_files(server.uuid, paths)
        await log_action(
            db, action="file.delete",
            description=f"Deleted files: {', '.join(paths)}",
            user=user, server_id=server.id,
        )
        await db.commit()
        return JSONResponse(content={"success": True})
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


# ---- Upload (multipart) ----

@router.post("/api/servers/{server_uuid}/files/upload")
async def upload_file_api(
    server_uuid: str,
    path: str = Form("."),
    file: UploadFile = FileParam(...),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)

    content = await file.read()
    try:
        await client.upload_file(server.uuid, path, file.filename, content)
        await log_action(
            db, action="file.upload",
            description=f"Uploaded: {file.filename} ({len(content)} bytes)",
            user=user, server_id=server.id,
        )
        await db.commit()
        return JSONResponse(content={"success": True, "filename": file.filename, "size": len(content)})
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


# ---- Download ----

@router.get("/api/servers/{server_uuid}/files/download")
async def download_file_api(
    server_uuid: str,
    path: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        raise HTTPException(status_code=404, detail="Server not found")
    if server.owner_id != user.id and not user.is_admin:
        raise HTTPException(status_code=403, detail="Access denied")

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        content = await client.download_file(server.uuid, path)
    except DaemonError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)

    filename = path.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    return StreamingResponse(
        iter([content]),
        media_type="application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ---- ZIP / UNZIP ----

@router.post("/api/servers/{server_uuid}/files/archive")
async def archive_api(
    request: Request,
    server_uuid: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    body = await request.json()
    action = body.get("action")
    path = body.get("path")
    name = body.get("name")
    if action not in ("zip", "unzip") or not path:
        return JSONResponse(status_code=400, content={"error": "Invalid request"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        data = await client.archive_files(server.uuid, action, path, name)
        return JSONResponse(content=data)
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


# ---- Permissions ----

@router.get("/api/servers/{server_uuid}/files/permissions")
async def permissions_api(
    server_uuid: str,
    path: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        data = await client.file_permissions(server.uuid, path)
        return JSONResponse(content=data)
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})


# ---- Upload jar (for custom servers) ----

@router.post("/api/servers/{server_uuid}/upload-jar")
async def upload_jar_api(
    server_uuid: str,
    file: UploadFile = FileParam(...),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Custom server ke liye jar upload karein."""
    result = await db.execute(select(Server).where(Server.uuid == server_uuid))
    server = result.scalar_one_or_none()
    if not server:
        return JSONResponse(status_code=404, content={"error": "Server not found"})
    if server.owner_id != user.id and not user.is_admin:
        return JSONResponse(status_code=403, content={"error": "Access denied"})

    if not file.filename.endswith(".jar"):
        return JSONResponse(status_code=400, content={"error": "Only .jar files allowed"})

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)

    # Upload to root of server install path
    content = await file.read()
    try:
        await client.upload_file(server.uuid, ".", file.filename, content)
        from models import ServerStatus
        server.status = ServerStatus.INSTALLED.value
        await db.commit()
        return JSONResponse(content={"success": True, "filename": file.filename})
    except DaemonError as e:
        return JSONResponse(status_code=e.status_code, content={"error": e.message})
