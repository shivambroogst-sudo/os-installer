"""
schemas.py - Pydantic schemas for API request/response validation
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, EmailStr, Field, field_validator


# ---- Auth ----

class LoginRequest(BaseModel):
    identifier: str = Field(..., min_length=3, max_length=255, description="Username or email")
    password: str = Field(..., min_length=1, max_length=128)
    remember: bool = False


class RegisterRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=32, pattern=r"^[a-zA-Z0-9_.-]+$")
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)
    password_confirm: str = Field(..., min_length=8, max_length=128)

    @field_validator("password_confirm")
    @classmethod
    def passwords_match(cls, v, info):
        if "password" in info.data and v != info.data["password"]:
            raise ValueError("Passwords do not match")
        return v


class PasswordResetRequest(BaseModel):
    email: EmailStr


class PasswordResetConfirm(BaseModel):
    token: str
    password: str = Field(..., min_length=8, max_length=128)
    password_confirm: str = Field(..., min_length=8, max_length=128)

    @field_validator("password_confirm")
    @classmethod
    def passwords_match(cls, v, info):
        if "password" in info.data and v != info.data["password"]:
            raise ValueError("Passwords do not match")
        return v


class EmailVerifyRequest(BaseModel):
    token: str


# ---- User ----

class UserOut(BaseModel):
    id: int
    uuid: str
    username: str
    email: str
    role: str
    is_active: bool
    is_email_verified: bool
    theme: str
    language: str
    timezone: str
    created_at: datetime

    class Config:
        from_attributes = True


class UserUpdate(BaseModel):
    theme: Optional[str] = None
    language: Optional[str] = None
    timezone: Optional[str] = None
    email: Optional[EmailStr] = None


class PasswordChange(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=8, max_length=128)
    new_password_confirm: str = Field(..., min_length=8, max_length=128)

    @field_validator("new_password_confirm")
    @classmethod
    def passwords_match(cls, v, info):
        if "new_password" in info.data and v != info.data["new_password"]:
            raise ValueError("Passwords do not match")
        return v


# ---- Server ----

class ServerCreate(BaseModel):
    name: str = Field(..., min_length=3, max_length=64)
    description: Optional[str] = Field(None, max_length=255)
    server_type: str = Field(..., description="paper|purpur|spigot|vanilla|fabric|forge|velocity|waterfall|bungeecord|custom")
    version: str = Field("latest", max_length=32)
    node_id: int
    memory_limit: int = Field(1024, ge=128, le=65536)
    disk_limit: int = Field(5120, ge=256, le=1048576)
    cpu_limit: int = Field(100, ge=10, le=400)
    startup_command: Optional[str] = None
    java_arguments: Optional[str] = None
    expires_in_days: Optional[int] = Field(None, ge=1, le=3650)
    auto_restart: bool = True
    auto_startup: bool = False


class ServerUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=3, max_length=64)
    description: Optional[str] = Field(None, max_length=255)
    memory_limit: Optional[int] = Field(None, ge=128, le=65536)
    disk_limit: Optional[int] = Field(None, ge=256, le=1048576)
    cpu_limit: Optional[int] = Field(None, ge=10, le=400)
    startup_command: Optional[str] = None
    java_arguments: Optional[str] = None
    auto_restart: Optional[bool] = None
    auto_startup: Optional[bool] = None


class ServerOut(BaseModel):
    id: int
    uuid: str
    name: str
    description: Optional[str]
    server_type: str
    version: str
    status: str
    owner_id: int
    node_id: int
    memory_limit: int
    disk_limit: int
    cpu_limit: int
    startup_command: str
    java_arguments: str
    auto_restart: bool
    auto_startup: bool
    is_suspended: bool
    expires_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True


class ServerAction(BaseModel):
    action: str = Field(..., description="start|stop|restart|kill|install")
    command: Optional[str] = None


# ---- Node ----

class NodeCreate(BaseModel):
    name: str = Field(..., min_length=3, max_length=64)
    fqdn: str = Field(..., max_length=255)
    daemon_host: str = Field(..., max_length=255)
    daemon_port: int = Field(8081, ge=1, le=65535)
    location: Optional[str] = None
    memory_total: int = Field(4096, ge=512, le=1048576)
    disk_total: int = Field(51200, ge=1024, le=10485760)
    cpu_cores: int = Field(2, ge=1, le=64)


class NodeOut(BaseModel):
    id: int
    uuid: str
    name: str
    fqdn: str
    daemon_host: str
    daemon_port: int
    status: str
    location: Optional[str]
    memory_total: int
    memory_used: int
    disk_total: int
    disk_used: int
    cpu_cores: int
    cpu_used: float
    last_heartbeat: Optional[datetime]
    api_key: str  # sirf admin ko
    auth_token: str
    created_at: datetime

    class Config:
        from_attributes = True


class NodeRegister(BaseModel):
    """Daemon self-register with panel"""
    name: str
    fqdn: str
    daemon_host: str
    daemon_port: int
    memory_total: int
    disk_total: int
    cpu_cores: int
    location: Optional[str] = None
    api_key: str  # panel-issued initial key


class NodeHeartbeat(BaseModel):
    memory_used: int
    disk_used: int
    cpu_used: float
    metadata: Optional[dict[str, Any]] = None


# ---- Allocation ----

class AllocationCreate(BaseModel):
    ip: str
    port: int = Field(..., ge=1, le=65535)
    is_primary: bool = False


class AllocationOut(BaseModel):
    id: int
    ip: str
    port: int
    is_primary: bool
    is_assigned: bool
    server_id: Optional[int]

    class Config:
        from_attributes = True


# ---- Backup ----

class BackupCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=128)


class BackupOut(BaseModel):
    id: int
    uuid: str
    name: str
    file_name: str
    size_bytes: int
    is_locked: bool
    is_manual: bool
    created_at: datetime

    class Config:
        from_attributes = True


# ---- Schedule ----

class ScheduleCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=64)
    action: str
    cron_expression: str = Field(..., description="Standard 5-field cron: */5 * * * *")
    command: Optional[str] = None
    is_enabled: bool = True


class ScheduleOut(BaseModel):
    id: int
    name: str
    action: str
    cron_expression: str
    command: Optional[str]
    is_enabled: bool
    last_run_at: Optional[datetime]
    next_run_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True


# ---- File manager ----

class FileCreateFolder(BaseModel):
    path: str
    name: str


class FileRename(BaseModel):
    path: str
    new_name: str


class FileMove(BaseModel):
    src_path: str
    dest_path: str


class FileDelete(BaseModel):
    paths: list[str]


class FileSaveContent(BaseModel):
    path: str
    content: str


# ---- API Keys ----

class ApiKeyCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=64)


class ApiKeyOut(BaseModel):
    id: int
    name: str
    key_prefix: str
    last_used_at: Optional[datetime]
    expires_at: Optional[datetime]
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


# ---- Notifications ----

class NotificationOut(BaseModel):
    id: int
    title: str
    message: str
    level: str
    is_read: bool
    link: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# ---- System settings ----

class SystemSettingUpdate(BaseModel):
    category: str = "general"
    settings: dict[str, str]


class SystemSettingsOut(BaseModel):
    category: str
    settings: dict[str, str]


# ---- Generic responses ----

class MessageResponse(BaseModel):
    message: str
    success: bool = True
    data: Optional[Any] = None


class ErrorResponse(BaseModel):
    detail: str
    code: Optional[str] = None
