// PyroPanel - main client-side JavaScript

// ---- Theme toggle ----
(function() {
  const toggle = document.getElementById('theme-toggle');
  if (toggle) {
    toggle.addEventListener('click', () => {
      const isDark = document.documentElement.classList.toggle('dark');
      localStorage.setItem('theme', isDark ? 'dark' : 'light');
      // Save to server
      fetch('/settings/profile', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `theme=${isDark ? 'dark' : 'light'}&csrf_token=${getCsrf()}`,
      }).catch(() => {});
    });
  }
})();

function getCsrf() {
  const match = document.cookie.match(/pyropanel_csrf=([^;]+)/);
  return match ? match[1] : '';
}

// ---- Form helpers ----
function confirmAction(message) {
  return confirm(message);
}

// ---- CSRF: intercept all form submissions and add X-CSRF-Token header ----
// Yeh conventional form POST ke liye - AJAX fetch calls apne aap header add karte hain
(function() {
  const originalSubmit = HTMLFormElement.prototype.submit;
  HTMLFormElement.prototype.submit = function() {
    injectCsrf(this);
    return originalSubmit.call(this);
  };
  document.addEventListener('submit', (e) => {
    if (e.target.tagName === 'FORM' && e.target.method && e.target.method.toLowerCase() === 'post') {
      injectCsrf(e.target);
    }
  }, true);

  function injectCsrf(form) {
    // Skip if already has hidden csrf input
    if (form.querySelector('input[name="csrf_token"]')) return;
    const csrf = getCsrf();
    if (!csrf) return;
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'csrf_token';
    input.value = csrf;
    form.appendChild(input);
  }
})();

// Set CSRF cookie on every page load (if not already set) - so forms work
// Note: cookie is set by server on login, JS just reads it

// ---- AJAX helper ----
async function api(method, url, body = null) {
  const opts = {
    method,
    headers: {
      'X-CSRF-Token': getCsrf(),
    },
  };
  if (body && !(body instanceof FormData)) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  } else if (body) {
    opts.body = body;
  }
  const resp = await fetch(url, opts);
  if (resp.status === 401) {
    window.location.href = '/auth/login';
    return null;
  }
  return resp.json().catch(() => ({success: false, error: 'Invalid response'}));
}

// ---- Toast notifications (simple) ----
function showToast(message, type = 'info') {
  const colors = {
    info: 'bg-blue-600',
    success: 'bg-green-600',
    error: 'bg-red-600',
    warning: 'bg-yellow-600',
  };
  const toast = document.createElement('div');
  toast.className = `fixed top-4 right-4 ${colors[type] || colors.info} text-white px-4 py-2 rounded-lg shadow-lg z-50 transition transform translate-x-full`;
  toast.textContent = message;
  document.body.appendChild(toast);
  requestAnimationFrame(() => toast.classList.remove('translate-x-full'));
  setTimeout(() => {
    toast.classList.add('translate-x-full');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ---- Auto-refresh server status (for server list page) ----
document.addEventListener('DOMContentLoaded', () => {
  // If on servers list, periodically refresh statuses
  const serverCards = document.querySelectorAll('[data-server-uuid]');
  if (serverCards.length > 0) {
    setInterval(async () => {
      for (const card of serverCards) {
        const uuid = card.dataset.serverUuid;
        try {
          const r = await fetch(`/api/servers/${uuid}/status`);
          const d = await r.json();
          const badge = card.querySelector('[data-status-badge]');
          if (badge && d.db_status) {
            badge.textContent = d.db_status.charAt(0).toUpperCase() + d.db_status.slice(1);
          }
        } catch (e) {}
      }
    }, 10000);
  }
});

// ---- Copy to clipboard ----
function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    showToast('Copied to clipboard', 'success');
  });
}

// ---- Time ago formatter (client-side) ----
function timeAgo(isoString) {
  const date = new Date(isoString);
  const now = new Date();
  const seconds = Math.floor((now - date) / 1000);
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds/60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds/3600)}h ago`;
  if (seconds < 2592000) return `${Math.floor(seconds/86400)}d ago`;
  return date.toLocaleDateString();
}

// Refresh time-ago elements every minute
setInterval(() => {
  document.querySelectorAll('[data-time-ago]').forEach(el => {
    el.textContent = timeAgo(el.dataset.timeAgo);
  });
}, 60000);
