"""
services/egg_service.py - Egg management service
Pterodactyl ke eggs jaisa system - server templates with install scripts,
startup config, aur variables.

Default eggs:
- Minecraft Java (Paper, Vanilla, Forge, Fabric, Spigot, Purpur)
- Minecraft Proxy (Velocity, Waterfall, BungeeCord)
- Custom (user-uploaded jar)
"""
from __future__ import annotations

import json
from typing import Any, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from models import Egg


# ---- Default Eggs (Pterodactyl-like) ----

DEFAULT_EGGS = [
    # Minecraft Java Edition
    {
        "name": "Paper",
        "description": "High performance fork of Spigot with better optimization",
        "category": "minecraft",
        "icon": "📄",
        "tags": "minecraft,java,paper,spigot",
        "startup_command": "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui",
        "default_memory": 1024,
        "default_disk": 5120,
        "default_cpu": 100,
        "install_script": """#!/bin/bash
# Paper install script
cd {{INSTALL_PATH}}
if [ "{{SERVER_VERSION}}" = "latest" ]; then
  VERSION=$(curl -s 'https://api.papermc.io/v2/projects/paper' | python3 -c "import sys,json; print(json.load(sys.stdin)['versions'][-1])")
else
  VERSION="{{SERVER_VERSION}}"
fi
BUILD=$(curl -s "https://api.papermc.io/v2/projects/paper/versions/$VERSION" | python3 -c "import sys,json; print(json.load(sys.stdin)['builds'][-1]['build'])")
FILENAME=$(curl -s "https://api.papermc.io/v2/projects/paper/versions/$VERSION/builds/$BUILD" | python3 -c "import sys,json; print(json.load(sys.stdin)['downloads']['application']['name'])")
curl -o "paper.jar" "https://api.papermc.io/v2/projects/paper/versions/$VERSION/builds/$BUILD/downloads/$FILENAME"
ln -sf paper.jar server.jar
echo "eula=true" > eula.txt
echo "Paper $VERSION build $BUILD installed"
""",
        "variables": [
            {
                "name": "Server Jar File",
                "env_variable": "SERVER_JARFILE",
                "default_value": "server.jar",
                "description": "The name of the jar file to run the server with.",
                "required": True,
                "user_viewable": True,
                "user_editable": False,
            },
            {
                "name": "Server Version",
                "env_variable": "SERVER_VERSION",
                "default_value": "latest",
                "description": "The version of Paper to install.",
                "required": True,
                "user_viewable": True,
                "user_editable": True,
            },
        ],
        "features": ["eula", "java_version"],
        "is_default": True,
    },
    {
        "name": "Vanilla",
        "description": "Official Mojang Minecraft server",
        "category": "minecraft",
        "icon": "🎮",
        "tags": "minecraft,java,vanilla,mojang",
        "startup_command": "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui",
        "default_memory": 1024,
        "default_disk": 5120,
        "default_cpu": 100,
        "install_script": """#!/bin/bash
cd {{INSTALL_PATH}}
if [ "{{SERVER_VERSION}}" = "latest" ]; then
  VERSION=$(curl -s 'https://launchermeta.mojang.com/mc/game/version_manifest.json' | python3 -c "import sys,json; print(json.load(sys.stdin)['latest']['release'])")
else
  VERSION="{{SERVER_VERSION}}"
fi
URL=$(curl -s 'https://launchermeta.mojang.com/mc/game/version_manifest.json' | python3 -c "import sys,json; versions={v['id']:v for v in json.load(sys.stdin)['versions']}; print(versions['$VERSION']['url'])")
URL=$(curl -s "$URL" | python3 -c "import sys,json; print(json.load(sys.stdin)['downloads']['server']['url'])")
curl -o server.jar "$URL"
echo "eula=true" > eula.txt
echo "Vanilla $VERSION installed"
""",
        "variables": [
            {
                "name": "Server Jar File",
                "env_variable": "SERVER_JARFILE",
                "default_value": "server.jar",
                "description": "The name of the jar file to run.",
                "required": True,
                "user_viewable": True,
                "user_editable": False,
            },
            {
                "name": "Server Version",
                "env_variable": "SERVER_VERSION",
                "default_value": "latest",
                "description": "Minecraft version (e.g. 1.20.4)",
                "required": True,
                "user_viewable": True,
                "user_editable": True,
            },
        ],
        "features": ["eula", "java_version"],
        "is_default": True,
    },
    {
        "name": "Purpur",
        "description": "Paper fork with extra optimizations and features",
        "category": "minecraft",
        "icon": "📜",
        "tags": "minecraft,java,purpur,paper",
        "startup_command": "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui",
        "default_memory": 1024,
        "default_disk": 5120,
        "default_cpu": 100,
        "install_script": """#!/bin/bash
cd {{INSTALL_PATH}}
if [ "{{SERVER_VERSION}}" = "latest" ]; then
  VERSION=$(curl -s 'https://api.purpurmc.org/v2/purpur' | python3 -c "import sys,json; print(json.load(sys.stdin)['version'])")
else
  VERSION="{{SERVER_VERSION}}"
fi
curl -o purpur.jar "https://api.purpurmc.org/v2/purpur/$VERSION/latest/download"
ln -sf purpur.jar server.jar
echo "eula=true" > eula.txt
echo "Purpur $VERSION installed"
""",
        "variables": [
            {
                "name": "Server Jar File",
                "env_variable": "SERVER_JARFILE",
                "default_value": "server.jar",
                "description": "The jar file to run.",
                "required": True,
                "user_viewable": True,
                "user_editable": False,
            },
            {
                "name": "Server Version",
                "env_variable": "SERVER_VERSION",
                "default_value": "latest",
                "description": "Purpur version",
                "required": True,
                "user_viewable": True,
                "user_editable": True,
            },
        ],
        "features": ["eula", "java_version"],
        "is_default": False,
    },
    {
        "name": "Spigot",
        "description": "Popular Bukkit-compatible Minecraft server",
        "category": "minecraft",
        "icon": "🪵",
        "tags": "minecraft,java,spigot,bukkit",
        "startup_command": "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui",
        "default_memory": 1024,
        "default_disk": 5120,
        "default_cpu": 100,
        "install_script": """#!/bin/bash
cd {{INSTALL_PATH}}
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then VERSION="1.20.4"; fi
curl -L -o spigot.jar "https://download.getbukkit.org/spigot/spigot-$VERSION.jar"
ln -sf spigot.jar server.jar
echo "eula=true" > eula.txt
echo "Spigot $VERSION installed"
""",
        "variables": [
            {
                "name": "Server Jar File",
                "env_variable": "SERVER_JARFILE",
                "default_value": "server.jar",
                "description": "The jar file to run.",
                "required": True,
                "user_viewable": True,
                "user_editable": False,
            },
            {
                "name": "Server Version",
                "env_variable": "SERVER_VERSION",
                "default_value": "latest",
                "description": "Spigot version",
                "required": True,
                "user_viewable": True,
                "user_editable": True,
            },
        ],
        "features": ["eula", "java_version"],
        "is_default": False,
    },
    {
        "name": "Forge",
        "description": "Minecraft Forge modding platform",
        "category": "minecraft",
        "icon": "🔨",
        "tags": "minecraft,java,forge,mods",
        "startup_command": "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui",
        "default_memory": 2048,
        "default_disk": 10240,
        "default_cpu": 200,
        "install_script": """#!/bin/bash
cd {{INSTALL_PATH}}
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then VERSION="1.20.1"; fi
# Try universal jar first
curl -L -o forge.jar "https://maven.minecraftforge.net/net/minecraftforge/forge/$VERSION-$VERSION-universal/forge-$VERSION-$VERSION-universal.jar"
if [ ! -f forge.jar ]; then
  # Fallback to installer
  curl -L -o forge-installer.jar "https://maven.minecraftforge.net/net/minecraftforge/forge/$VERSION-$VERSION/forge-$VERSION-$VERSION-installer.jar"
  java -jar forge-installer.jar --installServer
  rm -f forge-installer.jar
fi
ln -sf forge.jar server.jar
echo "eula=true" > eula.txt
echo "Forge $VERSION installed"
""",
        "variables": [
            {
                "name": "Server Jar File",
                "env_variable": "SERVER_JARFILE",
                "default_value": "server.jar",
                "description": "The jar file to run.",
                "required": True,
                "user_viewable": True,
                "user_editable": False,
            },
            {
                "name": "Server Version",
                "env_variable": "SERVER_VERSION",
                "default_value": "1.20.1",
                "description": "Minecraft version for Forge",
                "required": True,
                "user_viewable": True,
                "user_editable": True,
            },
        ],
        "features": ["eula", "java_version"],
        "is_default": False,
    },
    {
        "name": "Fabric",
        "description": "Lightweight Minecraft modding platform",
        "category": "minecraft",
        "icon": "🧵",
        "tags": "minecraft,java,fabric,mods",
        "startup_command": "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui",
        "default_memory": 1024,
        "default_disk": 5120,
        "default_cpu": 100,
        "install_script": """#!/bin/bash
cd {{INSTALL_PATH}}
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then
  VERSION=$(curl -s 'https://meta.fabricmc.net/v2/versions/game' | python3 -c "import sys,json; data=json.load(sys.stdin); stable=[v for v in data if v.get('stable')]; print(stable[-1]['version'] if stable else '1.20.4')")
fi
LOADER=$(curl -s 'https://meta.fabricmc.net/v2/versions/loader' | python3 -c "import sys,json; print(json.load(sys.stdin)[0]['version'])")
INSTALLER=$(curl -s 'https://meta.fabricmc.net/v2/versions/installer' | python3 -c "import sys,json; print(json.load(sys.stdin)[0]['version'])")
curl -o fabric-server.jar "https://meta.fabricmc.net/v2/versions/loader/$VERSION/$LOADER/$INSTALLER/server/jar"
ln -sf fabric-server.jar server.jar
echo "eula=true" > eula.txt
echo "Fabric $VERSION installed"
""",
        "variables": [
            {
                "name": "Server Jar File",
                "env_variable": "SERVER_JARFILE",
                "default_value": "server.jar",
                "description": "The jar file to run.",
                "required": True,
                "user_viewable": True,
                "user_editable": False,
            },
            {
                "name": "Server Version",
                "env_variable": "SERVER_VERSION",
                "default_value": "latest",
                "description": "Minecraft version for Fabric",
                "required": True,
                "user_viewable": True,
                "user_editable": True,
            },
        ],
        "features": ["eula", "java_version"],
        "is_default": False,
    },
    # Proxies
    {
        "name": "Velocity",
        "description": "Modern, high-performance Minecraft proxy",
        "category": "proxy",
        "icon": "⚡",
        "tags": "minecraft,proxy,velocity",
        "startup_command": "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}",
        "default_memory": 512,
        "default_disk": 1024,
        "default_cpu": 100,
        "install_script": """#!/bin/bash
cd {{INSTALL_PATH}}
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then
  VERSION=$(curl -s 'https://api.papermc.io/v2/projects/velocity' | python3 -c "import sys,json; print(json.load(sys.stdin)['versions'][-1])")
fi
BUILD=$(curl -s "https://api.papermc.io/v2/projects/velocity/versions/$VERSION" | python3 -c "import sys,json; print(json.load(sys.stdin)['builds'][-1]['build'])")
FILENAME=$(curl -s "https://api.papermc.io/v2/projects/velocity/versions/$VERSION/builds/$BUILD" | python3 -c "import sys,json; print(json.load(sys.stdin)['downloads']['application']['name'])")
curl -o velocity.jar "https://api.papermc.io/v2/projects/velocity/versions/$VERSION/builds/$BUILD/downloads/$FILENAME"
ln -sf velocity.jar server.jar
echo "Velocity $VERSION installed"
""",
        "variables": [
            {
                "name": "Server Jar File",
                "env_variable": "SERVER_JARFILE",
                "default_value": "server.jar",
                "description": "The jar file to run.",
                "required": True,
                "user_viewable": True,
                "user_editable": False,
            },
            {
                "name": "Server Version",
                "env_variable": "SERVER_VERSION",
                "default_value": "latest",
                "description": "Velocity version",
                "required": True,
                "user_viewable": True,
                "user_editable": True,
            },
        ],
        "features": [],
        "is_default": False,
    },
    {
        "name": "Waterfall",
        "description": "BungeeCord fork proxy with better performance",
        "category": "proxy",
        "icon": "💧",
        "tags": "minecraft,proxy,waterfall,bungeecord",
        "startup_command": "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}",
        "default_memory": 512,
        "default_disk": 1024,
        "default_cpu": 100,
        "install_script": """#!/bin/bash
cd {{INSTALL_PATH}}
VERSION="{{SERVER_VERSION}}"
if [ "$VERSION" = "latest" ]; then
  VERSION=$(curl -s 'https://api.papermc.io/v2/projects/waterfall' | python3 -c "import sys,json; print(json.load(sys.stdin)['versions'][-1])")
fi
BUILD=$(curl -s "https://api.papermc.io/v2/projects/waterfall/versions/$VERSION" | python3 -c "import sys,json; print(json.load(sys.stdin)['builds'][-1]['build'])")
FILENAME=$(curl -s "https://api.papermc.io/v2/projects/waterfall/versions/$VERSION/builds/$BUILD" | python3 -c "import sys,json; print(json.load(sys.stdin)['downloads']['application']['name'])")
curl -o waterfall.jar "https://api.papermc.io/v2/projects/waterfall/versions/$VERSION/builds/$BUILD/downloads/$FILENAME"
ln -sf waterfall.jar server.jar
echo "Waterfall $VERSION installed"
""",
        "variables": [
            {
                "name": "Server Jar File",
                "env_variable": "SERVER_JARFILE",
                "default_value": "server.jar",
                "description": "The jar file to run.",
                "required": True,
                "user_viewable": True,
                "user_editable": False,
            },
            {
                "name": "Server Version",
                "env_variable": "SERVER_VERSION",
                "default_value": "latest",
                "description": "Waterfall version",
                "required": True,
                "user_viewable": True,
                "user_editable": True,
            },
        ],
        "features": [],
        "is_default": False,
    },
    {
        "name": "BungeeCord",
        "description": "Classic Minecraft proxy server",
        "category": "proxy",
        "icon": "🔗",
        "tags": "minecraft,proxy,bungeecord",
        "startup_command": "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}",
        "default_memory": 512,
        "default_disk": 1024,
        "default_cpu": 100,
        "install_script": """#!/bin/bash
cd {{INSTALL_PATH}}
curl -o BungeeCord.jar "https://ci.md-5.net/job/BungeeCord/lastSuccessfulBuild/artifact/bootstrap/target/BungeeCord.jar"
ln -sf BungeeCord.jar server.jar
echo "BungeeCord installed"
""",
        "variables": [
            {
                "name": "Server Jar File",
                "env_variable": "SERVER_JARFILE",
                "default_value": "server.jar",
                "description": "The jar file to run.",
                "required": True,
                "user_viewable": True,
                "user_editable": False,
            },
        ],
        "features": [],
        "is_default": False,
    },
    {
        "name": "Custom",
        "description": "Upload your own server jar file",
        "category": "custom",
        "icon": "⚙️",
        "tags": "custom,jar",
        "startup_command": "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui",
        "default_memory": 1024,
        "default_disk": 5120,
        "default_cpu": 100,
        "install_script": """#!/bin/bash
cd {{INSTALL_PATH}}
echo "Custom server - please upload your jar file via File Manager"
echo "eula=true" > eula.txt
""",
        "variables": [
            {
                "name": "Server Jar File",
                "env_variable": "SERVER_JARFILE",
                "default_value": "server.jar",
                "description": "The jar file to run (upload via file manager).",
                "required": True,
                "user_viewable": True,
                "user_editable": True,
            },
        ],
        "features": ["eula", "java_version"],
        "is_default": False,
    },
]


async def ensure_default_eggs(db: AsyncSession) -> int:
    """Default eggs create karein agar table khali hai. Returns count."""
    result = await db.execute(select(Egg).limit(1))
    if result.scalar_one_or_none():
        return 0  # Already has eggs

    count = 0
    for egg_data in DEFAULT_EGGS:
        egg = Egg(
            name=egg_data["name"],
            description=egg_data["description"],
            category=egg_data["category"],
            author="ogultra",
            version="1.0",
            install_script=egg_data["install_script"],
            startup_command=egg_data["startup_command"],
            default_memory=egg_data["default_memory"],
            default_disk=egg_data["default_disk"],
            default_cpu=egg_data["default_cpu"],
            variables=egg_data.get("variables"),
            features=egg_data.get("features"),
            tags=egg_data.get("tags"),
            icon=egg_data.get("icon"),
            is_active=True,
            is_default=egg_data.get("is_default", False),
        )
        db.add(egg)
        count += 1

    await db.commit()
    return count


async def get_egg(db: AsyncSession, egg_id: int) -> Optional[Egg]:
    result = await db.execute(select(Egg).where(Egg.id == egg_id))
    return result.scalar_one_or_none()


async def get_egg_by_uuid(db: AsyncSession, egg_uuid: str) -> Optional[Egg]:
    result = await db.execute(select(Egg).where(Egg.uuid == egg_uuid))
    return result.scalar_one_or_none()


async def list_eggs(
    db: AsyncSession, category: Optional[str] = None, active_only: bool = True
) -> list[Egg]:
    query = select(Egg)
    if active_only:
        query = query.where(Egg.is_active == True)  # noqa: E712
    if category:
        query = query.where(Egg.category == category)
    query = query.order_by(Egg.category, Egg.name)
    result = await db.execute(query)
    return list(result.scalars().all())


async def create_egg(db: AsyncSession, egg_data: dict) -> Egg:
    """Custom egg create karein."""
    egg = Egg(
        name=egg_data["name"],
        description=egg_data.get("description"),
        category=egg_data.get("category", "custom"),
        author=egg_data.get("author", "admin"),
        version=egg_data.get("version", "1.0"),
        install_script=egg_data.get("install_script", ""),
        startup_command=egg_data.get("startup_command", ""),
        default_memory=egg_data.get("default_memory", 1024),
        default_disk=egg_data.get("default_disk", 5120),
        default_cpu=egg_data.get("default_cpu", 100),
        variables=egg_data.get("variables"),
        features=egg_data.get("features"),
        tags=egg_data.get("tags"),
        icon=egg_data.get("icon"),
        is_active=True,
        is_default=False,
    )
    db.add(egg)
    await db.commit()
    await db.refresh(egg)
    return egg


async def update_egg(db: AsyncSession, egg: Egg, egg_data: dict) -> Egg:
    """Egg update karein."""
    for key, value in egg_data.items():
        if hasattr(egg, key) and value is not None:
            setattr(egg, key, value)
    await db.commit()
    await db.refresh(egg)
    return egg


async def delete_egg(db: AsyncSession, egg: Egg) -> None:
    """Egg delete karein (agar koi server use nahi kar raha)."""
    await db.delete(egg)
    await db.commit()


def render_startup_command(template: str, variables: dict) -> str:
    """Startup command me {{VAR}} placeholders ko variables se replace karein."""
    out = template
    for k, v in variables.items():
        out = out.replace(f"{{{{{k}}}}}", str(v))
    return out


def render_install_script(script: str, context: dict) -> str:
    """Install script me placeholders ko replace karein.
    Context: {INSTALL_PATH, SERVER_VERSION, SERVER_MEMORY, ...}"""
    out = script
    for k, v in context.items():
        out = out.replace(f"{{{{{k}}}}}", str(v))
    return out


def get_egg_variables(egg: Egg, user_overrides: Optional[dict] = None) -> dict:
    """Egg ke variables ko env dict me convert karein.
    User overrides apply karein."""
    result = {}
    if not egg.variables:
        return result
    for var in egg.variables:
        env_name = var.get("env_variable", "")
        default = var.get("default_value", "")
        if user_overrides and env_name in user_overrides:
            result[env_name] = user_overrides[env_name]
        else:
            result[env_name] = default
    return result
