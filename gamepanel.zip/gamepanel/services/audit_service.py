"""
services/audit_service.py - Audit logging aur helpers
Saare important actions ka audit log banata hai.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy import select, func, desc
from sqlalchemy.ext.asyncio import AsyncSession

from models import AuditLog, User


async def log_action(
    db: AsyncSession,
    action: str,
    description: str,
    user: Optional[User] = None,
    server_id: Optional[int] = None,
    resource_type: Optional[str] = None,
    resource_id: Optional[int] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
    metadata: Optional[dict[str, Any]] = None,
) -> AuditLog:
    """Audit log entry create karein."""
    entry = AuditLog(
        user_id=user.id if user else None,
        server_id=server_id,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        description=description,
        ip_address=ip_address,
        user_agent=(user_agent or "")[:255] if user_agent else None,
        metadata_json=metadata,
        created_at=datetime.now(timezone.utc),
    )
    db.add(entry)
    await db.flush()
    return entry


async def get_recent_logs(
    db: AsyncSession,
    limit: int = 50,
    offset: int = 0,
    user_id: Optional[int] = None,
    action_filter: Optional[str] = None,
) -> tuple[list[AuditLog], int]:
    """Recent audit logs fetch karein with total count for pagination."""
    query = select(AuditLog)
    count_query = select(func.count(AuditLog.id))

    if user_id:
        query = query.where(AuditLog.user_id == user_id)
        count_query = count_query.where(AuditLog.user_id == user_id)
    if action_filter:
        query = query.where(AuditLog.action.ilike(f"%{action_filter}%"))
        count_query = count_query.where(AuditLog.action.ilike(f"%{action_filter}%"))

    total = (await db.execute(count_query)).scalar_one()
    query = query.order_by(desc(AuditLog.created_at)).limit(limit).offset(offset)
    result = await db.execute(query)
    return list(result.scalars().all()), total
