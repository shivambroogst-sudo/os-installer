"""
services/scheduler_service.py - Cron-based scheduler
Background task jo har minute check karta hai ki kaunsa schedule run karna hai.
Supports standard 5-field cron expressions.
"""
from __future__ import annotations

import asyncio
import re
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from database import async_session_factory
from models import Schedule, Server, ServerStatus, ScheduleAction
from services.server_service import (
    start_server,
    stop_server,
    restart_server,
    kill_server,
    send_command,
)
from services.audit_service import log_action


# ---- Cron parser (5-field: minute hour day-of-month month day-of-week) ----

class CronPattern:
    """Simple 5-field cron parser. Supports:
    - * (any)
    - */N (every N)
    - N (specific)
    - N-M (range)
    - N,M (list)
    """

    FIELD_RANGES = [
        (0, 59),  # minute
        (0, 23),  # hour
        (1, 31),  # day of month
        (1, 12),  # month
        (0, 6),   # day of week (0=Sunday)
    ]

    def __init__(self, expr: str):
        self.expr = expr.strip()
        self.fields = self.expr.split()
        if len(self.fields) != 5:
            raise ValueError(f"Invalid cron expression: {expr} (need 5 fields)")
        self._compiled = [self._parse_field(f, r) for f, r in zip(self.fields, self.FIELD_RANGES)]

    def _parse_field(self, field: str, rng: tuple[int, int]) -> set[int]:
        lo, hi = rng
        result: set[int] = set()
        for part in field.split(","):
            # */N
            m = re.match(r"^\*/(\d+)$", part)
            if m:
                step = int(m.group(1))
                for v in range(lo, hi + 1, step):
                    result.add(v)
                continue
            # * (any)
            if part == "*":
                for v in range(lo, hi + 1):
                    result.add(v)
                continue
            # N-M/S
            m = re.match(r"^(\d+)-(\d+)/(\d+)$", part)
            if m:
                a, b, s = int(m.group(1)), int(m.group(2)), int(m.group(3))
                for v in range(a, b + 1, s):
                    result.add(v)
                continue
            # N-M
            m = re.match(r"^(\d+)-(\d+)$", part)
            if m:
                a, b = int(m.group(1)), int(m.group(2))
                for v in range(a, b + 1):
                    result.add(v)
                continue
            # N/S
            m = re.match(r"^(\d+)/(\d+)$", part)
            if m:
                a, s = int(m.group(1)), int(m.group(2))
                for v in range(a, hi + 1, s):
                    result.add(v)
                continue
            # N
            m = re.match(r"^(\d+)$", part)
            if m:
                v = int(m.group(1))
                if lo <= v <= hi:
                    result.add(v)
                continue
            raise ValueError(f"Invalid cron field: {part}")
        return result

    def matches(self, dt: datetime) -> bool:
        """Check karein ki datetime cron expression se match hota hai ya nahi."""
        vals = [dt.minute, dt.hour, dt.day, dt.month, (dt.weekday() + 1) % 7]
        for compiled, v in zip(self._compiled, vals):
            if v not in compiled:
                return False
        return True

    def next_run(self, from_dt: Optional[datetime] = None) -> datetime:
        """Next matching datetime find karein (best-effort, brute force)."""
        from_dt = from_dt or datetime.now(timezone.utc)
        # Round down to minute
        check = from_dt.replace(second=0, microsecond=0)
        # Add one minute to start
        check = check.replace(minute=check.minute + 1) if check.minute < 59 else check.replace(hour=check.hour + 1, minute=0)
        for _ in range(525600):  # max 1 year
            if self.matches(check):
                return check
            # Increment minute
            check = check.replace(minute=check.minute + 1) if check.minute < 59 else check.replace(hour=check.hour + (1 if check.minute == 59 else 0), minute=0)
        return check


# ---- Scheduler runner ----

async def run_scheduled_action(db: AsyncSession, schedule: Schedule) -> None:
    """Schedule ke action ko execute karein."""
    server_result = await db.execute(select(Server).where(Server.id == schedule.server_id))
    server = server_result.scalar_one_or_none()
    if not server:
        return

    try:
        if schedule.action == ScheduleAction.START.value:
            await start_server(db, server)
        elif schedule.action == ScheduleAction.STOP.value:
            await stop_server(db, server)
        elif schedule.action == ScheduleAction.RESTART.value:
            await restart_server(db, server)
        elif schedule.action == ScheduleAction.KILL.value:
            await kill_server(db, server)
        elif schedule.action == ScheduleAction.COMMAND.value and schedule.command:
            await send_command(db, server, schedule.command)
        # Backup action handled by backup scheduler separately
    except Exception as e:
        await log_action(
            db,
            action="schedule.failed",
            description=f"Schedule '{schedule.name}' failed: {e}",
            server_id=server.id,
        )

    schedule.last_run_at = datetime.now(timezone.utc)
    await db.commit()


async def scheduler_loop() -> None:
    """Main scheduler loop - har minute check karta hai."""
    print("[scheduler] started")
    while True:
        try:
            now = datetime.now(timezone.utc)
            async with async_session_factory() as db:
                result = await db.execute(
                    select(Schedule).where(Schedule.is_enabled == True)  # noqa: E712
                )
                schedules = result.scalars().all()
                for schedule in schedules:
                    try:
                        cron = CronPattern(schedule.cron_expression)
                        if cron.matches(now):
                            await run_scheduled_action(db, schedule)
                            # Update next_run_at
                            schedule.next_run_at = cron.next_run(now)
                            await db.commit()
                    except Exception as e:
                        print(f"[scheduler] error on schedule {schedule.id}: {e}")
        except Exception as e:
            print(f"[scheduler] loop error: {e}")

        # Sleep until next minute boundary
        await asyncio.sleep(60 - datetime.now(timezone.utc).second)
