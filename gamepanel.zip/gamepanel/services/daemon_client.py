"""
services/daemon_client.py - HTTP client for talking to the daemon
Panel yeh client use karke daemon ko server start/stop/file/console commands bhejta hai.
Daemon pure Python hai aur ek FastAPI app expose karta hai.
"""
from __future__ import annotations

import json
from typing import Any, Optional

import httpx

from config import settings


class DaemonClient:
    """Async HTTP client for daemon communication."""

    def __init__(self, host: str, port: int, auth_token: str, timeout: float = 30.0):
        self.base_url = f"http://{host}:{port}"
        self.auth_token = auth_token
        self.timeout = timeout

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.auth_token}",
            "X-Daemon-Token": self.auth_token,
            "Content-Type": "application/json",
        }

    async def _request(
        self,
        method: str,
        path: str,
        json_body: Optional[dict] = None,
        params: Optional[dict] = None,
        timeout: Optional[float] = None,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        async with httpx.AsyncClient(timeout=timeout or self.timeout) as client:
            try:
                resp = await client.request(
                    method=method,
                    url=url,
                    headers=self._headers(),
                    json=json_body,
                    params=params,
                )
                resp.raise_for_status()
                if resp.content:
                    return resp.json()
                return {"success": True}
            except httpx.HTTPStatusError as e:
                # Try parse error message
                try:
                    body = e.response.json()
                    msg = body.get("detail") or body.get("message") or str(e)
                except Exception:
                    msg = str(e)
                raise DaemonError(msg, status_code=e.response.status_code) from e
            except httpx.RequestError as e:
                raise DaemonError(f"Daemon unreachable: {e}", status_code=503) from e

    # ---- Server lifecycle ----

    async def ping(self) -> bool:
        try:
            await self._request("GET", "/health", timeout=5.0)
            return True
        except DaemonError:
            return False

    async def install_server(
        self,
        server_uuid: str,
        server_type: str,
        version: str,
        install_path: str,
        memory_limit: int,
    ) -> dict:
        return await self._request(
            "POST",
            "/servers/install",
            {
                "uuid": server_uuid,
                "type": server_type,
                "version": version,
                "install_path": install_path,
                "memory_limit": memory_limit,
            },
            timeout=300.0,  # install can take a while
        )

    async def start_server(
        self,
        server_uuid: str,
        install_path: str,
        command: str,
        memory_limit: int,
        env: Optional[dict] = None,
    ) -> dict:
        return await self._request(
            "POST",
            f"/servers/{server_uuid}/start",
            {
                "install_path": install_path,
                "command": command,
                "memory_limit": memory_limit,
                "env": env or {},
            },
        )

    async def stop_server(self, server_uuid: str) -> dict:
        return await self._request("POST", f"/servers/{server_uuid}/stop")

    async def restart_server(self, server_uuid: str) -> dict:
        return await self._request("POST", f"/servers/{server_uuid}/restart")

    async def kill_server(self, server_uuid: str) -> dict:
        return await self._request("POST", f"/servers/{server_uuid}/kill")

    async def send_command(self, server_uuid: str, command: str) -> dict:
        return await self._request(
            "POST",
            f"/servers/{server_uuid}/command",
            {"command": command},
        )

    async def get_server_status(self, server_uuid: str) -> dict:
        return await self._request("GET", f"/servers/{server_uuid}/status")

    async def get_server_logs(self, server_uuid: str, lines: int = 200) -> dict:
        return await self._request("GET", f"/servers/{server_uuid}/logs", params={"lines": lines})

    async def get_server_resources(self, server_uuid: str) -> dict:
        return await self._request("GET", f"/servers/{server_uuid}/resources")

    async def delete_server(self, server_uuid: str, install_path: str) -> dict:
        return await self._request(
            "DELETE",
            f"/servers/{server_uuid}",
            {"install_path": install_path},
        )

    # ---- File manager ----

    async def list_files(self, server_uuid: str, path: str = ".") -> dict:
        return await self._request("GET", f"/servers/{server_uuid}/files", params={"path": path})

    async def read_file(self, server_uuid: str, path: str) -> dict:
        return await self._request(
            "GET", f"/servers/{server_uuid}/files/read", params={"path": path}
        )

    async def write_file(self, server_uuid: str, path: str, content: str) -> dict:
        return await self._request(
            "POST",
            f"/servers/{server_uuid}/files/write",
            {"path": path, "content": content},
        )

    async def create_folder(self, server_uuid: str, path: str, name: str) -> dict:
        return await self._request(
            "POST",
            f"/servers/{server_uuid}/files/folder",
            {"path": path, "name": name},
        )

    async def rename_file(self, server_uuid: str, path: str, new_name: str) -> dict:
        return await self._request(
            "POST",
            f"/servers/{server_uuid}/files/rename",
            {"path": path, "new_name": new_name},
        )

    async def move_file(self, server_uuid: str, src: str, dest: str) -> dict:
        return await self._request(
            "POST",
            f"/servers/{server_uuid}/files/move",
            {"src_path": src, "dest_path": dest},
        )

    async def delete_files(self, server_uuid: str, paths: list[str]) -> dict:
        return await self._request(
            "POST",
            f"/servers/{server_uuid}/files/delete",
            {"paths": paths},
        )

    async def upload_file(
        self, server_uuid: str, path: str, file_name: str, content: bytes
    ) -> dict:
        """File upload - multipart bytes bhejta hai."""
        url = f"{self.base_url}/servers/{server_uuid}/files/upload"
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            files = {"file": (file_name, content)}
            data = {"path": path}
            headers = {"Authorization": f"Bearer {self.auth_token}"}
            try:
                resp = await client.post(url, headers=headers, files=files, data=data)
                resp.raise_for_status()
                return resp.json() if resp.content else {"success": True}
            except httpx.HTTPStatusError as e:
                raise DaemonError(str(e), status_code=e.response.status_code) from e
            except httpx.RequestError as e:
                raise DaemonError(f"Daemon unreachable: {e}", status_code=503) from e

    async def download_file(self, server_uuid: str, path: str) -> bytes:
        """File download - raw bytes return karta hai."""
        url = f"{self.base_url}/servers/{server_uuid}/files/download"
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                resp = await client.get(
                    url,
                    headers=self._headers(),
                    params={"path": path},
                )
                resp.raise_for_status()
                return resp.content
            except httpx.HTTPStatusError as e:
                raise DaemonError(str(e), status_code=e.response.status_code) from e
            except httpx.RequestError as e:
                raise DaemonError(f"Daemon unreachable: {e}", status_code=503) from e

    async def archive_files(self, server_uuid: str, action: str, path: str, name: Optional[str] = None) -> dict:
        """action: 'zip' ya 'unzip'"""
        return await self._request(
            "POST",
            f"/servers/{server_uuid}/files/archive",
            {"action": action, "path": path, "name": name},
        )

    async def upload_file_from_url(
        self, server_uuid: str, url: str, path: str = ".", filename: Optional[str] = None
    ) -> dict:
        """URL se file download karke server directory me save karein.
        Background upload option - large files ke liye."""
        return await self._request(
            "POST",
            f"/servers/{server_uuid}/files/upload-url",
            {"url": url, "path": path, "filename": filename},
            timeout=600.0,  # 10 min for large downloads
        )

    async def file_permissions(self, server_uuid: str, path: str) -> dict:
        return await self._request(
            "GET", f"/servers/{server_uuid}/files/permissions", params={"path": path}
        )

    # ---- Backups ----

    async def create_backup(self, server_uuid: str, name: str) -> dict:
        return await self._request(
            "POST", f"/servers/{server_uuid}/backups", {"name": name}
        )

    async def restore_backup(self, server_uuid: str, backup_uuid: str) -> dict:
        return await self._request(
            "POST", f"/servers/{server_uuid}/backups/{backup_uuid}/restore"
        )

    async def delete_backup(self, server_uuid: str, backup_uuid: str) -> dict:
        return await self._request("DELETE", f"/servers/{server_uuid}/backups/{backup_uuid}")

    async def download_backup(self, server_uuid: str, backup_uuid: str) -> bytes:
        url = f"{self.base_url}/servers/{server_uuid}/backups/{backup_uuid}/download"
        async with httpx.AsyncClient(timeout=300.0) as client:
            try:
                resp = await client.get(url, headers=self._headers())
                resp.raise_for_status()
                return resp.content
            except httpx.HTTPStatusError as e:
                raise DaemonError(str(e), status_code=e.response.status_code) from e
            except httpx.RequestError as e:
                raise DaemonError(f"Daemon unreachable: {e}", status_code=503) from e


class DaemonError(Exception):
    def __init__(self, message: str, status_code: int = 500):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
