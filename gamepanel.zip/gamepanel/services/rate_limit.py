"""
services/rate_limit.py - In-memory rate limiter (sliding window)
Production me Redis use karna chahiye, but SQLite/PRoot VPS ke liye in-memory sufficient hai.
"""
from __future__ import annotations

import time
from collections import defaultdict
from threading import Lock
from typing import Dict, List

from fastapi import HTTPException, Request, status


class RateLimiter:
    """Sliding window rate limiter - in-memory."""

    def __init__(self) -> None:
        self._hits: Dict[str, List[float]] = defaultdict(list)
        self._lock = Lock()

    def hit(self, key: str, max_requests: int, window_seconds: int = 60) -> bool:
        """Returns True if allowed, False if rate-limited."""
        now = time.time()
        cutoff = now - window_seconds
        with self._lock:
            # Purge old hits
            self._hits[key] = [t for t in self._hits[key] if t > cutoff]
            if len(self._hits[key]) >= max_requests:
                return False
            self._hits[key].append(now)
            return True

    def client_key(self, request: Request, scope: str) -> str:
        """Client IP + scope based key."""
        # X-Forwarded-For agar proxy ke peeche hai
        forwarded = request.headers.get("X-Forwarded-For", "")
        if forwarded:
            ip = forwarded.split(",")[0].strip()
        else:
            ip = request.client.host if request.client else "unknown"
        return f"{scope}:{ip}"


rate_limiter = RateLimiter()


def rate_limit(scope: str, max_requests: int):
    """FastAPI dependency - rate limit enforce karein."""
    async def _check(request: Request):
        from config import settings
        if not settings.RATE_LIMIT_ENABLED:
            return True
        key = rate_limiter.client_key(request, scope)
        if not rate_limiter.hit(key, max_requests):
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many requests. Please slow down.",
                headers={"Retry-After": "60"},
            )
        return True
    return _check
