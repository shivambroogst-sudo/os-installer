"""
services/template_context.py - Common template context builder
Har template render karne se pehle yeh helper call karke
user, branding, settings, notifications, etc. fetch kar sakte ho.
"""
from __future__ import annotations

from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession

from config import settings
from models import User
from services.settings_service import get_branding
from services.notification_service import get_unread_count


async def build_context(
    db: AsyncSession,
    user: Optional[User] = None,
    request=None,
    **extra,
) -> dict:
    """Standard template context build karein. Request object required for Jinja2."""
    branding = await get_branding(db)
    ctx = {
        "request": request,  # Jinja2Templates ke liye required
        "settings": settings,
        "branding": branding,
        "current_user": user,
        "unread_notifications": 0,
    }
    if user:
        ctx["unread_notifications"] = await get_unread_count(db, user.id)
    ctx.update(extra)
    return ctx
