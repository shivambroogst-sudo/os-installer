"""
services/settings_service.py - System settings (key-value store)
Branding, SMTP, maintenance mode, custom footer, etc. - sab runtime configurable.
"""
from __future__ import annotations

import json
from typing import Any, Optional

from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession

from models import SystemSetting


DEFAULT_SETTINGS: dict[str, dict[str, str]] = {
    "branding": {
        "app_name": "ogultra",
        "logo_url": "",
        "favicon_url": "",
        "custom_footer": "Powered by ogultra",
    },
    "smtp": {
        "smtp_enabled": "false",
        "smtp_host": "",
        "smtp_port": "587",
        "smtp_user": "",
        "smtp_password": "",
        "smtp_from": "noreply@ogultra.local",
        "smtp_tls": "true",
        "smtp_ssl": "false",
    },
    "features": {
        "email_verification_required": "false",
        "password_reset_enabled": "true",
        "maintenance_mode": "false",
        "registration_enabled": "true",
    },
    "limits": {
        "max_servers_per_user": "10",
        "default_memory_mb": "1024",
        "default_disk_mb": "5120",
        "default_cpu_percent": "100",
    },
}


async def get_setting(db: AsyncSession, key: str, category: str = "general") -> Optional[str]:
    """Single setting value fetch karein."""
    result = await db.execute(
        select(SystemSetting).where(
            SystemSetting.key == key,
            SystemSetting.category == category,
        )
    )
    entry = result.scalar_one_or_none()
    return entry.value if entry else None


async def get_category_settings(db: AsyncSession, category: str) -> dict[str, str]:
    """Category ke saare settings fetch karein - defaults ke saath merge."""
    result = await db.execute(
        select(SystemSetting).where(SystemSetting.category == category)
    )
    entries = result.scalars().all()
    settings_dict = {entry.key: entry.value for entry in entries}
    # Merge defaults
    defaults = DEFAULT_SETTINGS.get(category, {})
    return {**defaults, **settings_dict}


async def set_setting(
    db: AsyncSession,
    key: str,
    value: str,
    category: str = "general",
) -> SystemSetting:
    """Setting upsert karein."""
    result = await db.execute(
        select(SystemSetting).where(
            SystemSetting.key == key,
            SystemSetting.category == category,
        )
    )
    entry = result.scalar_one_or_none()
    if entry:
        entry.value = value
    else:
        entry = SystemSetting(key=key, value=value, category=category)
        db.add(entry)
    await db.commit()
    await db.refresh(entry)
    return entry


async def set_category_settings(
    db: AsyncSession,
    category: str,
    settings_dict: dict[str, str],
) -> None:
    """Category ke multiple settings upsert karein."""
    for key, value in settings_dict.items():
        await set_setting(db, key, str(value), category)


async def get_all_settings(db: AsyncSession) -> dict[str, dict[str, str]]:
    """Saare categories fetch karein - defaults ke saath."""
    out: dict[str, dict[str, str]] = {}
    for category in DEFAULT_SETTINGS:
        out[category] = await get_category_settings(db, category)
    return out


async def is_maintenance_mode(db: AsyncSession) -> bool:
    val = await get_setting(db, "maintenance_mode", "features")
    return val == "true"


async def is_registration_enabled(db: AsyncSession) -> bool:
    val = await get_setting(db, "registration_enabled", "features")
    return val != "false"


async def get_branding(db: AsyncSession) -> dict[str, str]:
    return await get_category_settings(db, "branding")
