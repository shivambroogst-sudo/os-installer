"""
services/server_service.py - Server lifecycle orchestration
Panel-level logic: server create/delete, start/stop, expiry check, etc.
Daemon communication yahin se hoti hai.
"""
from __future__ import annotations

import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings, SERVERS_DIR
from models import (
    Allocation,
    AuditLog,
    Node,
    NodeStatus,
    Notification,
    Server,
    ServerStatus,
    ServerType,
    User,
)
from schemas import ServerCreate
from services.daemon_client import DaemonClient, DaemonError


# ---- Daemon client factory ----

def get_daemon_client(node: Node) -> DaemonClient:
    """Node ke liye DaemonClient instance return karein."""
    return DaemonClient(
        host=node.daemon_host,
        port=node.daemon_port,
        auth_token=node.auth_token,
    )


# ---- Server creation ----

DEFAULT_STARTUP_TEMPLATES = {
    ServerType.PAPER.value: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar server.jar nogui",
    ServerType.PURPUR.value: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar purpur.jar nogui",
    ServerType.SPIGOT.value: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar spigot.jar nogui",
    ServerType.VANILLA.value: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar server.jar nogui",
    ServerType.FABRIC.value: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar fabric-server.jar nogui",
    ServerType.FORGE.value: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar forge.jar nogui",
    ServerType.VELOCITY.value: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar velocity.jar",
    ServerType.WATERFALL.value: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar waterfall.jar",
    ServerType.BUNGEECORD.value: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar BungeeCord.jar",
    ServerType.CUSTOM.value: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar server.jar",
}


def default_startup_command(server_type: str) -> str:
    return DEFAULT_STARTUP_TEMPLATES.get(
        server_type, DEFAULT_STARTUP_TEMPLATES[ServerType.CUSTOM.value]
    )


def default_install_path(node: Node, server_uuid: str) -> str:
    """Daemon ke liye install path - relative to daemon's servers dir."""
    return f"/srv/pyropanel/servers/{server_uuid}"


async def allocate_port(db: AsyncSession, node_id: int, preferred_port: Optional[int] = None) -> Allocation:
    """Free port allocate karein node ke liye."""
    # Pehle preferred port try karein
    if preferred_port:
        result = await db.execute(
            select(Allocation).where(
                Allocation.node_id == node_id,
                Allocation.port == preferred_port,
            )
        )
        existing = result.scalar_one_or_none()
        if not existing:
            alloc = Allocation(
                node_id=node_id,
                ip="0.0.0.0",
                port=preferred_port,
                is_primary=True,
                is_assigned=True,
            )
            db.add(alloc)
            await db.flush()
            return alloc

    # Auto-find free port between 25565-25600 ya 10000-10100
    result = await db.execute(
        select(Allocation.port).where(Allocation.node_id == node_id)
    )
    used_ports = {row[0] for row in result.all()}

    # Try Minecraft default range first
    for port in range(25565, 25600):
        if port not in used_ports:
            alloc = Allocation(
                node_id=node_id,
                ip="0.0.0.0",
                port=port,
                is_primary=True,
                is_assigned=True,
            )
            db.add(alloc)
            await db.flush()
            return alloc

    # Fallback to high range
    for port in range(10000, 10100):
        if port not in used_ports:
            alloc = Allocation(
                node_id=node_id,
                ip="0.0.0.0",
                port=port,
                is_primary=True,
                is_assigned=True,
            )
            db.add(alloc)
            await db.flush()
            return alloc

    raise ValueError("No free ports available on this node")


async def create_server(
    db: AsyncSession,
    owner: User,
    payload: ServerCreate,
) -> Server:
    """Naya server create karein - allocation assign karein, install trigger karein."""
    # Node check
    node_result = await db.execute(select(Node).where(Node.id == payload.node_id))
    node = node_result.scalar_one_or_none()
    if not node:
        raise ValueError("Node not found")
    if node.status != NodeStatus.ONLINE.value:
        raise ValueError(f"Node is {node.status}, cannot create server")

    # Resource check
    if node.memory_free < payload.memory_limit:
        raise ValueError("Node does not have enough free memory")
    if node.disk_free < payload.disk_limit:
        raise ValueError("Node does not have enough free disk")

    # Allocation
    allocation = await allocate_port(db, node.id)

    # Expiry
    expires_at = None
    if payload.expires_in_days:
        expires_at = datetime.now(timezone.utc) + timedelta(days=payload.expires_in_days)

    # Startup command
    startup_command = payload.startup_command or default_startup_command(payload.server_type)
    java_arguments = payload.java_arguments or f"-Xms128M -Xmx{{SERVER_MEMORY}}M"

    server = Server(
        name=payload.name,
        description=payload.description,
        owner_id=owner.id,
        node_id=node.id,
        allocation_id=allocation.id,
        server_type=payload.server_type,
        version=payload.version,
        status=ServerStatus.INSTALLING.value,
        memory_limit=payload.memory_limit,
        disk_limit=payload.disk_limit,
        cpu_limit=payload.cpu_limit,
        startup_command=startup_command,
        java_arguments=java_arguments,
        auto_restart=payload.auto_restart,
        auto_startup=payload.auto_startup,
        expires_at=expires_at,
        install_path=default_install_path(node, secrets.token_hex(8)),
    )
    # Override uuid ke saath install_path set karna
    server.uuid = secrets.token_hex(16)
    server.install_path = f"/srv/pyropanel/servers/{server.uuid}"

    db.add(server)
    await db.flush()
    allocation.server_id = server.id

    # Audit log
    audit = AuditLog(
        user_id=owner.id,
        server_id=server.id,
        action="server.create",
        resource_type="server",
        resource_id=server.id,
        description=f"Created server '{server.name}' ({server.server_type}/{server.version}) on node '{node.name}'",
        metadata_json={"node_id": node.id, "type": server.server_type, "version": server.version},
    )
    db.add(audit)

    # Notification
    notif = Notification(
        user_id=owner.id,
        title="Server Created",
        message=f"Your server '{server.name}' is being installed on {node.name}.",
        level="info",
        link=f"/servers/{server.uuid}",
    )
    db.add(notif)
    await db.commit()
    await db.refresh(server)

    return server


async def trigger_install(db: AsyncSession, server: Server) -> None:
    """Daemon pe install trigger karein (best-effort, async)."""
    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one_or_none()
    if not node:
        return

    client = get_daemon_client(node)
    try:
        await client.install_server(
            server_uuid=server.uuid,
            server_type=server.server_type,
            version=server.version,
            install_path=server.install_path,
            memory_limit=server.memory_limit,
        )
        server.status = ServerStatus.INSTALLED.value
    except DaemonError as e:
        server.status = ServerStatus.FAILED.value
        await _notify_server_event(
            db, server, "Install Failed", f"Failed to install server: {e.message}", level="error"
        )
    await db.commit()


async def start_server(db: AsyncSession, server: Server) -> dict:
    """Server start karne ke liye daemon ko command bheje."""
    if server.status == ServerStatus.RUNNING.value:
        return {"status": "already_running"}
    if server.is_suspended:
        raise ValueError("Server is suspended")
    if server.is_expired:
        raise ValueError("Server has expired")

    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)

    # Build env with server variables
    env = {
        "SERVER_MEMORY": str(server.memory_limit),
        "SERVER_PORT": str(server.allocation.port if server.allocation else 25565),
        "SERVER_IP": server.allocation.ip if server.allocation else "0.0.0.0",
    }
    # User variables
    if server.startup_variables:
        for k, v in server.startup_variables.items():
            env[str(k)] = str(v)

    # Render startup command
    command = _render_template(server.startup_command, env)
    java_args = _render_template(server.java_arguments, env)
    full_command = f"{java_args} {command}".strip()

    try:
        result = await client.start_server(
            server_uuid=server.uuid,
            install_path=server.install_path,
            command=full_command,
            memory_limit=server.memory_limit,
            env=env,
        )
        server.status = ServerStatus.RUNNING.value
        server.last_started_at = datetime.now(timezone.utc)
        server.pid = result.get("pid")
        await db.commit()
        return result
    except DaemonError as e:
        server.status = ServerStatus.FAILED.value
        await db.commit()
        raise


async def stop_server(db: AsyncSession, server: Server) -> dict:
    """Server ko gracefully stop karne ke liye daemon ko command bheje."""
    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        result = await client.stop_server(server.uuid)
        server.status = ServerStatus.STOPPED.value
        server.last_stopped_at = datetime.now(timezone.utc)
        server.pid = None
        await db.commit()
        return result
    except DaemonError as e:
        # Force kill fallback
        if e.status_code == 503:
            raise
        await kill_server(db, server)
        return {"status": "killed"}


async def restart_server(db: AsyncSession, server: Server) -> dict:
    """Server restart karein."""
    try:
        await stop_server(db, server)
    except Exception:
        pass
    return await start_server(db, server)


async def kill_server(db: AsyncSession, server: Server) -> dict:
    """Server process ko forcefully kill karein."""
    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    try:
        result = await client.kill_server(server.uuid)
    except DaemonError:
        result = {"status": "error"}
    server.status = ServerStatus.STOPPED.value
    server.last_stopped_at = datetime.now(timezone.utc)
    server.pid = None
    await db.commit()
    return result


async def send_command(db: AsyncSession, server: Server, command: str) -> dict:
    """Server console me command bheje."""
    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)
    return await client.send_command(server.uuid, command)


async def delete_server(db: AsyncSession, server: Server) -> None:
    """Server delete karein - daemon pe files delete, db se record hata do."""
    node_result = await db.execute(select(Node).where(Node.id == server.node_id))
    node = node_result.scalar_one()
    client = get_daemon_client(node)

    # Stop if running
    if server.status == ServerStatus.RUNNING.value:
        try:
            await client.kill_server(server.uuid)
        except DaemonError:
            pass

    # Delete files on daemon
    try:
        await client.delete_server(server.uuid, server.install_path)
    except DaemonError:
        pass  # files may already be gone

    # Free allocation
    if server.allocation:
        server.allocation.server_id = None
        server.allocation.is_assigned = False

    # Audit
    audit = AuditLog(
        user_id=server.owner_id,
        server_id=server.id,
        action="server.delete",
        resource_type="server",
        resource_id=server.id,
        description=f"Deleted server '{server.name}'",
    )
    db.add(audit)
    await db.delete(server)
    await db.commit()


async def suspend_server(db: AsyncSession, server: Server, reason: Optional[str] = None) -> None:
    """Server suspend karein - stop karke suspended flag set karein."""
    if server.status == ServerStatus.RUNNING.value:
        try:
            await stop_server(db, server)
        except Exception:
            pass
    server.is_suspended = True
    server.suspension_reason = reason
    server.status = ServerStatus.SUSPENDED.value
    audit = AuditLog(
        user_id=server.owner_id,
        server_id=server.id,
        action="server.suspend",
        description=f"Suspended server '{server.name}': {reason or 'no reason'}",
    )
    db.add(audit)
    await _notify_server_event(
        db, server, "Server Suspended", f"Your server '{server.name}' has been suspended.", level="warning"
    )
    await db.commit()


async def unsuspend_server(db: AsyncSession, server: Server) -> None:
    """Server unsuspend karein."""
    server.is_suspended = False
    server.suspension_reason = None
    server.status = ServerStatus.STOPPED.value
    audit = AuditLog(
        user_id=server.owner_id,
        server_id=server.id,
        action="server.unsuspend",
        description=f"Unsuspended server '{server.name}'",
    )
    db.add(audit)
    await _notify_server_event(
        db, server, "Server Unsuspended", f"Your server '{server.name}' has been unsuspended.", level="success"
    )
    await db.commit()


async def reinstall_server(db: AsyncSession, server: Server) -> None:
    """Server reinstall karein."""
    server.status = ServerStatus.INSTALLING.value
    audit = AuditLog(
        user_id=server.owner_id,
        server_id=server.id,
        action="server.reinstall",
        description=f"Reinstalling server '{server.name}'",
    )
    db.add(audit)
    await db.commit()
    await trigger_install(db, server)


async def check_expired_servers(db: AsyncSession) -> int:
    """Expired servers ko suspend karein. Returns count."""
    result = await db.execute(
        select(Server).where(
            Server.expires_at.is_not(None),
            Server.expires_at < datetime.now(timezone.utc),
            Server.is_suspended == False,  # noqa: E712
        )
    )
    servers = result.scalars().all()
    count = 0
    for server in servers:
        await suspend_server(db, server, reason="Server expired")
        count += 1
    return count


# ---- Helpers ----

def _render_template(text: str, variables: dict) -> str:
    """Simple {{VAR}} template rendering."""
    out = text
    for k, v in variables.items():
        out = out.replace(f"{{{{{k}}}}}", str(v))
    return out


async def _notify_server_event(
    db: AsyncSession,
    server: Server,
    title: str,
    message: str,
    level: str = "info",
) -> None:
    notif = Notification(
        user_id=server.owner_id,
        title=title,
        message=message,
        level=level,
        link=f"/servers/{server.uuid}",
    )
    db.add(notif)
