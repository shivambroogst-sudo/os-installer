"""
services/email_service.py - Optional SMTP email sender
Email verification, password reset emails bhejta hai.
Agar SMTP disabled hai to skip kar deta hai.
"""
from __future__ import annotations

import asyncio
import smtplib
import ssl
from email.message import EmailMessage
from email.utils import formataddr
from typing import Optional

from config import settings


class EmailService:
    def __init__(self) -> None:
        self.enabled = settings.SMTP_ENABLED
        self.host = settings.SMTP_HOST
        self.port = settings.SMTP_PORT
        self.user = settings.SMTP_USER
        self.password = settings.SMTP_PASSWORD
        self.from_addr = settings.SMTP_FROM
        self.use_tls = settings.SMTP_TLS
        self.use_ssl = settings.SMTP_SSL

    async def send_email(
        self,
        to_email: str,
        subject: str,
        body: str,
        html: Optional[str] = None,
    ) -> bool:
        """Email bheje. SMTP disabled hai to False return kare."""
        if not self.enabled:
            return False

        # Offload to thread - smtplib sync hai
        loop = asyncio.get_event_loop()
        try:
            return await loop.run_in_executor(
                None, self._send_sync, to_email, subject, body, html
            )
        except Exception as e:
            print(f"[email] Failed to send to {to_email}: {e}")
            return False

    def _send_sync(
        self,
        to_email: str,
        subject: str,
        body: str,
        html: Optional[str] = None,
    ) -> bool:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = formataddr((settings.APP_NAME, self.from_addr))
        msg["To"] = to_email
        msg.set_content(body)
        if html:
            msg.add_alternative(html, subtype="html")

        try:
            if self.use_ssl:
                context = ssl.create_default_context()
                with smtplib.SMTP_SSL(self.host, self.port, context=context, timeout=30) as server:
                    if self.user:
                        server.login(self.user, self.password)
                    server.send_message(msg)
            else:
                with smtplib.SMTP(self.host, self.port, timeout=30) as server:
                    server.ehlo()
                    if self.use_tls:
                        server.starttls(context=ssl.create_default_context())
                        server.ehlo()
                    if self.user:
                        server.login(self.user, self.password)
                    server.send_message(msg)
            return True
        except Exception as e:
            print(f"[email] SMTP send error: {e}")
            return False

    async def send_verification_email(self, to_email: str, token: str, username: str) -> bool:
        verify_url = f"{settings.APP_URL}/auth/verify-email?token={token}"
        body = f"""
Hello {username},

Please verify your email address by clicking the link below:

{verify_url}

This link will expire in 24 hours.

If you did not create this account, please ignore this email.

--
{settings.APP_NAME}
"""
        html = f"""
<html><body style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">
<h2 style="color:#4f46e5;">{settings.APP_NAME}</h2>
<p>Hello <strong>{username}</strong>,</p>
<p>Please verify your email address by clicking the button below:</p>
<p style="margin:24px 0;">
  <a href="{verify_url}" style="background:#4f46e5;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;">Verify Email</a>
</p>
<p style="color:#6b7280;font-size:12px;">This link will expire in 24 hours. If you did not create this account, ignore this email.</p>
<hr style="border:0;border-top:1px solid #e5e7eb;margin:24px 0;">
<p style="color:#9ca3af;font-size:12px;">{settings.APP_NAME}</p>
</body></html>
"""
        return await self.send_email(to_email, f"Verify your email - {settings.APP_NAME}", body, html)

    async def send_password_reset_email(self, to_email: str, token: str, username: str) -> bool:
        reset_url = f"{settings.APP_URL}/auth/reset-password?token={token}"
        body = f"""
Hello {username},

We received a request to reset your password. Click the link below to set a new password:

{reset_url}

This link will expire in 1 hour.

If you did not request a password reset, please ignore this email.

--
{settings.APP_NAME}
"""
        html = f"""
<html><body style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">
<h2 style="color:#4f46e5;">{settings.APP_NAME}</h2>
<p>Hello <strong>{username}</strong>,</p>
<p>We received a request to reset your password. Click below to set a new password:</p>
<p style="margin:24px 0;">
  <a href="{reset_url}" style="background:#4f46e5;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;">Reset Password</a>
</p>
<p style="color:#6b7280;font-size:12px;">This link will expire in 1 hour. If you did not request a reset, ignore this email.</p>
<hr style="border:0;border-top:1px solid #e5e7eb;margin:24px 0;">
<p style="color:#9ca3af;font-size:12px;">{settings.APP_NAME}</p>
</body></html>
"""
        return await self.send_email(to_email, f"Reset your password - {settings.APP_NAME}", body, html)


email_service = EmailService()
