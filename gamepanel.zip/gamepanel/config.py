"""
config.py - Application configuration loader
Environment variables se ya .env file se config load karta hai.
Production me .env use karein, PRoot VPS pe defaults bhi kaam karenge.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import List, Optional

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


BASE_DIR: Path = Path(__file__).resolve().parent
DATA_DIR: Path = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

SERVERS_DIR: Path = BASE_DIR / "servers_data"
SERVERS_DIR.mkdir(parents=True, exist_ok=True)

BACKUPS_DIR: Path = BASE_DIR / "backups"
BACKUPS_DIR.mkdir(parents=True, exist_ok=True)

UPLOADS_DIR: Path = BASE_DIR / "uploads"
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

LOGS_DIR: Path = BASE_DIR / "logs"
LOGS_DIR.mkdir(parents=True, exist_ok=True)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # --- App ---
    APP_NAME: str = "ogultra"
    APP_ENV: str = "production"  # development | production
    APP_URL: str = "http://localhost:8000"
    APP_TIMEZONE: str = "Asia/Kolkata"
    APP_LANGUAGE: str = "en"
    MAINTENANCE_MODE: bool = False
    CUSTOM_FOOTER: str = ""

    # --- Security ---
    SECRET_KEY: str = "change-me-in-production-please-32-chars-minimum"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days
    SESSION_COOKIE_NAME: str = "pyropanel_session"
    CSRF_COOKIE_NAME: str = "pyropanel_csrf"
    Argon2_TIME_COST: int = 3
    Argon2_MEMORY_COST: int = 65536
    Argon2_PARALLELISM: int = 2

    # --- Database ---
    # SQLite default; agar DATABASE_URL set hai (postgres://...) to wo use hoga
    # SQLite absolute path ke liye 4 slashes chahiye: sqlite:////absolute/path/db.sqlite
    DATABASE_URL: str = f"sqlite:///{(DATA_DIR / 'pyropanel.db').as_posix()}"

    # --- Daemon ---
    DAEMON_HOST: str = "0.0.0.0"
    DAEMON_PORT: int = 8081
    DAEMON_API_KEY: str = "change-me-daemon-key"
    DAEMON_TOKEN: str = "daemon-shared-secret-change-me"

    # --- Panel -> Daemon communication ---
    PANEL_DAEMON_TOKEN: str = "daemon-shared-secret-change-me"

    # --- SMTP (optional) ---
    SMTP_ENABLED: bool = False
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM: str = "noreply@ogultra.local"
    SMTP_TLS: bool = True
    SMTP_SSL: bool = False

    # --- Email verification ---
    EMAIL_VERIFICATION_REQUIRED: bool = False
    PASSWORD_RESET_ENABLED: bool = True

    # --- Rate Limiting ---
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_LOGIN_PER_MINUTE: int = 10
    RATE_LIMIT_API_PER_MINUTE: int = 120

    # --- Backups ---
    MAX_BACKUPS_PER_SERVER: int = 10
    AUTO_BACKUP_RETENTION_DAYS: int = 7

    # --- Servers ---
    DEFAULT_MEMORY_MB: int = 1024
    DEFAULT_DISK_MB: int = 5120
    DEFAULT_CPU_PERCENT: int = 100
    SERVER_LOG_LINES_TAIL: int = 500

    # --- Allowed Origins (comma separated) ---
    CORS_ORIGINS: str = "*"

    @field_validator("SECRET_KEY")
    @classmethod
    def _validate_secret(cls, v: str) -> str:
        if len(v) < 16:
            raise ValueError("SECRET_KEY kam se kam 16 characters ka hona chahiye")
        return v

    @property
    def cors_origins_list(self) -> List[str]:
        if self.CORS_ORIGINS == "*":
            return ["*"]
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


settings = Settings()

# Common path constants
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"
