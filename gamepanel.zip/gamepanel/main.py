"""
main.py - ogultra main FastAPI application
Saare routers mount karta hai, middleware set karta hai,
scheduler aur expiry checker background tasks start karta hai.
"""
from __future__ import annotations

import asyncio
import os
import sys
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, Request, Response
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.sessions import SessionMiddleware

from config import settings, TEMPLATES_DIR, STATIC_DIR, BASE_DIR
from database import init_db, async_session_factory
from models import User, UserRole
from auth import (
    get_current_user_optional,
    verify_csrf,
    verify_csrf_async,
    set_csrf_cookie,
    create_csrf_token,
)
from templates_setup import templates
from services.template_context import build_context
from services.settings_service import (
    is_maintenance_mode,
    get_branding,
    is_registration_enabled,
)
from services.scheduler_service import scheduler_loop
from services.server_service import check_expired_servers
from services.rate_limit import rate_limiter


# ---- Init superadmin on first run ----

async def ensure_superadmin() -> None:
    """Pehli launch pe ek superadmin create karein agar koi user nahi hai."""
    from sqlalchemy import select, func
    from models import User, UserRole
    from security import hash_password

    async with async_session_factory() as db:
        count = (await db.execute(select(func.count(User.id)))).scalar_one()
        if count == 0:
            admin = User(
                username="admin",
                email="admin@ogultra.local",
                password_hash=hash_password("admin12345"),
                role=UserRole.SUPERADMIN.value,
                is_active=True,
                is_email_verified=True,
            )
            db.add(admin)
            await db.commit()
            print("=" * 60)
            print("  Default superadmin created:")
            print("    Username: admin")
            print("    Password: admin12345")
            print("  CHANGE THIS PASSWORD IMMEDIATELY!")
            print("=" * 60)


# ---- Maintenance middleware ----

class MaintenanceMiddleware(BaseHTTPMiddleware):
    """Maintenance mode active ho to sirf admin ko allow karein."""

    EXEMPT_PATHS = (
        "/auth/login", "/auth/logout", "/static", "/api/v1",
        "/health", "/favicon.ico",
    )

    async def dispatch(self, request: Request, call_next):
        # Skip exempt paths
        path = request.url.path
        if any(path.startswith(p) for p in self.EXEMPT_PATHS):
            return await call_next(request)

        # Check maintenance mode
        async with async_session_factory() as db:
            is_maint = await is_maintenance_mode(db)

        if not is_maint:
            return await call_next(request)

        # Allow admin users
        user = await get_current_user_optional(request, Depends())
        if user and user.is_admin:
            return await call_next(request)

        # Show maintenance page
        if "application/json" in request.headers.get("accept", ""):
            return JSONResponse(
                status_code=503,
                content={"detail": "System under maintenance. Please try again later."},
            )
        templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
        async with async_session_factory() as db:
            branding = await get_branding(db)
        return templates.TemplateResponse(
            "errors/maintenance.html",
            {"request": request, "branding": branding, "settings": settings},
            status_code=503,
        )


# ---- CSRF middleware ----

class CsrfMiddleware(BaseHTTPMiddleware):
    """State-changing requests pe CSRF check karein.
    Auth paths (login/register/reset) exempt hain kyunki wahan user
    unauthenticated hota hai aur session cookie set nahi hoti.
    Form data se bhi csrf_token field read karta hai."""

    EXEMPT_PATHS = (
        "/auth/login", "/auth/register", "/auth/reset-password",
        "/auth/verify-email", "/auth/logout",
    )

    async def dispatch(self, request: Request, call_next):
        if request.method not in ("POST", "PUT", "PATCH", "DELETE"):
            return await call_next(request)

        path = request.url.path
        # Skip exempt paths
        if any(path == p or path.startswith(p + "/") for p in self.EXEMPT_PATHS):
            return await call_next(request)
        # Skip API requests with Bearer token (separate auth)
        if request.headers.get("Authorization", "").startswith("Bearer "):
            return await call_next(request)

        # CSRF check - read body once, cache it for downstream
        try:
            # Read body bytes once
            body_bytes = await request.body()
            # Re-inject body so downstream handlers can read it again
            async def receive():
                return {"type": "http.request", "body": body_bytes, "more_body": False}
            request._receive = receive

            # Now check CSRF
            await verify_csrf_async(request)
        except Exception as e:
            detail = getattr(e, "detail", str(e))
            return JSONResponse(
                status_code=403,
                content={"detail": detail},
            )
        return await call_next(request)


class EnsureCsrfCookieMiddleware(BaseHTTPMiddleware):
    """Har GET request pe CSRF cookie set karein agar nahi hai.
    Taaki jab user form submit kare to cookie available ho."""

    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        # Sirf GET requests pe set karein (POST ko already exempt kiya)
        if request.method == "GET":
            cookie_token = request.cookies.get(settings.CSRF_COOKIE_NAME)
            if not cookie_token:
                # Naya CSRF token set karein response me
                token = create_csrf_token()
                response.set_cookie(
                    key=settings.CSRF_COOKIE_NAME,
                    value=token,
                    httponly=False,
                    secure=settings.APP_ENV == "production",
                    samesite="lax",
                    max_age=settings.JWT_EXPIRE_MINUTES * 60,
                    path="/",
                )
        return response


# ---- Background tasks ----

async def background_tasks_loop():
    """Background loop - har 5 minute me:
    - Expired servers suspend karein
    - Old rate limit entries purge karein
    """
    print("[background] started expiry/rate-limit cleanup loop")
    while True:
        try:
            async with async_session_factory() as db:
                count = await check_expired_servers(db)
                if count > 0:
                    print(f"[background] suspended {count} expired servers")
        except Exception as e:
            print(f"[background] expiry check error: {e}")

        await asyncio.sleep(300)  # 5 minutes


# ---- Lifespan ----

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    print("[panel] starting ogultra...")
    await init_db()
    await ensure_superadmin()

    # Ensure default eggs exist
    from services.egg_service import ensure_default_eggs
    async with async_session_factory() as db:
        egg_count = await ensure_default_eggs(db)
    if egg_count > 0:
        print(f"[panel] Created {egg_count} default eggs")

    # Start scheduler
    scheduler_task = asyncio.create_task(scheduler_loop())
    bg_task = asyncio.create_task(background_tasks_loop())

    print("[panel] ogultra ready")
    yield

    # Shutdown
    scheduler_task.cancel()
    bg_task.cancel()
    print("[panel] shutdown complete")


# ---- FastAPI app ----

app = FastAPI(
    title=settings.APP_NAME,
    description="Production-ready Python game hosting panel - no Docker required.",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)


# ---- Middleware ----

app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(SessionMiddleware, secret_key=settings.SECRET_KEY, max_age=86400)
app.add_middleware(CsrfMiddleware)
app.add_middleware(EnsureCsrfCookieMiddleware)
app.add_middleware(MaintenanceMiddleware)


# ---- CORS (for API) ----

from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---- Static files ----

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


# ---- Templates ----
# templates instance templates_setup.py se aata hai (with custom filters)


# ---- Register routers ----

from routers.auth import router as auth_router
from routers.dashboard import router as dashboard_router
from routers.servers import router as servers_router
from routers.console import router as console_router
from routers.files import router as files_router
from routers.backups import router as backups_router
from routers.scheduler import router as scheduler_router
from routers.nodes import router as nodes_router
from routers.admin import router as admin_router
from routers.user_settings import router as user_settings_router
from routers.api import router as api_router
from routers.eggs import router as eggs_router

app.include_router(auth_router)
app.include_router(dashboard_router)
app.include_router(servers_router)
app.include_router(console_router)
app.include_router(files_router)
app.include_router(backups_router)
app.include_router(scheduler_router)
app.include_router(nodes_router)
app.include_router(admin_router)
app.include_router(user_settings_router)
app.include_router(api_router)
app.include_router(eggs_router)


# ---- Root ----

@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    """Root - login ya dashboard pe redirect."""
    user = await get_current_user_optional(request, Depends())
    if user:
        return RedirectResponse(url="/dashboard", status_code=303)
    return RedirectResponse(url="/auth/login", status_code=303)


# ---- Health ----

@app.get("/health")
async def health():
    return {"status": "ok", "service": "panel", "version": "1.0.0"}


# ---- Error handlers ----

async def _get_user_from_request(request: Request) -> Optional[User]:
    """Error handlers ke liye - user fetch karein without Depends()."""
    from security import decode_token
    from sqlalchemy import select as sa_select
    token = request.cookies.get(settings.SESSION_COOKIE_NAME)
    auth_header = request.headers.get("Authorization", "")
    if not token and auth_header.startswith("Bearer "):
        token = auth_header[7:]
    if not token:
        return None
    payload = decode_token(token)
    if not payload or payload.get("type") != "access":
        return None
    user_id_str = payload.get("sub")
    if not user_id_str:
        return None
    try:
        user_id = int(user_id_str)
    except (ValueError, TypeError):
        return None
    async with async_session_factory() as db:
        result = await db.execute(sa_select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        return user


@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    if "application/json" in request.headers.get("accept", ""):
        return JSONResponse(status_code=404, content={"detail": "Not found"})
    user = await _get_user_from_request(request)
    async with async_session_factory() as db:
        ctx = await build_context(db, user, request=request)
    return templates.TemplateResponse("errors/404.html", ctx, status_code=404)


@app.exception_handler(500)
async def server_error_handler(request: Request, exc):
    import traceback
    print(f"[error] 500: {exc}\n{traceback.format_exc()}")
    if "application/json" in request.headers.get("accept", ""):
        return JSONResponse(status_code=500, content={"detail": "Internal server error"})
    user = await _get_user_from_request(request)
    async with async_session_factory() as db:
        ctx = await build_context(db, user, request=request, error=str(exc))
    return templates.TemplateResponse("errors/500.html", ctx, status_code=500)


# ---- Run ----

if __name__ == "__main__":
    import uvicorn

    host = os.environ.get("PANEL_HOST", "0.0.0.0")
    port = int(os.environ.get("PANEL_PORT", 8000))

    print(f"""
╔══════════════════════════════════════════════════╗
║   ogultra - Python Game Hosting Panel         ║
║   Panel running on http://{host}:{port:<23} ║
║   Docs: http://{host}:{port}/api/docs              ║
║                                                  ║
║   Default login: admin / admin12345              ║
╚══════════════════════════════════════════════════╝
""")
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=settings.APP_ENV == "development",
        log_level="info",
    )
