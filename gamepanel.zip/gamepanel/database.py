"""
database.py - SQLAlchemy async engine + session factory
SQLite aur PostgreSQL dono support karta hai.
"""
from __future__ import annotations

from typing import AsyncGenerator

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from config import settings


def _build_engine_url(url: str) -> str:
    """SQLite URL ko async driver ke saath convert karein.
    PostgreSQL URL ko asyncpg ke saath convert karein."""
    if url.startswith("sqlite://"):
        return url.replace("sqlite://", "sqlite+aiosqlite://", 1)
    if url.startswith("postgresql://"):
        return url.replace("postgresql://", "postgresql+asyncpg://", 1)
    if url.startswith("postgres://"):
        return url.replace("postgres://", "postgresql+asyncpg://", 1)
    return url


DB_URL = _build_engine_url(settings.DATABASE_URL)

engine = create_async_engine(
    DB_URL,
    echo=False,  # SQL logging disabled for production performance
    future=True,
    pool_pre_ping=True,
)

async_session_factory = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
)


class Base(DeclarativeBase):
    """Declarative base saare models ke liye."""
    pass


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency - async DB session deta hai."""
    async with async_session_factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def init_db() -> None:
    """Database tables create karein (startup pe call hota hai)."""
    # Import models taaki Base.metadata me register ho jayein
    import models  # noqa: F401

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
