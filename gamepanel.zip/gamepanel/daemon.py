"""
daemon.py - Pure Python server daemon
- Docker bilkul use nahi karta
- subprocess.Popen() se servers run karta hai
- Ubuntu 20/22 PRoot VPS ke saath compatible
- Live console + logs + resource usage
- Automatic process monitoring
- FastAPI app expose karta hai panel ke liye

Run karna:
    python daemon.py --host 0.0.0.0 --port 8081 --token your-secret

Panel ke saath integration:
    - POST /servers/install      -> server install karein
    - POST /servers/{uuid}/start -> server start karein
    - POST /servers/{uuid}/stop  -> graceful stop (SIGTERM)
    - POST /servers/{uuid}/kill  -> force kill (SIGKILL)
    - POST /servers/{uuid}/command -> console me command bheje
    - GET  /servers/{uuid}/status -> pid + running state
    - GET  /servers/{uuid}/logs   -> last N log lines
    - GET  /servers/{uuid}/resources -> CPU/memory usage
    - WS   /servers/{uuid}/ws    -> live console stream
    - GET  /servers/{uuid}/files -> file listing
    - POST /servers/{uuid}/files/write -> write file content
    - POST /servers/{uuid}/files/upload -> upload file (multipart)
    - GET  /servers/{uuid}/files/download -> download file
    - POST /servers/{uuid}/files/archive -> zip/unzip
    - POST /servers/{uuid}/backups -> create backup
    - POST /servers/{uuid}/backups/{id}/restore -> restore
    - DELETE /servers/{uuid}/backups/{id} -> delete backup
    - GET  /servers/{uuid}/backups/{id}/download -> download backup
    - GET  /health -> health check
    - POST /heartbeat -> panel ko heartbeat bhejne ke liye (optional)
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import platform
import pwd
import resource
import shutil
import signal
import stat
import subprocess
import sys
import threading
import time
import uuid as uuidlib
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import psutil
import uvicorn
from fastapi import (
    Depends,
    FastAPI,
    File,
    Form,
    HTTPException,
    Header,
    Request,
    UploadFile,
    WebSocket,
    WebSocketDisconnect,
    status,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel


# ---- Constants ----

BASE_DIR = Path(__file__).resolve().parent
SERVERS_DIR = BASE_DIR / "servers_data"
SERVERS_DIR.mkdir(parents=True, exist_ok=True)
BACKUPS_DIR = BASE_DIR / "backups"
BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR = BASE_DIR / "logs"
LOGS_DIR.mkdir(parents=True, exist_ok=True)

MAX_LOG_BUFFER = 5000  # lines per server
HEARTBEAT_INTERVAL = 30  # seconds


# ---- Server process manager ----

class ServerProcess:
    """Single server process ka manager - subprocess.Popen ke around."""

    def __init__(self, server_uuid: str, install_path: Path):
        self.uuid = server_uuid
        self.install_path = install_path
        self.process: Optional[subprocess.Popen] = None
        self.log_buffer: deque[str] = deque(maxlen=MAX_LOG_BUFFER)
        self.log_file: Optional[Path] = None
        self.log_fp = None
        self.command: str = ""
        self.env: dict[str, str] = {}
        self.start_time: Optional[float] = None
        self.crash_count: int = 0
        self.auto_restart: bool = True
        self._ws_clients: list[WebSocket] = []
        self._reader_thread: Optional[threading.Thread] = None
        self._monitor_thread: Optional[threading.Thread] = None
        self._stopping = False

    def _setup_logfile(self) -> None:
        """Server ke liye log file open karein."""
        log_dir = LOGS_DIR / self.uuid
        log_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = log_dir / f"{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.log"
        self.log_fp = open(self.log_file, "a", encoding="utf-8", buffering=1)

    def _close_logfile(self) -> None:
        if self.log_fp:
            try:
                self.log_fp.close()
            except Exception:
                pass
            self.log_fp = None

    def _append_log(self, line: str) -> None:
        """Log line buffer + file + websocket clients ko bheje."""
        self.log_buffer.append(line)
        if self.log_fp:
            try:
                self.log_fp.write(line + "\n")
            except Exception:
                pass
        # Broadcast to websocket clients
        for ws in list(self._ws_clients):
            try:
                # asyncio run - we're in sync thread, so use run_coroutine_threadsafe
                if ws.application_state == 1:  # CONNECTED
                    asyncio.run_coroutine_threadsafe(
                        ws.send_text(line), self._loop
                    )
            except Exception:
                pass

    def _reader_loop(self) -> None:
        """Background thread - process stdout/stderr ko padhe aur buffer me daale."""
        if not self.process:
            return
        try:
            while True:
                line = self.process.stdout.readline()
                if not line:
                    if self.process.poll() is not None:
                        break
                    continue
                # Decode + strip
                try:
                    decoded = line.decode("utf-8", errors="replace").rstrip("\r\n")
                except Exception:
                    decoded = str(line)
                self._append_log(decoded)
        except Exception as e:
            self._append_log(f"[daemon] reader error: {e}")
        finally:
            # Process exited
            exit_code = self.process.poll() if self.process else -1
            self._append_log(f"[daemon] process exited with code {exit_code}")

    def _monitor_loop(self) -> None:
        """Background thread - process crash detect karein aur auto-restart karein."""
        if not self.process:
            return
        # Wait for process to exit
        while self.process and self.process.poll() is None:
            time.sleep(2)
        if self._stopping:
            return  # intentional stop
        # Crashed
        self.crash_count += 1
        if self.auto_restart and self.crash_count < 5:
            self._append_log(f"[daemon] auto-restarting (crash #{self.crash_count}) in 5 seconds...")
            time.sleep(5)
            try:
                self._start_internal()
            except Exception as e:
                self._append_log(f"[daemon] auto-restart failed: {e}")

    def _start_internal(self) -> None:
        """Internal start - actually spawn the process."""
        self._setup_logfile()
        self._append_log(f"[daemon] starting: {self.command}")

        # Build shell command
        full_cmd = self.command
        # Use shlex for safety
        import shlex
        args = shlex.split(full_cmd)

        # Pre-exec for resource limits (best-effort on PRoot)
        def _set_limits():
            try:
                # Memory limit (RLIMIT_AS) - approximate
                if self.env.get("SERVER_MEMORY"):
                    mem_bytes = int(self.env["SERVER_MEMORY"]) * 1024 * 1024
                    # Soft + hard limit
                    resource.setrlimit(resource.RLIMIT_AS, (mem_bytes, mem_bytes))
            except Exception:
                pass  # PRoot me may fail silently
            # CPU niceness for soft CPU limit
            try:
                os.nice(5)
            except Exception:
                pass

        self.process = subprocess.Popen(
            args,
            cwd=str(self.install_path),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.PIPE,
            env={**os.environ, **self.env},
            preexec_fn=_set_limits if platform.system() == "Linux" else None,
            start_new_session=True,  # so we can kill the whole process group
        )
        self.start_time = time.time()
        self._stopping = False

        # Start reader + monitor threads
        self._reader_thread = threading.Thread(target=self._reader_loop, daemon=True)
        self._reader_thread.start()
        self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()

    def start(self, command: str, env: dict[str, str], auto_restart: bool = True) -> int:
        """Server start karein."""
        if self.process and self.process.poll() is None:
            raise RuntimeError("Server already running")
        self.command = command
        self.env = env
        self.auto_restart = auto_restart
        self.install_path.mkdir(parents=True, exist_ok=True)
        self._start_internal()
        return self.process.pid if self.process else 0

    def send_command(self, cmd: str) -> bool:
        """Console me command bheje (stdin me write karein)."""
        if not self.process or self.process.poll() is not None:
            return False
        try:
            self.process.stdin.write((cmd + "\n").encode("utf-8"))
            self.process.stdin.flush()
            self._append_log(f"[console] {cmd}")
            return True
        except Exception as e:
            self._append_log(f"[daemon] failed to send command: {e}")
            return False

    def stop(self, timeout: int = 15) -> bool:
        """Graceful stop - SIGTERM bheje, timeout pe SIGKILL."""
        if not self.process or self.process.poll() is not None:
            return True
        self._stopping = True
        try:
            # Try sending 'stop' command first (Minecraft friendly)
            self.send_command("stop")
            # Wait up to timeout
            try:
                self.process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                # SIGTERM the process group
                try:
                    os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
                except Exception:
                    self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    # SIGKILL
                    try:
                        os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)
                    except Exception:
                        self.process.kill()
            self._append_log("[daemon] server stopped")
        except Exception as e:
            self._append_log(f"[daemon] stop error: {e}")
            return False
        finally:
            self._close_logfile()
        return True

    def kill(self) -> bool:
        """Force kill - SIGKILL the entire process group."""
        if not self.process or self.process.poll() is not None:
            return True
        self._stopping = True
        try:
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)
            except Exception:
                self.process.kill()
            self._append_log("[daemon] server killed")
        except Exception as e:
            self._append_log(f"[daemon] kill error: {e}")
            return False
        finally:
            self._close_logfile()
        return True

    def get_status(self) -> dict[str, Any]:
        """Current status return karein."""
        running = bool(self.process and self.process.poll() is None)
        return {
            "uuid": self.uuid,
            "running": running,
            "pid": self.process.pid if running and self.process else None,
            "uptime_seconds": int(time.time() - self.start_time) if running and self.start_time else 0,
            "crash_count": self.crash_count,
            "started_at": datetime.fromtimestamp(self.start_time).isoformat() if self.start_time else None,
        }

    def get_resources(self) -> dict[str, Any]:
        """CPU/memory usage return karein using psutil."""
        running = bool(self.process and self.process.poll() is None)
        if not running:
            return {"uuid": self.uuid, "cpu_percent": 0, "memory_mb": 0, "disk_mb": 0}

        try:
            p = psutil.Process(self.process.pid)
            cpu = p.cpu_percent(interval=0.5)
            mem_info = p.memory_info()
            mem_mb = mem_info.rss / (1024 * 1024)
            # Also include children (for shell-spawned subprocesses)
            for child in p.children(recursive=True):
                try:
                    cpu += child.cpu_percent(interval=0)
                    mem_info_c = child.memory_info()
                    mem_mb += mem_info_c.rss / (1024 * 1024)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return {"uuid": self.uuid, "cpu_percent": 0, "memory_mb": 0, "disk_mb": 0}

        # Disk usage of install_path
        disk_mb = 0
        try:
            du = shutil.disk_usage(str(self.install_path))
            # We want used space inside install_path, not whole disk
            # Approximate using du command for accuracy
            try:
                result = subprocess.run(
                    ["du", "-sm", str(self.install_path)],
                    capture_output=True, text=True, timeout=5
                )
                if result.returncode == 0:
                    disk_mb = int(result.stdout.split()[0])
            except Exception:
                disk_mb = du.used / (1024 * 1024)
        except Exception:
            pass

        return {
            "uuid": self.uuid,
            "cpu_percent": round(cpu, 2),
            "memory_mb": round(mem_mb, 2),
            "disk_mb": round(disk_mb, 2),
        }

    def get_logs(self, lines: int = 200) -> list[str]:
        """Last N log lines return karein."""
        return list(self.log_buffer)[-lines:]

    def attach_websocket(self, ws: WebSocket) -> None:
        """WebSocket client attach karein - live logs receive karega."""
        self._ws_clients.append(ws)

    def detach_websocket(self, ws: WebSocket) -> None:
        """WebSocket client detach karein."""
        if ws in self._ws_clients:
            self._ws_clients.remove(ws)


# ---- Process registry ----

class ServerManager:
    """Saare running server processes ka registry."""

    def __init__(self) -> None:
        self._servers: dict[str, ServerProcess] = {}
        self._lock = threading.Lock()

    def get(self, uuid: str) -> Optional[ServerProcess]:
        return self._servers.get(uuid)

    def get_or_create(self, uuid: str, install_path: Path) -> ServerProcess:
        with self._lock:
            if uuid not in self._servers:
                self._servers[uuid] = ServerProcess(uuid, install_path)
            return self._servers[uuid]

    def remove(self, uuid: str) -> None:
        with self._lock:
            if uuid in self._servers:
                server = self._servers[uuid]
                if server.process and server.process.poll() is None:
                    server.stop(timeout=5)
                del self._servers[uuid]

    def list_all(self) -> dict[str, dict]:
        return {uuid: s.get_status() for uuid, s in self._servers.items()}


server_manager = ServerManager()


# ---- FastAPI daemon app ----

app = FastAPI(title="PyroPanel Daemon", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---- Auth middleware ----

class DaemonAuth:
    def __init__(self, token: str):
        self.token = token

    def validate(self, request: Request) -> None:
        auth = request.headers.get("Authorization", "")
        x_token = request.headers.get("X-Daemon-Token", "")
        if not auth and not x_token:
            raise HTTPException(status_code=401, detail="Authentication required")
        token = ""
        if auth.startswith("Bearer "):
            token = auth[7:]
        elif x_token:
            token = x_token
        if token != self.token:
            raise HTTPException(status_code=401, detail="Invalid token")


_auth: Optional[DaemonAuth] = None


def init_auth(token: str) -> None:
    global _auth
    _auth = DaemonAuth(token)


def require_auth(request: Request) -> None:
    if _auth:
        _auth.validate(request)


# ---- Pydantic models ----

class InstallRequest(BaseModel):
    uuid: str
    type: str
    version: str
    install_path: str
    memory_limit: int = 1024


class StartRequest(BaseModel):
    install_path: str
    command: str
    memory_limit: int = 1024
    env: dict[str, str] = {}
    auto_restart: bool = True


class CommandRequest(BaseModel):
    command: str


class DeleteRequest(BaseModel):
    install_path: str


class FolderRequest(BaseModel):
    path: str
    name: str


class RenameRequest(BaseModel):
    path: str
    new_name: str


class MoveRequest(BaseModel):
    src_path: str
    dest_path: str


class DeleteFilesRequest(BaseModel):
    paths: list[str]


class WriteFileRequest(BaseModel):
    path: str
    content: str


class ArchiveRequest(BaseModel):
    action: str  # zip | unzip
    path: str
    name: Optional[str] = None


class BackupCreateRequest(BaseModel):
    name: str


# ---- Health ----

@app.get("/health")
async def health():
    """Health check - no auth needed."""
    return {
        "status": "ok",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "platform": platform.platform(),
        "python": sys.version,
        "uptime": int(time.time() - START_TIME),
        "servers": len(server_manager._servers),
    }


# ---- Server lifecycle ----

@app.post("/servers/install")
async def install_server(req: InstallRequest, request: Request):
    """Server install karein (download jar files)."""
    require_auth(request)
    install_path = Path(req.install_path)
    # Local mc_installers module
    try:
        from mc_installers import install_server as do_install, accept_user_jar
    except ImportError:
        return JSONResponse(
            status_code=500,
            content={"detail": "mc_installers module not found on daemon"},
        )

    install_path.mkdir(parents=True, exist_ok=True)
    try:
        jar_path = do_install(req.type, req.version, install_path)
        return {"success": True, "jar": str(jar_path)}
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Install failed: {e}", "jar": None},
        )


@app.post("/servers/{server_uuid}/start")
async def start_server(server_uuid: str, req: StartRequest, request: Request):
    """Server start karein."""
    require_auth(request)
    install_path = Path(req.install_path)
    install_path.mkdir(parents=True, exist_ok=True)
    server = server_manager.get_or_create(server_uuid, install_path)
    try:
        pid = server.start(req.command, req.env, req.auto_restart)
        return {"success": True, "pid": pid}
    except Exception as e:
        return JSONResponse(status_code=500, content={"detail": str(e)})


@app.post("/servers/{server_uuid}/stop")
async def stop_server(server_uuid: str, request: Request):
    """Server stop karein."""
    require_auth(request)
    server = server_manager.get(server_uuid)
    if not server:
        return JSONResponse(status_code=404, content={"detail": "Server not found"})
    ok = server.stop()
    return {"success": ok}


@app.post("/servers/{server_uuid}/restart")
async def restart_server(server_uuid: str, request: Request):
    """Server restart karein."""
    require_auth(request)
    server = server_manager.get(server_uuid)
    if not server:
        return JSONResponse(status_code=404, content={"detail": "Server not found"})
    server.stop()
    await asyncio.sleep(2)
    try:
        pid = server.start(server.command, server.env, server.auto_restart)
        return {"success": True, "pid": pid}
    except Exception as e:
        return JSONResponse(status_code=500, content={"detail": str(e)})


@app.post("/servers/{server_uuid}/kill")
async def kill_server(server_uuid: str, request: Request):
    """Server force kill karein."""
    require_auth(request)
    server = server_manager.get(server_uuid)
    if not server:
        return JSONResponse(status_code=404, content={"detail": "Server not found"})
    ok = server.kill()
    return {"success": ok}


@app.post("/servers/{server_uuid}/command")
async def send_command(server_uuid: str, req: CommandRequest, request: Request):
    """Console command bheje."""
    require_auth(request)
    server = server_manager.get(server_uuid)
    if not server:
        return JSONResponse(status_code=404, content={"detail": "Server not found"})
    ok = server.send_command(req.command)
    return {"success": ok}


@app.get("/servers/{server_uuid}/status")
async def server_status(server_uuid: str, request: Request):
    require_auth(request)
    server = server_manager.get(server_uuid)
    if not server:
        return {"uuid": server_uuid, "running": False, "pid": None}
    return server.get_status()


@app.get("/servers/{server_uuid}/logs")
async def server_logs(server_uuid: str, request: Request, lines: int = 200):
    require_auth(request)
    server = server_manager.get(server_uuid)
    if not server:
        return {"logs": []}
    return {"logs": server.get_logs(lines)}


@app.get("/servers/{server_uuid}/resources")
async def server_resources(server_uuid: str, request: Request):
    require_auth(request)
    server = server_manager.get(server_uuid)
    if not server:
        return {"uuid": server_uuid, "cpu_percent": 0, "memory_mb": 0, "disk_mb": 0}
    return server.get_resources()


@app.delete("/servers/{server_uuid}")
async def delete_server_files(server_uuid: str, req: DeleteRequest, request: Request):
    """Server files delete karein aur process cleanup karein."""
    require_auth(request)
    server_manager.remove(server_uuid)
    install_path = Path(req.install_path)
    if install_path.exists() and install_path.is_dir():
        # Safety: only delete under SERVERS_DIR
        try:
            real = install_path.resolve()
            base = SERVERS_DIR.resolve()
            if str(real).startswith(str(base)):
                shutil.rmtree(real, ignore_errors=True)
        except Exception as e:
            return JSONResponse(status_code=500, content={"detail": str(e)})
    return {"success": True}


# ---- WebSocket live console ----

@app.websocket("/servers/{server_uuid}/ws")
async def server_ws(websocket: WebSocket, server_uuid: str):
    """Live console WebSocket - bidirectional."""
    # Auth via query param (WebSocket doesn't allow custom headers easily)
    token = websocket.query_params.get("token", "")
    if not _auth or token != _auth.token:
        await websocket.close(code=4401, reason="Unauthorized")
        return

    await websocket.accept()
    server = server_manager.get(server_uuid)
    if not server:
        await websocket.send_text("[daemon] server not found")
        await websocket.close()
        return

    server.attach_websocket(websocket)
    # Send last N logs as initial burst
    for line in server.get_logs(200):
        await websocket.send_text(line)

    try:
        while True:
            data = await websocket.receive_text()
            # Treat as console command
            if data.strip():
                server.send_command(data.strip())
    except WebSocketDisconnect:
        pass
    finally:
        server.detach_websocket(websocket)


# ---- File manager ----

def _safe_path(install_path: Path, requested: str) -> Path:
    """Path ko install_path ke andar rakhe - path traversal attack se bachata hai."""
    base = install_path.resolve()
    target = (install_path / requested).resolve()
    try:
        target.relative_to(base)
    except ValueError:
        raise HTTPException(status_code=400, detail="Path outside server directory")
    return target


@app.get("/servers/{server_uuid}/files")
async def list_files(server_uuid: str, request: Request, path: str = "."):
    """Server files list karein."""
    require_auth(request)
    server = server_manager.get(server_uuid)
    if not server:
        # Create on-demand for file browsing when server is stopped
        # We need install_path - get from query
        install_path_str = request.query_params.get("install_path", "")
        if not install_path_str:
            return JSONResponse(status_code=400, content={"detail": "install_path required"})
        server = server_manager.get_or_create(server_uuid, Path(install_path_str))

    target = _safe_path(server.install_path, path)
    if not target.exists():
        return JSONResponse(status_code=404, content={"detail": "Path not found"})

    if target.is_file():
        # Return single file info
        st = target.stat()
        return {
            "path": path,
            "is_dir": False,
            "files": [{
                "name": target.name,
                "size": st.st_size,
                "is_dir": False,
                "is_symlink": target.is_symlink(),
                "mode": oct(st.st_mode & 0o777),
                "modified": datetime.fromtimestamp(st.st_mtime).isoformat(),
            }],
        }

    items = []
    for entry in sorted(target.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
        try:
            st = entry.stat()
            items.append({
                "name": entry.name,
                "size": st.st_size if entry.is_file() else 0,
                "is_dir": entry.is_dir(),
                "is_symlink": entry.is_symlink(),
                "mode": oct(st.st_mode & 0o777),
                "modified": datetime.fromtimestamp(st.st_mtime).isoformat(),
            })
        except (PermissionError, FileNotFoundError):
            continue

    return {"path": path, "is_dir": True, "files": items}


@app.get("/servers/{server_uuid}/files/read")
async def read_file(server_uuid: str, request: Request, path: str):
    """File content read karein."""
    require_auth(request)
    install_path_str = request.query_params.get("install_path", "")
    server = server_manager.get(server_uuid)
    if server:
        install_path = server.install_path
    elif install_path_str:
        install_path = Path(install_path_str)
    else:
        return JSONResponse(status_code=400, content={"detail": "install_path required"})

    target = _safe_path(install_path, path)
    if not target.exists() or not target.is_file():
        return JSONResponse(status_code=404, content={"detail": "File not found"})

    # Limit file size for inline read (10MB)
    if target.stat().st_size > 10 * 1024 * 1024:
        return JSONResponse(status_code=413, content={"detail": "File too large for inline read"})

    try:
        content = target.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return JSONResponse(status_code=500, content={"detail": str(e)})

    return {"path": path, "content": content, "size": target.stat().st_size}


@app.post("/servers/{server_uuid}/files/write")
async def write_file(server_uuid: str, req: WriteFileRequest, request: Request):
    """File content write karein."""
    require_auth(request)
    install_path_str = request.query_params.get("install_path", "")
    server = server_manager.get(server_uuid)
    if server:
        install_path = server.install_path
    elif install_path_str:
        install_path = Path(install_path_str)
    else:
        return JSONResponse(status_code=400, content={"detail": "install_path required"})

    target = _safe_path(install_path, req.path)
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        target.write_text(req.content, encoding="utf-8")
    except Exception as e:
        return JSONResponse(status_code=500, content={"detail": str(e)})
    return {"success": True}


@app.post("/servers/{server_uuid}/files/folder")
async def create_folder(server_uuid: str, req: FolderRequest, request: Request):
    require_auth(request)
    install_path_str = request.query_params.get("install_path", "")
    server = server_manager.get(server_uuid)
    install_path = server.install_path if server else Path(install_path_str)

    base = _safe_path(install_path, req.path)
    new_dir = base / req.name
    try:
        new_dir.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return JSONResponse(status_code=500, content={"detail": str(e)})
    return {"success": True}


@app.post("/servers/{server_uuid}/files/rename")
async def rename_file(server_uuid: str, req: RenameRequest, request: Request):
    require_auth(request)
    install_path_str = request.query_params.get("install_path", "")
    server = server_manager.get(server_uuid)
    install_path = server.install_path if server else Path(install_path_str)

    target = _safe_path(install_path, req.path)
    new_path = target.parent / req.new_name
    try:
        target.rename(new_path)
    except Exception as e:
        return JSONResponse(status_code=500, content={"detail": str(e)})
    return {"success": True}


@app.post("/servers/{server_uuid}/files/move")
async def move_file(server_uuid: str, req: MoveRequest, request: Request):
    require_auth(request)
    install_path_str = request.query_params.get("install_path", "")
    server = server_manager.get(server_uuid)
    install_path = server.install_path if server else Path(install_path_str)

    src = _safe_path(install_path, req.src_path)
    dest = _safe_path(install_path, req.dest_path)
    try:
        shutil.move(str(src), str(dest))
    except Exception as e:
        return JSONResponse(status_code=500, content={"detail": str(e)})
    return {"success": True}


@app.post("/servers/{server_uuid}/files/delete")
async def delete_files(server_uuid: str, req: DeleteFilesRequest, request: Request):
    require_auth(request)
    install_path_str = request.query_params.get("install_path", "")
    server = server_manager.get(server_uuid)
    install_path = server.install_path if server else Path(install_path_str)

    for path in req.paths:
        target = _safe_path(install_path, path)
        try:
            if target.is_dir():
                shutil.rmtree(target, ignore_errors=False)
            else:
                target.unlink()
        except Exception as e:
            return JSONResponse(status_code=500, content={"detail": f"Failed to delete {path}: {e}"})
    return {"success": True}


@app.post("/servers/{server_uuid}/files/upload")
async def upload_file(
    server_uuid: str,
    request: Request,
    path: str = Form("."),
    file: UploadFile = File(...),
):
    """File upload - multipart form."""
    require_auth(request)
    install_path_str = request.query_params.get("install_path", "")
    server = server_manager.get(server_uuid)
    install_path = server.install_path if server else Path(install_path_str)

    base = _safe_path(install_path, path)
    if not base.exists():
        base.mkdir(parents=True, exist_ok=True)
    dest = base / file.filename

    # Stream to file
    try:
        with open(dest, "wb") as f:
            while chunk := await file.read(65536):
                f.write(chunk)
    except Exception as e:
        return JSONResponse(status_code=500, content={"detail": str(e)})
    return {"success": True, "filename": file.filename, "size": dest.stat().st_size}


@app.get("/servers/{server_uuid}/files/download")
async def download_file(server_uuid: str, request: Request, path: str):
    """File download - streaming response."""
    require_auth(request)
    install_path_str = request.query_params.get("install_path", "")
    server = server_manager.get(server_uuid)
    install_path = server.install_path if server else Path(install_path_str)

    target = _safe_path(install_path, path)
    if not target.exists() or not target.is_file():
        return JSONResponse(status_code=404, content={"detail": "File not found"})

    def iter_file():
        with open(target, "rb") as f:
            while chunk := f.read(65536):
                yield chunk

    return StreamingResponse(
        iter_file(),
        media_type="application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{target.name}"'},
    )


@app.post("/servers/{server_uuid}/files/archive")
async def archive_files(server_uuid: str, req: ArchiveRequest, request: Request):
    """ZIP / UNZIP operation."""
    require_auth(request)
    install_path_str = request.query_params.get("install_path", "")
    server = server_manager.get(server_uuid)
    install_path = server.install_path if server else Path(install_path_str)

    import zipfile
    target = _safe_path(install_path, req.path)

    if req.action == "zip":
        if not target.exists():
            return JSONResponse(status_code=404, content={"detail": "Path not found"})
        zip_name = req.name or (target.name + ".zip")
        zip_path = target.parent / zip_name
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            if target.is_file():
                zf.write(target, target.name)
            else:
                for root, dirs, files in os.walk(target):
                    for file in files:
                        fp = Path(root) / file
                        arcname = fp.relative_to(target.parent)
                        zf.write(fp, arcname)
        return {"success": True, "archive": str(zip_path)}

    elif req.action == "unzip":
        if not target.is_file() or not target.name.endswith(".zip"):
            return JSONResponse(status_code=400, content={"detail": "Not a zip file"})
        extract_dir = target.parent / (target.stem + "_extracted")
        extract_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(target, "r") as zf:
            zf.extractall(extract_dir)
        return {"success": True, "extracted_to": str(extract_dir)}

    return JSONResponse(status_code=400, content={"detail": "Unknown action"})


@app.get("/servers/{server_uuid}/files/permissions")
async def file_permissions(server_uuid: str, request: Request, path: str):
    """File permissions viewer."""
    require_auth(request)
    install_path_str = request.query_params.get("install_path", "")
    server = server_manager.get(server_uuid)
    install_path = server.install_path if server else Path(install_path_str)

    target = _safe_path(install_path, path)
    if not target.exists():
        return JSONResponse(status_code=404, content={"detail": "Path not found"})
    st = target.stat()
    return {
        "path": path,
        "mode": oct(st.st_mode & 0o777),
        "uid": st.st_uid,
        "gid": st.st_gid,
        "owner": _get_username(st.st_uid),
        "group": _get_groupname(st.st_gid),
        "size": st.st_size,
        "is_dir": target.is_dir(),
        "is_symlink": target.is_symlink(),
        "modified": datetime.fromtimestamp(st.st_mtime).isoformat(),
    }


def _get_username(uid: int) -> str:
    try:
        return pwd.getpwuid(uid).pw_name
    except (KeyError, ImportError):
        return str(uid)


def _get_groupname(gid: int) -> str:
    try:
        import grp
        return grp.getgrgid(gid).gr_name
    except (KeyError, ImportError):
        return str(gid)


# ---- Backups ----

@app.post("/servers/{server_uuid}/backups")
async def create_backup(server_uuid: str, req: BackupCreateRequest, request: Request):
    """Server ka backup create karein - zip file."""
    require_auth(request)
    install_path_str = request.query_params.get("install_path", "")
    server = server_manager.get(server_uuid)
    install_path = server.install_path if server else Path(install_path_str)

    if not install_path.exists():
        return JSONResponse(status_code=404, content={"detail": "Server install path not found"})

    import zipfile
    backup_uuid = uuidlib.uuid4().hex
    backup_dir = BACKUPS_DIR / server_uuid
    backup_dir.mkdir(parents=True, exist_ok=True)
    safe_name = "".join(c for c in req.name if c.isalnum() or c in "-_")[:64]
    file_name = f"{backup_uuid}_{safe_name}.zip"
    backup_path = backup_dir / file_name

    with zipfile.ZipFile(backup_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(install_path):
            # Skip backups/cache/logs
            dirs[:] = [d for d in dirs if d not in (".backup", "logs", "cache")]
            for file in files:
                fp = Path(root) / file
                arcname = fp.relative_to(install_path)
                try:
                    zf.write(fp, arcname)
                except (PermissionError, FileNotFoundError):
                    continue

    return {
        "success": True,
        "uuid": backup_uuid,
        "file_name": file_name,
        "file_path": str(backup_path),
        "size_bytes": backup_path.stat().st_size,
    }


@app.post("/servers/{server_uuid}/backups/{backup_uuid}/restore")
async def restore_backup(server_uuid: str, backup_uuid: str, request: Request):
    """Backup restore karein."""
    require_auth(request)
    install_path_str = request.query_params.get("install_path", "")
    server = server_manager.get(server_uuid)
    install_path = server.install_path if server else Path(install_path_str)

    backup_dir = BACKUPS_DIR / server_uuid
    backup_file = next(backup_dir.glob(f"{backup_uuid}_*.zip"), None)
    if not backup_file:
        return JSONResponse(status_code=404, content={"detail": "Backup not found"})

    import zipfile
    # Clear install_path (move current to .restore_old)
    if install_path.exists():
        old_path = install_path.parent / f"{install_path.name}.restore_old"
        if old_path.exists():
            shutil.rmtree(old_path, ignore_errors=True)
        shutil.move(str(install_path), str(old_path))
        install_path.mkdir(parents=True, exist_ok=True)
    else:
        install_path.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(backup_file, "r") as zf:
        zf.extractall(install_path)

    return {"success": True}


@app.delete("/servers/{server_uuid}/backups/{backup_uuid}")
async def delete_backup(server_uuid: str, backup_uuid: str, request: Request):
    require_auth(request)
    backup_dir = BACKUPS_DIR / server_uuid
    backup_file = next(backup_dir.glob(f"{backup_uuid}_*.zip"), None)
    if not backup_file:
        return JSONResponse(status_code=404, content={"detail": "Backup not found"})
    backup_file.unlink()
    return {"success": True}


@app.get("/servers/{server_uuid}/backups/{backup_uuid}/download")
async def download_backup(server_uuid: str, backup_uuid: str, request: Request):
    require_auth(request)
    backup_dir = BACKUPS_DIR / server_uuid
    backup_file = next(backup_dir.glob(f"{backup_uuid}_*.zip"), None)
    if not backup_file:
        return JSONResponse(status_code=404, content={"detail": "Backup not found"})

    def iter_file():
        with open(backup_file, "rb") as f:
            while chunk := f.read(65536):
                yield chunk

    return StreamingResponse(
        iter_file(),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{backup_file.name}"'},
    )


@app.get("/servers/{server_uuid}/backups")
async def list_backups(server_uuid: str, request: Request):
    require_auth(request)
    backup_dir = BACKUPS_DIR / server_uuid
    if not backup_dir.exists():
        return {"backups": []}
    backups = []
    for f in backup_dir.glob("*.zip"):
        # filename format: uuid_name.zip
        name_parts = f.stem.split("_", 1)
        backup_uuid = name_parts[0]
        name = name_parts[1] if len(name_parts) > 1 else "backup"
        st = f.stat()
        backups.append({
            "uuid": backup_uuid,
            "name": name,
            "file_name": f.name,
            "size_bytes": st.st_size,
            "created_at": datetime.fromtimestamp(st.st_mtime).isoformat(),
        })
    backups.sort(key=lambda b: b["created_at"], reverse=True)
    return {"backups": backups}


# ---- Node resource monitoring ----

@app.get("/resources")
async def node_resources(request: Request):
    """Node ka total resource usage return karein."""
    require_auth(request)
    cpu_percent = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory()
    disk = shutil.disk_usage(str(BASE_DIR))
    return {
        "cpu_percent": cpu_percent,
        "cpu_cores": psutil.cpu_count() or 1,
        "memory_total_mb": round(mem.total / (1024 * 1024)),
        "memory_used_mb": round(mem.used / (1024 * 1024)),
        "memory_free_mb": round(mem.available / (1024 * 1024)),
        "disk_total_mb": round(disk.total / (1024 * 1024)),
        "disk_used_mb": round(disk.used / (1024 * 1024)),
        "disk_free_mb": round(disk.free / (1024 * 1024)),
        "servers_running": sum(
            1 for s in server_manager._servers.values()
            if s.process and s.process.poll() is None
        ),
    }


# ---- Background heartbeat to panel ----

async def heartbeat_loop(panel_url: str, node_uuid: str, api_key: str):
    """Panel ko har 30s me resource usage bheje (HTTP POST)."""
    import httpx
    while True:
        try:
            cpu_percent = psutil.cpu_percent(interval=0.5)
            mem = psutil.virtual_memory()
            disk = shutil.disk_usage(str(BASE_DIR))
            payload = {
                "uuid": node_uuid,
                "memory_used": round(mem.used / (1024 * 1024)),
                "disk_used": round(disk.used / (1024 * 1024)),
                "cpu_used": cpu_percent,
                "status": "online",
                "metadata": {
                    "servers_running": sum(
                        1 for s in server_manager._servers.values()
                        if s.process and s.process.poll() is None
                    ),
                },
            }
            async with httpx.AsyncClient(timeout=10) as client:
                await client.post(
                    f"{panel_url}/api/nodes/{node_uuid}/heartbeat",
                    json=payload,
                    headers={"Authorization": f"Bearer {api_key}", "X-Node-Key": api_key},
                )
        except Exception as e:
            print(f"[heartbeat] failed: {e}")
        await asyncio.sleep(HEARTBEAT_INTERVAL)


# ---- Main entrypoint ----

START_TIME = time.time()


def main():
    parser = argparse.ArgumentParser(description="PyroPanel Daemon")
    parser.add_argument("--host", default="0.0.0.0", help="Bind address")
    parser.add_argument("--port", type=int, default=8081, help="Bind port")
    parser.add_argument("--token", required=True, help="Authentication token")
    parser.add_argument("--panel-url", default="", help="Panel URL for heartbeat")
    parser.add_argument("--node-uuid", default="", help="Node UUID for heartbeat")
    parser.add_argument("--node-api-key", default="", help="Node API key for panel heartbeat")
    args = parser.parse_args()

    init_auth(args.token)

    # Start heartbeat task if panel URL given
    if args.panel_url and args.node_uuid and args.node_api_key:
        @app.on_event("startup")
        async def _start_hb():
            asyncio.create_task(
                heartbeat_loop(args.panel_url, args.node_uuid, args.node_api_key)
            )

    print(f"[daemon] Starting PyroPanel daemon on {args.host}:{args.port}")
    print(f"[daemon] Servers dir: {SERVERS_DIR}")
    print(f"[daemon] Backups dir: {BACKUPS_DIR}")
    print(f"[daemon] Platform: {platform.platform()}")

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        log_level="info",
        access_log=False,
    )


if __name__ == "__main__":
    main()
