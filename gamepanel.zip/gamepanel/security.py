"""
security.py - Security utilities
JWT tokens, Argon2 password hashing, CSRF tokens, rate limiting helpers.
"""
from __future__ import annotations

import hashlib
import hmac
import secrets
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError

from config import settings


# ---- Password hashing (Argon2id) ----

_ph = PasswordHasher(
    time_cost=settings.Argon2_TIME_COST,
    memory_cost=settings.Argon2_MEMORY_COST,
    parallelism=settings.Argon2_PARALLELISM,
    hash_len=32,
    salt_len=16,
)


def hash_password(password: str) -> str:
    """Plain password ko Argon2id hash me convert karein."""
    return _ph.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    """Password ko hash se verify karein."""
    try:
        return _ph.verify(hashed, password)
    except (VerifyMismatchError, InvalidHashError):
        return False
    except Exception:
        return False


def needs_rehash(hashed: str) -> bool:
    """Check karein ki hash purane parameters pe hai to rehash karein."""
    return _ph.check_needs_rehash(hashed)


# ---- JWT ----

def create_access_token(
    subject: str | int,
    extra_claims: Optional[dict[str, Any]] = None,
    expires_minutes: Optional[int] = None,
) -> str:
    """JWT access token create karein."""
    expire_minutes = expires_minutes or settings.JWT_EXPIRE_MINUTES
    now = datetime.now(timezone.utc)
    payload: dict[str, Any] = {
        "sub": str(subject),
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=expire_minutes)).timestamp()),
        "jti": secrets.token_hex(16),
        "type": "access",
    }
    if extra_claims:
        payload.update(extra_claims)
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def create_csrf_token() -> str:
    """CSRF token generate karein (32 bytes random hex)."""
    return secrets.token_hex(32)


def decode_token(token: str) -> Optional[dict[str, Any]]:
    """JWT decode karein. Invalid/expired hone pe None return."""
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.JWT_ALGORITHM],
        )
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


# ---- API Keys ----

def generate_api_key() -> tuple[str, str, str]:
    """API key generate karein. Returns (full_key, prefix, hash).
    Full key sirf ek baar show hota hai client ko."""
    raw = secrets.token_bytes(32)
    full_key = "pp_" + raw.hex()
    prefix = full_key[:12]
    key_hash = hashlib.sha256(full_key.encode()).hexdigest()
    return full_key, prefix, key_hash


def hash_api_key(full_key: str) -> str:
    """API key ka SHA256 hash karein."""
    return hashlib.sha256(full_key.encode()).hexdigest()


# ---- Random tokens ----

def generate_token(length: int = 32) -> str:
    return secrets.token_urlsafe(length)


def constant_time_compare(a: str, b: str) -> bool:
    """Timing-safe string comparison."""
    return hmac.compare_digest(a.encode(), b.encode())


# ---- Rate limit key ----

def rate_limit_key(scope: str, identifier: str) -> str:
    """Redis-like key for rate limit tracking (in-memory)."""
    bucket = int(time.time() // 60)
    return f"rl:{scope}:{identifier}:{bucket}"
