#!/usr/bin/env bash
# PyroPanel - Daemon start script
# Usage: ./run_daemon.sh <auth_token> <panel_url> <node_uuid> <node_api_key>
# Example: ./run_daemon.sh my-secret http://localhost:8000 abc123 def456

set -e

cd "$(dirname "$0")"

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "[error] Python 3 is required"
    exit 1
fi

# Setup venv (same as panel)
if [ ! -d ".venv" ]; then
    python3 -m venv .venv
fi
source .venv/bin/activate

if [ ! -f ".venv/.deps_installed" ] || [ requirements.txt -nt .venv/.deps_installed ]; then
    pip install --upgrade pip
    pip install -r requirements.txt
    touch .venv/.deps_installed
fi

TOKEN="${1:-}"
PANEL_URL="${2:-}"
NODE_UUID="${3:-}"
NODE_API_KEY="${4:-}"

HOST="${DAEMON_HOST:-0.0.0.0}"
PORT="${DAEMON_PORT:-8081}"

if [ -z "$TOKEN" ]; then
    echo "Usage: $0 <auth_token> [panel_url] [node_uuid] [node_api_key]"
    echo ""
    echo "The auth_token is shown in the admin panel when you create a node."
    echo ""
    echo "If you just want to test the daemon standalone (no panel connection):"
    echo "  $0 my-test-token"
    exit 1
fi

ARGS="--host $HOST --port $PORT --token $TOKEN"

if [ -n "$PANEL_URL" ] && [ -n "$NODE_UUID" ] && [ -n "$NODE_API_KEY" ]; then
    ARGS="$ARGS --panel-url $PANEL_URL --node-uuid $NODE_UUID --node-api-key $NODE_API_KEY"
fi

echo "[daemon] Starting PyroPanel daemon on $HOST:$PORT"
exec python daemon.py $ARGS
