# PyroPanel

Production-ready Python game hosting panel - **no Docker required**. Built with FastAPI, Jinja2, TailwindCSS, and SQLAlchemy. Designed for Ubuntu 20/22 PRoot VPS environments.

## Features

- **Panel + Daemon architecture** - Panel (web UI) talks to one or more Daemons (server runners) over HTTP + WebSocket
- **Pure Python daemon** - Uses `subprocess.Popen()` to run servers. No Docker, no containers
- **Minecraft support** - Paper, Purpur, Spigot, Vanilla, Fabric, Forge, Velocity, Waterfall, BungeeCord (real download scripts + user jar upload)
- **Live console** - Real-time WebSocket-based console with ANSI support, command input, log search
- **File manager** - Upload, download, drag-drop, ZIP/UNZIP, online code editor, permissions viewer
- **Backups** - Create, restore, download, delete (zip-based)
- **Scheduler** - Standard 5-field cron expressions for start/stop/restart/kill/command/backup
- **Multi-node** - Multiple daemon nodes with resource monitoring, automatic free port allocation
- **Security** - JWT auth, Argon2id password hashing, CSRF protection, rate limiting, audit logs, API keys
- **REST API** - Full REST API with OpenAPI docs at `/api/docs`
- **Dark/Light theme** - User-selectable, persists across sessions
- **Responsive** - Works on desktop, tablet, mobile
- **SQLite default, PostgreSQL optional** - Switch via `DATABASE_URL` env var
- **Email (optional SMTP)** - Email verification, password reset (skip if SMTP disabled)
- **Notifications** - In-app notifications for server events
- **Maintenance mode** - Admins can lock out users during maintenance
- **Branding** - Customizable app name, logo, favicon, footer

## Quick Start

### Prerequisites

- Python 3.12+
- Ubuntu 20.04 / 22.04 (or any Linux)
- Java 17+ (for Minecraft servers, on the daemon host)
- ~512 MB RAM minimum

### Install & Run Panel

```bash
cd gamepanel
./run_panel.sh
# or: python main.py
```

This will:
1. Create a virtual environment
2. Install dependencies
3. Initialize SQLite database
4. Create a default admin user (`admin` / `admin12345`)
5. Start the panel on `http://0.0.0.0:8000`

**Change the admin password immediately after first login!**

### Add a Daemon Node

1. Login as admin → **Admin Overview** → **Nodes** → **Add Node**
2. Fill in node name, FQDN, daemon host/port, resources
3. After creation, open the node detail page - you'll see a pre-built daemon run command
4. On the daemon server, copy the PyroPanel directory, then run:

```bash
./run_daemon.sh <auth_token> <panel_url> <node_uuid> <node_api_key>
# or: python daemon.py --host 0.0.0.0 --port 8081 --token <auth_token>
```

5. The daemon will start sending heartbeats - node status will show **Online**

### Create Your First Server

1. Login → **Create Server**
2. Choose type (Paper, Vanilla, etc.), version, resources, expiry
3. Click **Create** - panel triggers daemon to download the server jar
4. Once installed, click **Start** - server runs via `subprocess.Popen()`
5. Open the **Console** tab to see live logs and send commands

## Architecture

```
┌────────────────────────────────────────────────────────────────┐
│                        PANEL (FastAPI)                         │
│  - Web UI (Jinja2 + Tailwind)                                  │
│  - REST API (/api/v1/*)                                        │
│  - Auth (JWT cookies + API keys)                              │
│  - Database (SQLite/PostgreSQL)                              │
│  - Scheduler (cron jobs)                                      │
│  - WebSocket proxy to daemon                                  │
└──────────────────┬─────────────────────────────────────────────┘
                   │ HTTP / WebSocket
                   ▼
┌────────────────────────────────────────────────────────────────┐
│                       DAEMON (FastAPI)                         │
│  - subprocess.Popen() for each server                         │
│  - File manager (local filesystem)                            │
│  - Backups (zip)                                              │
│  - Resource monitoring (psutil)                               │
│  - Live console (WebSocket to process stdout/stderr)          │
│  - Heartbeat to panel                                         │
└────────────────────────────────────────────────────────────────┘
                   │
                   ▼
┌────────────────────────────────────────────────────────────────┐
│              SERVER PROCESSES (Java/Minecraft)                 │
│  - Each runs as a subprocess                                  │
│  - Resource limits via RLIMIT_AS + nice                       │
│  - Auto-restart on crash (max 5 retries)                     │
└────────────────────────────────────────────────────────────────┘
```

## Project Structure

```
gamepanel/
├── main.py                  # FastAPI panel app + middleware + lifespan
├── daemon.py                # Pure Python daemon (FastAPI)
├── config.py                # Pydantic settings (env vars)
├── database.py              # SQLAlchemy async engine + session
├── models.py                # All ORM models
├── schemas.py               # Pydantic request/response schemas
├── security.py              # JWT, Argon2, API keys, CSRF
├── auth.py                  # Auth dependencies (current_user, login_user)
├── mc_installers.py         # Real downloaders for all MC server types
│
├── routers/
│   ├── auth.py              # Login, register, reset, verify
│   ├── dashboard.py         # User + admin dashboard
│   ├── servers.py           # Server CRUD + lifecycle actions
│   ├── console.py           # WebSocket proxy to daemon
│   ├── files.py             # File manager endpoints
│   ├── backups.py           # Backup CRUD
│   ├── scheduler.py         # Schedule CRUD
│   ├── nodes.py             # Node management + daemon heartbeat
│   ├── admin.py             # Users, logs, system settings
│   ├── user_settings.py     # Profile, password, API keys
│   └── api.py               # REST API (Bearer token)
│
├── services/
│   ├── daemon_client.py     # Async HTTP client for daemon
│   ├── server_service.py    # Server lifecycle orchestration
│   ├── audit_service.py     # Audit log helpers
│   ├── email_service.py     # Optional SMTP sender
│   ├── notification_service.py
│   ├── rate_limit.py        # In-memory rate limiter
│   ├── scheduler_service.py # Cron parser + scheduler loop
│   ├── settings_service.py  # Key-value system settings
│   └── template_context.py  # Common Jinja2 context builder
│
├── templates/               # Jinja2 templates (15+ pages)
│   ├── base.html            # Sidebar + topbar layout
│   ├── auth/                # login, register, reset
│   ├── dashboard/           # user, admin, notifications, activity, settings
│   ├── servers/             # list, create, manage
│   ├── files/               # manager
│   ├── backups/             # list
│   ├── scheduler/           # list
│   ├── admin/               # users, logs, settings
│   ├── nodes/               # list, create, detail
│   └── errors/              # 404, 500, maintenance
│
├── static/
│   ├── css/app.css
│   └── js/app.js
│
├── data/                    # SQLite DB (auto-created)
├── logs/                    # Server logs
├── servers_data/            # Server install paths (daemon side)
├── backups/                 # Backup zip files (daemon side)
│
├── requirements.txt
├── .env.example
├── run_panel.sh             # Panel start script
├── run_daemon.sh            # Daemon start script
└── README.md
```

## Configuration

All configuration via environment variables (or `.env` file). See `.env.example` for full list.

Key settings:

| Variable | Default | Description |
|----------|---------|-------------|
| `SECRET_KEY` | (change me) | JWT signing key - **MUST change in production** |
| `DATABASE_URL` | `sqlite:///data/pyropanel.db` | SQLite or PostgreSQL URL |
| `APP_URL` | `http://localhost:8000` | Public panel URL (for email links) |
| `SMTP_ENABLED` | `false` | Enable email sending |
| `EMAIL_VERIFICATION_REQUIRED` | `false` | Require email verification on signup |
| `MAINTENANCE_MODE` | `false` | Lock out non-admin users |
| `DEFAULT_MEMORY_MB` | `1024` | Default memory limit for new servers |
| `RATE_LIMIT_LOGIN_PER_MINUTE` | `10` | Max login attempts per minute per IP |

### PostgreSQL Setup

1. Create database: `CREATE DATABASE pyropanel;`
2. Set `DATABASE_URL=postgresql://user:pass@localhost:5432/pyropanel`
3. Run panel - tables auto-created on startup

### SMTP Setup

1. Admin → System Settings → SMTP tab
2. Enable SMTP, fill in host/port/user/pass
3. Click **Send Test** to verify
4. Email verification + password reset will work automatically

## API Usage

REST API is available at `/api/v1/*`. Authentication via Bearer token (API key).

```bash
# Create API key: User Settings → API Keys → New Key

# List your servers
curl -H "Authorization: Bearer pp_xxxxx" http://localhost:8000/api/v1/servers

# Start a server
curl -X POST -H "Authorization: Bearer pp_xxxxx" \
  "http://localhost:8000/api/v1/servers/<uuid>/action?action=start"

# Create a server
curl -X POST -H "Authorization: Bearer pp_xxxxx" \
  -H "Content-Type: application/json" \
  -d '{"name":"Test","server_type":"paper","version":"latest","node_id":1,"memory_limit":1024,"disk_limit":5120,"cpu_limit":100}' \
  http://localhost:8000/api/v1/servers
```

OpenAPI docs at `/api/docs` - interactive Swagger UI.

## Daemon (Standalone Mode)

You can run the daemon standalone (without panel) for testing:

```bash
python daemon.py --host 0.0.0.0 --port 8081 --token my-secret
```

Then test with curl:

```bash
# Health check
curl http://localhost:8081/health

# Node resources
curl -H "Authorization: Bearer my-secret" http://localhost:8081/resources
```

## PRoot VPS Notes

- Daemon uses `RLIMIT_AS` for memory limits - works in PRoot
- `os.nice()` for soft CPU limits - works in PRoot
- `subprocess.Popen` with `start_new_session=True` for clean process groups
- No Docker, no systemd, no privileged operations required
- Server files stored in `servers_data/` - ensure disk space

## Security Notes

- **Change `SECRET_KEY`** in production
- **Change default admin password** immediately
- HTTPS recommended (use a reverse proxy like Nginx/Caddy)
- API keys are SHA256-hashed in DB (only shown once at creation)
- CSRF tokens required for all state-changing form submissions
- Rate limiting on login (10/min) and API (120/min) by default
- Audit logs track all major actions

## Common Issues

### "Node is offline" after creating node
- Daemon not running - check `python daemon.py` is started
- Daemon port blocked by firewall
- `daemon_host` / `daemon_port` incorrect in node config
- `auth_token` mismatch between panel config and daemon `--token` arg

### "Install failed" on server creation
- Daemon can't reach internet (Minecraft download APIs)
- Disk full on daemon host
- Java not installed on daemon host (`apt install openjdk-17-jre`)
- Check daemon logs in `logs/` directory

### Console not showing logs
- Server not running - check status badge
- WebSocket connection blocked (check reverse proxy config)
- Auth token expired - re-login

### Server won't start
- Check startup command (Settings tab)
- Check Java is installed: `java -version`
- Check EULA accepted: `eula.txt` should contain `eula=true`
- Check daemon logs

## License

MIT License - use freely for personal and commercial projects.
