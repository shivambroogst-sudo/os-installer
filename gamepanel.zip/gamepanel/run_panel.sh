#!/usr/bin/env bash
# PyroPanel - Panel start script
# Usage: ./run_panel.sh [host] [port]

set -e

cd "$(dirname "$0")"

# Copy .env if not exists
if [ ! -f .env ]; then
    cp .env.example .env
    echo "[setup] Created .env from .env.example - please edit and set SECRET_KEY"
fi

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "[error] Python 3 is required"
    exit 1
fi

# Check Python version (3.12+)
PY_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "[info] Python $PY_VERSION detected"

# Install deps if needed
if [ ! -d ".venv" ]; then
    echo "[setup] Creating virtual environment..."
    python3 -m venv .venv
fi

source .venv/bin/activate

# Install/update deps
if [ ! -f ".venv/.deps_installed" ] || [ requirements.txt -nt .venv/.deps_installed ]; then
    echo "[setup] Installing dependencies..."
    pip install --upgrade pip
    pip install -r requirements.txt
    touch .venv/.deps_installed
fi

HOST="${1:-0.0.0.0}"
PORT="${2:-8000}"

export PANEL_HOST="$HOST"
export PANEL_PORT="$PORT"

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║   PyroPanel - Starting panel...                 ║"
echo "║   http://$HOST:$PORT"
echo "║   Docs: http://$HOST:$PORT/api/docs"
echo "║                                                  ║"
echo "║   Default login: admin / admin12345              ║"
echo "║   CHANGE THIS PASSWORD IMMEDIATELY!              ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

exec python main.py
