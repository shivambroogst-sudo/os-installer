"""
models.py - SQLAlchemy ORM models
Saare database tables: users, servers, nodes, allocations, backups,
schedules, audit_logs, notifications, api_keys, settings, activity_logs.
"""
from __future__ import annotations

import enum
import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    JSON,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _uuid_str() -> str:
    return uuid.uuid4().hex


# ---- Enums ----

class UserRole(str, enum.Enum):
    USER = "user"
    ADMIN = "admin"
    SUPERADMIN = "superadmin"


class ServerStatus(str, enum.Enum):
    INSTALLING = "installing"
    INSTALLED = "installed"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    STOPPED = "stopped"
    CRASHED = "crashed"
    SUSPENDED = "suspended"
    FAILED = "failed"


class NodeStatus(str, enum.Enum):
    ONLINE = "online"
    OFFLINE = "offline"
    MAINTENANCE = "maintenance"


class ServerType(str, enum.Enum):
    # Minecraft
    PAPER = "paper"
    PURPUR = "purpur"
    SPIGOT = "spigot"
    VANILLA = "vanilla"
    FABRIC = "fabric"
    FORGE = "forge"
    VELOCITY = "velocity"
    WATERFALL = "waterfall"
    BUNGEECORD = "bungeecord"
    # Custom
    CUSTOM = "custom"


class ScheduleAction(str, enum.Enum):
    START = "start"
    STOP = "stop"
    RESTART = "restart"
    KILL = "kill"
    BACKUP = "backup"
    COMMAND = "command"


# ---- Models ----

class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    uuid: Mapped[str] = mapped_column(String(64), default=_uuid_str, unique=True, index=True)
    username: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), default=UserRole.USER.value)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_email_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    email_verification_token: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    password_reset_token: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    password_reset_expires: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_login_ip: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    theme: Mapped[str] = mapped_column(String(10), default="dark")  # dark | light
    language: Mapped[str] = mapped_column(String(10), default="en")
    timezone: Mapped[str] = mapped_column(String(64), default="Asia/Kolkata")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, onupdate=_utcnow)

    servers: Mapped[list["Server"]] = relationship(
        back_populates="owner", cascade="all, delete-orphan"
    )
    api_keys: Mapped[list["ApiKey"]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )
    notifications: Mapped[list["Notification"]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )
    audit_logs: Mapped[list["AuditLog"]] = relationship(back_populates="user")

    @property
    def is_admin(self) -> bool:
        return self.role in (UserRole.ADMIN.value, UserRole.SUPERADMIN.value)

    @property
    def is_superadmin(self) -> bool:
        return self.role == UserRole.SUPERADMIN.value


class Node(Base):
    __tablename__ = "nodes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    uuid: Mapped[str] = mapped_column(String(64), default=_uuid_str, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(64), unique=True)
    fqdn: Mapped[str] = mapped_column(String(255))  # hostname or IP
    daemon_host: Mapped[str] = mapped_column(String(255))
    daemon_port: Mapped[int] = mapped_column(Integer, default=8081)
    api_key: Mapped[str] = mapped_column(String(128))  # daemon -> panel
    auth_token: Mapped[str] = mapped_column(String(128))  # panel -> daemon
    status: Mapped[str] = mapped_column(String(20), default=NodeStatus.OFFLINE.value)
    is_public: Mapped[bool] = mapped_column(Boolean, default=True)
    location: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    memory_total: Mapped[int] = mapped_column(Integer, default=4096)  # MB
    memory_used: Mapped[int] = mapped_column(Integer, default=0)
    disk_total: Mapped[int] = mapped_column(Integer, default=51200)  # MB
    disk_used: Mapped[int] = mapped_column(Integer, default=0)
    cpu_cores: Mapped[int] = mapped_column(Integer, default=2)
    cpu_used: Mapped[float] = mapped_column(Float, default=0.0)
    last_heartbeat: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    metadata_json: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, onupdate=_utcnow)

    servers: Mapped[list["Server"]] = relationship(back_populates="node")
    allocations: Mapped[list["Allocation"]] = relationship(
        back_populates="node", cascade="all, delete-orphan"
    )

    @property
    def memory_free(self) -> int:
        return max(0, self.memory_total - self.memory_used)

    @property
    def disk_free(self) -> int:
        return max(0, self.disk_total - self.disk_used)


class Allocation(Base):
    __tablename__ = "allocations"
    __table_args__ = (UniqueConstraint("node_id", "ip", "port", name="uq_alloc_node_ip_port"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    node_id: Mapped[int] = mapped_column(ForeignKey("nodes.id", ondelete="CASCADE"), index=True)
    server_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("servers.id", ondelete="SET NULL"), nullable=True, index=True
    )
    ip: Mapped[str] = mapped_column(String(64))
    port: Mapped[int] = mapped_column(Integer)
    is_primary: Mapped[bool] = mapped_column(Boolean, default=False)
    is_assigned: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)

    node: Mapped["Node"] = relationship(back_populates="allocations")
    server: Mapped[Optional["Server"]] = relationship(
        foreign_keys="Allocation.server_id"
    )


class Server(Base):
    __tablename__ = "servers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    uuid: Mapped[str] = mapped_column(String(64), default=_uuid_str, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(64))
    description: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    node_id: Mapped[int] = mapped_column(ForeignKey("nodes.id", ondelete="RESTRICT"), index=True)
    allocation_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("allocations.id", ondelete="SET NULL"), nullable=True
    )

    server_type: Mapped[str] = mapped_column(String(32), default=ServerType.PAPER.value)
    version: Mapped[str] = mapped_column(String(32), default="latest")
    egg_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("eggs.id", ondelete="SET NULL"), nullable=True, index=True
    )
    egg_config: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)

    status: Mapped[str] = mapped_column(String(20), default=ServerStatus.INSTALLING.value)
    pid: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)

    # Resource limits
    memory_limit: Mapped[int] = mapped_column(Integer, default=1024)  # MB
    disk_limit: Mapped[int] = mapped_column(Integer, default=5120)  # MB
    cpu_limit: Mapped[int] = mapped_column(Integer, default=100)  # % of one core
    swap_limit: Mapped[int] = mapped_column(Integer, default=0)

    # Startup
    startup_command: Mapped[str] = mapped_column(Text, default="")
    java_arguments: Mapped[str] = mapped_column(Text, default="-Xms128M -Xmx{{SERVER_MEMORY}}M")
    startup_variables: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    auto_restart: Mapped[bool] = mapped_column(Boolean, default=True)
    auto_startup: Mapped[bool] = mapped_column(Boolean, default=False)
    crash_count: Mapped[int] = mapped_column(Integer, default=0)

    # Expiry
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    is_suspended: Mapped[bool] = mapped_column(Boolean, default=False)
    suspension_reason: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    # Path on node
    install_path: Mapped[str] = mapped_column(String(512), default="")

    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, onupdate=_utcnow)
    last_started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_stopped_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    owner: Mapped["User"] = relationship(back_populates="servers")
    node: Mapped["Node"] = relationship(back_populates="servers")
    allocation: Mapped[Optional["Allocation"]] = relationship(
        foreign_keys="Server.allocation_id"
    )
    egg: Mapped[Optional["Egg"]] = relationship(back_populates="servers")
    backups: Mapped[list["Backup"]] = relationship(
        back_populates="server", cascade="all, delete-orphan"
    )
    schedules: Mapped[list["Schedule"]] = relationship(
        back_populates="server", cascade="all, delete-orphan"
    )
    audit_logs: Mapped[list["AuditLog"]] = relationship(back_populates="server")

    @property
    def is_running(self) -> bool:
        return self.status == ServerStatus.RUNNING.value

    @property
    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        # Handle both offset-naive and offset-aware datetimes (SQLite issue)
        exp = self.expires_at
        now = datetime.now(timezone.utc)
        # Make both offset-aware for comparison
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        return now > exp


class Backup(Base):
    __tablename__ = "backups"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    uuid: Mapped[str] = mapped_column(String(64), default=_uuid_str, unique=True, index=True)
    server_id: Mapped[int] = mapped_column(ForeignKey("servers.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(128))
    file_name: Mapped[str] = mapped_column(String(255))
    file_path: Mapped[str] = mapped_column(String(512))
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    is_locked: Mapped[bool] = mapped_column(Boolean, default=False)
    is_manual: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)

    server: Mapped["Server"] = relationship(back_populates="backups")


class Schedule(Base):
    __tablename__ = "schedules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    server_id: Mapped[int] = mapped_column(ForeignKey("servers.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(64))
    action: Mapped[str] = mapped_column(String(20))
    cron_expression: Mapped[str] = mapped_column(String(64))  # simple "*/5 * * * *"
    command: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    last_run_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    next_run_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)

    server: Mapped["Server"] = relationship(back_populates="schedules")


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    server_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("servers.id", ondelete="SET NULL"), nullable=True, index=True
    )
    action: Mapped[str] = mapped_column(String(64), index=True)
    resource_type: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    resource_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    description: Mapped[str] = mapped_column(Text)
    ip_address: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    metadata_json: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)

    user: Mapped[Optional["User"]] = relationship(back_populates="audit_logs")
    server: Mapped[Optional["Server"]] = relationship(back_populates="audit_logs")


class Notification(Base):
    __tablename__ = "notifications"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(128))
    message: Mapped[str] = mapped_column(Text)
    level: Mapped[str] = mapped_column(String(20), default="info")  # info|success|warning|error
    is_read: Mapped[bool] = mapped_column(Boolean, default=False)
    link: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)

    user: Mapped["User"] = relationship(back_populates="notifications")


class ApiKey(Base):
    __tablename__ = "api_keys"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(64))
    key_prefix: Mapped[str] = mapped_column(String(16), index=True)
    key_hash: Mapped[str] = mapped_column(String(255), unique=True)
    permissions: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    last_used_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)

    user: Mapped["User"] = relationship(back_populates="api_keys")


class SystemSetting(Base):
    """Key-value store for runtime configurable settings (branding, smtp, etc.)"""
    __tablename__ = "system_settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    key: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    value: Mapped[str] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String(32), default="general", index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, onupdate=_utcnow)


# ---- Egg System (Pterodactyl-like) ----

class Egg(Base):
    """Server eggs - templates with install scripts, startup config, variables.
    Pterodactyl ke eggs jaisa - ek egg me server type, version, install script,
    startup command, aur variables define hote hain."""
    __tablename__ = "eggs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    uuid: Mapped[str] = mapped_column(String(64), default=_uuid_str, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(128), index=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    category: Mapped[str] = mapped_column(String(64), default="minecraft", index=True)
    # minecraft, source, voice, rust, etc.

    # Author/metadata
    author: Mapped[str] = mapped_column(String(128), default="ogultra")
    version: Mapped[str] = mapped_column(String(32), default="1.0")

    # Install configuration
    install_script: Mapped[str] = mapped_column(Text, default="")
    # Shell script jo daemon pe run hota hai server install karne ke liye

    # Startup configuration
    startup_command: Mapped[str] = mapped_column(Text, default="")
    # e.g. "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JAR}} nogui"

    # Default resource limits
    default_memory: Mapped[int] = mapped_column(Integer, default=1024)
    default_disk: Mapped[int] = mapped_column(Integer, default=5120)
    default_cpu: Mapped[int] = mapped_column(Integer, default=100)

    # Variables (JSON array of variable definitions)
    # Each variable: {name, env_variable, default_value, description, required, user_viewable, user_editable, rules}
    variables: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)

    # Features (what this egg supports)
    # e.g. ["eula", "java_version"]
    features: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)

    # Tags for filtering
    tags: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    # Display
    icon: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    # Emoji ya icon name for UI

    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow, onupdate=_utcnow)

    servers: Mapped[list["Server"]] = relationship(back_populates="egg")


# Update Server model relationship - need to add egg_id
# Note: Server model already has server_type field, we'll add egg_id as optional link
