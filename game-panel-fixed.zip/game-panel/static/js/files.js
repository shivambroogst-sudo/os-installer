'use strict';

class FileManager {
  constructor(serverId) {
    this.serverId = serverId;
    this.currentPath = '/';
    this.selected = new Set();
    this.init();
  }

  init() {
    this.listEl = document.getElementById('file-list');
    this.pathEl = document.getElementById('current-path');
    this.breadcrumbEl = document.getElementById('breadcrumb');
    this.uploadInput = document.getElementById('file-upload-input');
    this.bindButtons();
    this.navigate('/');
  }

  async navigate(path) {
    this.currentPath = path;
    this.selected.clear();
    if (this.pathEl) this.pathEl.value = path;
    this.updateBreadcrumb(path);
    try {
      const data = await apiFetch(`/server/${this.serverId}/files/list?path=${encodeURIComponent(path)}`);
      this.renderFiles(data.files || []);
    } catch(e) {
      Toast.error(e.message);
    }
  }

  renderFiles(files) {
    if (!this.listEl) return;
    if (!files.length) {
      this.listEl.innerHTML = '<div style="text-align:center;padding:40px;color:var(--text-muted);">Empty directory</div>';
      return;
    }
    this.listEl.innerHTML = '';

    if (this.currentPath !== '/') {
      const back = this.createFileItem({
        name: '..', path: this.getParent(), is_dir: true, size: 0
      }, true);
      this.listEl.appendChild(back);
    }

    files.forEach(f => {
      this.listEl.appendChild(this.createFileItem(f));
    });
  }

  createFileItem(file, isBack = false) {
    const div = document.createElement('div');
    div.className = 'file-item';
    const icon = isBack ? '⬆️' : file.is_dir ? '📁' : this.getFileIcon(file.name);
    const size = file.is_dir ? '' : formatBytes(file.size);
    const date = file.modified ? formatDate(file.modified) : '';

    div.innerHTML = `
      <div class="file-icon">${icon}</div>
      <div class="file-name">${isBack ? 'Go up' : file.name}</div>
      <div class="file-size">${size}</div>
      <div class="file-date">${date}</div>
      ${!isBack ? `<div class="file-actions">
        ${!file.is_dir && this.isEditable(file.name) ? `<button class="btn btn-ghost btn-sm btn-icon" title="Edit" onclick="fileManager.editFile('${file.path}')">✏️</button>` : ''}
        <button class="btn btn-ghost btn-sm btn-icon" title="Move" onclick="fileManager.movePrompt('${file.path}','${file.name}')">➡️</button>
        <button class="btn btn-ghost btn-sm btn-icon" title="Rename" onclick="fileManager.renamePrompt('${file.path}','${file.name}')">🔤</button>
        <button class="btn btn-ghost btn-sm btn-icon text-danger" title="Delete" onclick="fileManager.deleteFile('${file.path}','${file.is_dir}')">🗑️</button>
      </div>` : ''}
    `;

    div.addEventListener('click', (e) => {
      if (e.target.closest('.file-actions')) return;
      if (file.is_dir) {
        this.navigate(isBack ? file.path : file.path);
      } else {
        if (e.ctrlKey || e.metaKey) {
          this.toggleSelect(file.path, div);
        }
      }
    });

    div.addEventListener('dblclick', () => {
      if (!file.is_dir && this.isEditable(file.name)) {
        this.editFile(file.path);
      }
    });

    return div;
  }

  getFileIcon(name) {
    const ext = name.split('.').pop().toLowerCase();
    const icons = {
      jar: '☕', zip: '📦', yml: '⚙️', yaml: '⚙️',
      json: '📋', txt: '📄', log: '📊', sh: '💻',
      bat: '💻', properties: '⚙️', py: '🐍', js: '📜',
      html: '🌐', xml: '📄', conf: '⚙️', cfg: '⚙️'
    };
    return icons[ext] || '📄';
  }

  isEditable(name) {
    const ext = name.split('.').pop().toLowerCase();
    const editables = ['txt','log','yml','yaml','json','xml','properties','sh','bat',
      'cfg','conf','config','py','js','html','css','java','kt','lua','toml','ini','env','md'];
    return editables.includes(ext);
  }

  toggleSelect(path, el) {
    if (this.selected.has(path)) {
      this.selected.delete(path);
      el.classList.remove('selected');
    } else {
      this.selected.add(path);
      el.classList.add('selected');
    }
    this.updateSelectionUI();
  }

  updateSelectionUI() {
    const bar = document.getElementById('selection-bar');
    const countEl = document.getElementById('selection-count');
    if (bar) bar.style.display = this.selected.size ? 'flex' : 'none';
    if (countEl) countEl.textContent = this.selected.size;
  }

  getParent() {
    const parts = this.currentPath.replace(/\/+$/, '').split('/');
    parts.pop();
    return parts.join('/') || '/';
  }

  updateBreadcrumb(path) {
    if (!this.breadcrumbEl) return;
    const parts = path.replace(/^\//, '').split('/').filter(Boolean);
    let html = `<span class="breadcrumb-item"><a href="#" onclick="fileManager.navigate('/')">Root</a></span>`;
    let built = '';
    parts.forEach((p, i) => {
      built += '/' + p;
      const isLast = i === parts.length - 1;
      html += `<span class="breadcrumb-sep">/</span>`;
      if (isLast) {
        html += `<span class="breadcrumb-item active">${p}</span>`;
      } else {
        const navPath = built;
        html += `<span class="breadcrumb-item"><a href="#" onclick="fileManager.navigate('${navPath}')">${p}</a></span>`;
      }
    });
    this.breadcrumbEl.innerHTML = html;
  }

  async editFile(path) {
    try {
      const data = await apiFetch(`/server/${this.serverId}/files/read?path=${encodeURIComponent(path)}`);
      const modal = document.getElementById('editor-modal');
      const textarea = document.getElementById('editor-content');
      const titleEl = document.getElementById('editor-title');
      const pathEl = document.getElementById('editor-path');
      if (!modal || !textarea) return;
      if (titleEl) titleEl.textContent = path.split('/').pop();
      if (pathEl) pathEl.value = path;
      textarea.value = data.content || '';
      openModal('editor-modal');
    } catch(e) {
      Toast.error(e.message);
    }
  }

  async saveFile() {
    const textarea = document.getElementById('editor-content');
    const pathEl = document.getElementById('editor-path');
    if (!textarea || !pathEl) return;
    try {
      await apiFetch(`/server/${this.serverId}/files/write`, {
        method: 'POST',
        body: JSON.stringify({ path: pathEl.value, content: textarea.value })
      });
      Toast.success('File saved.');
      closeModal('editor-modal');
    } catch(e) {
      Toast.error(e.message);
    }
  }

  async createFolder() {
    const name = prompt('Folder name:');
    if (!name) return;
    try {
      await apiFetch(`/server/${this.serverId}/files/create-folder`, {
        method: 'POST',
        body: JSON.stringify({ path: this.currentPath, name })
      });
      Toast.success('Folder created.');
      this.navigate(this.currentPath);
    } catch(e) {
      Toast.error(e.message);
    }
  }

  async renamePrompt(path, name) {
    const newName = prompt('New name:', name);
    if (!newName || newName === name) return;
    const dir = path.substring(0, path.lastIndexOf('/') + 1);
    const newPath = dir + newName;
    try {
      await apiFetch(`/server/${this.serverId}/files/rename`, {
        method: 'POST',
        body: JSON.stringify({ from: path, to: newPath })
      });
      Toast.success('Renamed.');
      this.navigate(this.currentPath);
    } catch(e) {
      Toast.error(e.message);
    }
  }

  async deleteFile(path, isDir) {
    if (!confirm(`Delete "${path.split('/').pop()}"? This cannot be undone.`)) return;
    try {
      await apiFetch(`/server/${this.serverId}/files/delete`, {
        method: 'POST',
        body: JSON.stringify({ paths: [path] })
      });
      Toast.success('Deleted.');
      this.navigate(this.currentPath);
    } catch(e) {
      Toast.error(e.message);
    }
  }

  async deleteSelected() {
    if (!this.selected.size) return;
    if (!confirm(`Delete ${this.selected.size} item(s)?`)) return;
    try {
      await apiFetch(`/server/${this.serverId}/files/delete`, {
        method: 'POST',
        body: JSON.stringify({ paths: [...this.selected] })
      });
      Toast.success('Deleted selected items.');
      this.navigate(this.currentPath);
    } catch(e) {
      Toast.error(e.message);
    }
  }

  uploadFiles(files) {
    if (!files.length) return;
    // Har file ko alag XHR se upload karte hain taaki har ek ka apna % dikh sake.
    files.forEach(f => this._uploadSingleFile(f));
  }

  _uploadSingleFile(file) {
    const formData = new FormData();
    formData.append('path', this.currentPath);
    formData.append('files', file);

    const row = this._createProgressRow(file.name);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', `/server/${this.serverId}/files/upload`, true);
    xhr.setRequestHeader('X-CSRFToken', getCsrfToken());

    xhr.upload.addEventListener('progress', (e) => {
      if (!e.lengthComputable) return;
      const pct = Math.round((e.loaded / e.total) * 100);
      this._updateProgressRow(row, pct);
    });

    xhr.addEventListener('load', () => {
      let ok = false;
      try {
        const data = JSON.parse(xhr.responseText);
        ok = (data.results || []).some(r => r.success);
      } catch (e) { /* ignore */ }
      this._updateProgressRow(row, 100, ok ? 'done' : 'error');
      if (ok) {
        Toast.success(`${file.name} uploaded.`);
        this.navigate(this.currentPath);
      } else {
        Toast.error(`${file.name} failed to upload.`);
      }
      setTimeout(() => row.remove(), ok ? 1500 : 4000);
    });

    xhr.addEventListener('error', () => {
      this._updateProgressRow(row, 0, 'error');
      Toast.error(`${file.name} failed to upload.`);
    });

    xhr.send(formData);
  }

  _createProgressRow(filename) {
    let container = document.getElementById('upload-progress-list');
    if (!container) {
      container = document.createElement('div');
      container.id = 'upload-progress-list';
      container.style.cssText = 'display:flex;flex-direction:column;gap:6px;margin-bottom:12px;';
      this.listEl?.parentElement?.insertBefore(container, this.listEl);
    }
    const row = document.createElement('div');
    row.className = 'upload-progress-row';
    row.style.cssText = 'padding:8px 12px;background:rgba(99,102,241,.08);border-radius:8px;';
    row.innerHTML = `
      <div class="d-flex justify-between align-center" style="margin-bottom:4px;">
        <span class="text-sm">⬆️ ${filename}</span>
        <span class="text-sm upload-pct">0%</span>
      </div>
      <div style="height:6px;background:rgba(255,255,255,.1);border-radius:4px;overflow:hidden;">
        <div class="upload-bar" style="height:100%;width:0%;background:var(--primary,#6366f1);transition:width .15s;"></div>
      </div>`;
    container.appendChild(row);
    return row;
  }

  _updateProgressRow(row, pct, state) {
    const bar = row.querySelector('.upload-bar');
    const label = row.querySelector('.upload-pct');
    if (bar) bar.style.width = pct + '%';
    if (label) label.textContent = state === 'error' ? 'Failed' : (pct + '%');
    if (state === 'error' && bar) bar.style.background = '#ef4444';
    if (state === 'done' && bar) bar.style.background = '#22c55e';
  }

  async createFolderAt(targetPath) {
    // targetPath jaisa "/plugins/new-name" — parent + name split
    const parts = targetPath.replace(/\/+$/, '').split('/');
    const name = parts.pop();
    const path = parts.join('/') || '/';
    return apiFetch(`/server/${this.serverId}/files/create-folder`, {
      method: 'POST',
      body: JSON.stringify({ path, name })
    });
  }

  async movePrompt(path, name) {
    const dest = prompt(`Move "${name}" to which folder? (e.g. /plugins or /)`, this.currentPath);
    if (dest === null) return;
    const cleanDest = dest.trim() || '/';
    const newPath = (cleanDest === '/' ? '' : cleanDest.replace(/\/+$/, '')) + '/' + name;
    try {
      await apiFetch(`/server/${this.serverId}/files/rename`, {
        method: 'POST',
        body: JSON.stringify({ from: path, to: newPath })
      });
      Toast.success(`Moved to ${cleanDest}`);
      this.navigate(this.currentPath);
    } catch(e) {
      Toast.error(e.message);
    }
  }

  async moveSelected() {
    if (!this.selected.size) return;
    const dest = prompt(`Move ${this.selected.size} item(s) to which folder? (e.g. /plugins or /)`, this.currentPath);
    if (dest === null) return;
    const cleanDest = dest.trim() || '/';
    const destPrefix = cleanDest === '/' ? '' : cleanDest.replace(/\/+$/, '');
    let success = 0, failed = 0;
    for (const path of this.selected) {
      const name = path.split('/').pop();
      try {
        await apiFetch(`/server/${this.serverId}/files/rename`, {
          method: 'POST',
          body: JSON.stringify({ from: path, to: `${destPrefix}/${name}` })
        });
        success++;
      } catch (e) { failed++; }
    }
    if (success) Toast.success(`${success} item(s) moved.`);
    if (failed) Toast.error(`${failed} item(s) failed to move.`);
    this.navigate(this.currentPath);
  }

  async searchFiles(query) {
    if (!query) return;
    try {
      const data = await apiFetch(`/server/${this.serverId}/files/search?q=${encodeURIComponent(query)}&path=${encodeURIComponent(this.currentPath)}`);
      this.renderFiles(data.results || []);
    } catch(e) {
      Toast.error(e.message);
    }
  }

  bindButtons() {
    const newFolderBtn = document.getElementById('btn-new-folder');
    if (newFolderBtn) newFolderBtn.addEventListener('click', () => this.createFolder());

    const uploadBtn = document.getElementById('btn-upload');
    if (uploadBtn && this.uploadInput) {
      uploadBtn.addEventListener('click', () => this.uploadInput.click());
      this.uploadInput.addEventListener('change', () => {
        this.uploadFiles(Array.from(this.uploadInput.files));
        this.uploadInput.value = '';
      });
    }

    const saveBtn = document.getElementById('btn-save-file');
    if (saveBtn) saveBtn.addEventListener('click', () => this.saveFile());

    const deleteSelBtn = document.getElementById('btn-delete-selected');
    if (deleteSelBtn) deleteSelBtn.addEventListener('click', () => this.deleteSelected());

    const moveSelBtn = document.getElementById('btn-move-selected');
    if (moveSelBtn) moveSelBtn.addEventListener('click', () => this.moveSelected());

    const searchInput = document.getElementById('file-search');
    let searchTimeout;
    if (searchInput) {
      searchInput.addEventListener('input', () => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
          const q = searchInput.value.trim();
          if (q) this.searchFiles(q);
          else this.navigate(this.currentPath);
        }, 400);
      });
    }

    const uploadZone = document.getElementById('upload-zone');
    if (uploadZone) {
      uploadZone.addEventListener('dragover', e => { e.preventDefault(); uploadZone.classList.add('dragover'); });
      uploadZone.addEventListener('dragleave', () => uploadZone.classList.remove('dragover'));
      uploadZone.addEventListener('drop', e => {
        e.preventDefault();
        uploadZone.classList.remove('dragover');
        const files = Array.from(e.dataTransfer.files);
        if (files.length) this.uploadFiles(files);
      });
    }
  }
}

window.FileManager = FileManager;
