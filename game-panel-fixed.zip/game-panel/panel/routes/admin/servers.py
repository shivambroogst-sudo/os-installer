import os
from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from ...extensions import db
from ...models.server import Server
from ...models.node import Node
from ...models.user import User
from ...models.allocation import Allocation
from ...utils.decorators import admin_required
from ...utils.auth import log_activity
from ...utils.helpers import get_next_folder_number, get_expiry_date, call_daemon, notify_user
from ... import eggs

admin_servers_bp = Blueprint('admin_servers', __name__, url_prefix='/admin/servers')


@admin_servers_bp.route('/')
@login_required
@admin_required
def list_servers():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    status_filter = request.args.get('status', '')
    node_filter = request.args.get('node_id', type=int)

    query = Server.query
    if search:
        query = query.filter(Server.name.ilike(f'%{search}%'))
    if status_filter:
        query = query.filter_by(status=status_filter)
    if node_filter:
        query = query.filter_by(node_id=node_filter)

    servers = query.order_by(Server.created_at.desc()).paginate(page=page, per_page=20)
    nodes = Node.query.filter_by(is_active=True).all()
    return render_template('admin/servers.html', servers=servers, nodes=nodes,
                           search=search, status_filter=status_filter, node_filter=node_filter)


@admin_servers_bp.route('/create', methods=['GET', 'POST'])
@login_required
@admin_required
def create_server():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        owner_id = request.form.get('owner_id', type=int)
        node_id = request.form.get('node_id', type=int)
        alloc_id = request.form.get('allocation_id', type=int)
        ram = request.form.get('ram', 1024, type=int)
        cpu = request.form.get('cpu', 100.0, type=float)
        disk = request.form.get('disk', 10240, type=int)
        java_version = request.form.get('java_version', 'java').strip()
        java_path = request.form.get('java_path', 'java').strip()
        egg_id = request.form.get('egg_id', '').strip()
        egg_version = request.form.get('egg_version', '').strip()
        startup_command = request.form.get('startup_command', '').strip()
        if not startup_command:
            startup_command = eggs.default_startup(egg_id) if egg_id else 'java -jar server.jar'
        description = request.form.get('description', '')
        auto_start = request.form.get('auto_start') == 'on'
        auto_restart = request.form.get('auto_restart') == 'on'
        expiry_option = request.form.get('expiry_option', 'none')
        custom_expiry = request.form.get('custom_expiry', '')

        if not name or not owner_id or not node_id or not alloc_id:
            flash('Name, owner, node, and allocation are required.', 'danger')
            return redirect(url_for('admin_servers.create_server'))

        node = Node.query.get_or_404(node_id)
        owner = User.query.get_or_404(owner_id)
        allocation = Allocation.query.get_or_404(alloc_id)

        if allocation.server_id:
            flash('Selected allocation is already in use.', 'danger')
            return redirect(url_for('admin_servers.create_server'))

        folder_number = get_next_folder_number()
        expiry_date = None
        if expiry_option != 'none':
            expiry_date = get_expiry_date(expiry_option, custom_expiry)

        server = Server(
            name=name,
            description=description,
            owner_id=owner_id,
            node_id=node_id,
            folder_number=folder_number,
            ram_limit=ram,
            cpu_limit=cpu,
            disk_limit=disk,
            java_version=java_version,
            java_path=java_path,
            startup_command=startup_command,
            auto_start=auto_start,
            auto_restart=auto_restart,
            expiry_date=expiry_date,
            expiry_days=int(expiry_option) if expiry_option.isdigit() else None,
            egg_id=egg_id or None,
            egg_version=egg_version or None,
            install_status='pending' if egg_id else 'none'
        )
        db.session.add(server)
        db.session.flush()

        allocation.server_id = server.id
        allocation.is_primary = True

        servers_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.dirname(__file__)))), 'servers', str(folder_number))
        os.makedirs(servers_dir, exist_ok=True)

        db.session.commit()

        daemon_payload = {
            'server_id': server.id,
            'folder': str(folder_number),
            'ram': ram,
            'cpu': cpu,
            'disk': disk,
            'java_path': java_path,
            'startup_command': startup_command,
            'jar_file': server.jar_file,
            'ip': allocation.ip_address,
            'port': allocation.port,
            'auto_start': auto_start,
            'auto_restart': auto_restart
        }
        if egg_id and egg_version:
            daemon_payload['egg'] = egg_id
            daemon_payload['egg_version'] = egg_version

        data, err = call_daemon(node, 'POST', '/api/servers/create', daemon_payload)

        if err:
            flash(f'Server created locally but daemon error: {err}', 'warning')
        elif egg_id and egg_version:
            flash(f'Server "{name}" create ho gaya. {eggs.get_egg(egg_id)["name"]} {egg_version} '
                 f'background me install ho raha hai — console me progress dekh sakte hain.', 'success')
        else:
            flash(f'Server "{name}" created successfully.', 'success')

        notify_user(owner_id, 'Server Created',
                    f'Your server "{name}" has been created.',
                    'success', url_for('user_dashboard.dashboard'))
        log_activity('server_created', f'Created server: {name} (folder {folder_number})',
                     server_id=server.id)
        return redirect(url_for('admin_servers.list_servers'))

    nodes = Node.query.filter_by(is_active=True).all()
    users = User.query.filter_by(is_active=True).all()
    return render_template('admin/server_create.html', nodes=nodes, users=users)


@admin_servers_bp.route('/eggs')
@login_required
@admin_required
def list_eggs():
    return jsonify(eggs.list_eggs())


@admin_servers_bp.route('/eggs/<egg_id>/versions')
@login_required
@admin_required
def egg_versions(egg_id):
    versions = eggs.fetch_versions(egg_id)
    return jsonify({'versions': versions})


@admin_servers_bp.route('/<int:server_id>/change-version', methods=['POST'])
@login_required
@admin_required
def change_version(server_id):
    """
    One-click version/software changer — server ke world/plugins/config files
    ko touch kiye bina bas jar file dobara install karta hai (jaise Paper
    1.21.1 se Spigot 1.21.1, ya Paper ka koi bhi version badalna).
    """
    server = Server.query.get_or_404(server_id)
    egg_id = request.form.get('egg_id', '').strip()
    egg_version = request.form.get('egg_version', '').strip()
    if not egg_id or not egg_version:
        return jsonify({'error': 'egg_id and egg_version are required'}), 400
    if egg_id not in eggs.EGGS:
        return jsonify({'error': 'Unknown software'}), 400

    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400

    server.egg_id = egg_id
    server.egg_version = egg_version
    server.install_status = 'pending'
    if not server.startup_command or request.form.get('reset_startup') == 'on':
        server.startup_command = eggs.default_startup(egg_id)
    db.session.commit()

    call_daemon(node, 'POST', f'/api/servers/{server_id}/stop', {})
    data, err = call_daemon(node, 'POST', f'/api/servers/{server_id}/install', {
        'folder': str(server.folder_number),
        'egg': egg_id,
        'egg_version': egg_version,
        'auto_start': False
    })
    if err:
        return jsonify({'error': err}), 500

    log_activity('server_version_changed', f'{server.name}: switched to {eggs.get_egg(egg_id)["name"]} {egg_version}',
                server_id=server_id)
    notify_user(server.owner_id, 'Server Software Changed',
               f'"{server.name}" is now being switched to {eggs.get_egg(egg_id)["name"]} {egg_version}.',
               'info', url_for('user_console.console', server_id=server_id))
    return jsonify({'success': True})


@admin_servers_bp.route('/<int:server_id>/suspend', methods=['POST'])
@login_required
@admin_required
def suspend_server(server_id):
    server = Server.query.get_or_404(server_id)
    reason = request.form.get('reason', 'Suspended by administrator')
    server.is_suspended = True
    server.suspension_reason = reason
    db.session.commit()
    node = server.node
    if node:
        call_daemon(node, 'POST', f'/api/servers/{server_id}/stop', {})
    log_activity('server_suspended', f'Suspended: {server.name}', server_id=server_id)
    return jsonify({'success': True})


@admin_servers_bp.route('/<int:server_id>/unsuspend', methods=['POST'])
@login_required
@admin_required
def unsuspend_server(server_id):
    server = Server.query.get_or_404(server_id)
    server.is_suspended = False
    server.suspension_reason = None
    db.session.commit()
    log_activity('server_unsuspended', f'Unsuspended: {server.name}', server_id=server_id)
    notify_user(server.owner_id, 'Server Unsuspended',
                f'Your server "{server.name}" has been unsuspended.', 'success')
    return jsonify({'success': True})


@admin_servers_bp.route('/<int:server_id>/renew', methods=['POST'])
@login_required
@admin_required
def renew_server(server_id):
    server = Server.query.get_or_404(server_id)
    expiry_option = request.form.get('expiry_option', '30')
    custom_expiry = request.form.get('custom_expiry', '')
    new_expiry = get_expiry_date(expiry_option, custom_expiry)
    if new_expiry:
        server.expiry_date = new_expiry
        if server.is_suspended and server.suspension_reason == 'Expired':
            server.is_suspended = False
            server.suspension_reason = None
        db.session.commit()
        notify_user(server.owner_id, 'Server Renewed',
                    f'Your server "{server.name}" has been renewed until {new_expiry.strftime("%Y-%m-%d")}.', 'success')
        log_activity('server_renewed', f'Renewed {server.name} to {new_expiry}', server_id=server_id)
        return jsonify({'success': True, 'expiry': new_expiry.strftime('%Y-%m-%d')})
    return jsonify({'error': 'Invalid expiry option'}), 400


@admin_servers_bp.route('/<int:server_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_server(server_id):
    server = Server.query.get_or_404(server_id)
    node = server.node
    if node:
        call_daemon(node, 'DELETE', f'/api/servers/{server_id}', {})
    name = server.name
    Allocation.query.filter_by(server_id=server_id).update({
        'server_id': None, 'is_primary': False
    })
    db.session.delete(server)
    db.session.commit()
    log_activity('server_deleted', f'Deleted server: {name}')
    return jsonify({'success': True})


@admin_servers_bp.route('/<int:server_id>/power/<action>', methods=['POST'])
@login_required
@admin_required
def power_action(server_id, action):
    server = Server.query.get_or_404(server_id)
    if action not in ('start', 'stop', 'restart', 'kill'):
        return jsonify({'error': 'Invalid action'}), 400
    node = server.node
    if not node:
        return jsonify({'error': 'Node not found'}), 400
    data, err = call_daemon(node, 'POST', f'/api/servers/{server_id}/{action}', {})
    if err:
        return jsonify({'error': err}), 500
    log_activity(f'server_{action}', f'{action.capitalize()} server: {server.name}', server_id=server_id)
    return jsonify({'success': True})
