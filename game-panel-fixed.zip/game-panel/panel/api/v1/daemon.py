from datetime import datetime
from flask import Blueprint, request, jsonify, current_app
from ...extensions import db, socketio
from ...models.node import Node
from ...models.server import Server
from ...models.backup import Backup

api_daemon_bp = Blueprint('api_daemon', __name__, url_prefix='/api/daemon')


def _verify_secret():
    secret = request.headers.get('X-Daemon-Secret')
    return secret == current_app.config.get('DAEMON_SECRET', '')


_LOCALHOST_ALIASES = {'127.0.0.1', 'localhost', '::1', '0.0.0.0'}


@api_daemon_bp.route('/heartbeat', methods=['POST'])
def heartbeat():
    if not _verify_secret():
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json() or {}
    node_fqdn = data.get('fqdn') or request.remote_addr
    node_id   = data.get('node_id')
    hostname  = data.get('hostname', '')

    node = None

    # 1) By explicit node_id (most reliable)
    if node_id:
        node = db.session.get(Node, int(node_id))

    # 2) By exact FQDN or hostname
    if not node:
        node = Node.query.filter(
            (Node.fqdn == node_fqdn) |
            (Node.fqdn == hostname)
        ).first()

    # 3) localhost / 127.0.0.1 / ::1 are all equivalent — try all aliases
    if not node and node_fqdn in _LOCALHOST_ALIASES:
        node = Node.query.filter(Node.fqdn.in_(_LOCALHOST_ALIASES)).first()

    # 4) Fall back to request's actual remote IP
    if not node and request.remote_addr:
        node = Node.query.filter(Node.fqdn == request.remote_addr).first()

    if not node:
        return jsonify({'error': 'Node not found'}), 404

    node.last_heartbeat = datetime.utcnow()
    node.cpu_percent = data.get('cpu_percent', 0.0)
    node.memory_used = data.get('memory_used', 0)
    node.memory_total = data.get('memory_total', 0)
    node.disk_used = data.get('disk_used', 0)
    node.disk_total = data.get('disk_total', 0)
    node.java_version = data.get('java_version', node.java_version)
    node.os_info = data.get('os_info', node.os_info)
    node.ping_ms = data.get('ping_ms', 0)
    db.session.commit()

    socketio.emit('node_stats', {
        'node_id': node.id,
        'cpu': node.cpu_percent,
        'memory_used': node.memory_used,
        'memory_total': node.memory_total,
        'disk_used': node.disk_used,
        'disk_total': node.disk_total,
        'online': True
    }, room=f'node_stats_{node.id}')

    return jsonify({'ok': True})


@api_daemon_bp.route('/server-status', methods=['POST'])
def server_status():
    if not _verify_secret():
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json() or {}
    server_id = data.get('server_id')
    status = data.get('status')
    pid = data.get('pid')

    if not server_id or not status:
        return jsonify({'error': 'Missing fields'}), 400

    server = db.session.get(Server, server_id)
    if not server:
        return jsonify({'error': 'Server not found'}), 404

    server.status = status
    if pid:
        server.pid = pid
    db.session.commit()

    socketio.emit('server_status', {
        'server_id': server_id,
        'status': status
    }, room=f'console_{server_id}')

    return jsonify({'ok': True})


@api_daemon_bp.route('/console-output', methods=['POST'])
def console_output():
    if not _verify_secret():
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json() or {}
    server_id = data.get('server_id')
    output = data.get('output', '')

    if server_id:
        socketio.emit('console_output', {
            'output': output
        }, room=f'console_{server_id}')

    return jsonify({'ok': True})


@api_daemon_bp.route('/install-status', methods=['POST'])
def install_status():
    if not _verify_secret():
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json() or {}
    server_id = data.get('server_id')
    status = data.get('status')
    jar_file = data.get('jar_file')
    startup_command = data.get('startup_command')

    if not server_id or not status:
        return jsonify({'error': 'Missing fields'}), 400

    server = db.session.get(Server, server_id)
    if not server:
        return jsonify({'error': 'Server not found'}), 404

    server.install_status = status
    if jar_file:
        server.jar_file = jar_file
    if startup_command:
        server.startup_command = startup_command
    if status == 'installed':
        server.status = 'offline'
    db.session.commit()

    socketio.emit('console_output', {
        'output': f'\r\n\x1b[36m[Panel] Install status: {status}\x1b[0m\r\n'
    }, room=f'console_{server_id}')
    socketio.emit('install_status', {
        'server_id': server_id,
        'status': status
    }, room=f'console_{server_id}')

    return jsonify({'ok': True})


@api_daemon_bp.route('/backup-complete', methods=['POST'])
def backup_complete():
    if not _verify_secret():
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json() or {}
    backup_id = data.get('backup_id')
    success = data.get('success', False)
    size = data.get('size', 0)

    backup = db.session.get(Backup, backup_id)
    if backup:
        backup.status = 'completed' if success else 'failed'
        backup.size = size
        backup.completed_at = datetime.utcnow()
        db.session.commit()

    return jsonify({'ok': True})


@api_daemon_bp.route('/crash', methods=['POST'])
def server_crash():
    if not _verify_secret():
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json() or {}
    server_id = data.get('server_id')

    server = db.session.get(Server, server_id)
    if server:
        server.status = 'crashed'
        db.session.commit()
        socketio.emit('server_status', {
            'server_id': server_id,
            'status': 'crashed'
        }, room=f'console_{server_id}')
        socketio.emit('console_output', {
            'output': '\r\n\x1b[31m[Panel] Server crashed!\x1b[0m\r\n'
        }, room=f'console_{server_id}')

    return jsonify({'ok': True})
