"""
Egg registry — Pterodactyl-style "software marketplace" Minecraft ecosystem
ke liye. Har egg ek downloadable/buildable server software hai. Panel side
sirf metadata + version list dikhata hai; asli download/build daemon karta
hai (daemon/installer.py).
"""
import requests

REQUEST_TIMEOUT = 8

EGGS = {
    'vanilla':    {'name': 'Vanilla Minecraft', 'category': 'Vanilla', 'icon': '🟩',
                  'description': 'Official Mojang Minecraft server, no plugins/mods.'},
    'paper':      {'name': 'Paper', 'category': 'Plugins', 'icon': '📄',
                  'description': 'High performance Spigot fork with plugin support.'},
    'purpur':     {'name': 'Purpur', 'category': 'Plugins', 'icon': '🟣',
                  'description': 'Paper fork with extra features and configs.'},
    'spigot':     {'name': 'Spigot', 'category': 'Plugins', 'icon': '🧩',
                  'description': 'Classic plugin server, built locally via BuildTools.'},
    'fabric':     {'name': 'Fabric', 'category': 'Modded', 'icon': '🧵',
                  'description': 'Lightweight modding platform.'},
    'forge':      {'name': 'Forge', 'category': 'Modded', 'icon': '🔨',
                  'description': 'Most widely used modding platform for Minecraft.'},
    'bungeecord': {'name': 'BungeeCord', 'category': 'Proxy', 'icon': '🌉',
                  'description': 'Proxy server to link multiple Minecraft servers.'},
    'waterfall':  {'name': 'Waterfall', 'category': 'Proxy', 'icon': '💧',
                  'description': 'PaperMC-maintained BungeeCord fork.'},
    'velocity':   {'name': 'Velocity', 'category': 'Proxy', 'icon': '🚀',
                  'description': 'Modern, high performance Minecraft proxy.'},
}

DEFAULT_STARTUP = {
    'vanilla':    'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    'paper':      'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    'purpur':     'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    'spigot':     'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    'fabric':     'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    'forge':      'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui',
    'bungeecord': 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}',
    'waterfall':  'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}',
    'velocity':   'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}',
}


def list_eggs():
    return [{'id': k, **v} for k, v in EGGS.items()]


def get_egg(egg_id):
    return EGGS.get(egg_id)


def default_startup(egg_id):
    return DEFAULT_STARTUP.get(egg_id, 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}} nogui')


def fetch_versions(egg_id):
    try:
        if egg_id in ('vanilla', 'spigot'):
            return _mojang_release_versions()
        if egg_id in ('paper', 'waterfall', 'velocity'):
            return _papermc_versions(egg_id)
        if egg_id == 'purpur':
            return _purpur_versions()
        if egg_id == 'fabric':
            return _mojang_release_versions()
        if egg_id == 'forge':
            return _forge_versions()
        if egg_id == 'bungeecord':
            return ['latest']
    except Exception:
        return []
    return []


def _mojang_release_versions():
    r = requests.get('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json', timeout=REQUEST_TIMEOUT)
    r.raise_for_status()
    data = r.json()
    return [v['id'] for v in data['versions'] if v['type'] == 'release']


def _papermc_versions(project):
    r = requests.get(f'https://api.papermc.io/v2/projects/{project}', timeout=REQUEST_TIMEOUT)
    r.raise_for_status()
    versions = r.json().get('versions', [])
    return list(reversed(versions))


def _purpur_versions():
    r = requests.get('https://api.purpurmc.org/v2/purpur', timeout=REQUEST_TIMEOUT)
    r.raise_for_status()
    versions = r.json().get('versions', [])
    return list(reversed(versions))


def _forge_versions():
    r = requests.get('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json',
                     timeout=REQUEST_TIMEOUT)
    r.raise_for_status()
    promos = r.json().get('promos', {})
    out = set()
    for key, val in promos.items():
        if key.endswith('-recommended') or key.endswith('-latest'):
            mcver = key.split('-')[0]
            out.add(f'{mcver}-{val}')
    return sorted(out, reverse=True)
