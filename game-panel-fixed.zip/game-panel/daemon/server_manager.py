import os
import threading
import logging
from .process_manager import ServerProcess

logger = logging.getLogger(__name__)


class ServerManager:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._processes = {}
                cls._instance._servers_dir = None
                cls._instance._panel_url = None
                cls._instance._daemon_secret = None
        return cls._instance

    def initialize(self, servers_dir: str, panel_url: str, daemon_secret: str):
        self._servers_dir = servers_dir
        self._panel_url = panel_url
        self._daemon_secret = daemon_secret

    def create_server(self, server_id: int, folder: str, startup_command: str,
                      java_path: str, ip: str, port: int, ram: int, cpu: float,
                      auto_start: bool = False, auto_restart: bool = False,
                      jar_file: str = 'server.jar') -> dict:
        os.makedirs(os.path.join(self._servers_dir, str(folder)), exist_ok=True)

        proc = ServerProcess(
            server_id=server_id,
            folder=folder,
            startup_command=startup_command,
            java_path=java_path,
            ip=ip,
            port=port,
            ram=ram,
            cpu=cpu,
            panel_url=self._panel_url,
            daemon_secret=self._daemon_secret,
            auto_restart=auto_restart,
            jar_file=jar_file
        )
        self._processes[server_id] = proc

        if auto_start:
            return proc.start(self._servers_dir)
        return {'success': True, 'message': 'Server registered'}

    def update_process_config(self, server_id: int, startup_command: str = None,
                              jar_file: str = None, ram: int = None):
        proc = self._processes.get(server_id)
        if not proc:
            return {'error': 'Server not registered'}
        if startup_command is not None:
            proc.startup_command = startup_command
        if jar_file is not None:
            proc.jar_file = jar_file
        if ram is not None:
            proc.ram = ram
        return {'success': True}

    def install_server(self, server_id: int, folder: str, egg: str, version: str,
                       auto_start: bool = False) -> dict:
        from .installer import run_install

        def _on_complete(success, jar_name):
            if success and jar_name:
                self.update_process_config(server_id, jar_file=jar_name)
                if auto_start:
                    self.start_server(server_id)

        run_install(self._servers_dir, server_id, folder, egg, version,
                   self._panel_url, self._daemon_secret, on_complete=_on_complete)
        return {'success': True, 'message': 'Install started'}

    def start_server(self, server_id: int) -> dict:
        proc = self._processes.get(server_id)
        if not proc:
            return {'error': 'Server not registered in daemon'}
        return proc.start(self._servers_dir)

    def stop_server(self, server_id: int) -> dict:
        proc = self._processes.get(server_id)
        if not proc:
            return {'error': 'Server not registered'}
        proc.stop()
        return {'success': True}

    def restart_server(self, server_id: int) -> dict:
        proc = self._processes.get(server_id)
        if not proc:
            return {'error': 'Server not registered'}
        return proc.restart(self._servers_dir)

    def kill_server(self, server_id: int) -> dict:
        proc = self._processes.get(server_id)
        if not proc:
            return {'error': 'Server not registered'}
        proc.kill()
        return {'success': True}

    def send_command(self, server_id: int, command: str) -> dict:
        proc = self._processes.get(server_id)
        if not proc:
            return {'error': 'Server not registered'}
        success = proc.send_command(command)
        return {'success': success}

    def get_stats(self, server_id: int) -> dict:
        proc = self._processes.get(server_id)
        if not proc:
            return {'status': 'offline', 'ram_used': 0, 'cpu_used': 0, 'disk_used': 0}
        stats = proc.get_stats()
        server_dir = os.path.join(self._servers_dir, str(self._get_folder(server_id)))
        if os.path.isdir(server_dir):
            import shutil
            usage = shutil.disk_usage(server_dir)
            stats['disk_used'] = (usage.total - usage.free) // (1024 * 1024)
        return stats

    def delete_server(self, server_id: int, folder: str) -> dict:
        proc = self._processes.get(server_id)
        if proc:
            proc.kill()
            del self._processes[server_id]
        import shutil
        server_dir = os.path.join(self._servers_dir, str(folder))
        if os.path.isdir(server_dir):
            shutil.rmtree(server_dir, ignore_errors=True)
        return {'success': True}

    def _get_folder(self, server_id: int) -> str:
        proc = self._processes.get(server_id)
        return proc.folder if proc else str(server_id)

    def get_all_status(self) -> dict:
        return {sid: proc.get_stats() for sid, proc in self._processes.items()}
