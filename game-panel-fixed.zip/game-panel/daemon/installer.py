"""
Egg / software installer — Pterodactyl-jaisa "egg install" system.
Server create hote hi (ya version change pe), yeh module sahi jar file
download/build karke server folder me daal deta hai, phir panel ko progress
console output ke through bhejta hai.
"""
import os
import re
import shutil
import subprocess
import threading
import logging
import requests

logger = logging.getLogger(__name__)

REQUEST_TIMEOUT = 30
DOWNLOAD_TIMEOUT = 300

# Eggs jinme Minecraft EULA accept karna zaroori nahi (proxy software)
NO_EULA_EGGS = {'bungeecord', 'waterfall', 'velocity'}


def run_install(servers_dir, server_id, folder, egg, version, panel_url, daemon_secret, on_complete=None):
    thread = threading.Thread(
        target=_install_worker,
        args=(servers_dir, server_id, folder, egg, version, panel_url, daemon_secret, on_complete),
        daemon=True
    )
    thread.start()
    return thread


def _report(panel_url, secret, server_id, line):
    try:
        requests.post(
            f'{panel_url}/api/daemon/console-output',
            json={'server_id': server_id, 'output': line + '\r\n'},
            headers={'X-Daemon-Secret': secret},
            timeout=5
        )
    except Exception:
        pass


def _report_status(panel_url, secret, server_id, status, jar_file=None, startup_command=None, progress=None):
    payload = {'server_id': server_id, 'status': status}
    if jar_file:
        payload['jar_file'] = jar_file
    if startup_command:
        payload['startup_command'] = startup_command
    if progress is not None:
        payload['progress'] = progress
    try:
        requests.post(
            f'{panel_url}/api/daemon/install-status',
            json=payload,
            headers={'X-Daemon-Secret': secret},
            timeout=5
        )
    except Exception:
        pass


def _download(url, dest, panel_url, secret, server_id, label):
    _report(panel_url, secret, server_id, f'[Installer] Downloading {label}...')
    with requests.get(url, stream=True, timeout=DOWNLOAD_TIMEOUT) as r:
        r.raise_for_status()
        total = int(r.headers.get('content-length', 0))
        written = 0
        last_pct = -1
        with open(dest, 'wb') as f:
            for chunk in r.iter_content(chunk_size=262144):
                if not chunk:
                    continue
                f.write(chunk)
                written += len(chunk)
                if total:
                    pct = int(written * 100 / total)
                    if pct != last_pct and pct % 10 == 0:
                        last_pct = pct
                        _report(panel_url, secret, server_id, f'[Installer] {label}: {pct}%')
    _report(panel_url, secret, server_id, f'[Installer] {label} downloaded ({written // 1024} KB).')


def _write_eula(server_path, egg):
    if egg in NO_EULA_EGGS:
        return
    with open(os.path.join(server_path, 'eula.txt'), 'w') as f:
        f.write('eula=true\n')


def _run(cmd, cwd, panel_url, secret, server_id, label):
    _report(panel_url, secret, server_id, f'[Installer] {label}: {" ".join(cmd)}')
    proc = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    for line in iter(proc.stdout.readline, ''):
        if line:
            _report(panel_url, secret, server_id, line.rstrip())
    proc.wait()
    if proc.returncode != 0:
        raise RuntimeError(f'{label} exited with code {proc.returncode}')


# ---------------------------------------------------------------------------
# Version / URL resolution
# ---------------------------------------------------------------------------

def _vanilla_url(version):
    manifest = requests.get('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json',
                            timeout=REQUEST_TIMEOUT).json()
    entry = next((v for v in manifest['versions'] if v['id'] == version), None)
    if not entry:
        raise ValueError(f'Vanilla version not found: {version}')
    version_data = requests.get(entry['url'], timeout=REQUEST_TIMEOUT).json()
    return version_data['downloads']['server']['url']


def _papermc_url(project, version):
    versions_resp = requests.get(f'https://api.papermc.io/v2/projects/{project}/versions/{version}/builds',
                                 timeout=REQUEST_TIMEOUT)
    versions_resp.raise_for_status()
    builds = versions_resp.json().get('builds', [])
    if not builds:
        raise ValueError(f'{project} version not found: {version}')
    default_builds = [b for b in builds if b.get('channel') == 'default'] or builds
    build = default_builds[-1]
    build_num = build['build']
    filename = build['downloads']['application']['name']
    return f'https://api.papermc.io/v2/projects/{project}/versions/{version}/builds/{build_num}/downloads/{filename}'


def _purpur_url(version):
    info = requests.get(f'https://api.purpurmc.org/v2/purpur/{version}', timeout=REQUEST_TIMEOUT).json()
    build = info.get('builds', {}).get('latest')
    if not build:
        raise ValueError(f'Purpur version not found: {version}')
    return f'https://api.purpurmc.org/v2/purpur/{version}/{build}/download'


def _fabric_server_url(version):
    loaders = requests.get(f'https://meta.fabricmc.net/v2/versions/loader/{version}', timeout=REQUEST_TIMEOUT).json()
    if not loaders:
        raise ValueError(f'No fabric loader available for {version}')
    loader_ver = next((l['loader']['version'] for l in loaders if l['loader'].get('stable')), loaders[0]['loader']['version'])
    installers = requests.get('https://meta.fabricmc.net/v2/versions/installer', timeout=REQUEST_TIMEOUT).json()
    installer_ver = next((i['version'] for i in installers if i.get('stable')), installers[0]['version'])
    return f'https://meta.fabricmc.net/v2/versions/loader/{version}/{loader_ver}/{installer_ver}/server/jar'


def _forge_installer_url(version):
    # version format expected: "<mcversion>-<forgeversion>"
    return f'https://maven.minecraftforge.net/net/minecraftforge/forge/{version}/forge-{version}-installer.jar'


# ---------------------------------------------------------------------------
# Egg-specific install routines. Each returns the jar_file name (relative to
# server root) that the startup command should launch, and optionally a full
# startup_command override (used by modern Forge, which ships a run script).
# ---------------------------------------------------------------------------

def _install_direct_jar(server_path, url, label, panel_url, secret, server_id):
    dest = os.path.join(server_path, 'server.jar')
    _download(url, dest, panel_url, secret, server_id, label)
    return 'server.jar', None


def _install_fabric(server_path, version, panel_url, secret, server_id):
    url = _fabric_server_url(version)
    dest = os.path.join(server_path, 'server.jar')
    _download(url, dest, panel_url, secret, server_id, f'Fabric {version}')
    return 'server.jar', None


def _install_forge(server_path, version, panel_url, secret, server_id):
    installer_url = _forge_installer_url(version)
    installer_path = os.path.join(server_path, 'forge-installer.jar')
    _download(installer_url, installer_path, panel_url, secret, server_id, f'Forge {version} installer')
    _run(['java', '-jar', 'forge-installer.jar', '--installServer'], server_path,
        panel_url, secret, server_id, 'Forge server install')
    try:
        os.remove(installer_path)
    except OSError:
        pass

    run_sh = os.path.join(server_path, 'run.sh')
    if os.path.isfile(run_sh):
        # Modern Forge (1.17+) ships a run.sh that wraps the real java args.
        os.chmod(run_sh, 0o755)
        return 'run.sh', 'bash run.sh nogui'

    # Older Forge produces a runnable universal jar directly.
    candidates = [f for f in os.listdir(server_path)
                 if f.startswith('forge-') and f.endswith('.jar') and 'installer' not in f]
    if candidates:
        src = os.path.join(server_path, candidates[0])
        dest = os.path.join(server_path, 'server.jar')
        shutil.move(src, dest)
        return 'server.jar', None

    raise RuntimeError('Forge install finished but no runnable jar/run.sh was found')


def _install_spigot(server_path, version, panel_url, secret, server_id):
    _report(panel_url, secret, server_id,
           '[Installer] Spigot BuildTools se compile hoga — isme kuchh minute lag sakte hain '
           'aur node par git + a JDK hona zaroori hai.')
    bt_path = os.path.join(server_path, 'BuildTools.jar')
    _download('https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar',
              bt_path, panel_url, secret, server_id, 'BuildTools')
    _run(['java', '-jar', 'BuildTools.jar', '--rev', version, '--output-dir', '.'], server_path,
        panel_url, secret, server_id, 'Spigot BuildTools')
    candidates = [f for f in os.listdir(server_path) if f.startswith('spigot-') and f.endswith('.jar')]
    if not candidates:
        raise RuntimeError('BuildTools finished but no spigot-*.jar was produced')
    shutil.move(os.path.join(server_path, candidates[0]), os.path.join(server_path, 'server.jar'))
    for junk in ('BuildTools.jar', 'BuildTools.log.txt'):
        p = os.path.join(server_path, junk)
        if os.path.isfile(p):
            try:
                os.remove(p)
            except OSError:
                pass
    return 'server.jar', None


INSTALLERS = {
    'vanilla':    lambda sp, v, pu, s, sid: _install_direct_jar(sp, _vanilla_url(v), f'Vanilla {v}', pu, s, sid),
    'paper':      lambda sp, v, pu, s, sid: _install_direct_jar(sp, _papermc_url('paper', v), f'Paper {v}', pu, s, sid),
    'waterfall':  lambda sp, v, pu, s, sid: _install_direct_jar(sp, _papermc_url('waterfall', v), f'Waterfall {v}', pu, s, sid),
    'velocity':   lambda sp, v, pu, s, sid: _install_direct_jar(sp, _papermc_url('velocity', v), f'Velocity {v}', pu, s, sid),
    'purpur':     lambda sp, v, pu, s, sid: _install_direct_jar(sp, _purpur_url(v), f'Purpur {v}', pu, s, sid),
    'bungeecord': lambda sp, v, pu, s, sid: _install_direct_jar(
        sp, 'https://ci.md-5.net/job/BungeeCord/lastSuccessfulBuild/artifact/bootstrap/target/BungeeCord.jar',
        'BungeeCord', pu, s, sid),
    'fabric':     _install_fabric,
    'forge':      _install_forge,
    'spigot':     _install_spigot,
}


def _install_worker(servers_dir, server_id, folder, egg, version, panel_url, secret, on_complete):
    server_path = os.path.join(servers_dir, str(folder))
    os.makedirs(server_path, exist_ok=True)
    _report_status(panel_url, secret, server_id, 'installing')
    _report(panel_url, secret, server_id, f'[Installer] === Installing {egg} {version} ===')

    installer_fn = INSTALLERS.get(egg)
    if not installer_fn:
        _report(panel_url, secret, server_id, f'[Installer] ERROR: Unknown software: {egg}')
        _report_status(panel_url, secret, server_id, 'install_failed')
        if on_complete:
            on_complete(False, None)
        return

    try:
        jar_file, startup_override = installer_fn(server_path, version, panel_url, secret, server_id)
        _write_eula(server_path, egg)
        _report(panel_url, secret, server_id, '[Installer] === Install complete ===')
        _report_status(panel_url, secret, server_id, 'installed',
                       jar_file=jar_file, startup_command=startup_override)
        if on_complete:
            on_complete(True, jar_file)
    except Exception as e:
        logger.exception('Install failed for server %s', server_id)
        _report(panel_url, secret, server_id, f'[Installer] ERROR: {e}')
        _report_status(panel_url, secret, server_id, 'install_failed')
        if on_complete:
            on_complete(False, None)
