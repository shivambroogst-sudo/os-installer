import os
import platform
import threading
import time
import logging
import shutil
import psutil
import requests
from flask import Flask, request, jsonify
from .server_manager import ServerManager
from .file_manager import (
    list_files, read_file, write_file, create_directory,
    delete_paths, rename_path, extract_archive, search_files,
    create_backup, restore_backup
)

logger = logging.getLogger(__name__)


def create_daemon_app(config=None):
    """
    config = config_loader.load_daemon_config() se aaya flat dict.
    Keys: secret, panel_url, servers_dir, backups_dir, java_path, heartbeat_interval, etc.
    """
    app = Flask(__name__)
    cfg = config or {}

    _base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # Daemon secret
    daemon_secret = cfg.get('secret', 'daemon-secret-change-me')
    if daemon_secret == 'CHANGE-THIS-DAEMON-SECRET':
        daemon_secret = 'daemon-secret-change-me'

    app.config['DAEMON_SECRET']        = daemon_secret
    app.config['PANEL_URL']            = cfg.get('panel_url', 'http://127.0.0.1:3000')
    app.config['NODE_FQDN']            = (os.environ.get('NODE_FQDN')
                                          or cfg.get('node_fqdn', '127.0.0.1'))
    app.config['NODE_ID']              = (os.environ.get('NODE_ID')
                                          or cfg.get('node_id') or None)
    app.config['SERVERS_DIR']          = cfg.get('servers_dir', os.path.join(_base, 'servers'))
    app.config['BACKUPS_DIR']          = cfg.get('backups_dir', os.path.join(_base, 'backups'))
    app.config['JAVA_PATH']            = cfg.get('java_path', 'java')
    app.config['HEARTBEAT_INTERVAL']   = int(cfg.get('heartbeat_interval', 30))
    app.config['MAX_RAM_MB']           = int(cfg.get('max_ram_mb', 8192))
    app.config['MAX_CPU_PERCENT']      = int(cfg.get('max_cpu_percent', 400))
    app.config['MONITOR_INTERVAL']     = int(cfg.get('monitor_interval', 5))

    os.makedirs(app.config['SERVERS_DIR'], exist_ok=True)
    os.makedirs(app.config['BACKUPS_DIR'], exist_ok=True)

    manager = ServerManager()
    manager.initialize(
        app.config['SERVERS_DIR'],
        app.config['PANEL_URL'],
        app.config['DAEMON_SECRET']
    )

    def _check_secret():
        secret = request.headers.get('X-Daemon-Secret')
        return secret == app.config['DAEMON_SECRET']

    def _require_secret():
        if not _check_secret():
            return jsonify({'error': 'Unauthorized'}), 401
        return None

    @app.route('/api/health', methods=['GET'])
    def health():
        return jsonify({'status': 'ok', 'daemon': 'running'})

    @app.route('/api/stats', methods=['GET'])
    def stats():
        err = _require_secret()
        if err:
            return err
        cpu = psutil.cpu_percent(interval=1)
        mem = psutil.virtual_memory()
        disk = shutil.disk_usage(app.config['SERVERS_DIR'])
        java_version = _get_java_version()
        return jsonify({
            'cpu_percent': cpu,
            'memory_used': mem.used,
            'memory_total': mem.total,
            'disk_used': disk.used,
            'disk_total': disk.total,
            'java_version': java_version,
            'os_info': f'{platform.system()} {platform.release()}',
            'hostname': platform.node()
        })

    @app.route('/api/servers/create', methods=['POST'])
    def create_server():
        err = _require_secret()
        if err:
            return err
        data = request.get_json() or {}
        result = manager.create_server(
            server_id=data['server_id'],
            folder=str(data['folder']),
            startup_command=data.get('startup_command', 'java -jar server.jar'),
            java_path=data.get('java_path', 'java'),
            ip=data.get('ip', '0.0.0.0'),
            port=data.get('port', 25565),
            ram=data.get('ram', 1024),
            cpu=data.get('cpu', 100.0),
            auto_start=data.get('auto_start', False),
            auto_restart=data.get('auto_restart', False),
            jar_file=data.get('jar_file', 'server.jar')
        )

        egg = data.get('egg')
        version = data.get('egg_version')
        if egg and version:
            manager.install_server(
                server_id=data['server_id'],
                folder=str(data['folder']),
                egg=egg,
                version=version,
                auto_start=data.get('auto_start', False)
            )

        return jsonify(result)

    @app.route('/api/servers/<int:server_id>/install', methods=['POST'])
    def install_server(server_id):
        err = _require_secret()
        if err:
            return err
        data = request.get_json() or {}
        folder = data.get('folder') or _get_folder(server_id)
        egg = data.get('egg')
        version = data.get('egg_version')
        if not egg or not version:
            return jsonify({'error': 'egg and egg_version are required'}), 400
        result = manager.install_server(
            server_id=server_id,
            folder=str(folder),
            egg=egg,
            version=version,
            auto_start=data.get('auto_start', False)
        )
        return jsonify(result)

    @app.route('/api/servers/<int:server_id>/start', methods=['POST'])
    def start_server(server_id):
        err = _require_secret()
        if err:
            return err
        result = manager.start_server(server_id)
        return jsonify(result)

    @app.route('/api/servers/<int:server_id>/stop', methods=['POST'])
    def stop_server(server_id):
        err = _require_secret()
        if err:
            return err
        result = manager.stop_server(server_id)
        return jsonify(result)

    @app.route('/api/servers/<int:server_id>/restart', methods=['POST'])
    def restart_server(server_id):
        err = _require_secret()
        if err:
            return err
        result = manager.restart_server(server_id)
        return jsonify(result)

    @app.route('/api/servers/<int:server_id>/kill', methods=['POST'])
    def kill_server(server_id):
        err = _require_secret()
        if err:
            return err
        result = manager.kill_server(server_id)
        return jsonify(result)

    @app.route('/api/servers/<int:server_id>/command', methods=['POST'])
    def send_command(server_id):
        err = _require_secret()
        if err:
            return err
        data = request.get_json() or {}
        result = manager.send_command(server_id, data.get('command', ''))
        return jsonify(result)

    @app.route('/api/servers/<int:server_id>/stats', methods=['GET'])
    def server_stats(server_id):
        err = _require_secret()
        if err:
            return err
        result = manager.get_stats(server_id)
        return jsonify(result)

    @app.route('/api/servers/<int:server_id>', methods=['DELETE'])
    def delete_server(server_id):
        err = _require_secret()
        if err:
            return err
        data = request.get_json() or {}
        folder = data.get('folder', str(server_id))
        result = manager.delete_server(server_id, folder)
        return jsonify(result)

    @app.route('/api/servers/<int:server_id>/files/list', methods=['GET'])
    def files_list(server_id):
        err = _require_secret()
        if err:
            return err
        folder = _get_folder(server_id)
        path = request.args.get('path', '/')
        try:
            files = list_files(app.config['SERVERS_DIR'], folder, path)
            return jsonify({'files': files})
        except Exception as e:
            return jsonify({'error': str(e)}), 400

    @app.route('/api/servers/<int:server_id>/files/read', methods=['GET'])
    def files_read(server_id):
        err = _require_secret()
        if err:
            return err
        folder = _get_folder(server_id)
        path = request.args.get('path', '')
        try:
            content = read_file(app.config['SERVERS_DIR'], folder, path)
            return jsonify({'content': content, 'path': path})
        except Exception as e:
            return jsonify({'error': str(e)}), 400

    @app.route('/api/servers/<int:server_id>/files/write', methods=['POST'])
    def files_write(server_id):
        err = _require_secret()
        if err:
            return err
        folder = _get_folder(server_id)
        data = request.get_json() or {}
        try:
            write_file(app.config['SERVERS_DIR'], folder,
                       data.get('path', ''), data.get('content', ''))
            return jsonify({'success': True})
        except Exception as e:
            return jsonify({'error': str(e)}), 400

    @app.route('/api/servers/<int:server_id>/files/mkdir', methods=['POST'])
    def files_mkdir(server_id):
        err = _require_secret()
        if err:
            return err
        folder = _get_folder(server_id)
        data = request.get_json() or {}
        try:
            create_directory(app.config['SERVERS_DIR'], folder,
                             data.get('path', '/'), data.get('name', ''))
            return jsonify({'success': True})
        except Exception as e:
            return jsonify({'error': str(e)}), 400

    @app.route('/api/servers/<int:server_id>/files/delete', methods=['POST'])
    def files_delete(server_id):
        err = _require_secret()
        if err:
            return err
        folder = _get_folder(server_id)
        data = request.get_json() or {}
        try:
            delete_paths(app.config['SERVERS_DIR'], folder, data.get('paths', []))
            return jsonify({'success': True})
        except Exception as e:
            return jsonify({'error': str(e)}), 400

    @app.route('/api/servers/<int:server_id>/files/rename', methods=['POST'])
    def files_rename(server_id):
        err = _require_secret()
        if err:
            return err
        folder = _get_folder(server_id)
        data = request.get_json() or {}
        try:
            rename_path(app.config['SERVERS_DIR'], folder,
                        data.get('from', ''), data.get('to', ''))
            return jsonify({'success': True})
        except Exception as e:
            return jsonify({'error': str(e)}), 400

    @app.route('/api/servers/<int:server_id>/files/upload', methods=['POST'])
    def files_upload(server_id):
        err = _require_secret()
        if err:
            return err
        folder = _get_folder(server_id)
        path = request.args.get('path', '/')
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        file = request.files['file']
        from .file_manager import save_upload
        try:
            save_upload(app.config['SERVERS_DIR'], folder, path, file, file.filename)
            return jsonify({'success': True})
        except Exception as e:
            return jsonify({'error': str(e)}), 400

    @app.route('/api/servers/<int:server_id>/files/extract', methods=['POST'])
    def files_extract(server_id):
        err = _require_secret()
        if err:
            return err
        folder = _get_folder(server_id)
        data = request.get_json() or {}
        try:
            extract_archive(app.config['SERVERS_DIR'], folder,
                            data.get('path', ''), data.get('destination', '/'))
            return jsonify({'success': True})
        except Exception as e:
            return jsonify({'error': str(e)}), 400

    @app.route('/api/servers/<int:server_id>/files/search', methods=['GET'])
    def files_search(server_id):
        err = _require_secret()
        if err:
            return err
        folder = _get_folder(server_id)
        query = request.args.get('q', '')
        path = request.args.get('path', '/')
        try:
            results = search_files(app.config['SERVERS_DIR'], folder, query, path)
            return jsonify({'results': results})
        except Exception as e:
            return jsonify({'error': str(e)}), 400

    @app.route('/api/servers/<int:server_id>/backups/create', methods=['POST'])
    def backup_create(server_id):
        err = _require_secret()
        if err:
            return err
        folder = _get_folder(server_id)
        data = request.get_json() or {}
        backup_id = data.get('backup_id')
        filename = data.get('filename', f'backup_{folder}.zip')
        try:
            size = create_backup(app.config['SERVERS_DIR'], folder,
                                 app.config['BACKUPS_DIR'], filename)
            _notify_panel_backup(app.config, backup_id, True, size)
            return jsonify({'success': True, 'size': size})
        except Exception as e:
            _notify_panel_backup(app.config, backup_id, False, 0)
            return jsonify({'error': str(e)}), 500

    @app.route('/api/servers/<int:server_id>/backups/<int:backup_id>/restore', methods=['POST'])
    def backup_restore(server_id, backup_id):
        err = _require_secret()
        if err:
            return err
        folder = _get_folder(server_id)
        from .file_manager import restore_backup as _restore
        try:
            _get_backup_filename = lambda bid: f'backup_{folder}_{bid}.zip'
            filename = _get_backup_filename(backup_id)
            _restore(app.config['SERVERS_DIR'], folder,
                     app.config['BACKUPS_DIR'], filename)
            return jsonify({'success': True})
        except Exception as e:
            return jsonify({'error': str(e)}), 500

    @app.route('/api/servers/<int:server_id>/backups/<int:backup_id>', methods=['DELETE'])
    def backup_delete(server_id, backup_id):
        err = _require_secret()
        if err:
            return err
        import glob
        pattern = os.path.join(app.config['BACKUPS_DIR'], f'backup_*_{backup_id}.zip')
        files = glob.glob(pattern)
        for f in files:
            os.remove(f)
        return jsonify({'success': True})

    def _get_folder(server_id):
        proc = manager._processes.get(server_id)
        return proc.folder if proc else str(server_id)

    def _get_java_version():
        try:
            import subprocess
            result = subprocess.run(['java', '-version'],
                                    capture_output=True, text=True, timeout=5)
            output = result.stderr or result.stdout
            for line in output.split('\n'):
                if 'version' in line.lower():
                    return line.strip()
        except Exception:
            pass
        return 'Unknown'

    def _notify_panel_backup(cfg, backup_id, success, size):
        try:
            requests.post(
                f"{cfg['PANEL_URL']}/api/daemon/backup-complete",
                json={'backup_id': backup_id, 'success': success, 'size': size},
                headers={'X-Daemon-Secret': cfg['DAEMON_SECRET']},
                timeout=5
            )
        except Exception:
            pass

    def _heartbeat_loop(cfg):
        import shutil, platform
        while True:
            try:
                cpu = psutil.cpu_percent(interval=1)
                mem = psutil.virtual_memory()
                disk = shutil.disk_usage(cfg['SERVERS_DIR'])
                requests.post(
                    f"{cfg['PANEL_URL']}/api/daemon/heartbeat",
                    json={
                        'fqdn': cfg['NODE_FQDN'],
                        'node_id': cfg.get('NODE_ID'),
                        'hostname': platform.node(),
                        'cpu_percent': cpu,
                        'memory_used': mem.used,
                        'memory_total': mem.total,
                        'disk_used': disk.used,
                        'disk_total': disk.total,
                        'java_version': _get_java_version(),
                        'os_info': f'{platform.system()} {platform.release()}'
                    },
                    headers={'X-Daemon-Secret': cfg['DAEMON_SECRET']},
                    timeout=10
                )
            except Exception:
                pass
            time.sleep(cfg.get('HEARTBEAT_INTERVAL', 30))

    t = threading.Thread(target=_heartbeat_loop, args=(app.config,), daemon=True)
    t.start()

    return app
