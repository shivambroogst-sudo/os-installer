import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  const email = 'admin@ogultra.com';
  const username = 'admin';
  const password = 'admin123';

  // Check if admin user already exists
  const existing = await prisma.user.findFirst({
    where: { OR: [{ email }, { username }] },
  });

  if (existing) {
    console.log('⚠️  Admin user already exists, skipping seed.');
    console.log(`   Email: ${existing.email}, Username: ${existing.username}`);
    return;
  }

  const salt = await bcrypt.genSalt(12);
  const passwordHash = await bcrypt.hash(password, salt);

  const admin = await prisma.user.create({
    data: {
      email,
      username,
      passwordHash,
      role: 'admin',
      isRootAdmin: true,
      firstName: 'Root',
      lastName: 'Admin',
      isActive: true,
    },
  });

  console.log('✅ Admin user created successfully:');
  console.log(`   ID: ${admin.id}`);
  console.log(`   Email: ${admin.email}`);
  console.log(`   Username: ${admin.username}`);
  console.log(`   Role: ${admin.role}`);
  console.log(`   Is Root Admin: ${admin.isRootAdmin}`);
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });