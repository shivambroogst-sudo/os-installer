# Worklog

## Task 2: Fix Auth Routes with Real Prisma DB + bcryptjs

**Date**: 2025-07-04

### Changes Made

#### 1. `src/app/api/auth/register/route.ts` — Replaced fake register with real DB implementation
- Validates username (min 2 chars), email (regex), password (min 6 chars)
- Hashes password with `bcryptjs` (12 salt rounds)
- Checks for duplicate email/username in Prisma DB (returns 409 on conflict)
- Creates user with `role='user'`, `isRootAdmin=false`
- Returns user data (without passwordHash) + simple SHA-256 token

#### 2. `src/app/api/auth/login/route.ts` — Replaced fake login with real DB implementation
- Validates email + password presence
- Finds user by email in Prisma DB (case-insensitive)
- Compares password with `bcryptjs.compare`
- Updates `lastLoginAt` on successful auth
- Returns user data (without passwordHash) + token on success
- Returns 401 on invalid credentials (generic error message)

#### 3. `prisma/seed.ts` — Created admin user seed script
- Creates default admin: `admin@ogultra.com` / `admin` / `admin123`
- Uses bcryptjs with 12 salt rounds for password hashing
- Sets `isRootAdmin=true`, `role='admin'`
- Idempotent: skips if admin user already exists
- Registered in package.json under `prisma.seed` config and `db:seed` script

#### 4. `.env.example` and `.env` — Created/updated environment files
- `DATABASE_URL=file:./dev.db` (SQLite, relative to prisma dir)
- `DAEMON_URL`, `DAEMON_TOKEN`, `NEXT_PUBLIC_DAEMON_WS_URL`, `JWT_SECRET`
- Note: No quotes around values (Prisma dotenv doesn't strip quotes)

#### 5. `package.json` — Added seed configuration
- Added `"db:seed": "tsx prisma/seed.ts"` script
- Added `"prisma": { "seed": "tsx prisma/seed.ts" }` config

#### 6. Database setup
- Ran `prisma db push --force-reset` successfully (SQLite at `prisma/dev.db`)
- Ran seed script — admin user created with ID `cmr6fstp50000rea12m9o3fz0`
- Cleaned up old `db/custom.db` directory

### Notes
- The shell had a stale `DATABASE_URL` env var pointing to old path; `.env` file now takes precedence when shell var is unset
- Prisma schema already fully compatible with SQLite — no changes needed
- `bcryptjs` and `@types/bcryptjs` were already in dependencies
- Tokens are simple SHA-256 hashes (placeholder until proper JWT implementation)

## Task 7: Add Server Install to Daemon

**Date**: 2025-07-04

### Changes Made

#### 1. `mini-services/ogultra-daemon/index.ts` — Added Minecraft server jar installation system

**Imports (line 9-10):**
- Changed `import { createServer, ... } from 'http'` to `import http, { createServer, ... } from 'http'` (default import for making HTTP requests)
- Added `import https from 'https'` for HTTPS download requests

**New Section: SERVER INSTALLATION (~240 lines added between FILE OPERATIONS and NODE INFO):**

Helper functions:
- `httpsGet(url)` — Fetches JSON/text from HTTP/HTTPS URLs with redirect following and 30s timeout
- `downloadFile(url, destPath, serverId)` — Downloads files with progress reporting (every 10%) streamed to WebSocket console, 120s timeout, redirect following, cleanup on error
- `createDefaultServerProperties(port)` — Generates default `server.properties` content with the specified port

Core functions:
- `installServer(serverId, software, version)` — Full async installation pipeline:
  1. Validates server exists and is stopped
  2. Sets status to `'installing'`, broadcasts via WebSocket
  3. Resolves download URL based on software type:
     - **Paper**: Fetches `api.papermc.io` for latest build number, constructs download URL
     - **Purpur**: Uses `api.purpurmc.org` latest download endpoint (redirect-based)
     - **Vanilla**: Fetches Mojang version manifest → version details → server jar download URL
     - **Spigot**: Falls back to Paper with a warning (BuildTools not supported)
  4. Downloads jar to `{workingDir}/server.jar` with progress streaming
  5. Creates `eula.txt` with `eula=true`
  6. Creates `server.properties` with default settings
  7. Updates `startupCommand` to `server.jar`
  8. Sets status to `'stopped'`, broadcasts final status
  9. Error handling: logs failure, resets status to `'stopped'`

- `installCustomJar(serverId, downloadUrl?, jarData?)` — Custom jar installation:
  - Downloads from URL or decodes base64 `jarData`
  - Same post-download steps as `installServer` (eula, properties, startupCommand)

**Route handlers (in `handleRequest` actionMatch section):**
- `POST /api/servers/:id/install` — Accepts `{ software, version }`, validates inputs, runs `installServer` asynchronously, returns immediate `{ success: true, message: 'Installation started' }`
- `POST /api/servers/:id/install/custom` — Accepts `{ downloadUrl }` or `{ jarData }`, runs `installCustomJar` asynchronously

**Default server.properties:**
```
server-port={port}, server-ip=, max-players=20, view-distance=10,
simulation-distance=10, enable-command-block=false, allow-flight=false,
level-seed=, level-type=minecraft\:normal, motd=OGUltra Minecraft Server,
online-mode=true, pvp=true, enable-rcon=false
```

#### 2. `mini-services/ogultra-daemon/package.json` — No changes needed
- `https` and `http` are Node.js built-in modules, not external dependencies

### Notes
- File grew from 888 lines to 1161 lines (+273 lines)
- Install endpoints are async — the HTTP response returns immediately while installation proceeds in background
- All installation progress is streamed to connected WebSocket clients via `addConsoleLine`
- `ServerState.status` type already included `'installing'` so no type changes needed
- All download functions handle HTTP redirects automatically
## Task 3: Update Frontend Views to Real API

**Date**: 2025-07-04

### Changes Made

#### 1. `src/components/views/servers-list.tsx` — Replaced mock data with real API calls
- Removed `mockServers`, `mockNodes` imports from `@/lib/mock-data`
- Added `useEffect`, `useCallback` imports for data fetching
- Added `listServers`, `createServer`, `deleteServer` from `@/lib/api`
- Added `useState` for `servers: ServerStatus[]`, `loading`, `creating`
- Added `fetchServers()` callback with `listServers()` API call + error toast
- Added `useEffect` with 5-second polling interval (`setInterval`)
- `ServerCard` now uses `ServerStatus` type from API (shows port, PID, uptime, CPU/memory bars)
- Removed mock-only fields (players, maxPlayers, disk, node name, software badge)
- Start/stop/restart buttons call `serverAction()` with toast feedback
- Delete button now calls `deleteServer()` with real API
- Create server dialog calls `createServer()` with loading state
- Added loading spinner (`Loader2` animate-spin) while fetching
- Simplified filter bar (removed software filter, kept status + search)

#### 2. `src/components/views/dashboard.tsx` — Replaced mock data with real API calls
- Removed `mockServers`, `mockNodes`, `mockActivityLogs` imports
- Added `useState`, `useEffect`, `useCallback`, `useMemo` for data management
- Added `listServers`, `getNodeInfo`, `serverAction` from `@/lib/api`
- Added `toast` from `sonner`
- Fetches servers + node info in parallel with `Promise.all` on mount + 5s polling
- Stats cards now show: Total Servers, Running Servers, Node Memory, CPU Cores
- Replaced Activity Feed with Node Information panel (hostname, platform, arch, CPU model, daemon version, memory, disk)
- Chart data generated from real server CPU/memory usage averages
- Connection status badge shows "Daemon Connected" or "Connecting..."
- Server cards adapted to `ServerStatus` type (removed players, disk bars)
- Start/stop/restart use `serverAction()` with toast feedback
- Added loading spinner state

#### 3. `src/components/views/server-console.tsx` — Replaced mock with real WebSocket API
- **Removed ALL mock data**: `mockConsoleLines`, `mockServers`, `mockPlayerNames`, `randomLogMessages`, mock log generators, fake command responses, fake TPS
- Added `getServer`, `createConsoleWebSocket`, `sendServerCommand`, `serverAction` from `@/lib/api`
- Fetches server info via `getServer()` on mount, pre-populates console from `server.consoleLines`
- Real WebSocket connection via `createConsoleWebSocket()` with:
  - `console_output` events → added to console buffer
  - `server_status` events → update server status/CPU/memory live
- Commands sent via `sendServerCommand()` API (not mock)
- Power actions (start/stop/restart/kill) call `serverAction()` with toast + refresh
- **Auto-reconnect**: on WebSocket close, reconnects after 3 seconds
- **Connection status indicator**: Shows Wifi/WifiOff icon + "Connected"/"Connecting..."/"Disconnected" with color coding (green/yellow/red)
- Mobile stats bar shows connection status
- Proper cleanup on unmount (close WS, clear timeouts)
- Pause button still works (filters incoming WS messages)
- Download logs generates real .txt file from console buffer
- Shows "No server selected" when no serverId
- Shows loading spinner while fetching server

#### 4. `src/components/views/server-files.tsx` — Replaced mock with real file API
- Removed `mockFileTree` import and entire `mockNestedTree` (150+ lines of mock data)
- Added `useEffect` for data fetching
- Added `useNavStore` for `selectedServerId`
- Added `listFiles`, `readFile`, `writeFile`, `deleteFile`, `createDirectory` from `@/lib/api`
- Local `FileEntry` interface matches API's `FileEntry` shape
- `fetchFiles()` calls `listFiles(selectedServerId, apiPath)` on path changes
- Directory navigation: clicking folders updates `currentPath` → triggers re-fetch
- Breadcrumb navigation from current path
- **File editing**: "Open"/"Edit" opens a dialog, calls `readFile()` to load content, saves via `writeFile()` with loading state
- **Create file**: calls `writeFile(path, '')` to create empty file
- **Create folder**: calls `createDirectory(path)` with loading state
- **Delete**: calls `deleteFile(path)` with confirmation dialog + loading state
- Added loading spinner while fetching files
- Upload/Compress/Rename show "not yet implemented" toast
- All modals show loading states during async operations

#### 5. `src/components/views/nodes-list.tsx` — Replaced mock with real node API
- Removed `mockNodes` import from `@/lib/mock-data`
- Added `useEffect`, `useCallback` for data fetching
- Added `getNodeInfo` + `type NodeInfo` from `@/lib/api`
- Fetches node info on mount + 10-second polling interval
- `NodeCard` adapted to show `NodeInfo` fields (hostname, platform, arch, CPU model, daemon version, server count, memory, disk)
- `ClusterStats` shows: Node Status, CPU cores, Memory, Disk, Servers
- Shows "No node connected" empty state when API returns no data
- Added loading spinner while fetching
- Add Node dialog kept for UI consistency (shows info toast)

### Notes
- All files retain the exact same visual design (glass-card, framer-motion animations, resource bars, etc.)
- Utility functions (`getStatusDotClass`, `getStatusLabel`, `formatMemory`, `formatBytes`, `getResourceBarClass`) kept importing from `@/lib/mock-data` as they are pure helpers, not mock data
- The `ServerStatus` API type has fewer fields than the mock data (no players, disk, software, node). Cards were adapted to show available data.
- Pre-existing Framer Motion `Variants` type warnings remain (not introduced by this change)
