# OGUltra Panel — Minecraft Server Hosting Panel

A fully working, self-hosted Minecraft server management panel with multi-node support, inspired by Pterodactyl. No Docker required — uses direct process management.

## Features

- **Real Server Management** — Start/Stop/Restart/Kill Minecraft servers via Java child processes
- **Live Console** — Real-time WebSocket connection to server stdin/stdout
- **File Manager** — Browse, read, edit, create, delete server files
- **Server Installation** — Download Paper, Purpur, Vanilla server jars with one click
- **Multi-Node** — Run daemon on multiple machines, manage from one panel
- **Resource Monitoring** — CPU, RAM, Disk tracking per server and node
- **Crash Detection** — Auto-restart servers on crash (configurable threshold)
- **Aikar's JVM Flags** — Optimized Java arguments out of the box
- **Auth System** — Real user registration/login with bcrypt password hashing
- **Modern UI** — Glassmorphism dark theme with React, TailwindCSS, Framer Motion

## Architecture

```
┌─────────────────────────┐        ┌─────────────────────────┐
│   OGUltra Panel         │        │   OGUltra Daemon (Node) │
│   Next.js :3000         │───────▶│   Node.js :3003         │
│                         │  HTTP  │                         │
│  - React Frontend       │  + WS  │  - Process Manager      │
│  - API Routes (proxy)   │        │  - File Operations      │
│  - Prisma DB (SQLite)   │        │  - WebSocket Console    │
│  - Auth (bcrypt)        │        │  - Resource Monitor     │
└─────────────────────────┘        └─────────────────────────┘
                                            │
                                    ┌───────┴───────┐
                                    │  Java Process  │
                                    │  (Minecraft)   │
                                    └───────────────┘
```

**Multi-Node:** Run multiple daemons on different servers. Panel communicates with each via HTTP/WebSocket.

## Tech Stack

| Component | Technology |
|-----------|-----------|
| Panel Frontend | React 19, Next.js 16, TailwindCSS 4, Framer Motion |
| Panel Backend | Next.js API Routes, Prisma ORM |
| Database | SQLite (default) — PostgreSQL also supported |
| Auth | bcryptjs password hashing |
| Daemon | Node.js, raw HTTP server, ws (WebSocket) |
| Process Mgmt | Node.js child_process (no Docker) |

## Quick Setup

### Prerequisites

- **Node.js 18+** (recommended: 20+)
- **npm** or **bun**
- **Java 8/11/17/21** (for running Minecraft servers)

### 1. Install & Setup

```bash
# Clone or extract the project
cd ogultra-panel

# Run the setup script
chmod +x setup.sh
./setup.sh
```

This will:
- Install all npm dependencies
- Setup the SQLite database
- Create the admin user

### 2. Start the Daemon (Terminal 1)

```bash
cd mini-services/ogultra-daemon
npm start
```

You should see:
```
========================================
  OGUltra Daemon v1.0.0
  Port: 3003
  Servers Dir: /path/to/servers
  Java: /usr/bin/java
========================================
```

### 3. Start the Panel (Terminal 2)

```bash
npm run dev
```

### 4. Open the Panel

Go to **http://localhost:3000**

**Default Login:**
- Email: `admin@ogultra.com`
- Password: `admin123`

## Usage

### Creating a Server

1. Go to **Servers** → Click **+ New Server**
2. Fill in: Name, Memory (MB), Port, Startup Command (e.g., `server.jar`)
3. Click **Create**
4. The server appears in the list with "Stopped" status

### Installing Minecraft

1. Click on a server to open it
2. The daemon will register the server
3. Use the install API to download a server jar:
   ```bash
   curl -X POST http://localhost:3003/api/servers/{server_id}/install \
     -H "Authorization: Bearer ormai tra-secret-token" \
     -H "Content-Type: application/json" \
     -d '{"software": "paper", "version": "1.21.4"}'
   ```
   Supported: `paper`, `purpur`, `vanilla`

### Starting a Server

1. Click on the server → Go to **Console** tab
2. Click **Start** button
3. Watch real-time logs in the console
4. Type commands and press Enter to send to the server

### Managing Files

1. Click on a server → Go to **Files** tab
2. Browse directories, click files to edit
3. Edit and save files — changes are written to the real server directory

## Configuration

### Environment Variables

#### Panel (.env)

| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_URL` | `file:./dev.db` | Prisma database URL |
| `DAEMON_URL` | `http://localhost:3003` | Daemon HTTP address |
| `DAEMON_TOKEN` | `ogultra-daemon-secret-token` | Auth token for daemon |
| `JWT_SECRET` | (change this!) | Secret for token signing |

#### Daemon (env vars)

| Variable | Default | Description |
|----------|---------|-------------|
| `DAEMON_PORT` | `3003` | Daemon HTTP/WS port |
| `DAEMON_TOKEN` | `ogultra-daemon-secret-token` | Must match panel's token |
| `DAEMON_UUID` | (auto-generated) | Unique node identifier |
| `SERVERS_DIR` | `./servers` | Directory for server files |

## Multi-Node Setup

To add additional nodes:

1. **Copy daemon to remote server:**
   ```bash
   scp -r mini-services/ogultra-daemon/ user@node2:/opt/ogultra-daemon/
   ```

2. **Start daemon on remote server:**
   ```bash
   ssh user@node2
   cd /opt/ogultra-daemon
   DAEMON_UUID=node-2 DAEMON_PORT=3003 DAEMON_TOKEN=your-shared-secret npm start
   ```

3. **Add the node in the panel** (via Admin → Nodes) with:
   - FQDN: `node2.example.com`
   - Daemon Port: `3003`
   - Daemon Token: `your-shared-secret`

## API Endpoints

### Panel API (port 3000)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/auth/login` | Login |
| POST | `/api/auth/register` | Register new user |
| GET | `/api/daemon/node` | Get node info (proxied) |
| GET | `/api/daemon/servers` | List all servers (proxied) |
| POST | `/api/daemon/servers` | Create server (proxied) |
| GET | `/api/daemon/servers/:id` | Get server status (proxied) |
| DELETE | `/api/daemon/servers/:id` | Delete server (proxied) |
| POST | `/api/daemon/servers/:id/action` | Server action (proxied) |
| GET | `/api/daemon/servers/:id/files` | List files (proxied) |
| POST | `/api/daemon/servers/:id/files` | File operations (proxied) |

### Daemon API (port 3003)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/node` | System info (CPU, RAM, Disk) |
| GET | `/api/servers` | All server statuses |
| POST | `/api/servers` | Register new server |
| GET | `/api/servers/:id` | Single server status |
| DELETE | `/api/servers/:id` | Delete server |
| POST | `/api/servers/:id/start` | Start server |
| POST | `/api/servers/:id/stop` | Stop server |
| POST | `/api/servers/:id/restart` | Restart server |
| POST | `/api/servers/:id/kill` | Force kill |
| POST | `/api/servers/:id/command` | Send console command |
| GET | `/api/servers/:id/console` | Get console lines |
| GET | `/api/servers/:id/files` | List files |
| GET | `/api/servers/:id/files/read` | Read file |
| POST | `/api/servers/:id/files/write` | Write file |
| POST | `/api/servers/:id/files/delete` | Delete file/dir |
| POST | `/api/servers/:id/files/mkdir` | Create directory |
| POST | `/api/servers/:id/install` | Install server software |
| POST | `/api/servers/:id/install/custom` | Install custom jar |
| WS | `/?token=xxx&server_id=xxx` | WebSocket console |

## Project Structure

```
ogultra-panel/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── auth/
│   │   │   │   ├── login/route.ts      # Real auth with bcrypt
│   │   │   │   └── register/route.ts   # Real registration
│   │   │   └── daemon/
│   │   │       ├── node/route.ts        # Proxy to daemon
│   │   │       └── servers/
│   │   │           ├── route.ts         # List/create servers
│   │   │           └── [id]/
│   │   │               ├── route.ts     # Get/delete server
│   │   │               ├── action/route.ts  # Start/stop/restart/kill
│   │   │               └── files/route.ts   # File operations
│   │   ├── globals.css
│   │   ├── layout.tsx
│   │   └── page.tsx
│   ├── components/
│   │   ├── auth/auth-page.tsx
│   │   ├── layout/sidebar.tsx
│   │   ├── layout/header.tsx
│   │   └── views/
│   │       ├── dashboard.tsx            # Real API data
│   │       ├── servers-list.tsx         # Real API data
│   │       ├── server-console.tsx       # Real WebSocket
│   │       ├── server-files.tsx         # Real file ops
│   │       ├── server-startup.tsx
│   │       ├── server-plugins.tsx
│   │       ├── server-backups.tsx
│   │       ├── server-schedules.tsx
│   │       ├── server-network.tsx
│   │       ├── server-settings.tsx
│   │       ├── server-databases.tsx
│   │       ├── nodes-list.tsx           # Real node info
│   │       ├── users-list.tsx
│   │       ├── admin-panel.tsx
│   │       └── activity-log.tsx
│   └── lib/
│       ├── api.ts                       # API client functions
│       ├── daemon.ts                    # Daemon HTTP client
│       ├── db.ts                        # Prisma client
│       ├── store.ts                     # Zustand stores
│       ├── utils.ts
│       └── mock-data.ts                 # Helper functions only
├── mini-services/
│   └── oggi tra-daemon/
│       ├── index.ts                     # Full daemon (1161 lines)
│       ├── package.json
│       └── bun.lock
├── prisma/
│   ├── schema.prisma                    # Full DB schema
│   ├── seed.ts                          # Admin user seeder
│   └── dev.db                           # SQLite database
├── .env                                 # Environment config
├── .env.example                         # Env template
├── setup.sh                             # One-click setup
├── package.json
├── tailwind.config.ts
├── tsconfig.json
└── next.config.ts
```

## Supported Server Software

| Software | Installer | Notes |
|----------|-----------|-------|
| Paper | ✅ Auto-download | Recommended, best performance |
| Purpur | ✅ Auto-download | Paper fork with extra features |
| Vanilla | ✅ Auto-download | Official Mojang server |
| Spigot | ⚠️ Falls back to Paper | Requires BuildTools for real Spigot |
| Custom JAR | ✅ URL or Base64 | Upload your own server jar |

## Java Version Support

The daemon auto-detects Java from:
- `PATH` (`which java`)
- `/usr/bin/java`
- `/usr/lib/jvm/java-{21,17,11,8}/bin/java`

You can also specify a custom Java path per server.

## License

MIT