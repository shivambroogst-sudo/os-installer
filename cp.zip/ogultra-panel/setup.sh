#!/bin/bash
# ============================================================
# OGUltra Panel — Setup Script
# A fully working Minecraft server hosting panel
# ============================================================

set -e

echo ""
echo "=========================================="
echo "  OGUltra Panel — Setup"
echo "  Minecraft Server Hosting Panel"
echo "=========================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}ERROR: Node.js is not installed!${NC}"
    echo "Install Node.js 18+ from https://nodejs.org or via your package manager:"
    echo "  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -"
    echo "  sudo apt install -y nodejs"
    exit 1
fi

NODE_VERSION=$(node -v | sed 's/v//' | cut -d. -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${RED}ERROR: Node.js 18+ required (found v$(node -v))${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Node.js v$(node -v) found${NC}"

# Check npm
if ! command -v npm &> /dev/null; then
    echo -e "${RED}ERROR: npm is not installed!${NC}"
    exit 1
fi
echo -e "${GREEN}✓ npm v$(npm -v) found${NC}"

# Check for Java (optional, for Minecraft servers)
if command -v java &> /dev/null; then
    JAVA_VER=$(java -version 2>&1 | head -1 | cut -d'"' -f2)
    echo -e "${GREEN}✓ Java $JAVA_VER found${NC}"
else
    echo -e "${YELLOW}⚠ Java not found — Minecraft servers won't start without it${NC}"
    echo "  Install Java 21: sudo apt install -y openjdk-21-jdk"
fi

echo ""
echo -e "${BLUE}--- Step 1: Install Panel Dependencies ---${NC}"
npm install
echo -e "${GREEN}✓ Panel dependencies installed${NC}"

echo ""
echo -e "${BLUE}--- Step 2: Setup Database ---${NC}"
npx prisma generate
npx prisma db push --force-reset
echo -e "${GREEN}✓ Database ready${NC}"

echo ""
echo -e "${BLUE}--- Step 3: Seed Admin User ---${NC}"
npx tsx prisma/seed.ts
echo -e "${GREEN}✓ Admin user created${NC}"

echo ""
echo -e "${BLUE}--- Step 4: Install Daemon Dependencies ---${NC}"
cd mini-services/ogultra-daemon
npm install
cd ../..
echo -e "${GREEN}✓ Daemon dependencies installed${NC}"

echo ""
echo "=========================================="
echo -e "${GREEN}  Setup Complete!${NC}"
echo "=========================================="
echo ""
echo "Default Admin Credentials:"
echo -e "  ${YELLOW}Email:    admin@ogultra.com${NC}"
echo -e "  ${YELLOW}Password: admin123${NC}"
echo ""
echo "To start the panel:"
echo ""
echo -e "  ${BLUE}Terminal 1 — Start the Daemon:${NC}"
echo "  cd mini-services/ogultra-daemon && npm start"
echo ""
echo -e "  ${BLUE}Terminal 2 — Start the Panel:${NC}"
echo "  npm run dev"
echo ""
echo "Then open http://localhost:3000"
echo ""
echo "Architecture:"
echo "  Panel (Next.js)  → http://localhost:3000"
echo "  Daemon           → http://localhost:3003"
echo "  Panel API        → http://localhost:3000/api/*"
echo "  Daemon API       → http://localhost:3003/api/*"
echo ""
echo "Multi-Node Setup:"
echo "  1. Copy 'mini-services/ogultra-daemon/' to each node server"
echo "  2. Set DAEMON_TOKEN env var to the same value on all nodes"
echo "  3. Set DAEMON_UUID to a unique value per node"
echo "  4. Start daemon on each node with: DAEMON_UUID=node-2 DAEMON_PORT=3004 npm start"
echo "  5. Add nodes in the Admin Panel with the node's FQDN and daemon port"
echo ""