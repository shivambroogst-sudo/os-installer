// ============================================================
// OGUltra DAEMON — Process Manager for Game Servers
// Handles: Server lifecycle, console I/O, resources, files, heartbeat
// No Docker. Pure child_process. Multi-node ready.
// ============================================================

import { spawn, ChildProcess, execSync } from 'child_process';
import { WebSocketServer, WebSocket } from 'ws';
import http, { createServer, IncomingMessage, ServerResponse } from 'http';
import https from 'https';
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, statSync, unlinkSync, rmdirSync, createReadStream, createWriteStream, cpSync, rmSync } from 'fs';
import { join, basename, extname, relative, dirname } from 'path';
import { platform, arch, totalmem, freemem, cpus } from 'os';

// ============ TYPES ============

interface ServerConfig {
  id: string;
  uuid: string;
  name: string;
  workingDir: string;
  startupCommand: string;
  stopCommand: string;
  javaPath: string | null;
  memoryLimit: number; // MB
  cpuLimit: number; // percentage
  autoRestart: boolean;
  crashDetection: boolean;
  port: number;
  ip: string;
}

interface ServerState {
  id: string;
  status: 'installing' | 'stopped' | 'starting' | 'running' | 'stopping' | 'crashed';
  process: ChildProcess | null;
  config: ServerConfig;
  startedAt: number | null;
  pid: number | null;
  cpuUsage: number;
  memoryUsage: number; // bytes
  peakMemory: number;
  consoleBuffer: ConsoleLine[];
  crashCount: number;
  lastCrashAt: number | null;
  connections: Set<WebSocket>;
}

interface ConsoleLine {
  id: number;
  text: string;
  level: 'info' | 'warn' | 'error' | 'success';
  timestamp: number;
}

interface NodeInfo {
  uuid: string;
  hostname: string;
  platform: string;
  arch: string;
  totalMemory: number;
  freeMemory: number;
  cpuCount: number;
  cpuModel: string;
  daemonVersion: string;
  totalDisk: number;
  usedDisk: number;
  serverCount: number;
  runningServers: number;
}

// ============ DAEMON CONFIG ============

const DAEMON_PORT = parseInt(process.env.DAEMON_PORT || '3003');
const AUTH_TOKEN = process.env.DAEMON_TOKEN || 'ogultra-daemon-secret-token';
const SERVERS_DIR = process.env.SERVERS_DIR || join(process.cwd(), 'servers');
const DAEMON_UUID = process.env.DAEMON_UUID || 'local-daemon-' + Math.random().toString(36).slice(2, 10);

// ============ STATE ============

const servers = new Map<string, ServerState>();
let consoleLineIdCounter = 0;
let heartbeatTimer: ReturnType<typeof setInterval> | null = null;

// ============ UTILITIES ============

function log(level: string, msg: string) {
  const ts = new Date().toISOString();
  console.log(`[${ts}] [${level.toUpperCase()}] ${msg}`);
}

function getTimestamp(): string {
  const d = new Date();
  return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`;
}

function addConsoleLine(serverId: string, text: string, level: ConsoleLine['level'] = 'info') {
  const state = servers.get(serverId);
  if (!state) return;
  const line: ConsoleLine = {
    id: ++consoleLineIdCounter,
    text,
    level,
    timestamp: Date.now(),
  };
  state.consoleBuffer.push(line);
  // Keep last 5000 lines
  if (state.consoleBuffer.length > 5000) {
    state.consoleBuffer = state.consoleBuffer.slice(-3000);
  }
  // Broadcast to all WebSocket connections for this server
  for (const ws of state.connections) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ event: 'console_output', data: line }));
    }
  }
}

function detectJava(): string | null {
  try {
    const result = execSync('which java 2>/dev/null || echo ""', { encoding: 'utf-8' }).trim();
    if (result) return result;
  } catch {}
  // Common Java paths
  const paths = [
    '/usr/bin/java', '/usr/local/bin/java',
    '/usr/lib/jvm/java-21/bin/java', '/usr/lib/jvm/java-17/bin/java',
    '/usr/lib/jvm/java-11/bin/java', '/usr/lib/jvm/java-8/bin/java',
  ];
  for (const p of paths) {
    if (existsSync(p)) return p;
  }
  return null;
}

function getAvailableMemoryMB(): number {
  return Math.floor(freemem() / 1024 / 1024);
}

function getTotalMemoryMB(): number {
  return Math.floor(totalmem() / 1024 / 1024);
}

function getCpuInfo() {
  const cpusInfo = cpus();
  return {
    count: cpusInfo.length,
    model: cpusInfo[0]?.model || 'Unknown',
  };
}

function getDiskUsage(path: string): { total: number; used: number } {
  try {
    const stats = statSync(path);
    // Simple estimation — in production use df or statvfs
    return { total: 51200, used: 2048 }; // MB
  } catch {
    return { total: 51200, used: 0 };
  }
}

// ============ SERVER MANAGEMENT ============

function registerServer(config: ServerConfig): boolean {
  if (servers.has(config.id)) {
    log('error', `Server ${config.id} already exists`);
    return false;
  }
  const workDir = config.workingDir || join(SERVERS_DIR, config.id);
  config.workingDir = workDir;
  mkdirSync(workDir, { recursive: true });

  const state: ServerState = {
    id: config.id,
    status: 'stopped',
    process: null,
    config,
    startedAt: null,
    pid: null,
    cpuUsage: 0,
    memoryUsage: 0,
    peakMemory: 0,
    consoleBuffer: [],
    crashCount: 0,
    lastCrashAt: null,
    connections: new Set(),
  };
  servers.set(config.id, state);
  addConsoleLine(config.id, `[OGUltra Daemon] Server "${config.name}" registered successfully`, 'success');
  log('info', `Server ${config.id} (${config.name}) registered`);
  return true;
}

function startServer(serverId: string): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };
  if (state.status === 'running' || state.status === 'starting') {
    return { success: false, error: 'Server is already running' };
  }

  state.status = 'starting';
  addConsoleLine(serverId, `[OGUltra] Starting server "${state.config.name}"...`, 'info');
  broadcastServerStatus(serverId);

  const javaPath = state.config.javaPath || detectJava() || 'java';
  const args = buildStartupArgs(state.config);

  try {
    const child = spawn(javaPath, args, {
      cwd: state.config.workingDir,
      env: {
        ...process.env,
        SERVER_MEMORY: `${state.config.memoryLimit}M`,
      },
      stdio: ['pipe', 'pipe', 'pipe'],
      detached: false,
    });

    state.process = child;
    state.pid = child.pid || null;
    state.startedAt = Date.now();
    state.cpuUsage = 0;
    state.memoryUsage = 0;

    // Handle stdout
    child.stdout?.on('data', (data: Buffer) => {
      const text = data.toString('utf-8');
      const level = detectLogLevel(text);
      addConsoleLine(serverId, text, level);

      // Detect server started
      if (text.includes('Done (') || text.includes('Started') || text.includes('Listening on')) {
        if (state.status === 'starting') {
          state.status = 'running';
          addConsoleLine(serverId, `[OGUltra] Server is now running`, 'success');
          broadcastServerStatus(serverId);
        }
      }
    });

    // Handle stderr
    child.stderr?.on('data', (data: Buffer) => {
      const text = data.toString('utf-8');
      addConsoleLine(serverId, text, 'error');
    });

    // Handle stdin
    child.stdin?.on('error', () => {
      // stdin write after close — ignore
    });

    // Handle exit
    child.on('exit', (code, signal) => {
      const wasRunning = state.status === 'running';
      state.status = 'stopped';
      state.process = null;
      state.pid = null;
      state.cpuUsage = 0;
      state.memoryUsage = 0;

      if (code === 0) {
        addConsoleLine(serverId, `[OGUltra] Server stopped (exit code 0)`, 'info');
      } else if (code !== null) {
        addConsoleLine(serverId, `[OGUltra] Server crashed with exit code ${code}`, 'error');
        if (wasRunning && state.config.crashDetection) {
          state.crashCount++;
          state.lastCrashAt = Date.now();
          if (state.config.autoRestart && state.crashCount < 5) {
            addConsoleLine(serverId, `[OGUltra] Auto-restarting in 5 seconds... (crash #${state.crashCount})`, 'warn');
            setTimeout(() => {
              if (servers.has(serverId) && servers.get(serverId)!.status === 'stopped') {
                startServer(serverId);
              }
            }, 5000);
          } else if (state.crashCount >= 5) {
            state.status = 'crashed';
            addConsoleLine(serverId, `[OGUltra] Server crashed ${state.crashCount} times, not auto-restarting`, 'error');
          }
        }
      } else {
        addConsoleLine(serverId, `[OGUltra] Server killed by signal ${signal}`, 'warn');
      }

      broadcastServerStatus(serverId);
    });

    // Handle error
    child.on('error', (err) => {
      state.status = 'crashed';
      state.process = null;
      state.pid = null;
      addConsoleLine(serverId, `[OGUltra] Failed to start: ${err.message}`, 'error');
      broadcastServerStatus(serverId);
    });

    // Timeout: if not "running" in 60s, mark as running anyway
    setTimeout(() => {
      if (servers.has(serverId) && servers.get(serverId)!.status === 'starting') {
        state.status = 'running';
        addConsoleLine(serverId, `[OGUltra] Server marked as running (startup timeout)`, 'warn');
        broadcastServerStatus(serverId);
      }
    }, 60000);

    return { success: true };
  } catch (err: any) {
    state.status = 'crashed';
    addConsoleLine(serverId, `[OGUltra] Exception starting server: ${err.message}`, 'error');
    broadcastServerStatus(serverId);
    return { success: false, error: err.message };
  }
}

function stopServer(serverId: string, gracePeriod: number = 30000): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };
  if (state.status !== 'running' && state.status !== 'starting') {
    return { success: false, error: 'Server is not running' };
  }

  state.status = 'stopping';
  addConsoleLine(serverId, `[OGUltra] Stopping server...`, 'info');
  broadcastServerStatus(serverId);

  if (state.config.stopCommand) {
    sendCommand(serverId, state.config.stopCommand);
  } else {
    sendCommand(serverId, 'stop');
  }

  // Force kill after grace period
  setTimeout(() => {
    if (state.process && (state.status === 'stopping' || state.status === 'running')) {
      addConsoleLine(serverId, `[OGUltra] Force killing server...`, 'warn');
      try { state.process.kill('SIGKILL'); } catch {}
    }
  }, gracePeriod);

  return { success: true };
}

function restartServer(serverId: string): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };

  if (state.status === 'running' || state.status === 'starting') {
    stopServer(serverId, 15000);
    setTimeout(() => {
      startServer(serverId);
    }, 16000);
    return { success: true };
  } else {
    return startServer(serverId);
  }
}

function killServer(serverId: string): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };

  if (state.process) {
    try {
      state.process.kill('SIGKILL');
      addConsoleLine(serverId, `[OGUltra] Server forcefully killed`, 'error');
    } catch {}
  }
  state.status = 'stopped';
  state.process = null;
  state.pid = null;
  broadcastServerStatus(serverId);
  return { success: true };
}

function sendCommand(serverId: string, command: string): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };
  if (!state.process || !state.process.stdin) {
    return { success: false, error: 'Server is not running' };
  }
  if (state.status !== 'running') {
    return { success: false, error: 'Server is not running' };
  }

  try {
    state.process.stdin.write(command + '\n');
    addConsoleLine(serverId, `> ${command}`, 'info');
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

function buildStartupArgs(config: ServerConfig): string[] {
  const memMB = config.memoryLimit;
  const args: string[] = [
    `-Xms${Math.max(256, Math.floor(memMB * 0.5))}M`,
    `-Xmx${memMB}M`,
    '-XX:+UseG1GC',
    '-XX:+ParallelRefProcEnabled',
    '-XX:MaxGCPauseMillis=200',
    '-XX:+UnlockExperimentalVMOptions',
    '-XX:+DisableExplicitGC',
    '-XX:G1NewSizePercent=30',
    '-XX:G1MaxNewSizePercent=40',
    '-XX:G1HeapRegionSize=8M',
    '-XX:G1ReservePercent=20',
    '-XX:G1HeapWastePercent=5',
    '-XX:G1MixedGCCountTarget=4',
    '-XX:InitiatingHeapOccupancyPercent=15',
    '-XX:G1MixedGCLiveThresholdPercent=90',
    '-XX:G1RSetUpdatingPauseTimePercent=5',
    '-XX:SurvivorRatio=32',
    '-XX:+PerfDisableSharedMem',
    '-XX:MaxTenuringThreshold=1',
    '-Dusing.aikars.flags=https://mcflags.emc.gs',
    '-Daikars.new.flags=true',
    '-jar', config.startupCommand,
    'nogui',
  ];
  return args;
}

function detectLogLevel(text: string): ConsoleLine['level'] {
  const lower = text.toLowerCase();
  if (lower.includes('error') || lower.includes('exception') || lower.includes('fatal') || lower.includes('failed')) return 'error';
  if (lower.includes('warn') || lower.includes('caution') || lower.includes("can't keep up")) return 'warn';
  if (lower.includes('done (') || lower.includes('success') || lower.includes('saved')) return 'success';
  return 'info';
}

function broadcastServerStatus(serverId: string) {
  const state = servers.get(serverId);
  if (!state) return;
  const statusData = {
    event: 'server_status',
    data: {
      id: state.id,
      status: state.status,
      pid: state.pid,
      cpuUsage: state.cpuUsage,
      memoryUsage: state.memoryUsage,
    },
  };
  for (const ws of state.connections) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(statusData));
    }
  }
}

// ============ RESOURCE MONITORING ============

function updateResourceUsage() {
  for (const [id, state] of servers) {
    if (state.process && state.pid) {
      try {
        // Read memory from /proc on Linux
        const memInfo = readFileSync(`/proc/${state.pid}/status`, 'utf-8');
        const vmRssMatch = memInfo.match(/VmRSS:\s*(\d+)\s*kB/);
        if (vmRssMatch) {
          state.memoryUsage = parseInt(vmRssMatch[1]) * 1024; // bytes
          state.peakMemory = Math.max(state.peakMemory, state.memoryUsage);
        }
        // CPU — simplified estimation
        state.cpuUsage = Math.random() * 5 + (state.status === 'running' ? 5 : 0); // placeholder
      } catch {
        // Process might have exited
      }
    }
  }
}

// ============ FILE OPERATIONS ============

function listFiles(serverId: string, path: string): { name: string; type: 'file' | 'folder'; size: number; modified: string }[] {
  const state = servers.get(serverId);
  if (!state) return [];
  const fullPath = join(state.config.workingDir, path);
  if (!existsSync(fullPath)) return [];

  try {
    const entries = readdirSync(fullPath, { withFileTypes: true });
    return entries
      .map(e => {
        try {
          const s = statSync(join(fullPath, e.name));
          return {
            name: e.name,
            type: e.isDirectory() ? 'folder' as const : 'file' as const,
            size: e.isFile() ? s.size : 0,
            modified: s.mtime.toISOString(),
          };
        } catch {
          return { name: e.name, type: e.isFile() ? 'file' as const : 'folder' as const, size: 0, modified: new Date().toISOString() };
        }
      })
      .sort((a, b) => {
        if (a.type !== b.type) return a.type === 'folder' ? -1 : 1;
        return a.name.localeCompare(b.name);
      });
  } catch (err: any) {
    return [];
  }
}

function readFileContent(serverId: string, path: string): { success: boolean; content?: string; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };
  const fullPath = join(state.config.workingDir, path);
  try {
    const content = readFileSync(fullPath, 'utf-8');
    return { success: true, content };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

function writeFileContent(serverId: string, path: string, content: string): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };
  const fullPath = join(state.config.workingDir, path);
  try {
    mkdirSync(dirname(fullPath), { recursive: true });
    writeFileSync(fullPath, content, 'utf-8');
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

function deleteFile(serverId: string, path: string): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };
  const fullPath = join(state.config.workingDir, path);
  try {
    const s = statSync(fullPath);
    if (s.isDirectory()) {
      rmSync(fullPath, { recursive: true, force: true });
    } else {
      unlinkSync(fullPath);
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

function createDirectory(serverId: string, path: string): { success: boolean; error?: string } {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };
  const fullPath = join(state.config.workingDir, path);
  try {
    mkdirSync(fullPath, { recursive: true });
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

// ============ SERVER INSTALLATION ============

function httpsGet(url: string): Promise<{ data: string; statusCode: number }> {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith('https') ? https : http;
    mod.get(url, { timeout: 30000 }, (res) => {
      if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return httpsGet(res.headers.location).then(resolve).catch(reject);
      }
      let data = '';
      res.setEncoding('utf-8');
      res.on('data', (chunk: string) => { data += chunk; });
      res.on('end', () => resolve({ data, statusCode: res.statusCode || 200 }));
      res.on('error', reject);
    }).on('error', reject);
  });
}

function downloadFile(url: string, destPath: string, serverId: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith('https') ? https : http;
    mod.get(url, { timeout: 120000 }, (res) => {
      // Handle redirects
      if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return downloadFile(res.headers.location, destPath, serverId).then(resolve).catch(reject);
      }
      if (res.statusCode && res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode} for ${url}`));
      }
      const file = createWriteStream(destPath);
      let downloaded = 0;
      let lastReportedPct = -1;
      const total = parseInt(res.headers['content-length'] || '0', 10);
      res.on('data', (chunk: Buffer) => {
        downloaded += chunk.length;
        if (total > 0) {
          const pct = Math.round((downloaded / total) * 100);
          // Report progress at every 10% increment
          if (pct !== lastReportedPct && (pct % 10 === 0 || pct === 100)) {
            lastReportedPct = pct;
            addConsoleLine(serverId, `[Installer] Downloading... ${pct}% (${(downloaded / 1024 / 1024).toFixed(1)} MB / ${(total / 1024 / 1024).toFixed(1)} MB)`, 'info');
          }
        }
      });
      res.pipe(file);
      file.on('finish', () => { file.close(); resolve(); });
      file.on('error', (err) => {
        try { unlinkSync(destPath); } catch {}
        reject(err);
      });
    }).on('error', reject);
  });
}

function createDefaultServerProperties(port: number): string {
  return [
    `server-port=${port}`,
    `server-ip=`,
    `max-players=20`,
    `view-distance=10`,
    `simulation-distance=10`,
    `enable-command-block=false`,
    `allow-flight=false`,
    `level-seed=`,
    `level-type=minecraft\:normal`,
    `motd=OGUltra Minecraft Server`,
    `online-mode=true`,
    `pvp=true`,
    `enable-rcon=false`,
  ].join('\n') + '\n';
}

async function installServer(serverId: string, software: string, version: string): Promise<{ success: boolean; error?: string }> {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };
  if (state.status === 'running' || state.status === 'starting') {
    return { success: false, error: 'Server must be stopped before installing' };
  }

  // Set status to installing
  state.status = 'installing';
  broadcastServerStatus(serverId);

  const workDir = state.config.workingDir;
  const jarPath = join(workDir, 'server.jar');

  try {
    addConsoleLine(serverId, `[Installer] Starting installation of ${software} ${version}...`, 'info');
    addConsoleLine(serverId, `[Installer] Working directory: ${workDir}`, 'info');

    let downloadUrl: string;

    switch (software) {
      case 'paper': {
        addConsoleLine(serverId, `[Installer] Fetching Paper build info for version ${version}...`, 'info');
        const buildInfo = await httpsGet(`https://api.papermc.io/v2/projects/paper/versions/${version}`);
        if (buildInfo.statusCode !== 200) {
          throw new Error(`Failed to fetch Paper version info: HTTP ${buildInfo.statusCode}`);
        }
        const versionData = JSON.parse(buildInfo.data);
        const builds = versionData.builds as number[];
        const latestBuild = builds[builds.length - 1];
        addConsoleLine(serverId, `[Installer] Latest Paper build for ${version}: #${latestBuild}`, 'info');
        downloadUrl = `https://api.papermc.io/v2/projects/paper/versions/${version}/builds/${latestBuild}/downloads/paper-${version}-${latestBuild}.jar`;
        break;
      }
      case 'purpur': {
        addConsoleLine(serverId, `[Installer] Resolving Purpur download URL for ${version}...`, 'info');
        downloadUrl = `https://api.purpurmc.org/v2/purpur/${version}/latest/download`;
        break;
      }
      case 'vanilla': {
        addConsoleLine(serverId, `[Installer] Fetching Vanilla version manifest...`, 'info');
        const manifestResp = await httpsGet('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');
        if (manifestResp.statusCode !== 200) {
          throw new Error('Failed to fetch Minecraft version manifest');
        }
        const manifest = JSON.parse(manifestResp.data);
        const versionEntry = (manifest.versions as any[]).find((v: any) => v.id === version);
        if (!versionEntry) {
          throw new Error(`Minecraft version ${version} not found in manifest`);
        }
        addConsoleLine(serverId, `[Installer] Fetching version details for ${version}...`, 'info');
        const versionResp = await httpsGet(versionEntry.url);
        if (versionResp.statusCode !== 200) {
          throw new Error('Failed to fetch version details');
        }
        const versionDetail = JSON.parse(versionResp.data);
        const serverJar = versionDetail.downloads?.server;
        if (!serverJar?.url) {
          throw new Error('No server jar download URL found for this version');
        }
        downloadUrl = serverJar.url;
        addConsoleLine(serverId, `[Installer] Vanilla server URL resolved (sha1: ${serverJar.sha1})`, 'info');
        break;
      }
      case 'spigot': {
        addConsoleLine(serverId, `[Installer] [WARN] Spigot requires BuildTools which cannot be run in this environment.`, 'warn');
        addConsoleLine(serverId, `[Installer] Falling back to Paper (Spigot-compatible) for version ${version}...`, 'warn');
        const buildInfo = await httpsGet(`https://api.papermc.io/v2/projects/paper/versions/${version}`);
        if (buildInfo.statusCode !== 200) {
          throw new Error(`Failed to fetch Paper version info for Spigot fallback: HTTP ${buildInfo.statusCode}`);
        }
        const versionData = JSON.parse(buildInfo.data);
        const builds = versionData.builds as number[];
        const latestBuild = builds[builds.length - 1];
        downloadUrl = `https://api.papermc.io/v2/projects/paper/versions/${version}/builds/${latestBuild}/downloads/paper-${version}-${latestBuild}.jar`;
        break;
      }
      default:
        throw new Error(`Unknown software type: ${software}`);
    }

    // Download the jar
    addConsoleLine(serverId, `[Installer] Downloading from: ${downloadUrl}`, 'info');
    await downloadFile(downloadUrl, jarPath, serverId);
    addConsoleLine(serverId, `[Installer] Download complete!`, 'success');

    // Create eula.txt
    writeFileSync(join(workDir, 'eula.txt'), 'eula=true\n', 'utf-8');
    addConsoleLine(serverId, `[Installer] Created eula.txt (eula=true)`, 'info');

    // Create server.properties
    const props = createDefaultServerProperties(state.config.port);
    writeFileSync(join(workDir, 'server.properties'), props, 'utf-8');
    addConsoleLine(serverId, `[Installer] Created server.properties`, 'info');

    // Update startup command to point to the downloaded jar
    state.config.startupCommand = 'server.jar';
    addConsoleLine(serverId, `[Installer] Updated startup command to: server.jar`, 'info');

    // Set status to stopped (ready to start)
    state.status = 'stopped';
    broadcastServerStatus(serverId);
    addConsoleLine(serverId, `[Installer] Installation complete! Server is ready to start.`, 'success');

    return { success: true };
  } catch (err: any) {
    addConsoleLine(serverId, `[Installer] Installation failed: ${err.message}`, 'error');
    state.status = 'stopped';
    broadcastServerStatus(serverId);
    return { success: false, error: err.message };
  }
}

async function installCustomJar(serverId: string, downloadUrl?: string, jarData?: string): Promise<{ success: boolean; error?: string }> {
  const state = servers.get(serverId);
  if (!state) return { success: false, error: 'Server not found' };
  if (state.status === 'running' || state.status === 'starting') {
    return { success: false, error: 'Server must be stopped before installing' };
  }

  state.status = 'installing';
  broadcastServerStatus(serverId);

  const workDir = state.config.workingDir;
  const jarPath = join(workDir, 'server.jar');

  try {
    if (downloadUrl) {
      addConsoleLine(serverId, `[Installer] Downloading custom jar from: ${downloadUrl}`, 'info');
      await downloadFile(downloadUrl, jarPath, serverId);
      addConsoleLine(serverId, `[Installer] Custom jar downloaded successfully!`, 'success');
    } else if (jarData) {
      addConsoleLine(serverId, `[Installer] Decoding base64 jar data...`, 'info');
      const buffer = Buffer.from(jarData, 'base64');
      writeFileSync(jarPath, buffer);
      addConsoleLine(serverId, `[Installer] Custom jar saved (${(buffer.length / 1024 / 1024).toFixed(2)} MB)`, 'success');
    } else {
      throw new Error('Either downloadUrl or jarData must be provided');
    }

    // Create eula.txt
    writeFileSync(join(workDir, 'eula.txt'), 'eula=true\n', 'utf-8');
    addConsoleLine(serverId, `[Installer] Created eula.txt (eula=true)`, 'info');

    // Create server.properties
    const props = createDefaultServerProperties(state.config.port);
    writeFileSync(join(workDir, 'server.properties'), props, 'utf-8');
    addConsoleLine(serverId, `[Installer] Created server.properties`, 'info');

    // Update startup command
    state.config.startupCommand = 'server.jar';
    state.status = 'stopped';
    broadcastServerStatus(serverId);
    addConsoleLine(serverId, `[Installer] Custom installation complete! Server is ready to start.`, 'success');

    return { success: true };
  } catch (err: any) {
    addConsoleLine(serverId, `[Installer] Custom installation failed: ${err.message}`, 'error');
    state.status = 'stopped';
    broadcastServerStatus(serverId);
    return { success: false, error: err.message };
  }
}

// ============ NODE INFO ============

function getNodeInfo(): NodeInfo {
  const diskInfo = getDiskUsage(SERVERS_DIR);
  let runningCount = 0;
  for (const state of servers.values()) {
    if (state.status === 'running') runningCount++;
  }
  const cpu = getCpuInfo();
  return {
    uuid: DAEMON_UUID,
    hostname: execSync('hostname').toString().trim(),
    platform: platform(),
    arch: arch(),
    totalMemory: getTotalMemoryMB(),
    freeMemory: getAvailableMemoryMB(),
    cpuCount: cpu.count,
    cpuModel: cpu.model,
    daemonVersion: '1.0.0',
    totalDisk: diskInfo.total,
    usedDisk: diskInfo.used,
    serverCount: servers.size,
    runningServers: runningCount,
  };
}

function getServerStatus(serverId: string) {
  const state = servers.get(serverId);
  if (!state) return null;
  return {
    id: state.id,
    name: state.config.name,
    status: state.status,
    pid: state.pid,
    cpuUsage: state.cpuUsage,
    memoryUsage: state.memoryUsage,
    peakMemory: state.peakMemory,
    memoryLimit: state.config.memoryLimit * 1024 * 1024,
    cpuLimit: state.config.cpuLimit,
    port: state.config.port,
    startedAt: state.startedAt,
    crashCount: state.crashCount,
    consoleLines: state.consoleBuffer.slice(-100),
  };
}

function getAllServerStatuses() {
  const result: any[] = [];
  for (const state of servers.values()) {
    result.push(getServerStatus(state.id));
  }
  return result;
}

// ============ HTTP SERVER ============

const httpServer = createServer((req: IncomingMessage, res: ServerResponse) => {
  // Auth check
  const authHeader = req.headers['authorization'];
  if (authHeader !== `Bearer ${AUTH_TOKEN}`) {
    res.writeHead(401, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Unauthorized' }));
    return;
  }

  if (req.method === 'OPTIONS') {
    res.writeHead(200, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    });
    res.end();
    return;
  }

  // Parse URL
  const url = new URL(req.url || '/', `http://localhost:${DAEMON_PORT}`);
  const path = url.pathname;

  // Read body for POST/PUT
  let body = '';
  req.on('data', chunk => { body += chunk; });
  req.on('error', () => {});
  req.on('end', () => {
    let parsed: any = {};
    if (body) {
      try { parsed = JSON.parse(body); } catch {}
    }
    try {
      handleRequest(req, res, path, parsed, url);
    } catch (err: any) {
      console.error('[OGUltra] Unhandled error:', err);
      if (!res.headersSent) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: err.message }));
      }
    }
  });
});

function handleRequest(req: IncomingMessage, res: ServerResponse, path: string, body: any, url: URL) {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  };

  function json(data: any, status = 200) {
    res.writeHead(status, headers);
    res.end(JSON.stringify(data));
  }

  // === NODE ENDPOINTS ===
  if (path === '/api/node' && req.method === 'GET') {
    return json({ success: true, data: getNodeInfo() });
  }

  // === SERVER ENDPOINTS ===
  if (path === '/api/servers' && req.method === 'GET') {
    return json({ success: true, data: getAllServerStatuses() });
  }

  if (path === '/api/servers' && req.method === 'POST') {
    const config: ServerConfig = {
      id: body.id || `srv_${Date.now()}`,
      uuid: body.uuid || `uuid_${Date.now()}`,
      name: body.name || 'New Server',
      workingDir: body.workingDir || join(SERVERS_DIR, body.id || `srv_${Date.now()}`),
      startupCommand: body.startupCommand || 'server.jar',
      stopCommand: body.stopCommand || 'stop',
      javaPath: body.javaPath || null,
      memoryLimit: body.memoryLimit || 1024,
      cpuLimit: body.cpuLimit || 100,
      autoRestart: body.autoRestart ?? true,
      crashDetection: body.crashDetection ?? true,
      port: body.port || 25565,
      ip: body.ip || '0.0.0.0',
    };
    const ok = registerServer(config);
    return json({ success: ok, data: ok ? getServerStatus(config.id) : null });
  }

  const serverMatch = path.match(/^\/api\/servers\/([^/]+)$/);
  if (serverMatch) {
    const serverId = serverMatch[1];
    if (req.method === 'GET') {
      const status = getServerStatus(serverId);
      if (!status) return json({ success: false, error: 'Server not found' }, 404);
      return json({ success: true, data: status });
    }
    if (req.method === 'DELETE') {
      killServer(serverId);
      servers.delete(serverId);
      return json({ success: true });
    }
  }

  // === SERVER ACTIONS ===
  const actionMatch = path.match(/^\/api\/servers\/([^/]+)\/(.+)$/);
  if (actionMatch) {
    const serverId = actionMatch[1];
    const action = actionMatch[2];

    if (action === 'start' && req.method === 'POST') {
      return json(startServer(serverId));
    }
    if (action === 'stop' && req.method === 'POST') {
      return json(stopServer(serverId));
    }
    if (action === 'restart' && req.method === 'POST') {
      return json(restartServer(serverId));
    }
    if (action === 'kill' && req.method === 'POST') {
      return json(killServer(serverId));
    }
    if (action === 'command' && req.method === 'POST') {
      const cmd = body.command || '';
      return json(sendCommand(serverId, cmd));
    }
    if (action === 'console' && req.method === 'GET') {
      const state = servers.get(serverId);
      if (!state) return json({ success: false, error: 'Server not found' }, 404);
      const after = parseInt(url.searchParams.get('after') || '0');
      const lines = state.consoleBuffer.filter(l => l.id > after);
      return json({ success: true, data: lines });
    }

    // === FILE OPERATIONS ===
    if (action === 'files' && req.method === 'GET') {
      const filePath = url.searchParams.get('path') || '/';
      return json({ success: true, data: listFiles(serverId, filePath) });
    }
    if (action === 'files/read' && req.method === 'GET') {
      const filePath = url.searchParams.get('path') || '';
      return json(readFileContent(serverId, filePath));
    }
    if (action === 'files/write' && req.method === 'POST') {
      return json(writeFileContent(serverId, body.path || '', body.content || ''));
    }
    if (action === 'files/delete' && req.method === 'POST') {
      return json(deleteFile(serverId, body.path || ''));
    }
    if (action === 'files/mkdir' && req.method === 'POST') {
      return json(createDirectory(serverId, body.path || ''));
    }

    // === SERVER INSTALLATION ===
    if (action === 'install' && req.method === 'POST') {
      const software = body.software;
      const version = body.version;
      if (!software || !version) {
        return json({ success: false, error: 'Missing required fields: software, version' }, 400);
      }
      const validSoftware = ['paper', 'purpur', 'spigot', 'vanilla'];
      if (!validSoftware.includes(software)) {
        return json({ success: false, error: `Invalid software type. Must be one of: ${validSoftware.join(', ')}` }, 400);
      }
      // Run install asynchronously, return immediate response
      installServer(serverId, software, version).then((result) => {
        // Installation completed — status already updated via broadcast
        log('info', `Installation for ${serverId} (${software} ${version}): ${result.success ? 'success' : 'failed: ' + result.error}`);
      }).catch((err) => {
        log('error', `Installation error for ${serverId}: ${err.message}`);
      });
      return json({ success: true, message: 'Installation started' });
    }

    // === CUSTOM JAR INSTALLATION ===
    if (action === 'install/custom' && req.method === 'POST') {
      const downloadUrl = body.downloadUrl;
      const jarData = body.jarData;
      if (!downloadUrl && !jarData) {
        return json({ success: false, error: 'Either downloadUrl or jarData (base64) must be provided' }, 400);
      }
      installCustomJar(serverId, downloadUrl, jarData).then((result) => {
        log('info', `Custom installation for ${serverId}: ${result.success ? 'success' : 'failed: ' + result.error}`);
      }).catch((err) => {
        log('error', `Custom installation error for ${serverId}: ${err.message}`);
      });
      return json({ success: true, message: 'Custom installation started' });
    }
  }

  // === HEARTBEAT ===
  if (path === '/api/heartbeat' && req.method === 'GET') {
    return json({ success: true, data: { ts: Date.now(), servers: servers.size } });
  }

  json({ error: 'Not found' }, 404);
}

// ============ WEBSOCKET SERVER ============

const wss = new WebSocketServer({ server: httpServer });

wss.on('connection', (ws, req) => {
  const url = new URL(req.url || '/', `http://localhost:${DAEMON_PORT}`);
  const token = url.searchParams.get('token');
  const serverId = url.searchParams.get('server_id');

  if (token !== AUTH_TOKEN) {
    ws.close(4001, 'Unauthorized');
    return;
  }

  if (!serverId || !servers.has(serverId)) {
    ws.close(4002, 'Invalid server ID');
    return;
  }

  const state = servers.get(serverId)!;
  state.connections.add(ws);
  log('info', `WebSocket connected for server ${serverId} (total: ${state.connections.size})`);

  // Send current console buffer
  ws.send(JSON.stringify({
    event: 'console_history',
    data: state.consoleBuffer.slice(-200),
  }));

  // Send current status
  ws.send(JSON.stringify({
    event: 'server_status',
    data: {
      id: state.id,
      status: state.status,
      pid: state.pid,
      cpuUsage: state.cpuUsage,
      memoryUsage: state.memoryUsage,
    },
  }));

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === 'command' && typeof msg.command === 'string') {
        sendCommand(serverId, msg.command);
      }
      if (msg.type === 'action') {
        if (msg.action === 'start') startServer(serverId);
        if (msg.action === 'stop') stopServer(serverId);
        if (msg.action === 'restart') restartServer(serverId);
        if (msg.action === 'kill') killServer(serverId);
      }
    } catch {}
  });

  ws.on('close', () => {
    state.connections.delete(ws);
    log('info', `WebSocket disconnected for server ${serverId}`);
  });

  ws.on('error', () => {
    state.connections.delete(ws);
  });
});

// ============ STARTUP ============

// Ensure servers directory
mkdirSync(SERVERS_DIR, { recursive: true });

// Start HTTP + WebSocket server
httpServer.listen(DAEMON_PORT, '0.0.0.0', () => {
  log('info', `========================================`);
  log('info', `  OGUltra Daemon v1.0.0`);
  log('info', `  Port: ${DAEMON_PORT}`);
  log('info', `  Servers Dir: ${SERVERS_DIR}`);
  log('info', `  Node UUID: ${DAEMON_UUID}`);
  log('info', `  Java: ${detectJava() || 'Not found'}`);
  log('info', `  OS: ${platform()} ${arch()}`);
  log('info', `  CPUs: ${cpus().length}`);
  log('info', `  Memory: ${getTotalMemoryMB()} MB total`);
  log('info', `========================================`);
});

// Resource monitoring interval
setInterval(updateResourceUsage, 3000);

// Heartbeat log
heartbeatTimer = setInterval(() => {
  log('debug', `Heartbeat — ${servers.size} servers registered, ${[...servers.values()].filter(s => s.status === 'running').length} running`);
}, 30000);

// Graceful shutdown
process.on('SIGTERM', () => {
  log('info', 'Received SIGTERM, shutting down...');
  for (const [id, state] of servers) {
    if (state.process) {
      log('info', `Stopping server ${id}...`);
      try { state.process.kill('SIGTERM'); } catch {}
    }
  }
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  setTimeout(() => process.exit(0), 5000);
});

process.on('SIGINT', () => {
  log('info', 'Received SIGINT, shutting down...');
  for (const [id, state] of servers) {
    if (state.process) {
      try { state.process.kill('SIGTERM'); } catch {}
    }
  }
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  setTimeout(() => process.exit(0), 5000);
});