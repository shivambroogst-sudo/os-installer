const DAEMON_URL = 'http://localhost:3003';
const DAEMON_TOKEN = 'ogultra-daemon-secret-token';

export async function daemonFetch(path: string, opts: RequestInit = {}) {
  return fetch(`${DAEMON_URL}${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${DAEMON_TOKEN}`,
      ...opts.headers,
    },
  });
}