// ============ Mock Data for OGUltra Panel ============
// This provides realistic demo data for the panel UI

export const mockUser = {
  id: 'usr_01',
  email: 'admin@ogultra.io',
  username: 'admin',
  firstName: 'OGUltra',
  lastName: 'Admin',
  avatar: null,
  role: 'owner' as const,
  isRootAdmin: true,
};

export const mockServers = [
  {
    id: 'srv_01',
    uuid: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890',
    name: 'Survival SMP',
    description: 'Main survival server with economy and land claiming',
    status: 'running' as const,
    nodeId: 'node_01',
    node: { name: 'US-East-1', status: 'online' as const },
    cpuLimit: 200,
    memoryLimit: 4096,
    diskLimit: 10240,
    cpuUsage: 23.5,
    memoryUsage: 1843,
    diskUsage: 3200,
    serverType: 'minecraft',
    software: 'Paper',
    ip: '0.0.0.0',
    port: 25565,
    players: 12,
    maxPlayers: 100,
    version: '1.21.4',
    isSuspended: false,
    createdAt: '2026-01-15T10:00:00Z',
  },
  {
    id: 'srv_02',
    uuid: 'b2c3d4e5-f6a7-8901-bcde-f12345678901',
    name: 'Creative World',
    description: 'Creative building server with WorldEdit',
    status: 'running' as const,
    nodeId: 'node_01',
    node: { name: 'US-East-1', status: 'online' as const },
    cpuLimit: 100,
    memoryLimit: 2048,
    diskLimit: 5120,
    cpuUsage: 8.2,
    memoryUsage: 756,
    diskUsage: 1800,
    serverType: 'minecraft',
    software: 'Purpur',
    ip: '0.0.0.0',
    port: 25566,
    players: 5,
    maxPlayers: 50,
    version: '1.21.4',
    isSuspended: false,
    createdAt: '2026-02-20T14:30:00Z',
  },
  {
    id: 'srv_03',
    uuid: 'c3d4e5f6-a7b8-9012-cdef-123456789012',
    name: 'Skyblock',
    description: 'Skyblock challenge server with custom islands',
    status: 'stopped' as const,
    nodeId: 'node_01',
    node: { name: 'US-East-1', status: 'online' as const },
    cpuLimit: 100,
    memoryLimit: 2048,
    diskLimit: 5120,
    cpuUsage: 0,
    memoryUsage: 0,
    diskUsage: 950,
    serverType: 'minecraft',
    software: 'Paper',
    ip: '0.0.0.0',
    port: 25567,
    players: 0,
    maxPlayers: 80,
    version: '1.21.3',
    isSuspended: false,
    createdAt: '2026-03-01T08:00:00Z',
  },
  {
    id: 'srv_04',
    uuid: 'd4e5f6a7-b8c9-0123-defa-234567890123',
    name: 'Modded Pack',
    description: 'Create modded server with 200+ mods',
    status: 'running' as const,
    nodeId: 'node_02',
    node: { name: 'EU-West-1', status: 'online' as const },
    cpuLimit: 400,
    memoryLimit: 8192,
    diskLimit: 20480,
    cpuUsage: 67.8,
    memoryUsage: 6245,
    diskUsage: 12800,
    serverType: 'minecraft',
    software: 'Forge',
    ip: '0.0.0.0',
    port: 25568,
    players: 3,
    maxPlayers: 30,
    version: '1.20.1',
    isSuspended: false,
    createdAt: '2026-03-15T16:00:00Z',
  },
  {
    id: 'srv_05',
    uuid: 'e5f6a7b8-c9d0-1234-efab-345678901234',
    name: 'Proxy',
    description: 'BungeeCord proxy for network routing',
    status: 'running' as const,
    nodeId: 'node_01',
    node: { name: 'US-East-1', status: 'online' as const },
    cpuLimit: 50,
    memoryLimit: 512,
    diskLimit: 1024,
    cpuUsage: 2.1,
    memoryUsage: 128,
    diskUsage: 85,
    serverType: 'proxy',
    software: 'Velocity',
    ip: '0.0.0.0',
    port: 25565,
    players: 20,
    maxPlayers: 500,
    version: '3.3.0',
    isSuspended: false,
    createdAt: '2026-01-10T06:00:00Z',
  },
  {
    id: 'srv_06',
    uuid: 'f6a7b8c9-d0e1-2345-fabc-456789012345',
    name: 'Factions',
    description: 'PvP factions server with custom enchants',
    status: 'crashed' as const,
    nodeId: 'node_02',
    node: { name: 'EU-West-1', status: 'online' as const },
    cpuLimit: 200,
    memoryLimit: 4096,
    diskLimit: 8192,
    cpuUsage: 0,
    memoryUsage: 0,
    diskUsage: 4500,
    serverType: 'minecraft',
    software: 'Spigot',
    ip: '0.0.0.0',
    port: 25569,
    players: 0,
    maxPlayers: 60,
    version: '1.21.4',
    isSuspended: false,
    createdAt: '2026-04-05T12:00:00Z',
  },
];

export const mockNodes = [
  {
    id: 'node_01',
    uuid: 'n1a2b3c4-d5e6-7890-abcd-ef1234567890',
    name: 'US-East-1',
    description: 'Primary US East Coast node',
    fqdn: 'us-east-1.ogultra.io',
    daemonPort: 8080,
    isPublic: true,
    totalCpu: 800,
    totalMemory: 16384,
    totalDisk: 51200,
    usedCpu: 31.2,
    usedMemory: 2784,
    usedDisk: 7035,
    status: 'online' as const,
    serverCount: 4,
    lastPingAt: '2026-07-04T10:15:00Z',
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'node_02',
    uuid: 'n2b3c4d5-e6f7-8901-bcde-f12345678901',
    name: 'EU-West-1',
    description: 'Europe West Coast node',
    fqdn: 'eu-west-1.ogultra.io',
    daemonPort: 8080,
    isPublic: true,
    totalCpu: 1200,
    totalMemory: 32768,
    totalDisk: 102400,
    usedCpu: 22.7,
    usedMemory: 6245,
    usedDisk: 17300,
    status: 'online' as const,
    serverCount: 2,
    lastPingAt: '2026-07-04T10:14:30Z',
    createdAt: '2026-02-15T00:00:00Z',
  },
  {
    id: 'node_03',
    uuid: 'n3c4d5e6-f7a8-9012-cdef-123456789012',
    name: 'Asia-Tokyo-1',
    description: 'Asia Pacific node (Tokyo)',
    fqdn: 'asia-tokyo-1.ogultra.io',
    daemonPort: 8080,
    isPublic: false,
    totalCpu: 1600,
    totalMemory: 65536,
    totalDisk: 204800,
    usedCpu: 0,
    usedMemory: 0,
    usedDisk: 0,
    status: 'offline' as const,
    serverCount: 0,
    lastPingAt: null,
    createdAt: '2026-05-01T00:00:00Z',
  },
];

export const mockUsers = [
  { id: 'usr_01', email: 'admin@ogultra.io', username: 'admin', role: 'owner', isRootAdmin: true, lastLoginAt: '2026-07-04T09:30:00Z', servers: 6 },
  { id: 'usr_02', email: 'john@example.com', username: 'john', role: 'admin', isRootAdmin: false, lastLoginAt: '2026-07-04T08:15:00Z', servers: 3 },
  { id: 'usr_03', email: 'sarah@example.com', username: 'sarah', role: 'moderator', isRootAdmin: false, lastLoginAt: '2026-07-03T22:00:00Z', servers: 2 },
  { id: 'usr_04', email: 'mike@example.com', username: 'mike', role: 'user', isRootAdmin: false, lastLoginAt: '2026-07-03T18:45:00Z', servers: 1 },
  { id: 'usr_05', email: 'emma@example.com', username: 'emma', role: 'user', isRootAdmin: false, lastLoginAt: '2026-07-02T14:20:00Z', servers: 0 },
];

export const mockActivityLogs = [
  { id: 'log_01', username: 'admin', action: 'server.start', target: 'Survival SMP', ip: '192.168.1.1', timestamp: '2026-07-04T10:12:00Z' },
  { id: 'log_02', username: 'john', action: 'file.upload', target: 'Creative World', ip: '10.0.0.5', timestamp: '2026-07-04T10:05:00Z' },
  { id: 'log_03', username: 'admin', action: 'backup.create', target: 'Modded Pack', ip: '192.168.1.1', timestamp: '2026-07-04T09:55:00Z' },
  { id: 'log_04', username: 'sarah', action: 'plugin.install', target: 'Survival SMP', ip: '172.16.0.3', timestamp: '2026-07-04T09:40:00Z' },
  { id: 'log_05', username: 'admin', action: 'user.create', target: 'emma', ip: '192.168.1.1', timestamp: '2026-07-04T09:20:00Z' },
  { id: 'log_06', username: 'john', action: 'server.restart', target: 'Creative World', ip: '10.0.0.5', timestamp: '2026-07-04T09:10:00Z' },
  { id: 'log_07', username: 'admin', action: 'settings.update', target: 'Panel Branding', ip: '192.168.1.1', timestamp: '2026-07-04T08:50:00Z' },
  { id: 'log_08', username: 'mike', action: 'console.command', target: 'Survival SMP', ip: '192.168.2.10', timestamp: '2026-07-04T08:30:00Z' },
];

export const mockBackups = [
  { id: 'bak_01', name: 'Auto Backup - 2026-07-04', server: 'Survival SMP', fileSize: 245_000_000, createdAt: '2026-07-04T06:00:00Z', isSuccessful: true },
  { id: 'bak_02', name: 'Pre-Update Backup', server: 'Creative World', fileSize: 128_000_000, createdAt: '2026-07-03T20:00:00Z', isSuccessful: true },
  { id: 'bak_03', name: 'Weekly Backup', server: 'Modded Pack', fileSize: 2_100_000_000, createdAt: '2026-07-01T06:00:00Z', isSuccessful: true },
  { id: 'bak_04', name: 'Manual Backup', server: 'Factions', fileSize: 890_000_000, createdAt: '2026-06-30T15:00:00Z', isSuccessful: false },
];

export const mockPlugins = [
  { name: 'EssentialsX', version: '2.20.1', description: 'Essential commands and features', enabled: true, downloads: '15M' },
  { name: 'WorldEdit', version: '7.3.0', description: 'In-game map editor', enabled: true, downloads: '12M' },
  { name: 'LuckPerms', version: '5.4.102', description: 'Advanced permissions management', enabled: true, downloads: '8M' },
  { name: 'Vault', version: '1.7.3', description: 'Economy/permission/chat API', enabled: true, downloads: '10M' },
  { name: 'GriefPrevention', version: '16.18.1', description: 'Land claim protection', enabled: false, downloads: '3M' },
  { name: 'PlaceholderAPI', version: '2.11.5', description: 'Unified placeholder system', enabled: true, downloads: '5M' },
];

export const mockConsoleLines = [
  { id: 1, level: 'info', text: '[10:12:01 INFO]: Starting minecraft server version 1.21.4', time: '10:12:01' },
  { id: 2, level: 'info', text: '[10:12:01 INFO]: Loading properties', time: '10:12:01' },
  { id: 3, level: 'info', text: '[10:12:02 INFO]: Default game type: SURVIVAL', time: '10:12:02' },
  { id: 4, level: 'info', text: '[10:12:02 INFO]: Generating keypair', time: '10:12:02' },
  { id: 5, level: 'info', text: '[10:12:02 INFO]: Starting Minecraft server on *:25565', time: '10:12:02' },
  { id: 6, level: 'info', text: '[10:12:02 INFO]: Using default channel type', time: '10:12:02' },
  { id: 7, level: 'info', text: '[10:12:03 INFO]: Preparing level "world"', time: '10:12:03' },
  { id: 8, level: 'info', text: '[10:12:05 INFO]: Preparing start region for dimension minecraft:overworld', time: '10:12:05' },
  { id: 9, level: 'info', text: '[10:12:06 INFO]: Time elapsed: 1234 ms', time: '10:12:06' },
  { id: 10, level: 'info', text: '[10:12:06 INFO]: Done (8.234s)! For help, type "help"', time: '10:12:06' },
  { id: 11, level: 'info', text: '[10:12:08 INFO]: Player123 joined the game', time: '10:12:08' },
  { id: 12, level: 'info', text: '[10:12:15 INFO]: Steve joined the game', time: '10:12:15' },
  { id: 13, level: 'warn', text: '[10:12:20 WARN]: Can\'t keep up! Is the server overloaded? Running 2842ms or 56 ticks behind', time: '10:12:20' },
  { id: 14, level: 'info', text: '[10:12:25 INFO]: Alex joined the game', time: '10:12:25' },
  { id: 15, level: 'info', text: '[10:12:30 INFO]: Player123 lost connection: Disconnected', time: '10:12:30' },
  { id: 16, level: 'info', text: '[10:12:35 INFO]: Player123 left the game', time: '10:12:35' },
  { id: 17, level: 'error', text: '[10:12:40 ERROR]: Could not pass event PlayerMoveEvent to GriefPrevention v16.18.1', time: '10:12:40' },
  { id: 18, level: 'info', text: '[10:12:45 INFO]: <Steve> Hey everyone!', time: '10:12:45' },
  { id: 19, level: 'info', text: '[10:12:50 INFO]: <Alex> Welcome to the server!', time: '10:12:50' },
  { id: 20, level: 'success', text: '[10:12:55 INFO]: Server saved successfully in 234ms', time: '10:12:55' },
];

export const mockFileTree = [
  { name: 'plugins', type: 'folder' as const, size: 0, modified: '2026-07-04 09:30' },
  { name: 'world', type: 'folder' as const, size: 0, modified: '2026-07-04 10:12' },
  { name: 'world_nether', type: 'folder' as const, size: 0, modified: '2026-07-03 18:00' },
  { name: 'world_the_end', type: 'folder' as const, size: 0, modified: '2026-06-28 14:00' },
  { name: 'logs', type: 'folder' as const, size: 0, modified: '2026-07-04 10:12' },
  { name: 'server.properties', type: 'file' as const, size: 1420, modified: '2026-07-04 08:00' },
  { name: 'server.jar', type: 'file' as const, size: 52428800, modified: '2026-07-01 12:00' },
  { name: 'eula.txt', type: 'file' as const, size: 12, modified: '2026-01-15 10:00' },
  { name: 'ops.json', type: 'file' as const, size: 45, modified: '2026-07-02 16:00' },
  { name: 'whitelist.json', type: 'file' as const, size: 128, modified: '2026-07-03 09:00' },
  { name: 'bukkit.yml', type: 'file' as const, size: 3200, modified: '2026-07-01 10:00' },
  { name: 'spigot.yml', type: 'file' as const, size: 8900, modified: '2026-07-01 10:00' },
  { name: 'paper.yml', type: 'file' as const, size: 12400, modified: '2026-07-01 10:00' },
  { name: 'commands.yml', type: 'file' as const, size: 680, modified: '2026-01-15 10:00' },
  { name: 'help.yml', type: 'file' as const, size: 240, modified: '2026-01-15 10:00' },
];

export const mockSchedules = [
  { id: 'sch_01', name: 'Auto Restart', cron: '0 4 * * *', action: 'Restart', isActive: true, lastRun: '2026-07-04T04:00:00Z', nextRun: '2026-07-05T04:00:00Z' },
  { id: 'sch_02', name: 'Auto Backup', cron: '0 */6 * * *', action: 'Backup', isActive: true, lastRun: '2026-07-04T06:00:00Z', nextRun: '2026-07-04T12:00:00Z' },
  { id: 'sch_03', name: 'Broadcast', cron: '0 12 * * 1', action: 'Command: broadcast Weekly event starting!', isActive: false, lastRun: null, nextRun: null },
];

// ============ Helper Functions ============

export function getStatusColor(status: string): string {
  switch (status) {
    case 'running': return 'text-status-online';
    case 'stopped': return 'text-status-offline';
    case 'starting': return 'text-status-starting';
    case 'stopping': return 'text-status-stopping';
    case 'crashed': return 'text-status-error';
    case 'installing': return 'text-status-installing';
    case 'online': return 'text-status-online';
    case 'offline': return 'text-status-offline';
    default: return 'text-status-offline';
  }
}

export function getStatusDotClass(status: string): string {
  switch (status) {
    case 'running':
    case 'online': return 'status-dot-online';
    case 'stopped':
    case 'offline': return 'status-dot-offline';
    case 'starting':
    case 'stopping':
    case 'installing': return 'status-dot-warning';
    case 'crashed': return 'status-dot-error';
    default: return 'status-dot-offline';
  }
}

export function getStatusLabel(status: string): string {
  return status.charAt(0).toUpperCase() + status.slice(1);
}

export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

export function formatMemory(mb: number): string {
  if (mb >= 1024) return (mb / 1024).toFixed(1) + ' GB';
  return mb + ' MB';
}

export function getResourceBarClass(percentage: number): string {
  if (percentage < 60) return 'resource-bar-fill-low';
  if (percentage < 85) return 'resource-bar-fill-medium';
  return 'resource-bar-fill-high';
}

export function getInitials(name: string): string {
  return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
}