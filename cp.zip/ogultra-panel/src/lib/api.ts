// ============ OGUltra Panel — Daemon API Client ============
// All frontend calls to the daemon go through these functions.
// Panel API routes proxy to the daemon on port 3003.

const API_BASE = ''; // Same origin — uses Next.js API routes

// ============ Auth ============

export interface LoginResponse {
  success: boolean;
  user?: {
    id: string;
    email: string;
    username: string;
    role: string;
    isRootAdmin: boolean;
  };
  token?: string;
  error?: string;
}

export async function login(email: string, password: string): Promise<LoginResponse> {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  return res.json();
}

export async function register(username: string, email: string, password: string): Promise<LoginResponse> {
  const res = await fetch('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, email, password }),
  });
  return res.json();
}

// ============ Daemon Node ============

export interface NodeInfo {
  uuid: string;
  hostname: string;
  platform: string;
  arch: string;
  totalMemory: number;
  freeMemory: number;
  cpuCount: number;
  cpuModel: string;
  daemonVersion: string;
  totalDisk: number;
  usedDisk: number;
  serverCount: number;
  runningServers: number;
}

export async function getNodeInfo(): Promise<{ success: boolean; data?: NodeInfo; error?: string }> {
  const res = await fetch('/api/daemon/node');
  return res.json();
}

// ============ Servers ============

export interface ServerStatus {
  id: string;
  name: string;
  status: 'installing' | 'stopped' | 'starting' | 'running' | 'stopping' | 'crashed';
  pid: number | null;
  cpuUsage: number;
  memoryUsage: number;
  peakMemory: number;
  memoryLimit: number;
  cpuLimit: number;
  port: number;
  startedAt: number | null;
  crashCount: number;
  consoleLines: ConsoleLine[];
}

export interface ConsoleLine {
  id: number;
  text: string;
  level: 'info' | 'warn' | 'error' | 'success';
  timestamp: number;
}

export interface CreateServerRequest {
  id: string;
  name: string;
  startupCommand: string;
  memoryLimit: number;
  cpuLimit: number;
  port: number;
  autoRestart?: boolean;
  crashDetection?: boolean;
  javaPath?: string;
}

export async function listServers(): Promise<{ success: boolean; data?: ServerStatus[] }> {
  try {
    const res = await fetch('/api/daemon/servers');
    return res.json();
  } catch {
    return { success: false };
  }
}

export async function getServer(id: string): Promise<{ success: boolean; data?: ServerStatus }> {
  try {
    const res = await fetch(`/api/daemon/servers/${id}`);
    return res.json();
  } catch {
    return { success: false };
  }
}

export async function createServer(config: CreateServerRequest): Promise<{ success: boolean; data?: ServerStatus; error?: string }> {
  const res = await fetch('/api/daemon/servers', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config),
  });
  return res.json();
}

export async function deleteServer(id: string): Promise<{ success: boolean }> {
  const res = await fetch(`/api/daemon/servers/${id}`, { method: 'DELETE' });
  return res.json();
}

// ============ Server Actions ============

export async function serverAction(id: string, action: 'start' | 'stop' | 'restart' | 'kill'): Promise<{ success: boolean; error?: string }> {
  const res = await fetch(`/api/daemon/servers/${id}/action`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action }),
  });
  return res.json();
}

export async function sendServerCommand(id: string, command: string): Promise<{ success: boolean; error?: string }> {
  const res = await fetch(`/api/daemon/servers/${id}/action`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'command', command }),
  });
  return res.json();
}

// ============ File Operations ============

export interface FileEntry {
  name: string;
  type: 'file' | 'folder';
  size: number;
  modified: string;
}

export async function listFiles(serverId: string, path: string = '/'): Promise<{ success: boolean; data?: FileEntry[] }> {
  try {
    const res = await fetch(`/api/daemon/servers/${serverId}/files?path=${encodeURIComponent(path)}`);
    return res.json();
  } catch {
    return { success: false };
  }
}

export async function readFile(serverId: string, path: string): Promise<{ success: boolean; content?: string; error?: string }> {
  const res = await fetch(`/api/daemon/servers/${serverId}/files`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ operation: 'read', path }),
  });
  return res.json();
}

export async function writeFile(serverId: string, path: string, content: string): Promise<{ success: boolean; error?: string }> {
  const res = await fetch(`/api/daemon/servers/${serverId}/files`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ operation: 'write', path, content }),
  });
  return res.json();
}

export async function deleteFile(serverId: string, path: string): Promise<{ success: boolean; error?: string }> {
  const res = await fetch(`/api/daemon/servers/${serverId}/files`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ operation: 'delete', path }),
  });
  return res.json();
}

export async function createDirectory(serverId: string, path: string): Promise<{ success: boolean; error?: string }> {
  const res = await fetch(`/api/daemon/servers/${serverId}/files`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ operation: 'mkdir', path }),
  });
  return res.json();
}

// ============ WebSocket Console ============

const DAEMON_WS_PORT = 3003;
const DAEMON_TOKEN = 'ogultra-daemon-secret-token';

export function createConsoleWebSocket(
  serverId: string,
  onMessage: (data: any) => void,
  onOpen?: () => void,
  onClose?: () => void,
): WebSocket | null {
  try {
    // Connect through the gateway using XTransformPort
    const wsUrl = `/?XTransformPort=${DAEMON_WS_PORT}&token=${DAEMON_TOKEN}&server_id=${serverId}`;
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      console.log(`[OGUltra] WebSocket connected to server ${serverId}`);
      onOpen?.();
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        onMessage(data);
      } catch (e) {
        console.error('[OGUltra] Failed to parse WS message:', e);
      }
    };

    ws.onclose = (event) => {
      console.log(`[OGUltra] WebSocket closed: ${event.code} ${event.reason}`);
      onClose?.();
    };

    ws.onerror = (error) => {
      console.error('[OGUltra] WebSocket error:', error);
    };

    return ws;
  } catch (e) {
    console.error('[OGUltra] Failed to create WebSocket:', e);
    return null;
  }
}