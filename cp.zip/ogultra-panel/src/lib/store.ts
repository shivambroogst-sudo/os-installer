import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// ============ Auth Store ============

export interface User {
  id: string;
  email: string;
  username: string;
  firstName?: string | null;
  lastName?: string | null;
  avatar?: string | null;
  role: string;
  isRootAdmin: boolean;
}

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (user: User, token: string) => void;
  logout: () => void;
  updateUser: (data: Partial<User>) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      login: (user, token) => set({ user, token, isAuthenticated: true }),
      logout: () => set({ user: null, token: null, isAuthenticated: false }),
      updateUser: (data) =>
        set((state) => ({
          user: state.user ? { ...state.user, ...data } : null,
        })),
    }),
    { name: 'ogultra-auth' }
  )
);

// ============ Navigation Store ============

export type View =
  | 'dashboard'
  | 'servers'
  | 'server-detail'
  | 'nodes'
  | 'node-detail'
  | 'users'
  | 'admin'
  | 'admin-settings'
  | 'admin-branding'
  | 'admin-roles'
  | 'admin-security'
  | 'activity';

export type ServerTab =
  | 'console'
  | 'files'
  | 'databases'
  | 'startup'
  | 'plugins'
  | 'backups'
  | 'schedules'
  | 'network'
  | 'settings';

interface NavigationState {
  currentView: View;
  selectedServerId: string | null;
  selectedNodeId: string | null;
  selectedServerTab: ServerTab;
  sidebarOpen: boolean;
  setView: (view: View) => void;
  selectServer: (id: string) => void;
  selectNode: (id: string) => void;
  setServerTab: (tab: ServerTab) => void;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
}

export const useNavStore = create<NavigationState>()((set) => ({
  currentView: 'dashboard',
  selectedServerId: null,
  selectedNodeId: null,
  selectedServerTab: 'console',
  sidebarOpen: true,
  setView: (view) => set({ currentView: view }),
  selectServer: (id) => set({ selectedServerId: id, currentView: 'server-detail' }),
  selectNode: (id) => set({ selectedNodeId: id, currentView: 'node-detail' }),
  setServerTab: (tab) => set({ selectedServerTab: tab }),
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
}));

// ============ Theme Store ============

interface ThemeState {
  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;
  toggleTheme: () => void;
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      theme: 'dark',
      setTheme: (theme) => set({ theme }),
      toggleTheme: () => set((s) => ({ theme: s.theme === 'dark' ? 'light' : 'dark' })),
    }),
    { name: 'ogultra-theme' }
  )
);