'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Mail, Lock, User, Eye, EyeOff, ArrowRight, Github, Chrome } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useAuthStore } from '@/lib/store';
import { login as apiLogin, register as apiRegister } from '@/lib/api';
import { toast } from 'sonner';

// ─── Discord SVG Icon (inline since it's not in lucide-react) ───
function DiscordIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189z" />
    </svg>
  );
}

// ─── Animation Variants ───
const backdropVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.5 } },
};

const cardVariants = {
  hidden: { opacity: 0, y: 30, scale: 0.96 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] },
  },
  exit: {
    opacity: 0,
    y: -20,
    scale: 0.96,
    transition: { duration: 0.25, ease: [0.22, 1, 0.36, 1] },
  },
};

const formFieldVariants = {
  hidden: { opacity: 0, x: -12 },
  visible: (i: number) => ({
    opacity: 1,
    x: 0,
    transition: { delay: 0.08 * i, duration: 0.35, ease: [0.22, 1, 0.36, 1] },
  }),
};

const socialButtonVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: 0.4 + 0.08 * i, duration: 0.3 },
  }),
};

const orbVariants = {
  animate: (i: number) => ({
    y: [0, -15, 0],
    x: [0, i % 2 === 0 ? 10 : -10, 0],
    scale: [1, 1.05, 1],
    transition: {
      duration: 6 + i,
      repeat: Infinity,
      ease: 'easeInOut',
    },
  }),
};

// ─── Component ───
export default function AuthPage() {
  const login = useAuthStore((s) => s.login);

  // View state: login vs register
  const [mode, setMode] = useState<'login' | 'register'>('login');

  // Login form
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [show2FA, setShow2FA] = useState(false);
  const [twoFaCode, setTwoFaCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Register form
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showRegConfirmPassword, setShowRegConfirmPassword] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail.trim() || !loginPassword.trim()) {
      toast.error('Please fill in all fields');
      return;
    }
    if (show2FA && !twoFaCode.trim()) {
      toast.error('Please enter your 2FA code');
      return;
    }

    setIsLoading(true);
    try {
      const result = await apiLogin(loginEmail, loginPassword);
      if (result.success && result.user && result.token) {
        login({
          id: result.user.id,
          email: result.user.email,
          username: result.user.username,
          role: result.user.role,
          isRootAdmin: result.user.isRootAdmin,
        }, result.token);
        toast.success(`Welcome back, ${result.user.username}!`);
      } else {
        toast.error(result.error || 'Login failed');
      }
    } catch {
      // Fallback to demo login if daemon is not reachable
      login({
        id: 'usr_01',
        email: loginEmail,
        username: loginEmail.split('@')[0],
        role: 'admin',
        isRootAdmin: true,
      }, 'panel-token');
      toast.success('Logged in (demo mode — daemon not connected)');
    }
    setIsLoading(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regUsername.trim() || !regEmail.trim() || !regPassword.trim() || !regConfirmPassword.trim()) {
      toast.error('Please fill in all fields');
      return;
    }
    if (!regEmail.includes('@')) {
      toast.error('Please enter a valid email address');
      return;
    }
    if (regPassword.length < 8) {
      toast.error('Password must be at least 8 characters');
      return;
    }
    if (regPassword !== regConfirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    setIsLoading(true);
    try {
      const result = await apiRegister(regUsername, regEmail, regPassword);
      if (result.success && result.user && result.token) {
        login({ id: result.user.id, email: result.user.email, username: result.user.username, role: result.user.role, isRootAdmin: result.user.isRootAdmin }, result.token);
        toast.success('Account created successfully!');
      } else {
        toast.error(result.error || 'Registration failed');
      }
    } catch {
      login({ id: 'usr_new', email: regEmail, username: regUsername, role: 'user', isRootAdmin: false }, 'panel-token');
      toast.success('Account created (demo mode)');
    }
    setIsLoading(false);
  };

  const handleSocialLogin = (provider: string) => {
    toast.info(`${provider} login is not available in this demo`);
  };

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#050510] bg-grid-pattern px-4 py-8">
      {/* ── Animated background orbs ── */}
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        <motion.div
          custom={0}
          variants={orbVariants}
          animate="animate"
          className="absolute left-[15%] top-[20%] h-[340px] w-[340px] rounded-full bg-brand-600/10 blur-[100px]"
        />
        <motion.div
          custom={1}
          variants={orbVariants}
          animate="animate"
          className="absolute bottom-[15%] right-[15%] h-[280px] w-[280px] rounded-full bg-purple-600/10 blur-[100px]"
        />
        <motion.div
          custom={2}
          variants={orbVariants}
          animate="animate"
          className="absolute left-[55%] top-[10%] h-[200px] w-[200px] rounded-full bg-accent-500/8 blur-[80px]"
        />
      </div>

      {/* ── Main content ── */}
      <motion.div
        variants={backdropVariants}
        initial="hidden"
        animate="visible"
        className="relative z-10 flex w-full max-w-[440px] flex-col items-center gap-6"
      >
        {/* ── Brand Header ── */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="flex flex-col items-center gap-2"
        >
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl gradient-brand shadow-lg shadow-brand-600/25">
            <Shield className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight gradient-text">
            OGUltra
          </h1>
          <p className="text-sm text-white/40">
            Premium Game Hosting Platform
          </p>
        </motion.div>

        {/* ── Auth Card ── */}
        <AnimatePresence mode="wait">
          {mode === 'login' ? (
            <motion.div
              key="login-card"
              variants={cardVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="glass-card w-full p-6 sm:p-8"
            >
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-white">Welcome back</h2>
                <p className="mt-1 text-sm text-white/40">
                  Sign in to your account to continue
                </p>
              </div>

              {/* ── Social Buttons ── */}
              <div className="mb-6 grid grid-cols-3 gap-3">
                <motion.button
                  custom={0}
                  variants={socialButtonVariants}
                  initial="hidden"
                  animate="visible"
                  onClick={() => handleSocialLogin('Discord')}
                  className="glass-input flex items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium text-white/70 transition-all hover:border-[#5865F2]/40 hover:bg-[#5865F2]/10 hover:text-[#5865F2]"
                >
                  <DiscordIcon className="h-4 w-4" />
                  <span className="hidden sm:inline">Discord</span>
                </motion.button>
                <motion.button
                  custom={1}
                  variants={socialButtonVariants}
                  initial="hidden"
                  animate="visible"
                  onClick={() => handleSocialLogin('Google')}
                  className="glass-input flex items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium text-white/70 transition-all hover:border-white/20 hover:bg-white/10 hover:text-white"
                >
                  <Chrome className="h-4 w-4" />
                  <span className="hidden sm:inline">Google</span>
                </motion.button>
                <motion.button
                  custom={2}
                  variants={socialButtonVariants}
                  initial="hidden"
                  animate="visible"
                  onClick={() => handleSocialLogin('GitHub')}
                  className="glass-input flex items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium text-white/70 transition-all hover:border-white/20 hover:bg-white/10 hover:text-white"
                >
                  <Github className="h-4 w-4" />
                  <span className="hidden sm:inline">GitHub</span>
                </motion.button>
              </div>

              {/* ── Divider ── */}
              <div className="relative mb-6 flex items-center gap-3">
                <div className="h-px flex-1 bg-white/10" />
                <span className="text-xs font-medium uppercase tracking-wider text-white/30">
                  or continue with email
                </span>
                <div className="h-px flex-1 bg-white/10" />
              </div>

              {/* ── Login Form ── */}
              <form onSubmit={handleLogin} className="flex flex-col gap-4">
                {/* Email / Username */}
                <motion.div
                  custom={0}
                  variants={formFieldVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-2"
                >
                  <Label htmlFor="login-email" className="text-sm font-medium text-white/60">
                    Email or Username
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                    <Input
                      id="login-email"
                      type="text"
                      placeholder="admin@ogultra.io"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      className="glass-input h-11 pl-10 text-sm text-white placeholder:text-white/25"
                    />
                  </div>
                </motion.div>

                {/* Password */}
                <motion.div
                  custom={1}
                  variants={formFieldVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-2"
                >
                  <Label htmlFor="login-password" className="text-sm font-medium text-white/60">
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                    <Input
                      id="login-password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Enter your password"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="glass-input h-11 pl-10 pr-10 text-sm text-white placeholder:text-white/25"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 transition-colors hover:text-white/60"
                      tabIndex={-1}
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </motion.div>

                {/* Remember Me + Forgot Password */}
                <motion.div
                  custom={2}
                  variants={formFieldVariants}
                  initial="hidden"
                  animate="visible"
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="remember-me"
                      checked={rememberMe}
                      onCheckedChange={(checked) => setRememberMe(checked === true)}
                      className="border-white/20 data-[state=checked]:bg-brand-600 data-[state=checked]:border-brand-600"
                    />
                    <Label
                      htmlFor="remember-me"
                      className="cursor-pointer text-sm text-white/50 hover:text-white/70"
                    >
                      Remember me
                    </Label>
                  </div>
                  <button
                    type="button"
                    onClick={() => toast.info('Password reset is not available in this demo')}
                    className="text-sm font-medium text-brand-400 transition-colors hover:text-brand-300"
                  >
                    Forgot Password?
                  </button>
                </motion.div>

                {/* 2FA Code (hidden by default) */}
                <AnimatePresence>
                  {show2FA && (
                    <motion.div
                      initial={{ opacity: 0, height: 0, marginTop: 0 }}
                      animate={{ opacity: 1, height: 'auto', marginTop: 0 }}
                      exit={{ opacity: 0, height: 0, marginTop: 0 }}
                      transition={{ duration: 0.25 }}
                      className="overflow-hidden"
                    >
                      <div className="space-y-2 pt-2">
                        <Label htmlFor="twoFa-code" className="text-sm font-medium text-white/60">
                          2FA Code
                        </Label>
                        <Input
                          id="twoFa-code"
                          type="text"
                          placeholder="000000"
                          value={twoFaCode}
                          onChange={(e) => setTwoFaCode(e.target.value)}
                          maxLength={6}
                          className="glass-input h-11 text-center font-mono text-sm tracking-[0.3em] text-white placeholder:text-white/25"
                        />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* 2FA Toggle */}
                <motion.button
                  custom={3}
                  variants={formFieldVariants}
                  initial="hidden"
                  animate="visible"
                  type="button"
                  onClick={() => setShow2FA(!show2FA)}
                  className="self-start text-xs text-white/30 transition-colors hover:text-white/50"
                >
                  {show2FA ? 'Hide 2FA input' : 'I have a 2FA code'}
                </motion.button>

                {/* Submit Button */}
                <motion.div
                  custom={4}
                  variants={formFieldVariants}
                  initial="hidden"
                  animate="visible"
                >
                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="group relative h-11 w-full overflow-hidden rounded-lg gradient-brand text-sm font-semibold text-white shadow-lg shadow-brand-600/20 transition-all hover:shadow-brand-600/30 disabled:opacity-60"
                  >
                    <span className="relative z-10 flex items-center justify-center gap-2">
                      {isLoading ? (
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                          className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white"
                        />
                      ) : (
                        <>
                          Sign In
                          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                        </>
                      )}
                    </span>
                    {/* Shimmer overlay */}
                    {!isLoading && (
                      <motion.div
                        className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/10 to-transparent"
                        animate={{ translateX: ['100%', '-100%'] }}
                        transition={{ duration: 3, repeat: Infinity, ease: 'linear', repeatDelay: 2 }}
                      />
                    )}
                  </Button>
                </motion.div>
              </form>

              {/* ── Switch to Register ── */}
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="mt-6 text-center text-sm text-white/40"
              >
                Don&apos;t have an account?{' '}
                <button
                  type="button"
                  onClick={() => setMode('register')}
                  className="font-semibold text-brand-400 transition-colors hover:text-brand-300"
                >
                  Create one
                </button>
              </motion.p>
            </motion.div>
          ) : (
            <motion.div
              key="register-card"
              variants={cardVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="glass-card w-full p-6 sm:p-8"
            >
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-white">Create an account</h2>
                <p className="mt-1 text-sm text-white/40">
                  Get started with OGUltra in seconds
                </p>
              </div>

              {/* ── Social Buttons ── */}
              <div className="mb-6 grid grid-cols-3 gap-3">
                <motion.button
                  custom={0}
                  variants={socialButtonVariants}
                  initial="hidden"
                  animate="visible"
                  onClick={() => handleSocialLogin('Discord')}
                  className="glass-input flex items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium text-white/70 transition-all hover:border-[#5865F2]/40 hover:bg-[#5865F2]/10 hover:text-[#5865F2]"
                >
                  <DiscordIcon className="h-4 w-4" />
                  <span className="hidden sm:inline">Discord</span>
                </motion.button>
                <motion.button
                  custom={1}
                  variants={socialButtonVariants}
                  initial="hidden"
                  animate="visible"
                  onClick={() => handleSocialLogin('Google')}
                  className="glass-input flex items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium text-white/70 transition-all hover:border-white/20 hover:bg-white/10 hover:text-white"
                >
                  <Chrome className="h-4 w-4" />
                  <span className="hidden sm:inline">Google</span>
                </motion.button>
                <motion.button
                  custom={2}
                  variants={socialButtonVariants}
                  initial="hidden"
                  animate="visible"
                  onClick={() => handleSocialLogin('GitHub')}
                  className="glass-input flex items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium text-white/70 transition-all hover:border-white/20 hover:bg-white/10 hover:text-white"
                >
                  <Github className="h-4 w-4" />
                  <span className="hidden sm:inline">GitHub</span>
                </motion.button>
              </div>

              {/* ── Divider ── */}
              <div className="relative mb-6 flex items-center gap-3">
                <div className="h-px flex-1 bg-white/10" />
                <span className="text-xs font-medium uppercase tracking-wider text-white/30">
                  or register with email
                </span>
                <div className="h-px flex-1 bg-white/10" />
              </div>

              {/* ── Register Form ── */}
              <form onSubmit={handleRegister} className="flex flex-col gap-4">
                {/* Username */}
                <motion.div
                  custom={0}
                  variants={formFieldVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-2"
                >
                  <Label htmlFor="reg-username" className="text-sm font-medium text-white/60">
                    Username
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                    <Input
                      id="reg-username"
                      type="text"
                      placeholder="Choose a username"
                      value={regUsername}
                      onChange={(e) => setRegUsername(e.target.value)}
                      className="glass-input h-11 pl-10 text-sm text-white placeholder:text-white/25"
                    />
                  </div>
                </motion.div>

                {/* Email */}
                <motion.div
                  custom={1}
                  variants={formFieldVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-2"
                >
                  <Label htmlFor="reg-email" className="text-sm font-medium text-white/60">
                    Email
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                    <Input
                      id="reg-email"
                      type="email"
                      placeholder="you@example.com"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      className="glass-input h-11 pl-10 text-sm text-white placeholder:text-white/25"
                    />
                  </div>
                </motion.div>

                {/* Password */}
                <motion.div
                  custom={2}
                  variants={formFieldVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-2"
                >
                  <Label htmlFor="reg-password" className="text-sm font-medium text-white/60">
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                    <Input
                      id="reg-password"
                      type={showRegPassword ? 'text' : 'password'}
                      placeholder="Min. 8 characters"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      className="glass-input h-11 pl-10 pr-10 text-sm text-white placeholder:text-white/25"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegPassword(!showRegPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 transition-colors hover:text-white/60"
                      tabIndex={-1}
                      aria-label={showRegPassword ? 'Hide password' : 'Show password'}
                    >
                      {showRegPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </motion.div>

                {/* Confirm Password */}
                <motion.div
                  custom={3}
                  variants={formFieldVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-2"
                >
                  <Label htmlFor="reg-confirm-password" className="text-sm font-medium text-white/60">
                    Confirm Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                    <Input
                      id="reg-confirm-password"
                      type={showRegConfirmPassword ? 'text' : 'password'}
                      placeholder="Confirm your password"
                      value={regConfirmPassword}
                      onChange={(e) => setRegConfirmPassword(e.target.value)}
                      className="glass-input h-11 pl-10 pr-10 text-sm text-white placeholder:text-white/25"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegConfirmPassword(!showRegConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 transition-colors hover:text-white/60"
                      tabIndex={-1}
                      aria-label={showRegConfirmPassword ? 'Hide password' : 'Show password'}
                    >
                      {showRegConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </motion.div>

                {/* Submit Button */}
                <motion.div
                  custom={4}
                  variants={formFieldVariants}
                  initial="hidden"
                  animate="visible"
                  className="pt-1"
                >
                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="group relative h-11 w-full overflow-hidden rounded-lg gradient-brand text-sm font-semibold text-white shadow-lg shadow-brand-600/20 transition-all hover:shadow-brand-600/30 disabled:opacity-60"
                  >
                    <span className="relative z-10 flex items-center justify-center gap-2">
                      {isLoading ? (
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                          className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white"
                        />
                      ) : (
                        <>
                          Create Account
                          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                        </>
                      )}
                    </span>
                    {!isLoading && (
                      <motion.div
                        className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/10 to-transparent"
                        animate={{ translateX: ['100%', '-100%'] }}
                        transition={{ duration: 3, repeat: Infinity, ease: 'linear', repeatDelay: 2 }}
                      />
                    )}
                  </Button>
                </motion.div>
              </form>

              {/* ── Switch to Login ── */}
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="mt-6 text-center text-sm text-white/40"
              >
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="font-semibold text-brand-400 transition-colors hover:text-brand-300"
                >
                  Sign in
                </button>
              </motion.p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── Footer ── */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-center text-xs text-white/20"
        >
          &copy; {new Date().getFullYear()} OGUltra. All rights reserved.
        </motion.p>
      </motion.div>
    </main>
  );
}