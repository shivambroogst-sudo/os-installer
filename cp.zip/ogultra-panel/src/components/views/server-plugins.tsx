'use client';
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  Plus,
  Settings,
  RefreshCw,
  Trash2,
  Download,
  Puzzle,
  Filter,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { mockPlugins, mockServers } from '@/lib/mock-data';
import { useNavStore } from '@/lib/store';
import { toast } from 'sonner';

// ============ Types ============

interface Plugin {
  name: string;
  version: string;
  description: string;
  enabled: boolean;
  downloads: string;
}

// ============ Component ============

export default function ServerPlugins() {
  const { selectedServerId } = useNavStore();
  const server = mockServers.find((s) => s.id === selectedServerId) ?? mockServers[0];

  const [plugins, setPlugins] = useState<Plugin[]>([...mockPlugins]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showEnabledOnly, setShowEnabledOnly] = useState(false);
  const [installDialogOpen, setInstallDialogOpen] = useState(false);
  const [installSearch, setInstallSearch] = useState('');

  const filteredPlugins = useMemo(() => {
    let result = plugins;
    if (showEnabledOnly) {
      result = result.filter((p) => p.enabled);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.version.toLowerCase().includes(q)
      );
    }
    return result;
  }, [plugins, showEnabledOnly, searchQuery]);

  const enabledCount = plugins.filter((p) => p.enabled).length;

  const handleTogglePlugin = (name: string) => {
    setPlugins((prev) =>
      prev.map((p) => (p.name === name ? { ...p, enabled: !p.enabled } : p))
    );
    const plugin = plugins.find((p) => p.name === name);
    toast.success(`${plugin?.name} ${plugin?.enabled ? 'disabled' : 'enabled'}`);
  };

  const handleConfigure = (name: string) => {
    toast.info(`Opening config for ${name}`, {
      description: 'Configuration editor would open here.',
    });
  };

  const handleReload = (name: string) => {
    toast.success(`Reloading ${name}`, {
      description: 'Plugin reload command has been sent.',
    });
  };

  const handleUninstall = (name: string) => {
    setPlugins((prev) => prev.filter((p) => p.name !== name));
    toast.success(`${name} uninstalled`, {
      description: 'The plugin has been removed.',
    });
  };

  const handleInstallPlugin = () => {
    if (!installSearch.trim()) {
      toast.error('Enter a plugin name to install');
      return;
    }
    setPlugins((prev) => [
      ...prev,
      {
        name: installSearch.trim(),
        version: '1.0.0',
        description: 'Newly installed plugin',
        enabled: true,
        downloads: '0',
      },
    ]);
    setInstallSearch('');
    setInstallDialogOpen(false);
    toast.success(`Installed ${installSearch.trim()}`, {
      description: 'The plugin has been installed successfully.',
    });
  };

  return (
    <TooltipProvider>
      <motion.div
        className="space-y-6"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
      >
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white">Plugin Manager</h2>
            <p className="text-sm text-zinc-400 mt-1">
              {enabledCount} of {plugins.length} plugins enabled on {server.name}
            </p>
          </div>
          <Button
            className="bg-brand-600 hover:bg-brand-500 text-white"
            onClick={() => setInstallDialogOpen(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Install Plugin
          </Button>
        </div>

        {/* Search & Filter Bar */}
        <motion.div
          className="glass-card p-4"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
        >
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search plugins..."
                className="pl-9 bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600"
              />
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/5 border border-zinc-700">
                <Filter className="w-3.5 h-3.5 text-zinc-400" />
                <span className="text-sm text-zinc-300">Enabled Only</span>
                <Switch
                  checked={showEnabledOnly}
                  onCheckedChange={setShowEnabledOnly}
                  className="data-[state=checked]:bg-brand-600"
                />
              </div>
            </div>
          </div>
        </motion.div>

        {/* Plugin Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          <AnimatePresence mode="popLayout">
            {filteredPlugins.map((plugin, index) => (
              <motion.div
                key={plugin.name}
                className={`glass-card p-5 flex flex-col ${!plugin.enabled ? 'opacity-60' : ''}`}
                initial={{ opacity: 0, y: 12, scale: 0.98 }}
                animate={{ opacity: plugin.enabled ? 1 : 0.6, y: 0, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95, y: -8 }}
                transition={{ delay: index * 0.04, duration: 0.25 }}
                layout
              >
                {/* Plugin Header */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="p-2 rounded-lg bg-brand-500/20 shrink-0">
                      <Puzzle className="w-4 h-4 text-brand-400" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-sm font-semibold text-white truncate">{plugin.name}</h3>
                      <Badge variant="outline" className="border-brand-500/30 text-brand-400 text-xs mt-0.5">
                        v{plugin.version}
                      </Badge>
                    </div>
                  </div>
                  <Switch
                    checked={plugin.enabled}
                    onCheckedChange={() => handleTogglePlugin(plugin.name)}
                    className="data-[state=checked]:bg-accent-500 shrink-0"
                  />
                </div>

                {/* Description */}
                <p className="text-sm text-zinc-400 mb-4 flex-1">{plugin.description}</p>

                {/* Downloads */}
                <div className="flex items-center gap-1.5 mb-4">
                  <Download className="w-3.5 h-3.5 text-zinc-500" />
                  <span className="text-xs text-zinc-500">{plugin.downloads} downloads</span>
                </div>

                <Separator className="bg-zinc-800 mb-4" />

                {/* Actions */}
                <div className="flex items-center gap-2">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 text-zinc-400 hover:text-white hover:bg-white/5 flex-1"
                        onClick={() => handleConfigure(plugin.name)}
                      >
                        <Settings className="w-3.5 h-3.5 mr-1.5" />
                        Configure
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Edit plugin configuration</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 text-zinc-400 hover:text-white hover:bg-white/5"
                        onClick={() => handleReload(plugin.name)}
                        disabled={!plugin.enabled}
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Reload plugin</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 text-red-400/70 hover:text-red-400 hover:bg-red-500/10"
                        onClick={() => handleUninstall(plugin.name)}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Uninstall plugin</TooltipContent>
                  </Tooltip>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Empty State */}
        {filteredPlugins.length === 0 && (
          <motion.div
            className="glass-card p-12 flex flex-col items-center justify-center text-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className="p-4 rounded-2xl bg-white/5 mb-4">
              <Puzzle className="w-10 h-10 text-zinc-600" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">No plugins found</h3>
            <p className="text-sm text-zinc-400 max-w-sm">
              {searchQuery
                ? `No plugins match "${searchQuery}". Try a different search term.`
                : showEnabledOnly
                ? 'No enabled plugins. Enable some plugins or toggle the filter.'
                : 'No plugins installed. Click the button above to install one.'}
            </p>
          </motion.div>
        )}

        {/* Install Plugin Dialog */}
        <Dialog open={installDialogOpen} onOpenChange={setInstallDialogOpen}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-md">
            <DialogHeader>
              <DialogTitle>Install Plugin</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm text-zinc-300">Plugin Name</label>
                <Input
                  value={installSearch}
                  onChange={(e) => setInstallSearch(e.target.value)}
                  placeholder="e.g. EssentialsX"
                  className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600"
                  onKeyDown={(e) => e.key === 'Enter' && handleInstallPlugin()}
                />
              </div>
              <p className="text-xs text-zinc-500">
                Enter the plugin name or slug from SpigotMC / Modrinth / Hangar.
              </p>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white"
                onClick={() => setInstallDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                className="bg-brand-600 hover:bg-brand-500 text-white"
                onClick={handleInstallPlugin}
              >
                Install
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>
    </TooltipProvider>
  );
}