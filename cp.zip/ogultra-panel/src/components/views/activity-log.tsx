'use client';
import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import {
  Search,
  Download,
  Clock,
  Filter,
  X,
  Activity,
  Globe,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  mockActivityLogs,
  getInitials,
} from '@/lib/mock-data';

// ─── Animation Variants ───
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.04, delayChildren: 0.05 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 16, scale: 0.98 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { type: 'spring', stiffness: 260, damping: 24, mass: 0.8 },
  },
};

// ─── Action Colors ───
const actionColorMap: Record<string, { text: string; bg: string; badgeClass: string }> = {
  'server.start': { text: 'text-emerald-400', bg: 'bg-emerald-500/10', badgeClass: 'border-emerald-500/20 text-emerald-400 bg-emerald-500/10' },
  'server.stop': { text: 'text-red-400', bg: 'bg-red-500/10', badgeClass: 'border-red-500/20 text-red-400 bg-red-500/10' },
  'server.restart': { text: 'text-amber-400', bg: 'bg-amber-500/10', badgeClass: 'border-amber-500/20 text-amber-400 bg-amber-500/10' },
  'file.upload': { text: 'text-blue-400', bg: 'bg-blue-500/10', badgeClass: 'border-blue-500/20 text-blue-400 bg-blue-500/10' },
  'plugin.install': { text: 'text-purple-400', bg: 'bg-purple-500/10', badgeClass: 'border-purple-500/20 text-purple-400 bg-purple-500/10' },
  'user.create': { text: 'text-brand-400', bg: 'bg-brand-500/10', badgeClass: 'border-brand-500/20 text-brand-400 bg-brand-500/10' },
  'settings.update': { text: 'text-amber-400', bg: 'bg-amber-500/10', badgeClass: 'border-amber-500/20 text-amber-400 bg-amber-500/10' },
  'console.command': { text: 'text-muted-foreground', bg: 'bg-white/5', badgeClass: 'border-white/10 text-muted-foreground bg-white/[0.03]' },
  'backup.create': { text: 'text-cyan-400', bg: 'bg-cyan-500/10', badgeClass: 'border-cyan-500/20 text-cyan-400 bg-cyan-500/10' },
};

const actionLabels: Record<string, string> = {
  'server.start': 'started',
  'server.stop': 'stopped',
  'server.restart': 'restarted',
  'file.upload': 'uploaded files to',
  'backup.create': 'created a backup of',
  'plugin.install': 'installed a plugin on',
  'user.create': 'created user',
  'settings.update': 'updated',
  'console.command': 'ran a command on',
};

const avatarColors = [
  'bg-brand-500/25 text-brand-300',
  'bg-accent-500/25 text-accent-300',
  'bg-purple-500/25 text-purple-300',
  'bg-amber-500/25 text-amber-300',
  'bg-cyan-500/25 text-cyan-300',
  'bg-pink-500/25 text-pink-300',
];

function getAvatarColor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return avatarColors[Math.abs(hash) % avatarColors.length];
}

function getRelativeTime(timestamp: string): string {
  const now = Date.now();
  const then = new Date(timestamp).getTime();
  const diffMs = now - then;
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return 'Just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDay = Math.floor(diffHr / 24);
  if (diffDay < 30) return `${diffDay}d ago`;
  const diffMonth = Math.floor(diffDay / 30);
  return `${diffMonth}mo ago`;
}

function isWithinDateRange(timestamp: string, range: string): boolean {
  if (range === 'all') return true;
  const now = Date.now();
  const then = new Date(timestamp).getTime();
  const diffMs = now - then;
  const diffDay = diffMs / (1000 * 60 * 60 * 24);
  if (range === 'today') return diffDay < 1;
  if (range === 'week') return diffDay < 7;
  if (range === 'month') return diffDay < 30;
  return true;
}

// ─── Main Activity Log ───
export default function ActivityLog() {
  const [search, setSearch] = useState('');
  const [userFilter, setUserFilter] = useState('all');
  const [actionFilter, setActionFilter] = useState('all');
  const [dateRange, setDateRange] = useState('all');

  const uniqueUsers = [...new Set(mockActivityLogs.map((l) => l.username))];
  const uniqueActions = [...new Set(mockActivityLogs.map((l) => l.action))];

  const filteredLogs = useMemo(() => {
    return mockActivityLogs.filter((log) => {
      const matchesSearch =
        !search ||
        log.username.toLowerCase().includes(search.toLowerCase()) ||
        log.target.toLowerCase().includes(search.toLowerCase()) ||
        log.action.toLowerCase().includes(search.toLowerCase());
      const matchesUser = userFilter === 'all' || log.username === userFilter;
      const matchesAction = actionFilter === 'all' || log.action === actionFilter;
      const matchesDate = isWithinDateRange(log.timestamp, dateRange);
      return matchesSearch && matchesUser && matchesAction && matchesDate;
    });
  }, [search, userFilter, actionFilter, dateRange]);

  const handleExport = () => {
    toast.success('Activity log exported successfully!');
  };

  return (
    <motion.div
      className="space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* Page Header */}
      <motion.div variants={itemVariants} className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Activity Log</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Track all actions across the panel
          </p>
        </div>
        <Button
          onClick={handleExport}
          variant="outline"
          className="gap-2 border-white/10 text-sm text-muted-foreground hover:text-foreground hover:border-white/20"
        >
          <Download className="w-4 h-4" />
          Export
        </Button>
      </motion.div>

      {/* Filter Bar */}
      <motion.div variants={itemVariants} className="glass-card !p-0 overflow-hidden">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 p-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50" />
            <Input
              placeholder="Search logs..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="glass-input h-9 pl-9 text-sm bg-transparent"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground/50 hover:text-foreground transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Select value={userFilter} onValueChange={setUserFilter}>
              <SelectTrigger className="w-[130px] h-9 glass-input bg-transparent text-sm">
                <SelectValue placeholder="User" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Users</SelectItem>
                {uniqueUsers.map((u) => (
                  <SelectItem key={u} value={u}>
                    {u}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={actionFilter} onValueChange={setActionFilter}>
              <SelectTrigger className="w-[150px] h-9 glass-input bg-transparent text-sm">
                <Filter className="w-3.5 h-3.5 mr-1.5 text-muted-foreground/50" />
                <SelectValue placeholder="Action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Actions</SelectItem>
                {uniqueActions.map((a) => (
                  <SelectItem key={a} value={a}>
                    {actionLabels[a] || a}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-[110px] h-9 glass-input bg-transparent text-sm">
                <Clock className="w-3.5 h-3.5 mr-1.5 text-muted-foreground/50" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </motion.div>

      {/* Results Count */}
      <motion.div variants={itemVariants}>
        <p className="text-xs text-muted-foreground/60">
          Showing {filteredLogs.length} of {mockActivityLogs.length} entries
        </p>
      </motion.div>

      {/* Log Entries */}
      <motion.div variants={containerVariants} className="space-y-2">
        {filteredLogs.length === 0 ? (
          <motion.div variants={itemVariants} className="flex flex-col items-center justify-center py-20">
            <div className="w-16 h-16 rounded-2xl bg-white/[0.03] flex items-center justify-center mb-4">
              <Activity className="w-7 h-7 text-muted-foreground/30" />
            </div>
            <h3 className="text-base font-semibold text-foreground mb-1">No logs found</h3>
            <p className="text-sm text-muted-foreground text-center max-w-xs">
              No activity logs match your current filters.
            </p>
          </motion.div>
        ) : (
          filteredLogs.map((log, idx) => {
            const colors = actionColorMap[log.action] ?? actionColorMap['console.command'];
            return (
              <motion.div
                key={log.id}
                variants={itemVariants}
                className="glass-card !p-0 overflow-hidden"
              >
                <div className="flex items-center gap-4 px-5 py-3.5">
                  {/* Avatar */}
                  <Avatar className="h-8 w-8 flex-shrink-0">
                    <AvatarFallback
                      className={`text-xs font-bold ${getAvatarColor(log.username)}`}
                    >
                      {log.username.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground leading-snug">
                      <span className="font-medium text-foreground/90">{log.username}</span>{' '}
                      <span className={colors.text}>
                        {actionLabels[log.action] || log.action}
                      </span>{' '}
                      <span className="text-muted-foreground font-medium">{log.target}</span>
                    </p>
                    <div className="flex items-center gap-3 mt-1">
                      <div className="flex items-center gap-1 text-[11px] text-muted-foreground/50">
                        <Globe className="w-3 h-3" />
                        <span className="font-mono">{log.ip}</span>
                      </div>
                      <div className="flex items-center gap-1 text-[11px] text-muted-foreground/50">
                        <Clock className="w-3 h-3" />
                        <span>{getRelativeTime(log.timestamp)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Action Badge */}
                  <Badge
                    variant="outline"
                    className={`text-[10px] px-2 py-0 h-5 font-mono hidden sm:flex flex-shrink-0 ${colors.badgeClass}`}
                  >
                    {log.action}
                  </Badge>
                </div>
              </motion.div>
            );
          })
        )}
      </motion.div>
    </motion.div>
  );
}