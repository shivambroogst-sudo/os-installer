'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Cpu,
  Save,
  RotateCcw,
  ChevronDown,
  ChevronRight,
  FolderSearch,
  Lightbulb,
  MemoryStick,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { useNavStore } from '@/lib/store';
import { mockServers } from '@/lib/mock-data';
import { toast } from 'sonner';

// ============ Memory Recommendations ============

const memoryRecommendations: Record<string, { min: string; recommended: string; notes: string }> = {
  '8': { min: '512MB', recommended: '1-2 GB', notes: 'Legacy support. Limited G1GC options.' },
  '11': { min: '1 GB', recommended: '2-4 GB', notes: 'LTS release. Stable G1GC support.' },
  '16': { min: '1 GB', recommended: '2-6 GB', notes: 'Good for modern plugins with ZGC.' },
  '17': { min: '1 GB', recommended: '2-8 GB', notes: 'LTS release. Excellent G1GC and ZGC support.' },
  '21': { min: '2 GB', recommended: '4-12 GB', notes: 'LTS release. Best performance for modern servers.' },
  '24': { min: '2 GB', recommended: '4-16 GB', notes: 'Latest LTS. Virtual threads and improved GC.' },
  '25': { min: '2 GB', recommended: '4-16 GB', notes: 'Early access. Use for testing only.' },
};

// ============ Component ============

export default function ServerStartup() {
  const { selectedServerId } = useNavStore();
  const server = mockServers.find((s) => s.id === selectedServerId) ?? mockServers[0];

  // Startup config
  const [javaVersion, setJavaVersion] = useState('21');
  const [customJavaPath, setCustomJavaPath] = useState('');
  const [serverJar, setServerJar] = useState('server.jar');
  const [startupCommand, setStartupCommand] = useState(
    'java -Xms1024M -Xmx4096M -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5 -SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1 -Dusing.aikars.flags=https://mcflags.emc.gs -Daikars.new.flags=true -jar server.jar nogui'
  );
  const [autoDetectMemory, setAutoDetectMemory] = useState(true);
  const [jvmFlags, setJvmFlags] = useState('-XX:+UseG1GC\n-XX:+ParallelRefProcEnabled\n-XX:MaxGCPauseMillis=200');

  // Server properties
  const [propertiesExpanded, setPropertiesExpanded] = useState(false);
  const [serverName, setServerName] = useState(server.name);
  const [maxPlayers, setMaxPlayers] = useState(String(server.maxPlayers));
  const [viewDistance, setViewDistance] = useState('10');
  const [simulationDistance, setSimulationDistance] = useState('8');
  const [onlineMode, setOnlineMode] = useState(true);
  const [pvpEnabled, setPvpEnabled] = useState(true);
  const [whitelistEnabled, setWhitelistEnabled] = useState(false);
  const [motd, setMotd] = useState('§bOGUltra §7- §fSurvival SMP §7| §aJoin now!');
  const [difficulty, setDifficulty] = useState('normal');
  const [gameMode, setGameMode] = useState('survival');
  const [levelSeed, setLevelSeed] = useState('');
  const [levelName, setLevelName] = useState('world');

  // Dialog
  const [fileDialogOpen, setFileDialogOpen] = useState(false);

  const handleSave = () => {
    toast.success('Startup configuration saved', {
      description: `${server.name} startup settings have been updated.`,
    });
  };

  const handleReset = () => {
    toast.info('Configuration reset', {
      description: 'Startup settings have been reset to defaults.',
    });
  };

  const handleSelectJar = (fileName: string) => {
    setServerJar(fileName);
    setFileDialogOpen(false);
    toast.success('JAR file selected', { description: `Selected: ${fileName}` });
  };

  const recommendation = memoryRecommendations[javaVersion];

  return (
    <TooltipProvider>
      <motion.div
        className="space-y-6"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
      >
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white">Startup Configuration</h2>
            <p className="text-sm text-zinc-400 mt-1">Configure JVM options, server JAR, and startup behavior</p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white"
              onClick={handleReset}
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset
            </Button>
            <Button className="bg-brand-600 hover:bg-brand-500 text-white" onClick={handleSave}>
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </div>

        {/* Memory Recommendations */}
        {recommendation && (
          <motion.div
            className="glass-card p-5 gradient-brand-subtle"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
          >
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-brand-500/20 shrink-0">
                <Lightbulb className="w-5 h-5 text-brand-400" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  Memory Recommendations for Java {javaVersion}
                  <Badge variant="outline" className="border-brand-500/30 text-brand-400 text-xs">
                    {javaVersion === '17' || javaVersion === '21' || javaVersion === '24' ? 'LTS' : 'Non-LTS'}
                  </Badge>
                </h3>
                <p className="text-sm text-zinc-400 mt-1">{recommendation.notes}</p>
                <div className="flex flex-wrap gap-4 mt-3">
                  <div className="flex items-center gap-2">
                    <MemoryStick className="w-3.5 h-3.5 text-zinc-500" />
                    <span className="text-xs text-zinc-500">Min:</span>
                    <span className="text-sm font-mono text-white">{recommendation.min}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MemoryStick className="w-3.5 h-3.5 text-accent-400" />
                    <span className="text-xs text-zinc-500">Recommended:</span>
                    <span className="text-sm font-mono text-accent-400">{recommendation.recommended}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Cpu className="w-3.5 h-3.5 text-zinc-500" />
                    <span className="text-xs text-zinc-500">Server Limit:</span>
                    <span className="text-sm font-mono text-white">{(server.memoryLimit / 1024).toFixed(1)} GB</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column: Java & JAR Config */}
          <div className="space-y-6">
            {/* Java Configuration */}
            <motion.div
              className="glass-card p-5"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <div className="flex items-center gap-2 mb-5">
                <div className="p-1.5 rounded-md bg-brand-500/20">
                  <Cpu className="w-4 h-4 text-brand-400" />
                </div>
                <h3 className="text-sm font-semibold text-white">Java Configuration</h3>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-zinc-300 text-sm">Java Version</Label>
                  <Select value={javaVersion} onValueChange={setJavaVersion}>
                    <SelectTrigger className="bg-white/5 border-zinc-700 text-white">
                      <SelectValue placeholder="Select Java version" />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-900 border-zinc-800">
                      <SelectItem value="8">Java 8 (1.8.0)</SelectItem>
                      <SelectItem value="11">Java 11 (LTS)</SelectItem>
                      <SelectItem value="16">Java 16</SelectItem>
                      <SelectItem value="17">Java 17 (LTS)</SelectItem>
                      <SelectItem value="21">Java 21 (LTS)</SelectItem>
                      <SelectItem value="24">Java 24 (LTS)</SelectItem>
                      <SelectItem value="25">Java 25 (Early Access)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-zinc-300 text-sm">
                    Custom Java Path
                    <span className="text-zinc-600 ml-1">(optional)</span>
                  </Label>
                  <Input
                    value={customJavaPath}
                    onChange={(e) => setCustomJavaPath(e.target.value)}
                    placeholder="/usr/lib/jvm/java-21/bin/java"
                    className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-zinc-300 text-sm">Server JAR File</Label>
                  <div className="flex gap-2">
                    <Input
                      value={serverJar}
                      onChange={(e) => setServerJar(e.target.value)}
                      placeholder="server.jar"
                      className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600 flex-1"
                    />
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white shrink-0"
                          onClick={() => setFileDialogOpen(true)}
                        >
                          <FolderSearch className="w-4 h-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Browse Files</TooltipContent>
                    </Tooltip>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* JVM Flags */}
            <motion.div
              className="glass-card p-5"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-md bg-purple-500/20">
                    <Cpu className="w-4 h-4 text-purple-400" />
                  </div>
                  <h3 className="text-sm font-semibold text-white">JVM Flags</h3>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-zinc-300 text-sm">Auto-detect Memory Flags</Label>
                    <p className="text-xs text-zinc-500 mt-0.5">Automatically set -Xms and -Xmx based on allocation</p>
                  </div>
                  <Switch
                    checked={autoDetectMemory}
                    onCheckedChange={setAutoDetectMemory}
                    className="data-[state=checked]:bg-brand-600"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-zinc-300 text-sm">Additional JVM Flags</Label>
                  <Textarea
                    value={jvmFlags}
                    onChange={(e) => setJvmFlags(e.target.value)}
                    placeholder="One flag per line..."
                    rows={5}
                    className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600 font-mono text-sm resize-none"
                  />
                </div>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Startup Command */}
          <div className="space-y-6">
            <motion.div
              className="glass-card p-5"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.12 }}
            >
              <div className="flex items-center gap-2 mb-5">
                <div className="p-1.5 rounded-md bg-emerald-500/20">
                  <svg className="w-4 h-4 text-emerald-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="4 17 10 11 4 5" />
                    <line x1="12" x2="20" y1="19" y2="19" />
                  </svg>
                </div>
                <h3 className="text-sm font-semibold text-white">Startup Command</h3>
              </div>

              <div className="space-y-2">
                <Label className="text-zinc-300 text-sm">Full Command</Label>
                <Textarea
                  value={startupCommand}
                  onChange={(e) => setStartupCommand(e.target.value)}
                  rows={14}
                  className="bg-white/5 border-zinc-700 text-white font-mono text-xs leading-relaxed resize-none"
                />
                <p className="text-xs text-zinc-500">
                  The full command used to start your server. Memory flags are auto-prepended when auto-detect is enabled.
                </p>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Server Properties */}
        <motion.div
          className="glass-card overflow-hidden"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <button
            className="w-full flex items-center justify-between p-5 hover:bg-white/[0.02] transition-colors"
            onClick={() => setPropertiesExpanded(!propertiesExpanded)}
          >
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-md bg-orange-500/20">
                <svg className="w-4 h-4 text-orange-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                  <circle cx="12" cy="12" r="3" />
                </svg>
              </div>
              <h3 className="text-sm font-semibold text-white">Server Properties</h3>
              <Badge variant="outline" className="border-zinc-700 text-zinc-400 text-xs ml-2">server.properties</Badge>
            </div>
            {propertiesExpanded ? (
              <ChevronDown className="w-4 h-4 text-zinc-500" />
            ) : (
              <ChevronRight className="w-4 h-4 text-zinc-500" />
            )}
          </button>

          {propertiesExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <Separator className="bg-zinc-800" />
              <div className="p-5 space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-zinc-300 text-sm">Server Name</Label>
                    <Input
                      value={serverName}
                      onChange={(e) => setServerName(e.target.value)}
                      className="bg-white/5 border-zinc-700 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-zinc-300 text-sm">Max Players</Label>
                    <Input
                      type="number"
                      value={maxPlayers}
                      onChange={(e) => setMaxPlayers(e.target.value)}
                      className="bg-white/5 border-zinc-700 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-zinc-300 text-sm">View Distance</Label>
                    <Input
                      type="number"
                      value={viewDistance}
                      onChange={(e) => setViewDistance(e.target.value)}
                      className="bg-white/5 border-zinc-700 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-zinc-300 text-sm">Simulation Distance</Label>
                    <Input
                      type="number"
                      value={simulationDistance}
                      onChange={(e) => setSimulationDistance(e.target.value)}
                      className="bg-white/5 border-zinc-700 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-zinc-300 text-sm">Level Seed</Label>
                    <Input
                      value={levelSeed}
                      onChange={(e) => setLevelSeed(e.target.value)}
                      placeholder="Leave empty for random"
                      className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-zinc-300 text-sm">Level Name</Label>
                    <Input
                      value={levelName}
                      onChange={(e) => setLevelName(e.target.value)}
                      className="bg-white/5 border-zinc-700 text-white"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-zinc-300 text-sm">MOTD (Message of the Day)</Label>
                  <Input
                    value={motd}
                    onChange={(e) => setMotd(e.target.value)}
                    className="bg-white/5 border-zinc-700 text-white font-mono text-sm"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-zinc-300 text-sm">Difficulty</Label>
                    <Select value={difficulty} onValueChange={setDifficulty}>
                      <SelectTrigger className="bg-white/5 border-zinc-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-zinc-900 border-zinc-800">
                        <SelectItem value="peaceful">Peaceful</SelectItem>
                        <SelectItem value="easy">Easy</SelectItem>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="hard">Hard</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-zinc-300 text-sm">Game Mode</Label>
                    <Select value={gameMode} onValueChange={setGameMode}>
                      <SelectTrigger className="bg-white/5 border-zinc-700 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-zinc-900 border-zinc-800">
                        <SelectItem value="survival">Survival</SelectItem>
                        <SelectItem value="creative">Creative</SelectItem>
                        <SelectItem value="adventure">Adventure</SelectItem>
                        <SelectItem value="spectator">Spectator</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-5 pt-0">
                    <div className="space-y-3 pt-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-zinc-300 text-sm">Online Mode</Label>
                        <Switch
                          checked={onlineMode}
                          onCheckedChange={setOnlineMode}
                          className="data-[state=checked]:bg-brand-600"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-zinc-300 text-sm">PVP</Label>
                        <Switch
                          checked={pvpEnabled}
                          onCheckedChange={setPvpEnabled}
                          className="data-[state=checked]:bg-brand-600"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-zinc-300 text-sm">Whitelist</Label>
                        <Switch
                          checked={whitelistEnabled}
                          onCheckedChange={setWhitelistEnabled}
                          className="data-[state=checked]:bg-brand-600"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </motion.div>

        {/* File Browser Dialog */}
        <Dialog open={fileDialogOpen} onOpenChange={setFileDialogOpen}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-lg">
            <DialogHeader>
              <DialogTitle>Select Server JAR</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 py-4 max-h-64 overflow-y-auto">
              {['server.jar', 'paper-1.21.4.jar', 'purpur-1.21.4.jar', 'spigot-1.21.4.jar', 'forge-1.20.1-installer.jar'].map((jar) => (
                <button
                  key={jar}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg border border-zinc-800 hover:border-brand-500/50 hover:bg-white/[0.03] transition-all text-left group"
                  onClick={() => handleSelectJar(jar)}
                >
                  <div className="p-1.5 rounded bg-orange-500/20 group-hover:bg-orange-500/30 transition-colors">
                    <svg className="w-4 h-4 text-orange-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                      <polyline points="14 2 14 8 20 8" />
                    </svg>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{jar}</p>
                  </div>
                  {serverJar === jar && (
                    <Badge className="bg-brand-600 text-white text-xs">Selected</Badge>
                  )}
                </button>
              ))}
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white"
                onClick={() => setFileDialogOpen(false)}
              >
                Cancel
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>
    </TooltipProvider>
  );
}