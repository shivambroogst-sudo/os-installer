'use client';
import { useState, useEffect, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Server, HardDrive, Cpu, MemoryStick, ArrowUpRight, Activity, TrendingUp, Power, PowerOff, RotateCcw, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useNavStore } from '@/lib/store';
import { listServers, getNodeInfo, serverAction, type ServerStatus, type NodeInfo } from '@/lib/api';
import { getStatusDotClass, getStatusLabel, formatMemory, formatBytes, getResourceBarClass } from '@/lib/mock-data';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer } from 'recharts';

// ─── Animation Variants ───
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.06, delayChildren: 0.05 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.97 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { type: 'spring', stiffness: 260, damping: 24, mass: 0.8 },
  },
};

const cardHover = {
  rest: { y: 0, boxShadow: '0 0 0 0 rgba(92,124,250,0)' },
  hover: {
    y: -3,
    boxShadow: '0 8px 32px rgba(92,124,250,0.15), 0 0 0 1px rgba(92,124,250,0.2)',
    transition: { type: 'spring', stiffness: 400, damping: 25 },
  },
};

// ─── Custom Tooltip ───
function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number; dataKey: string }>; label?: string }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="glass-card !rounded-lg !px-3 !py-2 !border-glass-border">
      <p className="text-xs text-muted-foreground mb-1">{label}</p>
      {payload.map((entry) => (
        <div key={entry.dataKey} className="flex items-center gap-2 text-xs">
          <span
            className="w-2 h-2 rounded-full"
            style={{ background: entry.dataKey === 'cpu' ? '#5c7cfa' : '#34d399' }}
          />
          <span className="text-muted-foreground capitalize">{entry.dataKey}:</span>
          <span className="text-foreground font-medium">{entry.value}%</span>
        </div>
      ))}
    </div>
  );
}

// ─── Chart Card ───
function ResourceChart({ servers }: { servers: ServerStatus[] }) {
  const chartData = useMemo(() => {
    const data: Array<{ time: string; cpu: number; memory: number }> = [];
    const now = new Date();
    for (let i = 23; i >= 0; i--) {
      const hour = new Date(now.getTime() - i * 60 * 60 * 1000);
      const label = hour.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
      const runningServers = servers.filter(s => s.status === 'running');
      const totalCpu = runningServers.length > 0
        ? runningServers.reduce((sum, s) => sum + s.cpuUsage, 0) / runningServers.length
        : 0;
      const totalMem = runningServers.length > 0
        ? runningServers.reduce((sum, s) => sum + (s.memoryLimit > 0 ? (s.memoryUsage / s.memoryLimit) * 100 : 0), 0) / runningServers.length
        : 0;
      // Add slight variance for visual interest
      const cpu = Math.round(Math.max(0, Math.min(100, totalCpu + (Math.random() - 0.5) * 5)) * 10) / 10;
      const memory = Math.round(Math.max(0, Math.min(100, totalMem + (Math.random() - 0.5) * 3)) * 10) / 10;
      data.push({ time: label, cpu, memory });
    }
    return data;
  }, [servers]);

  return (
    <motion.div variants={itemVariants}>
      <Card className="glass-card !p-0 overflow-hidden">
        <CardHeader className="pb-2 px-6 pt-5">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base font-semibold text-foreground flex items-center gap-2">
                <Activity className="w-4 h-4 text-brand-400" />
                Resource Usage
              </CardTitle>
              <CardDescription className="text-xs mt-1">
                CPU and memory usage over the last 24 hours
              </CardDescription>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-brand-500" />
                <span className="text-muted-foreground">CPU</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-accent-400" />
                <span className="text-muted-foreground">Memory</span>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="cpuGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#5c7cfa" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#5c7cfa" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="memGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#34d399" stopOpacity={0.25} />
                    <stop offset="100%" stopColor="#34d399" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="rgba(255,255,255,0.05)"
                  vertical={false}
                />
                <XAxis
                  dataKey="time"
                  tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }}
                  axisLine={{ stroke: 'rgba(255,255,255,0.06)' }}
                  tickLine={false}
                  interval={3}
                />
                <YAxis
                  tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                  domain={[0, 100]}
                  tickFormatter={(v) => `${v}%`}
                />
                <RechartsTooltip
                  content={<CustomTooltip />}
                  cursor={{
                    stroke: 'rgba(92,124,250,0.2)',
                    strokeWidth: 1,
                    strokeDasharray: '4 4',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="cpu"
                  stroke="#5c7cfa"
                  strokeWidth={2}
                  fill="url(#cpuGradient)"
                  dot={false}
                  activeDot={{
                    r: 4,
                    fill: '#5c7cfa',
                    stroke: '#0a0a14',
                    strokeWidth: 2,
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="memory"
                  stroke="#34d399"
                  strokeWidth={2}
                  fill="url(#memGradient)"
                  dot={false}
                  activeDot={{
                    r: 4,
                    fill: '#34d399',
                    stroke: '#0a0a14',
                    strokeWidth: 2,
                  }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// ─── Server Card ───
function ServerCard({ server }: { server: ServerStatus }) {
  const selectServer = useNavStore((s) => s.selectServer);
  const cpuPercent = server.cpuLimit > 0 ? (server.cpuUsage / server.cpuLimit) * 100 : 0;
  const memPercent = server.memoryLimit > 0 ? (server.memoryUsage / server.memoryLimit) * 100 : 0;

  const isRunning = server.status === 'running';

  return (
    <motion.div
      variants={itemVariants}
      whileHover="hover"
      initial="rest"
      animate="rest"
    >
      <motion.div
        variants={cardHover}
        className="glass-card cursor-pointer h-full !p-0 overflow-hidden group"
        onClick={() => selectServer(server.id)}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') selectServer(server.id);
        }}
      >
        {/* Header */}
        <div className="px-5 pt-5 pb-3">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  isRunning
                    ? 'bg-brand-500/15'
                    : server.status === 'crashed'
                    ? 'bg-red-500/15'
                    : 'bg-white/5'
                }`}
              >
                <Server
                  className={`w-4 h-4 ${
                    isRunning ? 'text-brand-400' : server.status === 'crashed' ? 'text-red-400' : 'text-muted-foreground/50'
                  }`}
                />
              </div>
              <div className="min-w-0">
                <h3 className="text-sm font-semibold text-foreground truncate">{server.name}</h3>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className={`status-dot ${getStatusDotClass(server.status)}`} />
                  <span className="text-[11px] text-muted-foreground">{getStatusLabel(server.status)}</span>
                </div>
              </div>
            </div>
            <Badge
              variant="outline"
              className="text-[10px] px-2 py-0 h-5 border-white/10 text-muted-foreground bg-white/[0.03] flex-shrink-0"
            >
              :{server.port}
            </Badge>
          </div>
        </div>

        {/* Resource Bars */}
        <div className="px-5 space-y-3 pb-4">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <Cpu className="w-3 h-3 text-muted-foreground/50" />
                <span className="text-[11px] text-muted-foreground">CPU</span>
              </div>
              <span className="text-[11px] text-muted-foreground font-mono">
                {server.cpuUsage.toFixed(1)}% / {server.cpuLimit}%
              </span>
            </div>
            <div className="resource-bar">
              <div
                className={`resource-bar-fill ${getResourceBarClass(cpuPercent)}`}
                style={{ width: `${cpuPercent}%` }}
              />
            </div>
          </div>
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <MemoryStick className="w-3 h-3 text-muted-foreground/50" />
                <span className="text-[11px] text-muted-foreground">Memory</span>
              </div>
              <span className="text-[11px] text-muted-foreground font-mono">
                {formatMemory(server.memoryUsage)} / {formatMemory(server.memoryLimit)}
              </span>
            </div>
            <div className="resource-bar">
              <div
                className={`resource-bar-fill ${getResourceBarClass(memPercent)}`}
                style={{ width: `${memPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="px-5 pb-4 pt-1 border-t border-white/[0.04]">
          <div className="flex items-center gap-1.5">
            <Button
              variant="ghost"
              size="sm"
              className={`h-7 px-2 text-[11px] gap-1 ${
                isRunning
                  ? 'text-red-400/80 hover:text-red-300 hover:bg-red-500/10'
                  : 'text-emerald-400/80 hover:text-emerald-300 hover:bg-emerald-500/10'
              }`}
              onClick={async (e) => {
                e.stopPropagation();
                const action = isRunning ? 'stop' : 'start';
                const res = await serverAction(server.id, action);
                if (res.success) toast.success(`${action === 'stop' ? 'Stopping' : 'Starting'} ${server.name}...`);
                else toast.error(res.error || `Failed to ${action}`);
              }}
            >
              {isRunning ? <PowerOff className="w-3 h-3" /> : <Power className="w-3 h-3" />}
              {isRunning ? 'Stop' : 'Start'}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-[11px] gap-1 text-amber-400/80 hover:text-amber-300 hover:bg-amber-500/10"
              onClick={async (e) => {
                e.stopPropagation();
                const res = await serverAction(server.id, 'restart');
                if (res.success) toast.success(`Restarting ${server.name}...`);
                else toast.error(res.error || 'Failed to restart');
              }}
            >
              <RotateCcw className="w-3 h-3" />
              Restart
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-[11px] gap-1 text-muted-foreground/60 hover:text-foreground hover:bg-white/5 ml-auto"
              onClick={(e) => {
                e.stopPropagation();
                selectServer(server.id);
              }}
            >
              <ArrowUpRight className="w-3 h-3" />
              Details
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── Main Dashboard ───
export default function Dashboard() {
  const [servers, setServers] = useState<ServerStatus[]>([]);
  const [nodeInfo, setNodeInfo] = useState<NodeInfo | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    try {
      const [serverRes, nodeRes] = await Promise.all([
        listServers(),
        getNodeInfo(),
      ]);
      if (serverRes.success && serverRes.data) {
        setServers(serverRes.data);
      }
      if (nodeRes.success && nodeRes.data) {
        setNodeInfo(nodeRes.data);
      }
    } catch {
      // silently handle
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const runningServers = servers.filter((s) => s.status === 'running').length;
  const totalCpuUsage = nodeInfo ? ((nodeInfo.cpuCount * (100 - (nodeInfo.freeMemory / nodeInfo.totalMemory) * 100))).toFixed(1) : '—';
  const usedMemory = nodeInfo ? nodeInfo.totalMemory - nodeInfo.freeMemory : 0;

  const stats = [
    {
      label: 'Total Servers',
      value: servers.length,
      sub: `${runningServers} running`,
      icon: Server,
      iconBg: 'bg-brand-500/15',
      iconColor: 'text-brand-400',
      change: `${runningServers}/${servers.length}`,
      changePositive: runningServers > 0,
    },
    {
      label: 'Running Servers',
      value: runningServers,
      sub: 'Currently active',
      icon: Cpu,
      iconBg: 'bg-accent-500/15',
      iconColor: 'text-accent-400',
      change: runningServers > 0 ? 'Active' : 'None',
      changePositive: runningServers > 0,
    },
    {
      label: 'Node Memory',
      value: nodeInfo ? formatMemory(nodeInfo.totalMemory) : '—',
      sub: nodeInfo ? `${formatMemory(usedMemory)} used` : 'Loading...',
      icon: HardDrive,
      iconBg: 'bg-purple-500/15',
      iconColor: 'text-purple-400',
      change: nodeInfo ? `${Math.round((usedMemory / nodeInfo.totalMemory) * 100)}%` : '—',
      changePositive: true,
    },
    {
      label: 'CPU Cores',
      value: nodeInfo ? nodeInfo.cpuCount : '—',
      sub: nodeInfo ? nodeInfo.cpuModel : 'Loading...',
      icon: TrendingUp,
      iconBg: 'bg-emerald-500/15',
      iconColor: 'text-emerald-400',
      change: nodeInfo ? `${nodeInfo.totalDisk > 0 ? Math.round((nodeInfo.usedDisk / nodeInfo.totalDisk) * 100) : 0}% disk` : '—',
      changePositive: true,
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 text-brand-400 animate-spin" />
      </div>
    );
  }

  return (
    <motion.div
      className="space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* Page Header */}
      <motion.div variants={itemVariants} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Overview of your game hosting infrastructure
          </p>
        </div>
        <Badge
          variant="outline"
          className="border-accent-500/20 bg-accent-500/5 text-accent-400 text-xs gap-1.5 px-3 py-1"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-accent-400 animate-pulse" />
          {nodeInfo ? 'Daemon Connected' : 'Connecting...'}
        </Badge>
      </motion.div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <motion.div key={stat.label} variants={itemVariants}>
            <Card className="glass-card !p-0 group">
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center ${stat.iconBg}`}
                  >
                    <stat.icon className={`w-5 h-5 ${stat.iconColor}`} />
                  </div>
                  <div className="flex items-center gap-0.5 text-emerald-400 text-xs font-medium bg-emerald-500/10 px-2 py-0.5 rounded-full">
                    <TrendingUp className="w-3 h-3" />
                    {stat.change}
                  </div>
                </div>
                <div className="mt-4">
                  <p className="text-2xl font-bold text-foreground tracking-tight">{stat.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
                </div>
                <p className="text-[11px] text-muted-foreground/50 mt-2">{stat.sub}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Chart + Node Info */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <ResourceChart servers={servers} />
        </div>
        <div className="lg:col-span-1">
          <motion.div variants={itemVariants}>
            <Card className="glass-card !p-0 h-full">
              <CardHeader className="pb-3 px-6 pt-5">
                <CardTitle className="text-base font-semibold text-foreground flex items-center gap-2">
                  <HardDrive className="w-4 h-4 text-accent-400" />
                  Node Information
                </CardTitle>
                <CardDescription className="text-xs">System details from the daemon</CardDescription>
              </CardHeader>
              <CardContent className="px-6 pb-6">
                {nodeInfo ? (
                  <div className="space-y-3">
                    {[
                      { label: 'Hostname', value: nodeInfo.hostname },
                      { label: 'Platform', value: nodeInfo.platform },
                      { label: 'Architecture', value: nodeInfo.arch },
                      { label: 'CPU Model', value: nodeInfo.cpuModel },
                      { label: 'Daemon Version', value: nodeInfo.daemonVersion },
                    ].map((item) => (
                      <div key={item.label} className="flex items-center justify-between py-2 border-b border-white/[0.04]">
                        <span className="text-xs text-muted-foreground">{item.label}</span>
                        <span className="text-xs text-foreground font-medium font-mono truncate max-w-[200px] text-right" title={item.value}>
                          {item.value}
                        </span>
                      </div>
                    ))}
                    <div className="flex items-center justify-between py-2">
                      <span className="text-xs text-muted-foreground">Servers</span>
                      <span className="text-xs text-foreground font-medium">
                        {nodeInfo.runningServers} / {nodeInfo.serverCount} running
                      </span>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-white/[0.04]">
                      <span className="text-xs text-muted-foreground">Memory</span>
                      <span className="text-xs text-foreground font-mono">
                        {formatMemory(nodeInfo.totalMemory - nodeInfo.freeMemory)} / {formatMemory(nodeInfo.totalMemory)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between py-2">
                      <span className="text-xs text-muted-foreground">Disk</span>
                      <span className="text-xs text-foreground font-mono">
                        {formatBytes(nodeInfo.usedDisk)} / {formatBytes(nodeInfo.totalDisk)}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center py-8 text-muted-foreground text-sm">
                    No node information available
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      {/* Server List */}
      <motion.div variants={itemVariants}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-foreground">Servers</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {runningServers} of {servers.length} servers running
            </p>
          </div>
        </div>
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4"
          variants={containerVariants}
        >
          {servers.map((server) => (
            <ServerCard key={server.id} server={server} />
          ))}
        </motion.div>
      </motion.div>
    </motion.div>
  );
}