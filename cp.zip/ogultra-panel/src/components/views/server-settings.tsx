'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Save,
  AlertTriangle,
  Trash2,
  UserPlus,
  UserMinus,
  Shield,
  Edit3,
  Copy,
  Ban,
  CheckCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { mockServers, mockUser } from '@/lib/mock-data';
import { useNavStore } from '@/lib/store';
import { toast } from 'sonner';

// ============ Types ============

interface SubUser {
  id: string;
  email: string;
  username: string;
  permissions: string[];
}

// ============ Component ============

export default function ServerSettings() {
  const { selectedServerId } = useNavStore();
  const server = mockServers.find((s) => s.id === selectedServerId) ?? mockServers[0];

  // General settings
  const [serverName, setServerName] = useState(server.name);
  const [description, setDescription] = useState(server.description);
  const [isSuspended, setIsSuspended] = useState(server.isSuspended);

  // Sub-users
  const [subUsers, setSubUsers] = useState<SubUser[]>([
    { id: 'su_01', email: 'john@example.com', username: 'john', permissions: ['console', 'files', 'backups'] },
    { id: 'su_02', email: 'sarah@example.com', username: 'sarah', permissions: ['console', 'plugins'] },
  ]);

  // Dialogs
  const [renameDialogOpen, setRenameDialogOpen] = useState(false);
  const [renameValue, setRenameValue] = useState(server.name);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [addUserDialogOpen, setAddUserDialogOpen] = useState(false);
  const [addUserEmail, setAddUserEmail] = useState('');
  const [addUserPermissions, setAddUserPermissions] = useState<string[]>([]);

  const allPermissions = [
    { key: 'console', label: 'Console' },
    { key: 'files', label: 'Files' },
    { key: 'backups', label: 'Backups' },
    { key: 'schedules', label: 'Schedules' },
    { key: 'startup', label: 'Startup' },
    { key: 'plugins', label: 'Plugins' },
    { key: 'databases', label: 'Databases' },
    { key: 'network', label: 'Network' },
    { key: 'settings', label: 'Settings' },
  ];

  const handleSaveGeneral = () => {
    toast.success('Settings saved', {
      description: 'Server settings have been updated.',
    });
  };

  const handleRename = () => {
    if (!renameValue.trim()) {
      toast.error('Server name is required');
      return;
    }
    setServerName(renameValue);
    setRenameDialogOpen(false);
    toast.success('Server renamed', {
      description: `Server is now called "${renameValue}".`,
    });
  };

  const handleToggleSuspend = () => {
    setIsSuspended(!isSuspended);
    toast.success(isSuspended ? 'Server unsuspended' : 'Server suspended', {
      description: isSuspended
        ? 'The server is now accessible again.'
        : 'The server has been suspended and will stop.',
    });
  };

  const handleDeleteServer = () => {
    if (deleteConfirmText !== server.name) {
      toast.error('Confirmation text does not match');
      return;
    }
    setDeleteDialogOpen(false);
    setDeleteConfirmText('');
    toast.success('Server deleted', {
      description: 'All server data has been permanently removed.',
    });
  };

  const handleCopyUuid = () => {
    navigator.clipboard?.writeText(server.uuid);
    toast.success('UUID copied to clipboard');
  };

  const handleAddUser = () => {
    if (!addUserEmail.trim()) {
      toast.error('Email is required');
      return;
    }
    const newUser: SubUser = {
      id: `su_${Date.now()}`,
      email: addUserEmail,
      username: addUserEmail.split('@')[0],
      permissions: addUserPermissions,
    };
    setSubUsers((prev) => [...prev, newUser]);
    setAddUserEmail('');
    setAddUserPermissions([]);
    setAddUserDialogOpen(false);
    toast.success('Sub-user added', {
      description: `${newUser.username} has been granted access.`,
    });
  };

  const handleRemoveUser = (id: string) => {
    const user = subUsers.find((u) => u.id === id);
    setSubUsers((prev) => prev.filter((u) => u.id !== id));
    toast.success('Sub-user removed', {
      description: `${user?.username} no longer has access.`,
    });
  };

  const togglePermission = (permKey: string) => {
    setAddUserPermissions((prev) =>
      prev.includes(permKey) ? prev.filter((p) => p !== permKey) : [...prev, permKey]
    );
  };

  return (
    <TooltipProvider>
      <motion.div
        className="space-y-6"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
      >
        {/* Header */}
        <div>
          <h2 className="text-xl font-bold text-white">Server Settings</h2>
          <p className="text-sm text-zinc-400 mt-1">
            Manage {server.name} configuration and access control
          </p>
        </div>

        {/* General Settings */}
        <motion.div
          className="glass-card p-5"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
        >
          <div className="flex items-center gap-2 mb-5">
            <div className="p-1.5 rounded-md bg-brand-500/20">
              <svg className="w-4 h-4 text-brand-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                <circle cx="12" cy="12" r="3" />
              </svg>
            </div>
            <h3 className="text-sm font-semibold text-white">General</h3>
          </div>

          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-end gap-3">
              <div className="flex-1 space-y-2">
                <Label className="text-zinc-300 text-sm">Server Name</Label>
                <div className="flex gap-2">
                  <Input
                    value={serverName}
                    onChange={(e) => setServerName(e.target.value)}
                    className="bg-white/5 border-zinc-700 text-white flex-1"
                  />
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="outline"
                        size="icon"
                        className="border-zinc-700 text-zinc-400 hover:bg-white/5 hover:text-white shrink-0"
                        onClick={() => {
                          setRenameValue(serverName);
                          setRenameDialogOpen(true);
                        }}
                      >
                        <Edit3 className="w-4 h-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Rename Server</TooltipContent>
                  </Tooltip>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-zinc-300 text-sm">Description</Label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600 resize-none"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-zinc-300 text-sm">Server UUID</Label>
              <div className="flex items-center gap-2">
                <Input
                  value={server.uuid}
                  readOnly
                  className="bg-white/[0.03] border-zinc-700 text-zinc-500 font-mono text-sm flex-1 cursor-not-allowed"
                />
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="outline"
                      size="icon"
                      className="border-zinc-700 text-zinc-400 hover:bg-white/5 hover:text-white shrink-0"
                      onClick={handleCopyUuid}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Copy UUID</TooltipContent>
                </Tooltip>
              </div>
            </div>

            <div className="pt-2">
              <Button className="bg-brand-600 hover:bg-brand-500 text-white" onClick={handleSaveGeneral}>
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Server Owner */}
        <motion.div
          className="glass-card p-5"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="flex items-center gap-2 mb-4">
            <div className="p-1.5 rounded-md bg-purple-500/20">
              <Shield className="w-4 h-4 text-purple-400" />
            </div>
            <h3 className="text-sm font-semibold text-white">Server Owner</h3>
          </div>

          <div className="flex items-center gap-4 p-4 rounded-lg bg-white/[0.03] border border-zinc-800">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">
              {mockUser.username.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <p className="text-sm font-medium text-white">{mockUser.firstName} {mockUser.lastName}</p>
              <p className="text-xs text-zinc-400">{mockUser.email}</p>
            </div>
            <Badge className="ml-auto bg-purple-500/20 text-purple-400 border-purple-500/30 text-xs">
              Owner
            </Badge>
          </div>
        </motion.div>

        {/* Sub-Users */}
        <motion.div
          className="glass-card overflow-hidden"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <div className="px-5 py-4 border-b border-zinc-800/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-md bg-cyan-500/20">
                  <Shield className="w-4 h-4 text-cyan-400" />
                </div>
                <h3 className="text-sm font-semibold text-white">Sub-Users</h3>
                <Badge variant="outline" className="border-zinc-700 text-zinc-400 text-xs">
                  {subUsers.length}
                </Badge>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white"
                onClick={() => {
                  setAddUserEmail('');
                  setAddUserPermissions([]);
                  setAddUserDialogOpen(true);
                }}
              >
                <UserPlus className="w-3.5 h-3.5 mr-1.5" />
                Add User
              </Button>
            </div>
          </div>

          {subUsers.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-zinc-800 hover:bg-transparent">
                    <TableHead className="text-zinc-400 font-medium">User</TableHead>
                    <TableHead className="text-zinc-400 font-medium hidden sm:table-cell">Email</TableHead>
                    <TableHead className="text-zinc-400 font-medium">Permissions</TableHead>
                    <TableHead className="text-zinc-400 font-medium text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {subUsers.map((user) => (
                    <TableRow key={user.id} className="border-zinc-800 hover:bg-white/[0.02]">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-xs font-bold text-white">
                            {user.username.slice(0, 2).toUpperCase()}
                          </div>
                          <span className="text-sm font-medium text-white">{user.username}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-zinc-400 text-sm hidden sm:table-cell">{user.email}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {user.permissions.map((perm) => (
                            <Badge
                              key={perm}
                              variant="outline"
                              className="border-zinc-700 text-zinc-400 text-xs"
                            >
                              {perm}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex justify-end">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-red-400/70 hover:text-red-400 hover:bg-red-500/10"
                                onClick={() => handleRemoveUser(user.id)}
                              >
                                <UserMinus className="w-3.5 h-3.5" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Remove User</TooltipContent>
                          </Tooltip>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="py-8 text-center">
              <Shield className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
              <p className="text-sm text-zinc-400">No sub-users assigned</p>
              <p className="text-xs text-zinc-500 mt-1">Add a sub-user to grant access to this server.</p>
            </div>
          )}
        </motion.div>

        {/* Suspend Section */}
        <motion.div
          className="glass-card p-5"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center gap-2 mb-4">
            <div className="p-1.5 rounded-md bg-yellow-500/20">
              <Ban className="w-4 h-4 text-yellow-400" />
            </div>
            <h3 className="text-sm font-semibold text-white">Suspend Server</h3>
          </div>

          <p className="text-sm text-zinc-400 mb-4">
            Suspending a server will immediately stop it and prevent it from being started.
            All data is preserved. Users will lose access to the server.
          </p>

          <div className="flex items-center justify-between p-4 rounded-lg bg-yellow-500/5 border border-yellow-500/20">
            <div>
              <p className="text-sm font-medium text-white">
                Server Status: <span className={isSuspended ? 'text-yellow-400' : 'text-accent-400'}>
                  {isSuspended ? 'Suspended' : 'Active'}
                </span>
              </p>
              <p className="text-xs text-zinc-500 mt-0.5">
                {isSuspended ? 'Unsuspend to allow access' : 'Suspend to restrict access'}
              </p>
            </div>
            <Switch
              checked={!isSuspended}
              onCheckedChange={handleToggleSuspend}
              className="data-[state=checked]:bg-accent-500"
            />
          </div>
        </motion.div>

        {/* Delete Section (Danger Zone) */}
        <motion.div
          className="glass-card p-5 border-red-500/20"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <div className="flex items-center gap-2 mb-4">
            <div className="p-1.5 rounded-md bg-red-500/20">
              <AlertTriangle className="w-4 h-4 text-red-400" />
            </div>
            <h3 className="text-sm font-semibold text-red-400">Danger Zone</h3>
          </div>

          <p className="text-sm text-zinc-400 mb-4">
            Once you delete a server, there is no going back. This will permanently remove all
            server files, databases, backups, and allocations associated with this server.
          </p>

          <Button
            variant="outline"
            className="border-red-500/50 text-red-400 hover:bg-red-500/10 hover:text-red-300 hover:border-red-500"
            onClick={() => {
              setDeleteConfirmText('');
              setDeleteDialogOpen(true);
            }}
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Delete Server
          </Button>
        </motion.div>

        {/* Rename Dialog */}
        <Dialog open={renameDialogOpen} onOpenChange={setRenameDialogOpen}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-md">
            <DialogHeader>
              <DialogTitle>Rename Server</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label className="text-zinc-300 text-sm">New Name</Label>
                <Input
                  value={renameValue}
                  onChange={(e) => setRenameValue(e.target.value)}
                  className="bg-white/5 border-zinc-700 text-white"
                  onKeyDown={(e) => e.key === 'Enter' && handleRename()}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white"
                onClick={() => setRenameDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button className="bg-brand-600 hover:bg-brand-500 text-white" onClick={handleRename}>
                Rename
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-md">
            <DialogHeader>
              <DialogTitle className="text-red-400">Delete Server</DialogTitle>
              <DialogDescription className="text-zinc-400">
                This action cannot be undone. All data will be permanently deleted.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 mb-4">
                <p className="text-sm text-red-400">
                  ⚠️ Type <code className="font-mono font-bold">{server.name}</code> to confirm deletion.
                </p>
              </div>
              <div className="space-y-2">
                <Label className="text-zinc-300 text-sm">Confirm Server Name</Label>
                <Input
                  value={deleteConfirmText}
                  onChange={(e) => setDeleteConfirmText(e.target.value)}
                  placeholder={server.name}
                  className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white"
                onClick={() => setDeleteDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                className="bg-red-600 hover:bg-red-500 text-white"
                onClick={handleDeleteServer}
                disabled={deleteConfirmText !== server.name}
              >
                Delete Permanently
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Add Sub-User Dialog */}
        <Dialog open={addUserDialogOpen} onOpenChange={setAddUserDialogOpen}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-lg">
            <DialogHeader>
              <DialogTitle>Add Sub-User</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label className="text-zinc-300 text-sm">Email Address</Label>
                <Input
                  value={addUserEmail}
                  onChange={(e) => setAddUserEmail(e.target.value)}
                  placeholder="user@example.com"
                  className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600"
                />
              </div>

              <Separator className="bg-zinc-800" />

              <div className="space-y-2">
                <Label className="text-zinc-300 text-sm">Permissions</Label>
                <div className="grid grid-cols-3 gap-2">
                  {allPermissions.map((perm) => (
                    <button
                      key={perm.key}
                      onClick={() => togglePermission(perm.key)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-sm transition-all ${
                        addUserPermissions.includes(perm.key)
                          ? 'border-brand-500/50 bg-brand-500/10 text-brand-400'
                          : 'border-zinc-800 bg-white/[0.02] text-zinc-400 hover:bg-white/[0.04]'
                      }`}
                    >
                      <CheckCircle className={`w-3.5 h-3.5 ${addUserPermissions.includes(perm.key) ? 'opacity-100' : 'opacity-0'}`} />
                      {perm.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white"
                onClick={() => setAddUserDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                className="bg-brand-600 hover:bg-brand-500 text-white"
                onClick={handleAddUser}
              >
                Add User
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>
    </TooltipProvider>
  );
}