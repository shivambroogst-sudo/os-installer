'use client';
import { useState, useRef, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Send, Maximize2, Minimize2, Download, Trash2, Pause, Play, Wifi, WifiOff, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { getStatusDotClass, getStatusLabel } from '@/lib/mock-data';
import { useNavStore } from '@/lib/store';
import { getServer, createConsoleWebSocket, sendServerCommand, serverAction, type ServerStatus } from '@/lib/api';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Power,
  RotateCcw,
  Skull,
  ArrowDown,
  Terminal as TerminalIcon,
  Cpu,
  HardDrive,
  Zap,
} from 'lucide-react';

// ============ Types ============

interface ConsoleLine {
  id: number;
  level: 'info' | 'warn' | 'error' | 'success' | 'command';
  text: string;
  time: string;
}

type WsConnectionState = 'connecting' | 'connected' | 'disconnected';

// ============ Helpers ============

function getTimestamp(): string {
  const now = new Date();
  return now.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

// ============ Component ============

export default function ServerConsole() {
  const { selectedServerId } = useNavStore();

  // Server state
  const [server, setServer] = useState<ServerStatus | null>(null);
  const [loading, setLoading] = useState(true);

  // Console state
  const [lines, setLines] = useState<ConsoleLine[]>([]);
  const [commandInput, setCommandInput] = useState('');
  const [autoScroll, setAutoScroll] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [wsState, setWsState] = useState<WsConnectionState>('disconnected');

  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const lineIdCounter = useRef(1);
  const isAtBottom = useRef(true);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ============ Fetch server info ============

  const fetchServer = useCallback(async () => {
    if (!selectedServerId) return;
    try {
      const res = await getServer(selectedServerId);
      if (res.success && res.data) {
        setServer(res.data);
        // Pre-populate console lines from server data
        if (res.data.consoleLines && res.data.consoleLines.length > 0 && lines.length === 0) {
          const initialLines: ConsoleLine[] = res.data.consoleLines.map((cl) => ({
            id: lineIdCounter.current++,
            level: cl.level as ConsoleLine['level'],
            text: cl.text,
            time: new Date(cl.timestamp).toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          }));
          setLines(initialLines);
        }
      }
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  }, [selectedServerId, lines.length]);

  useEffect(() => {
    fetchServer();
  }, [fetchServer]);

  // ============ WebSocket connection ============

  const connectWs = useCallback(() => {
    if (!selectedServerId || wsRef.current?.readyState === WebSocket.OPEN) return;

    // Clean up existing connection
    if (wsRef.current) {
      wsRef.current.onopen = null;
      wsRef.current.onmessage = null;
      wsRef.current.onclose = null;
      wsRef.current.onerror = null;
      if (wsRef.current.readyState === WebSocket.OPEN || wsRef.current.readyState === WebSocket.CONNECTING) {
        wsRef.current.close();
      }
      wsRef.current = null;
    }

    setWsState('connecting');

    const ws = createConsoleWebSocket(
      selectedServerId,
      // onMessage
      (data: any) => {
        if (isPaused) return;

        if (data.event === 'console_output') {
          const d = data.data;
          const line: ConsoleLine = {
            id: lineIdCounter.current++,
            level: (d.level || 'info') as ConsoleLine['level'],
            text: d.text || '',
            time: d.timestamp
              ? new Date(d.timestamp).toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })
              : getTimestamp(),
          };
          setLines((prev) => [...prev, line]);
        } else if (data.event === 'server_status') {
          const d = data.data;
          setServer((prev) => prev ? {
            ...prev,
            status: d.status || prev.status,
            pid: d.pid ?? prev.pid,
            cpuUsage: d.cpuUsage ?? prev.cpuUsage,
            memoryUsage: d.memoryUsage ?? prev.memoryUsage,
          } : prev);
        }
      },
      // onOpen
      () => {
        setWsState('connected');
        console.log(`[Console] Connected to server ${selectedServerId}`);
      },
      // onClose
      () => {
        setWsState('disconnected');
        wsRef.current = null;
        console.log(`[Console] Disconnected from server ${selectedServerId}`);
        // Auto-reconnect after 3 seconds
        if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = setTimeout(() => {
          if (selectedServerId) {
            connectWs();
          }
        }, 3000);
      },
    );

    wsRef.current = ws;
  }, [selectedServerId, isPaused]);

  useEffect(() => {
    if (selectedServerId) {
      connectWs();
    }
    return () => {
      if (wsRef.current) {
        wsRef.current.onopen = null;
        wsRef.current.onmessage = null;
        wsRef.current.onclose = null;
        wsRef.current.onerror = null;
        if (wsRef.current.readyState === WebSocket.OPEN || wsRef.current.readyState === WebSocket.CONNECTING) {
          wsRef.current.close();
        }
        wsRef.current = null;
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      setWsState('disconnected');
    };
  }, [selectedServerId, connectWs]);

  // ============ Auto-scroll logic ============

  const scrollToBottom = useCallback(() => {
    if (scrollRef.current) {
      const viewport = scrollRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight;
      }
    }
  }, []);

  useEffect(() => {
    if (autoScroll && isAtBottom.current) {
      scrollToBottom();
    }
  }, [lines, autoScroll, scrollToBottom]);

  // ============ Command handling ============

  const handleSendCommand = useCallback(async () => {
    const cmd = commandInput.trim();
    if (!cmd || !selectedServerId) return;

    // Add command line to console locally
    const cmdLine: ConsoleLine = {
      id: lineIdCounter.current++,
      level: 'command',
      text: `> ${cmd}`,
      time: getTimestamp(),
    };

    setLines((prev) => [...prev, cmdLine]);
    setCommandInput('');

    // Send via API
    try {
      const res = await sendServerCommand(selectedServerId, cmd);
      if (!res.success) {
        toast.error(res.error || 'Failed to send command');
      }
    } catch {
      toast.error('Failed to send command');
    }

    // Re-focus input
    inputRef.current?.focus();
  }, [commandInput, selectedServerId]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSendCommand();
    }
  };

  // ============ Action handlers ============

  const handlePowerAction = async (action: string) => {
    if (!selectedServerId || !server) return;

    try {
      const res = await serverAction(selectedServerId, action as 'start' | 'stop' | 'restart' | 'kill');
      if (res.success) {
        toast.success(`Server ${action} triggered`, {
          description: `${server.name} is now ${action === 'start' ? 'starting' : action === 'kill' ? 'being killed' : action + 'ing'}...`,
        });
        const actionLine: ConsoleLine = {
          id: lineIdCounter.current++,
          level: 'warn',
          text: `[${getTimestamp()} WARN]: Server ${action} signal sent.`,
          time: getTimestamp(),
        };
        setLines((prev) => [...prev, actionLine]);
        // Refresh server status
        fetchServer();
      } else {
        toast.error(res.error || `Failed to ${action} server`);
      }
    } catch {
      toast.error(`Failed to ${action} server`);
    }
  };

  const handleClearConsole = () => {
    setLines([]);
    toast.success('Console cleared');
  };

  const handleDownloadLogs = () => {
    if (lines.length === 0) {
      toast.info('No logs to download');
      return;
    }
    const logText = lines.map((l) => l.text).join('\n');
    const blob = new Blob([logText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${server?.name || 'server'}-logs.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Logs downloaded');
  };

  const handleToggleFullscreen = () => {
    setIsFullscreen((prev) => !prev);
  };

  // ============ Scroll position tracking ============

  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    const threshold = 60;
    isAtBottom.current = target.scrollHeight - target.scrollTop - target.clientHeight < threshold;
  }, []);

  // ============ Stats computation ============

  const cpuPercent = server ? server.cpuUsage.toFixed(1) : '0.0';
  const memPercent = server && server.memoryLimit > 0 ? ((server.memoryUsage / server.memoryLimit) * 100).toFixed(1) : '0.0';

  // ============ Connection status indicator ============

  const wsIndicatorClass = wsState === 'connected'
    ? 'bg-accent-400'
    : wsState === 'connecting'
    ? 'bg-yellow-400 animate-pulse'
    : 'bg-red-400';

  const wsLabel = wsState === 'connected'
    ? 'Connected'
    : wsState === 'connecting'
    ? 'Connecting...'
    : 'Disconnected';

  // ============ Render helpers ============

  const getLineClass = (level: ConsoleLine['level']): string => {
    if (level === 'command') return 'terminal-line text-brand-400 font-semibold';
    return `terminal-line terminal-line-${level}`;
  };

  // ============ Loading state ============

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 text-brand-400 animate-spin" />
      </div>
    );
  }

  if (!server) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <TerminalIcon className="w-10 h-10 text-muted-foreground/30 mb-3" />
        <h3 className="text-base font-semibold text-foreground mb-1">No server selected</h3>
        <p className="text-sm text-muted-foreground">Select a server to view its console.</p>
      </div>
    );
  }

  return (
    <motion.div
      className={`flex flex-col rounded-xl overflow-hidden border border-glass-border ${isFullscreen ? 'fixed inset-0 z-50 rounded-none' : 'h-[calc(100vh-220px)] min-h-[400px]'}`}
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
    >
      {/* ============ Top Bar ============ */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-glass-border bg-glass-strong">
        {/* Left: Server info + stats */}
        <div className="flex items-center gap-3 flex-wrap min-w-0">
          <div className="flex items-center gap-2 min-w-0">
            <TerminalIcon className="w-4 h-4 text-brand-400 shrink-0" />
            <span className="font-semibold text-sm text-white truncate">{server.name}</span>
            <span className={`status-dot ${getStatusDotClass(server.status)} shrink-0`} />
            <span className="text-xs text-muted-foreground capitalize">{server.status}</span>
          </div>

          {/* Connection Status */}
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-white/5 border border-white/[0.06]">
            {wsState === 'connected' ? (
              <Wifi className="w-3 h-3 text-accent-400" />
            ) : wsState === 'connecting' ? (
              <Loader2 className="w-3 h-3 text-yellow-400 animate-spin" />
            ) : (
              <WifiOff className="w-3 h-3 text-red-400" />
            )}
            <span className={`text-[10px] font-medium ${
              wsState === 'connected' ? 'text-accent-400' : wsState === 'connecting' ? 'text-yellow-400' : 'text-red-400'
            }`}>
              {wsLabel}
            </span>
          </div>

          <div className="hidden sm:flex items-center gap-2">
            {/* CPU */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/5 border border-white/[0.06]">
              <Cpu className="w-3 h-3 text-brand-400" />
              <span className="text-xs font-medium text-zinc-300">CPU</span>
              <span className="text-xs font-mono text-white">{cpuPercent}%</span>
            </div>

            {/* Memory */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/5 border border-white/[0.06]">
              <HardDrive className="w-3 h-3 text-brand-400" />
              <span className="text-xs font-medium text-zinc-300">MEM</span>
              <span className="text-xs font-mono text-white">{server.memoryUsage} / {server.memoryLimit} MB</span>
            </div>

            {/* PID */}
            {server.pid && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/5 border border-white/[0.06]">
                <span className="text-xs font-medium text-zinc-300">PID</span>
                <span className="text-xs font-mono text-white">{server.pid}</span>
              </div>
            )}
          </div>
        </div>

        {/* Right: Action buttons */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Power dropdown */}
          <DropdownMenu>
            <Tooltip>
              <TooltipTrigger asChild>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-zinc-400 hover:text-white hover:bg-white/10"
                  >
                    <Power className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
              </TooltipTrigger>
              <TooltipContent side="bottom">Power Control</TooltipContent>
            </Tooltip>
            <DropdownMenuContent
              align="end"
              className="w-44 bg-zinc-900/95 border-zinc-800 backdrop-blur-xl"
            >
              <DropdownMenuItem
                onClick={() => handlePowerAction('start')}
                className="text-accent-400 focus:bg-accent-500/10 focus:text-accent-300 cursor-pointer"
              >
                <Play className="w-4 h-4 mr-2" />
                Start
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => handlePowerAction('stop')}
                className="text-yellow-400 focus:bg-yellow-500/10 focus:text-yellow-300 cursor-pointer"
              >
                <Pause className="w-4 h-4 mr-2" />
                Stop
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-zinc-800" />
              <DropdownMenuItem
                onClick={() => handlePowerAction('restart')}
                className="text-brand-400 focus:bg-brand-500/10 focus:text-brand-300 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Restart
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => handlePowerAction('kill')}
                className="text-red-400 focus:bg-red-500/10 focus:text-red-300 cursor-pointer"
              >
                <Skull className="w-4 h-4 mr-2" />
                Kill
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Auto-scroll toggle */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${autoScroll ? 'text-brand-400' : 'text-zinc-500'} hover:text-white hover:bg-white/10`}
                onClick={() => setAutoScroll((prev) => !prev)}
              >
                <ArrowDown className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">
              {autoScroll ? 'Auto-scroll: ON' : 'Auto-scroll: OFF'}
            </TooltipContent>
          </Tooltip>

          {/* Pause/Resume toggle */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${isPaused ? 'text-yellow-400' : 'text-zinc-400'} hover:text-white hover:bg-white/10`}
                onClick={() => setIsPaused((prev) => !prev)}
              >
                {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">
              {isPaused ? 'Resume output' : 'Pause output'}
            </TooltipContent>
          </Tooltip>

          {/* Clear console */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-zinc-400 hover:text-white hover:bg-white/10"
                onClick={handleClearConsole}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">Clear Console</TooltipContent>
          </Tooltip>

          {/* Download logs */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-zinc-400 hover:text-white hover:bg-white/10"
                onClick={handleDownloadLogs}
              >
                <Download className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">Download Logs</TooltipContent>
          </Tooltip>

          {/* Fullscreen toggle */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-zinc-400 hover:text-white hover:bg-white/10"
                onClick={handleToggleFullscreen}
              >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">
              {isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            </TooltipContent>
          </Tooltip>
        </div>
      </div>

      {/* ============ Mobile Stats Bar ============ */}
      <div className="sm:hidden flex items-center gap-1.5 px-3 py-1.5 border-b border-glass-border bg-white/[0.02] overflow-x-auto">
        <span className="text-xs font-medium text-zinc-400">CPU:</span>
        <span className="text-xs font-mono text-white">{cpuPercent}%</span>
        <span className="text-zinc-700 mx-1">|</span>
        <span className="text-xs font-medium text-zinc-400">MEM:</span>
        <span className="text-xs font-mono text-white">{server.memoryUsage}/{server.memoryLimit}MB</span>
        <span className="text-zinc-700 mx-1">|</span>
        <span className="text-xs font-medium text-zinc-400">PID:</span>
        <span className="text-xs font-mono text-white">{server.pid || '—'}</span>
        <span className="text-zinc-700 mx-1">|</span>
        <span className={`w-2 h-2 rounded-full ${wsIndicatorClass}`} />
        <span className={`text-xs font-medium ${wsState === 'connected' ? 'text-accent-400' : wsState === 'connecting' ? 'text-yellow-400' : 'text-red-400'}`}>
          {wsLabel}
        </span>
      </div>

      {/* ============ Console Output ============ */}
      <div className="flex-1 terminal-container min-h-0">
        <ScrollArea className="h-full" ref={scrollRef} onScrollCapture={handleScroll}>
          <div className="px-4 py-3 min-h-full">
            {lines.length === 0 && (
              <div className="flex items-center justify-center h-32 text-zinc-600 text-sm">
                {wsState === 'connected'
                  ? 'Console output will appear here...'
                  : wsState === 'connecting'
                  ? 'Connecting to server...'
                  : 'Disconnected from server. Reconnecting...'}
              </div>
            )}
            {lines.map((line) => (
              <div key={line.id} className={getLineClass(line.level)}>
                <span className="text-zinc-600 mr-2 select-none">{line.time}</span>
                {line.level === 'command' ? (
                  <span className="text-brand-400">{line.text}</span>
                ) : (
                  line.text
                )}
              </div>
            ))}
            {/* Blinking cursor at bottom */}
            <div className="terminal-line flex items-center">
              <span className="text-zinc-600 mr-2 select-none">{getTimestamp()}</span>
              <span className="text-brand-400 font-semibold">&gt;</span>
              <span className="inline-block w-2 h-4 ml-1 bg-brand-400/80 animate-pulse" />
            </div>
          </div>
        </ScrollArea>
      </div>

      {/* ============ Command Input ============ */}
      <div className="border-t border-glass-border bg-zinc-950/80">
        <div className="flex items-center gap-2 px-4 py-2.5">
          <span className="text-brand-400 font-mono text-sm font-bold shrink-0 select-none">&gt;</span>
          <input
            ref={inputRef}
            type="text"
            value={commandInput}
            onChange={(e) => setCommandInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type a command..."
            className="terminal-input flex-1 text-sm px-1 py-0.5 placeholder:text-zinc-600"
            spellCheck={false}
            autoComplete="off"
            disabled={server.status === 'stopped' || server.status === 'crashed'}
          />
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                size="icon"
                className="h-8 w-8 shrink-0 bg-brand-600 hover:bg-brand-500 text-white"
                onClick={handleSendCommand}
                disabled={!commandInput.trim() || server.status === 'stopped' || server.status === 'crashed'}
              >
                <Send className="w-3.5 h-3.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="top">Send Command</TooltipContent>
          </Tooltip>
        </div>
      </div>
    </motion.div>
  );
}