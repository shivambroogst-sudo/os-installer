'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import {
  Settings,
  Palette,
  ShieldCheck,
  Mail,
  Users,
  KeyRound,
  Plus,
  Trash2,
  Pencil,
  Send,
  Eye,
  EyeOff,
  Globe,
  Webhook,
  RotateCcw,
  Copy,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';

// ─── Animation Variants ───
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05, delayChildren: 0.05 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { type: 'spring', stiffness: 260, damping: 24, mass: 0.8 },
  },
};

// ─── Tab Icons ───
const tabIconClass = 'w-3.5 h-3.5';

// ─── Common Section Wrapper ───
function SectionCard({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <Card className="glass-card !p-0 overflow-hidden">
      <CardHeader className="pb-3 px-6 pt-5">
        <CardTitle className="text-base font-semibold text-foreground">{title}</CardTitle>
        {description && (
          <CardDescription className="text-xs mt-1">{description}</CardDescription>
        )}
      </CardHeader>
      <CardContent className="px-6 pb-5">{children}</CardContent>
    </Card>
  );
}

function FormField({
  label,
  description,
  children,
}: {
  label: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-2">
      <div>
        <Label className="text-sm text-muted-foreground">{label}</Label>
        {description && (
          <p className="text-[11px] text-muted-foreground/50 mt-0.5">{description}</p>
        )}
      </div>
      {children}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// GENERAL SETTINGS TAB
// ═══════════════════════════════════════════════════════════
function GeneralSettingsTab() {
  const [panelName, setPanelName] = useState('OGUltra Panel');
  const [panelDesc, setPanelDesc] = useState('Premium Game Hosting Platform');
  const [language, setLanguage] = useState('en');
  const [timezone, setTimezone] = useState('UTC');

  const handleSave = () => {
    toast.success('General settings saved successfully!');
  };

  return (
    <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
      <motion.div variants={itemVariants}>
        <SectionCard title="General Settings" description="Configure basic panel settings">
          <div className="space-y-4">
            <FormField label="Panel Name">
              <Input
                value={panelName}
                onChange={(e) => setPanelName(e.target.value)}
                className="glass-input h-10 text-sm bg-transparent"
              />
            </FormField>
            <FormField label="Panel Description">
              <Textarea
                value={panelDesc}
                onChange={(e) => setPanelDesc(e.target.value)}
                className="glass-input min-h-[80px] text-sm bg-transparent resize-none"
              />
            </FormField>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField label="Default Language">
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="glass-input h-10 text-sm bg-transparent">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="es">Spanish</SelectItem>
                    <SelectItem value="fr">French</SelectItem>
                    <SelectItem value="de">German</SelectItem>
                    <SelectItem value="zh">Chinese</SelectItem>
                    <SelectItem value="ja">Japanese</SelectItem>
                  </SelectContent>
                </Select>
              </FormField>
              <FormField label="Timezone">
                <Select value={timezone} onValueChange={setTimezone}>
                  <SelectTrigger className="glass-input h-10 text-sm bg-transparent">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="UTC">UTC</SelectItem>
                    <SelectItem value="America/New_York">America/New_York</SelectItem>
                    <SelectItem value="America/Chicago">America/Chicago</SelectItem>
                    <SelectItem value="America/Los_Angeles">America/Los_Angeles</SelectItem>
                    <SelectItem value="Europe/London">Europe/London</SelectItem>
                    <SelectItem value="Europe/Berlin">Europe/Berlin</SelectItem>
                    <SelectItem value="Asia/Tokyo">Asia/Tokyo</SelectItem>
                  </SelectContent>
                </Select>
              </FormField>
            </div>
          </div>
          <div className="mt-6 flex justify-end">
            <Button
              onClick={handleSave}
              className="gradient-brand text-white border-0 shadow-lg shadow-brand-600/20"
            >
              Save Changes
            </Button>
          </div>
        </SectionCard>
      </motion.div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// BRANDING TAB
// ═══════════════════════════════════════════════════════════
function BrandingTab() {
  const [logoUrl, setLogoUrl] = useState('/logo.svg');
  const [faviconUrl, setFaviconUrl] = useState('/favicon.ico');
  const [primaryColor, setPrimaryColor] = useState('#5c7cfa');
  const [accentColor, setAccentColor] = useState('#34d399');
  const [bgImageUrl, setBgImageUrl] = useState('');
  const [customCss, setCustomCss] = useState('');
  const [footerText, setFooterText] = useState('');
  const [copyrightText, setCopyrightText] = useState('© 2026 OGUltra. All rights reserved.');
  const [loginBg, setLoginBg] = useState('');

  const handleSave = () => {
    toast.success('Branding settings saved successfully!');
  };

  return (
    <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
      <motion.div variants={itemVariants}>
        <SectionCard title="Brand Identity" description="Customize your panel's appearance">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <FormField label="Logo URL" description="Image URL for the panel logo">
                <Input
                  value={logoUrl}
                  onChange={(e) => setLogoUrl(e.target.value)}
                  className="glass-input h-10 text-sm bg-transparent font-mono"
                />
              </FormField>
              <FormField label="Favicon URL">
                <Input
                  value={faviconUrl}
                  onChange={(e) => setFaviconUrl(e.target.value)}
                  className="glass-input h-10 text-sm bg-transparent font-mono"
                />
              </FormField>
              <div className="grid grid-cols-2 gap-4">
                <FormField label="Primary Color">
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={primaryColor}
                      onChange={(e) => setPrimaryColor(e.target.value)}
                      className="w-10 h-10 rounded-lg border border-white/10 cursor-pointer bg-transparent"
                    />
                    <Input
                      value={primaryColor}
                      onChange={(e) => setPrimaryColor(e.target.value)}
                      className="glass-input h-10 text-sm bg-transparent font-mono flex-1"
                    />
                  </div>
                </FormField>
                <FormField label="Accent Color">
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={accentColor}
                      onChange={(e) => setAccentColor(e.target.value)}
                      className="w-10 h-10 rounded-lg border border-white/10 cursor-pointer bg-transparent"
                    />
                    <Input
                      value={accentColor}
                      onChange={(e) => setAccentColor(e.target.value)}
                      className="glass-input h-10 text-sm bg-transparent font-mono flex-1"
                    />
                  </div>
                </FormField>
              </div>
              <FormField label="Background Image URL" description="Optional background for the panel">
                <Input
                  value={bgImageUrl}
                  onChange={(e) => setBgImageUrl(e.target.value)}
                  className="glass-input h-10 text-sm bg-transparent font-mono"
                />
              </FormField>
              <FormField label="Login Page Background URL">
                <Input
                  value={loginBg}
                  onChange={(e) => setLoginBg(e.target.value)}
                  className="glass-input h-10 text-sm bg-transparent font-mono"
                />
              </FormField>
            </div>

            <div className="space-y-4">
              <FormField label="Custom CSS" description="Inject custom CSS into the panel">
                <Textarea
                  value={customCss}
                  onChange={(e) => setCustomCss(e.target.value)}
                  placeholder="/* Custom CSS here */"
                  className="glass-input min-h-[120px] text-sm bg-transparent font-mono resize-none"
                />
              </FormField>
              <FormField label="Footer Text">
                <Input
                  value={footerText}
                  onChange={(e) => setFooterText(e.target.value)}
                  className="glass-input h-10 text-sm bg-transparent"
                />
              </FormField>
              <FormField label="Copyright Text">
                <Input
                  value={copyrightText}
                  onChange={(e) => setCopyrightText(e.target.value)}
                  className="glass-input h-10 text-sm bg-transparent"
                />
              </FormField>

              {/* Preview */}
              <div className="mt-4">
                <Label className="text-sm text-muted-foreground mb-2 block">Preview</Label>
                <div
                  className="rounded-xl border border-white/[0.08] p-4 space-y-3 overflow-hidden"
                  style={{
                    background: `linear-gradient(135deg, ${primaryColor}15, ${accentColor}10)`,
                  }}
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center"
                      style={{ background: `linear-gradient(135deg, ${primaryColor}, ${primaryColor}cc)` }}
                    >
                      <Settings className="w-4 h-4 text-white" />
                    </div>
                    <span
                      className="text-base font-bold"
                      style={{ color: primaryColor }}
                    >
                      {panelName || 'Panel Name'}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {panelDesc || 'Panel Description'}
                  </p>
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-1.5 rounded-full" style={{ background: primaryColor }} />
                    <div className="w-10 h-1.5 rounded-full" style={{ background: accentColor }} />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 flex justify-end">
            <Button
              onClick={handleSave}
              className="gradient-brand text-white border-0 shadow-lg shadow-brand-600/20"
            >
              Save Changes
            </Button>
          </div>
        </SectionCard>
      </motion.div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// SECURITY TAB
// ═══════════════════════════════════════════════════════════
function SecurityTab() {
  const [tfaRequirement, setTfaRequirement] = useState('off');
  const [passwordMinLength, setPasswordMinLength] = useState(8);
  const [requireUppercase, setRequireUppercase] = useState(true);
  const [requireLowercase, setRequireLowercase] = useState(true);
  const [requireNumbers, setRequireNumbers] = useState(true);
  const [requireSpecial, setRequireSpecial] = useState(false);
  const [sessionTimeout, setSessionTimeout] = useState(120);
  const [rateLimiting, setRateLimiting] = useState(true);
  const [maxAttempts, setMaxAttempts] = useState(5);
  const [ipWhitelist, setIpWhitelist] = useState('');
  const [csrfProtection, setCsrfProtection] = useState(true);

  const handleSave = () => {
    toast.success('Security settings saved successfully!');
  };

  return (
    <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
      <motion.div variants={itemVariants}>
        <SectionCard title="Two-Factor Authentication" description="Configure 2FA requirements for users">
          <div className="space-y-4">
            <FormField label="2FA Requirement">
              <Select value={tfaRequirement} onValueChange={setTfaRequirement}>
                <SelectTrigger className="glass-input h-10 text-sm bg-transparent">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="off">Off (Disabled)</SelectItem>
                  <SelectItem value="admins">Admins Only</SelectItem>
                  <SelectItem value="all">All Users</SelectItem>
                </SelectContent>
              </Select>
            </FormField>
          </div>
        </SectionCard>
      </motion.div>

      <motion.div variants={itemVariants}>
        <SectionCard title="Password Policy" description="Set password complexity requirements">
          <div className="space-y-4">
            <FormField label="Minimum Password Length">
              <Input
                type="number"
                value={passwordMinLength}
                onChange={(e) => setPasswordMinLength(Number(e.target.value))}
                min={4}
                max={128}
                className="glass-input h-10 text-sm bg-transparent w-32"
              />
            </FormField>
            <Separator className="bg-white/[0.06]" />
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">Require the following:</p>
              <div className="flex items-center justify-between">
                <Label className="text-sm text-foreground">Uppercase letters (A-Z)</Label>
                <Switch checked={requireUppercase} onCheckedChange={setRequireUppercase} />
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-sm text-foreground">Lowercase letters (a-z)</Label>
                <Switch checked={requireLowercase} onCheckedChange={setRequireLowercase} />
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-sm text-foreground">Numbers (0-9)</Label>
                <Switch checked={requireNumbers} onCheckedChange={setRequireNumbers} />
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-sm text-foreground">Special characters (!@#$%)</Label>
                <Switch checked={requireSpecial} onCheckedChange={setRequireSpecial} />
              </div>
            </div>
          </div>
        </SectionCard>
      </motion.div>

      <motion.div variants={itemVariants}>
        <SectionCard title="Session & Rate Limiting" description="Manage sessions and login protection">
          <div className="space-y-4">
            <FormField label="Session Timeout (minutes)" description="Time before inactive sessions expire">
              <Input
                type="number"
                value={sessionTimeout}
                onChange={(e) => setSessionTimeout(Number(e.target.value))}
                min={5}
                max={43200}
                className="glass-input h-10 text-sm bg-transparent w-32"
              />
            </FormField>
            <Separator className="bg-white/[0.06]" />
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm text-foreground">Login Rate Limiting</Label>
                <p className="text-[11px] text-muted-foreground/50 mt-0.5">
                  Limit login attempts to prevent brute force
                </p>
              </div>
              <Switch checked={rateLimiting} onCheckedChange={setRateLimiting} />
            </div>
            {rateLimiting && (
              <FormField label="Max Login Attempts" description="Before temporary lockout">
                <Input
                  type="number"
                  value={maxAttempts}
                  onChange={(e) => setMaxAttempts(Number(e.target.value))}
                  min={1}
                  max={20}
                  className="glass-input h-10 text-sm bg-transparent w-32"
                />
              </FormField>
            )}
          </div>
        </SectionCard>
      </motion.div>

      <motion.div variants={itemVariants}>
        <SectionCard title="Advanced Security" description="IP restrictions and CSRF protection">
          <div className="space-y-4">
            <FormField label="IP Whitelist" description="One IP address per line. Leave empty to allow all.">
              <Textarea
                value={ipWhitelist}
                onChange={(e) => setIpWhitelist(e.target.value)}
                placeholder={"192.168.1.0/24\n10.0.0.1"}
                className="glass-input min-h-[80px] text-sm bg-transparent font-mono resize-none"
              />
            </FormField>
            <Separator className="bg-white/[0.06]" />
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm text-foreground">CSRF Protection</Label>
                <p className="text-[11px] text-muted-foreground/50 mt-0.5">
                  Cross-Site Request Forgery protection
                </p>
              </div>
              <Switch checked={csrfProtection} onCheckedChange={setCsrfProtection} />
            </div>
          </div>
        </SectionCard>
      </motion.div>

      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          className="gradient-brand text-white border-0 shadow-lg shadow-brand-600/20"
        >
          Save Changes
        </Button>
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// MAIL TAB
// ═══════════════════════════════════════════════════════════
function MailTab() {
  const [smtpHost, setSmtpHost] = useState('smtp.example.com');
  const [smtpPort, setSmtpPort] = useState(587);
  const [smtpUser, setSmtpUser] = useState('');
  const [smtpPass, setSmtpPass] = useState('');
  const [showSmtpPass, setShowSmtpPass] = useState(false);
  const [fromName, setFromName] = useState('OGUltra Panel');
  const [fromEmail, setFromEmail] = useState('noreply@ogultra.io');
  const [encryption, setEncryption] = useState('tls');
  const [testEmail, setTestEmail] = useState('');

  const handleSave = () => {
    toast.success('Mail settings saved successfully!');
  };

  const handleTest = () => {
    if (!testEmail.trim() || !testEmail.includes('@')) {
      toast.error('Please enter a valid email address');
      return;
    }
    toast.success(`Test email sent to ${testEmail}`);
  };

  const templates = [
    { name: 'Welcome Email', description: 'Sent to new users after registration' },
    { name: 'Password Reset', description: 'Sent when user requests password reset' },
    { name: '2FA Verification', description: 'Sent when user enables 2FA' },
  ];

  return (
    <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
      <motion.div variants={itemVariants}>
        <SectionCard title="SMTP Configuration" description="Configure outgoing email server">
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-2">
                <FormField label="SMTP Host">
                  <Input
                    value={smtpHost}
                    onChange={(e) => setSmtpHost(e.target.value)}
                    className="glass-input h-10 text-sm bg-transparent font-mono"
                  />
                </FormField>
              </div>
              <FormField label="SMTP Port">
                <Input
                  type="number"
                  value={smtpPort}
                  onChange={(e) => setSmtpPort(Number(e.target.value))}
                  className="glass-input h-10 text-sm bg-transparent"
                />
              </FormField>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField label="SMTP Username">
                <Input
                  value={smtpUser}
                  onChange={(e) => setSmtpUser(e.target.value)}
                  className="glass-input h-10 text-sm bg-transparent"
                />
              </FormField>
              <FormField label="SMTP Password">
                <div className="relative">
                  <Input
                    type={showSmtpPass ? 'text' : 'password'}
                    value={smtpPass}
                    onChange={(e) => setSmtpPass(e.target.value)}
                    className="glass-input h-10 text-sm bg-transparent pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSmtpPass(!showSmtpPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground/50 hover:text-foreground transition-colors"
                    tabIndex={-1}
                  >
                    {showSmtpPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </FormField>
            </div>
            <FormField label="Encryption">
              <Select value={encryption} onValueChange={setEncryption}>
                <SelectTrigger className="glass-input h-10 text-sm bg-transparent w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="tls">TLS</SelectItem>
                  <SelectItem value="ssl">SSL</SelectItem>
                </SelectContent>
              </Select>
            </FormField>
          </div>
        </SectionCard>
      </motion.div>

      <motion.div variants={itemVariants}>
        <SectionCard title="Sender Information" description="Configure the sender details for outgoing emails">
          <div className="space-y-4">
            <FormField label="From Name">
              <Input
                value={fromName}
                onChange={(e) => setFromName(e.target.value)}
                className="glass-input h-10 text-sm bg-transparent"
              />
            </FormField>
            <FormField label="From Email">
              <Input
                type="email"
                value={fromEmail}
                onChange={(e) => setFromEmail(e.target.value)}
                className="glass-input h-10 text-sm bg-transparent"
              />
            </FormField>
          </div>
        </SectionCard>
      </motion.div>

      <motion.div variants={itemVariants}>
        <SectionCard title="Send Test Email" description="Verify your mail configuration">
          <div className="flex flex-col sm:flex-row gap-3">
            <Input
              type="email"
              placeholder="test@example.com"
              value={testEmail}
              onChange={(e) => setTestEmail(e.target.value)}
              className="glass-input h-10 text-sm bg-transparent flex-1"
            />
            <Button
              onClick={handleTest}
              variant="outline"
              className="gap-2 border-white/10 text-sm whitespace-nowrap"
            >
              <Send className="w-4 h-4" />
              Send Test
            </Button>
          </div>
        </SectionCard>
      </motion.div>

      <motion.div variants={itemVariants}>
        <SectionCard title="Email Templates" description="Manage email notification templates">
          <div className="space-y-2">
            {templates.map((tpl) => (
              <div
                key={tpl.name}
                className="flex items-center justify-between py-3 px-4 rounded-xl hover:bg-white/[0.03] transition-colors"
              >
                <div>
                  <p className="text-sm font-medium text-foreground">{tpl.name}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">{tpl.description}</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 px-3 text-[11px] gap-1 text-brand-400/80 hover:text-brand-300 hover:bg-brand-500/10"
                  onClick={() => toast.info('Template editor coming soon')}
                >
                  <Pencil className="w-3 h-3" />
                  Edit
                </Button>
              </div>
            ))}
          </div>
        </SectionCard>
      </motion.div>

      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          className="gradient-brand text-white border-0 shadow-lg shadow-brand-600/20"
        >
          Save Changes
        </Button>
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// ROLES TAB
// ═══════════════════════════════════════════════════════════

const systemRoles = [
  { name: 'Owner', description: 'Full unrestricted access to the entire panel', userCount: 1, color: 'text-brand-400' },
  { name: 'Admin', description: 'Full admin access including node management', userCount: 1, color: 'text-purple-400' },
  { name: 'Moderator', description: 'Can manage users and view activity logs', userCount: 1, color: 'text-amber-400' },
  { name: 'Support', description: 'Can view servers and assist users', userCount: 0, color: 'text-cyan-400' },
  { name: 'User', description: 'Basic access to assigned servers only', userCount: 2, color: 'text-muted-foreground' },
];

const permissionCategories = [
  {
    category: 'Servers',
    permissions: [
      { id: 'server.view', label: 'View Servers' },
      { id: 'server.create', label: 'Create Servers' },
      { id: 'server.edit', label: 'Edit Servers' },
      { id: 'server.delete', label: 'Delete Servers' },
      { id: 'server.start', label: 'Start/Stop Servers' },
      { id: 'server.console', label: 'Access Console' },
      { id: 'server.files', label: 'Manage Files' },
    ],
  },
  {
    category: 'Users',
    permissions: [
      { id: 'user.view', label: 'View Users' },
      { id: 'user.create', label: 'Create Users' },
      { id: 'user.edit', label: 'Edit Users' },
      { id: 'user.delete', label: 'Delete Users' },
      { id: 'user.impersonate', label: 'Impersonate Users' },
    ],
  },
  {
    category: 'Nodes',
    permissions: [
      { id: 'node.view', label: 'View Nodes' },
      { id: 'node.create', label: 'Create Nodes' },
      { id: 'node.edit', label: 'Edit Nodes' },
      { id: 'node.delete', label: 'Delete Nodes' },
    ],
  },
  {
    category: 'Backups',
    permissions: [
      { id: 'backup.view', label: 'View Backups' },
      { id: 'backup.create', label: 'Create Backups' },
      { id: 'backup.download', label: 'Download Backups' },
      { id: 'backup.restore', label: 'Restore Backups' },
      { id: 'backup.delete', label: 'Delete Backups' },
    ],
  },
  {
    category: 'Settings',
    permissions: [
      { id: 'settings.view', label: 'View Settings' },
      { id: 'settings.edit', label: 'Edit Settings' },
      { id: 'settings.branding', label: 'Edit Branding' },
    ],
  },
  {
    category: 'Admin',
    permissions: [
      { id: 'admin.activity', label: 'View Activity Logs' },
      { id: 'admin.roles', label: 'Manage Roles' },
      { id: 'admin.api', label: 'Manage API Tokens' },
      { id: 'admin.mail', label: 'Manage Mail Settings' },
    ],
  },
];

function RolesTab() {
  const [createRoleOpen, setCreateRoleOpen] = useState(false);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleDesc, setNewRoleDesc] = useState('');
  const [selectedPerms, setSelectedPerms] = useState<string[]>([]);

  const togglePermission = (permId: string) => {
    setSelectedPerms((prev) =>
      prev.includes(permId)
        ? prev.filter((p) => p !== permId)
        : [...prev, permId]
    );
  };

  const handleCreateRole = () => {
    if (!newRoleName.trim()) {
      toast.error('Role name is required');
      return;
    }
    toast.success(`Role "${newRoleName}" created with ${selectedPerms.length} permissions!`);
    setCreateRoleOpen(false);
    setNewRoleName('');
    setNewRoleDesc('');
    setSelectedPerms([]);
  };

  return (
    <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
      <motion.div variants={itemVariants}>
        <Card className="glass-card !p-0 overflow-hidden">
          <CardHeader className="pb-3 px-6 pt-5">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base font-semibold text-foreground">
                  System Roles
                </CardTitle>
                <CardDescription className="text-xs mt-1">
                  Define permission levels for your panel
                </CardDescription>
              </div>
              <Button
                onClick={() => setCreateRoleOpen(true)}
                className="gap-2 gradient-brand text-white border-0 shadow-lg shadow-brand-600/20 text-sm h-9"
              >
                <Plus className="w-4 h-4" />
                Create Custom Role
              </Button>
            </div>
          </CardHeader>
          <CardContent className="px-2 pb-2">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-b border-white/[0.06] hover:bg-transparent">
                    <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider">
                      Role
                    </TableHead>
                    <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider hidden sm:table-cell">
                      Description
                    </TableHead>
                    <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider text-center">
                      Users
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {systemRoles.map((role, idx) => (
                    <motion.tr
                      key={role.name}
                      className="border-b border-white/[0.04] last:border-0 hover:bg-white/[0.02] transition-colors"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05 * idx, type: 'spring', stiffness: 300, damping: 25 }}
                    >
                      <TableCell className="py-3.5">
                        <span className={`text-sm font-medium ${role.color}`}>{role.name}</span>
                      </TableCell>
                      <TableCell className="py-3.5 hidden sm:table-cell">
                        <span className="text-sm text-muted-foreground">{role.description}</span>
                      </TableCell>
                      <TableCell className="py-3.5 text-center">
                        <Badge
                          variant="outline"
                          className="text-[10px] px-2 py-0 h-5 border-white/10 text-muted-foreground bg-white/[0.03]"
                        >
                          {role.userCount}
                        </Badge>
                      </TableCell>
                    </motion.tr>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Create Role Dialog */}
      <Dialog open={createRoleOpen} onOpenChange={setCreateRoleOpen}>
        <DialogContent className="glass-card !rounded-2xl max-w-2xl border-white/[0.08] bg-[#0c0c1a]/95 backdrop-blur-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold text-foreground">
              Create Custom Role
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField label="Role Name">
                <Input
                  placeholder="Custom Role"
                  value={newRoleName}
                  onChange={(e) => setNewRoleName(e.target.value)}
                  className="glass-input h-10 text-sm bg-transparent"
                />
              </FormField>
              <FormField label="Description">
                <Input
                  placeholder="Optional description"
                  value={newRoleDesc}
                  onChange={(e) => setNewRoleDesc(e.target.value)}
                  className="glass-input h-10 text-sm bg-transparent"
                />
              </FormField>
            </div>

            <Separator className="bg-white/[0.06]" />

            <div className="flex items-center justify-between">
              <Label className="text-sm text-foreground">Permissions</Label>
              <span className="text-xs text-muted-foreground">
                {selectedPerms.length} of {permissionCategories.reduce((s, c) => s + c.permissions.length, 0)} selected
              </span>
            </div>

            <div className="space-y-4">
              {permissionCategories.map((cat) => (
                <div key={cat.category}>
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground/60 mb-2">
                    {cat.category}
                  </p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {cat.permissions.map((perm) => (
                      <label
                        key={perm.id}
                        className="flex items-center gap-2 py-1.5 px-2 rounded-lg hover:bg-white/[0.03] cursor-pointer transition-colors"
                      >
                        <Checkbox
                          checked={selectedPerms.includes(perm.id)}
                          onCheckedChange={() => togglePermission(perm.id)}
                          className="border-white/20 data-[state=checked]:bg-brand-600 data-[state=checked]:border-brand-600"
                        />
                        <span className="text-xs text-muted-foreground">{perm.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter className="gap-2 pt-2">
            <Button
              variant="ghost"
              onClick={() => setCreateRoleOpen(false)}
              className="text-muted-foreground hover:text-foreground"
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreateRole}
              className="gradient-brand text-white border-0 shadow-lg shadow-brand-600/20"
            >
              Create Role
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// API TAB
// ═══════════════════════════════════════════════════════════

const mockApiTokens = [
  {
    id: 'tok_01',
    name: 'Deploy Script',
    createdAt: '2026-06-01',
    lastUsed: '2026-07-04',
    permissions: ['servers:read', 'servers:write', 'nodes:read'],
  },
  {
    id: 'tok_02',
    name: 'Monitoring Bot',
    createdAt: '2026-05-15',
    lastUsed: '2026-07-03',
    permissions: ['servers:read', 'nodes:read', 'users:read'],
  },
  {
    id: 'tok_03',
    name: 'Backup Automation',
    createdAt: '2026-04-20',
    lastUsed: null,
    permissions: ['servers:read', 'backups:read', 'backups:write'],
  },
];

const mockWebhooks = [
  { id: 'wh_01', url: 'https://hooks.example.com/ogultra', events: ['server.start', 'server.stop', 'server.crash'] },
  { id: 'wh_02', url: 'https://discord.com/api/webhooks/...', events: ['backup.complete', 'user.create'] },
];

function ApiTab() {
  const [createTokenOpen, setCreateTokenOpen] = useState(false);
  const [addWebhookOpen, setAddWebhookOpen] = useState(false);

  // Create token form
  const [tokenName, setTokenName] = useState('');
  const [tokenPerms, setTokenPerms] = useState<string[]>([]);
  const [tokenExpiry, setTokenExpiry] = useState('never');

  // Add webhook form
  const [webhookUrl, setWebhookUrl] = useState('');
  const [webhookEvents, setWebhookEvents] = useState<string[]>([]);

  const availableTokenPerms = [
    'servers:read', 'servers:write',
    'nodes:read', 'nodes:write',
    'users:read', 'users:write',
    'backups:read', 'backups:write',
  ];

  const availableEvents = [
    'server.start', 'server.stop', 'server.crash', 'server.restart',
    'backup.complete', 'backup.failed',
    'user.create', 'user.delete',
    'node.online', 'node.offline',
  ];

  const toggleTokenPerm = (perm: string) => {
    setTokenPerms((prev) =>
      prev.includes(perm) ? prev.filter((p) => p !== perm) : [...prev, perm]
    );
  };

  const toggleWebhookEvent = (event: string) => {
    setWebhookEvents((prev) =>
      prev.includes(event) ? prev.filter((e) => e !== event) : [...prev, event]
    );
  };

  const handleCreateToken = () => {
    if (!tokenName.trim()) {
      toast.error('Token name is required');
      return;
    }
    if (tokenPerms.length === 0) {
      toast.error('Select at least one permission');
      return;
    }
    toast.success(`API token "${tokenName}" created successfully!`);
    setCreateTokenOpen(false);
    setTokenName('');
    setTokenPerms([]);
    setTokenExpiry('never');
  };

  const handleAddWebhook = () => {
    if (!webhookUrl.trim()) {
      toast.error('Webhook URL is required');
      return;
    }
    if (webhookEvents.length === 0) {
      toast.error('Select at least one event');
      return;
    }
    toast.success('Webhook added successfully!');
    setAddWebhookOpen(false);
    setWebhookUrl('');
    setWebhookEvents([]);
  };

  const handleRevokeToken = (name: string) => {
    toast.success(`Token "${name}" revoked`);
  };

  const handleDeleteWebhook = (url: string) => {
    toast.success('Webhook removed');
  };

  return (
    <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-4">
      {/* API Tokens */}
      <motion.div variants={itemVariants}>
        <Card className="glass-card !p-0 overflow-hidden">
          <CardHeader className="pb-3 px-6 pt-5">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base font-semibold text-foreground flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-brand-400" />
                  API Tokens
                </CardTitle>
                <CardDescription className="text-xs mt-1">
                  Manage API tokens for programmatic access
                </CardDescription>
              </div>
              <Button
                onClick={() => setCreateTokenOpen(true)}
                className="gap-2 gradient-brand text-white border-0 shadow-lg shadow-brand-600/20 text-sm h-9"
              >
                <Plus className="w-4 h-4" />
                Create Token
              </Button>
            </div>
          </CardHeader>
          <CardContent className="px-2 pb-2">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-b border-white/[0.06] hover:bg-transparent">
                    <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider">
                      Name
                    </TableHead>
                    <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider hidden sm:table-cell">
                      Created
                    </TableHead>
                    <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider hidden md:table-cell">
                      Last Used
                    </TableHead>
                    <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider hidden lg:table-cell">
                      Permissions
                    </TableHead>
                    <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider text-right">
                      Actions
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockApiTokens.map((token, idx) => (
                    <motion.tr
                      key={token.id}
                      className="border-b border-white/[0.04] last:border-0 hover:bg-white/[0.02] transition-colors"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05 * idx, type: 'spring', stiffness: 300, damping: 25 }}
                    >
                      <TableCell className="py-3.5">
                        <div className="flex items-center gap-2">
                          <KeyRound className="w-3.5 h-3.5 text-brand-400/60" />
                          <span className="text-sm font-medium text-foreground">{token.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="py-3.5 hidden sm:table-cell">
                        <span className="text-sm text-muted-foreground">{token.createdAt}</span>
                      </TableCell>
                      <TableCell className="py-3.5 hidden md:table-cell">
                        <span className="text-sm text-muted-foreground">
                          {token.lastUsed ?? 'Never'}
                        </span>
                      </TableCell>
                      <TableCell className="py-3.5 hidden lg:table-cell">
                        <div className="flex flex-wrap gap-1">
                          {token.permissions.map((p) => (
                            <Badge
                              key={p}
                              variant="outline"
                              className="text-[10px] px-1.5 py-0 h-4 border-white/10 text-muted-foreground bg-white/[0.03] font-mono"
                            >
                              {p}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="py-3.5 text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-[11px] gap-1 text-red-400/50 hover:text-red-300 hover:bg-red-500/10"
                          onClick={() => handleRevokeToken(token.name)}
                        >
                          <Trash2 className="w-3 h-3" />
                          Revoke
                        </Button>
                      </TableCell>
                    </motion.tr>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Webhooks */}
      <motion.div variants={itemVariants}>
        <Card className="glass-card !p-0 overflow-hidden">
          <CardHeader className="pb-3 px-6 pt-5">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base font-semibold text-foreground flex items-center gap-2">
                  <Webhook className="w-4 h-4 text-purple-400" />
                  Webhooks
                </CardTitle>
                <CardDescription className="text-xs mt-1">
                  Receive HTTP callbacks for panel events
                </CardDescription>
              </div>
              <Button
                onClick={() => setAddWebhookOpen(true)}
                variant="outline"
                className="gap-2 border-white/10 text-sm text-muted-foreground hover:text-foreground h-9"
              >
                <Plus className="w-4 h-4" />
                Add Webhook
              </Button>
            </div>
          </CardHeader>
          <CardContent className="px-2 pb-2">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-b border-white/[0.06] hover:bg-transparent">
                    <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider">
                      URL
                    </TableHead>
                    <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider hidden sm:table-cell">
                      Events
                    </TableHead>
                    <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider text-right">
                      Actions
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockWebhooks.map((wh, idx) => (
                    <motion.tr
                      key={wh.id}
                      className="border-b border-white/[0.04] last:border-0 hover:bg-white/[0.02] transition-colors"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05 * idx, type: 'spring', stiffness: 300, damping: 25 }}
                    >
                      <TableCell className="py-3.5">
                        <div className="flex items-center gap-2">
                          <Globe className="w-3.5 h-3.5 text-purple-400/60" />
                          <span className="text-sm text-foreground font-mono truncate max-w-[250px]">
                            {wh.url}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="py-3.5 hidden sm:table-cell">
                        <div className="flex flex-wrap gap-1">
                          {wh.events.map((ev) => (
                            <Badge
                              key={ev}
                              variant="outline"
                              className="text-[10px] px-1.5 py-0 h-4 border-white/10 text-muted-foreground bg-white/[0.03] font-mono"
                            >
                              {ev}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="py-3.5 text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-[11px] gap-1 text-red-400/50 hover:text-red-300 hover:bg-red-500/10"
                          onClick={() => handleDeleteWebhook(wh.url)}
                        >
                          <Trash2 className="w-3 h-3" />
                          Remove
                        </Button>
                      </TableCell>
                    </motion.tr>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Create Token Dialog */}
      <Dialog open={createTokenOpen} onOpenChange={setCreateTokenOpen}>
        <DialogContent className="glass-card !rounded-2xl max-w-md border-white/[0.08] bg-[#0c0c1a]/95 backdrop-blur-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold text-foreground">
              Create API Token
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <FormField label="Token Name" description="A descriptive name for this token">
              <Input
                placeholder="My API Token"
                value={tokenName}
                onChange={(e) => setTokenName(e.target.value)}
                className="glass-input h-10 text-sm bg-transparent"
              />
            </FormField>

            <FormField label="Expiry">
              <Select value={tokenExpiry} onValueChange={setTokenExpiry}>
                <SelectTrigger className="glass-input h-10 text-sm bg-transparent">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="never">Never</SelectItem>
                  <SelectItem value="30d">30 Days</SelectItem>
                  <SelectItem value="90d">90 Days</SelectItem>
                  <SelectItem value="1y">1 Year</SelectItem>
                </SelectContent>
              </Select>
            </FormField>

            <Separator className="bg-white/[0.06]" />

            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-sm text-foreground">Permissions</Label>
                <span className="text-xs text-muted-foreground">
                  {tokenPerms.length} selected
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {availableTokenPerms.map((perm) => (
                  <label
                    key={perm}
                    className="flex items-center gap-2 py-1.5 px-2 rounded-lg hover:bg-white/[0.03] cursor-pointer transition-colors"
                  >
                    <Checkbox
                      checked={tokenPerms.includes(perm)}
                      onCheckedChange={() => toggleTokenPerm(perm)}
                      className="border-white/20 data-[state=checked]:bg-brand-600 data-[state=checked]:border-brand-600"
                    />
                    <span className="text-xs text-muted-foreground font-mono">{perm}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2 pt-2">
            <Button
              variant="ghost"
              onClick={() => setCreateTokenOpen(false)}
              className="text-muted-foreground hover:text-foreground"
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreateToken}
              className="gradient-brand text-white border-0 shadow-lg shadow-brand-600/20"
            >
              Create Token
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Webhook Dialog */}
      <Dialog open={addWebhookOpen} onOpenChange={setAddWebhookOpen}>
        <DialogContent className="glass-card !rounded-2xl max-w-md border-white/[0.08] bg-[#0c0c1a]/95 backdrop-blur-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold text-foreground">
              Add Webhook
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <FormField label="Webhook URL">
              <Input
                placeholder="https://hooks.example.com/your-endpoint"
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
                className="glass-input h-10 text-sm bg-transparent font-mono"
              />
            </FormField>

            <Separator className="bg-white/[0.06]" />

            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-sm text-foreground">Events</Label>
                <span className="text-xs text-muted-foreground">
                  {webhookEvents.length} selected
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                {availableEvents.map((event) => (
                  <label
                    key={event}
                    className="flex items-center gap-2 py-1.5 px-2 rounded-lg hover:bg-white/[0.03] cursor-pointer transition-colors"
                  >
                    <Checkbox
                      checked={webhookEvents.includes(event)}
                      onCheckedChange={() => toggleWebhookEvent(event)}
                      className="border-white/20 data-[state=checked]:bg-brand-600 data-[state=checked]:border-brand-600"
                    />
                    <span className="text-xs text-muted-foreground font-mono">{event}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2 pt-2">
            <Button
              variant="ghost"
              onClick={() => setAddWebhookOpen(false)}
              className="text-muted-foreground hover:text-foreground"
            >
              Cancel
            </Button>
            <Button
              onClick={handleAddWebhook}
              className="gradient-brand text-white border-0 shadow-lg shadow-brand-600/20"
            >
              Add Webhook
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// ADMIN PANEL MAIN
// ═══════════════════════════════════════════════════════════
export default function AdminPanel() {
  const [activeTab, setActiveTab] = useState('general');

  return (
    <motion.div
      className="space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* Page Header */}
      <motion.div variants={itemVariants}>
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Admin Panel</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Configure and manage your panel settings
          </p>
        </div>
      </motion.div>

      {/* Tabs */}
      <motion.div variants={itemVariants}>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="glass-card !p-1 h-auto flex flex-wrap gap-1 bg-transparent border border-white/[0.06]">
            <TabsTrigger
              value="general"
              className="gap-2 text-xs data-[state=active]:bg-brand-600/15 data-[state=active]:text-brand-400 rounded-lg px-3 py-2 h-9"
            >
              <Settings className={tabIconClass} />
              General
            </TabsTrigger>
            <TabsTrigger
              value="branding"
              className="gap-2 text-xs data-[state=active]:bg-brand-600/15 data-[state=active]:text-brand-400 rounded-lg px-3 py-2 h-9"
            >
              <Palette className={tabIconClass} />
              Branding
            </TabsTrigger>
            <TabsTrigger
              value="security"
              className="gap-2 text-xs data-[state=active]:bg-brand-600/15 data-[state=active]:text-brand-400 rounded-lg px-3 py-2 h-9"
            >
              <ShieldCheck className={tabIconClass} />
              Security
            </TabsTrigger>
            <TabsTrigger
              value="mail"
              className="gap-2 text-xs data-[state=active]:bg-brand-600/15 data-[state=active]:text-brand-400 rounded-lg px-3 py-2 h-9"
            >
              <Mail className={tabIconClass} />
              Mail
            </TabsTrigger>
            <TabsTrigger
              value="roles"
              className="gap-2 text-xs data-[state=active]:bg-brand-600/15 data-[state=active]:text-brand-400 rounded-lg px-3 py-2 h-9"
            >
              <Users className={tabIconClass} />
              Roles
            </TabsTrigger>
            <TabsTrigger
              value="api"
              className="gap-2 text-xs data-[state=active]:bg-brand-600/15 data-[state=active]:text-brand-400 rounded-lg px-3 py-2 h-9"
            >
              <KeyRound className={tabIconClass} />
              API
            </TabsTrigger>
          </TabsList>

          <TabsContent value="general">
            <GeneralSettingsTab />
          </TabsContent>
          <TabsContent value="branding">
            <BrandingTab />
          </TabsContent>
          <TabsContent value="security">
            <SecurityTab />
          </TabsContent>
          <TabsContent value="mail">
            <MailTab />
          </TabsContent>
          <TabsContent value="roles">
            <RolesTab />
          </TabsContent>
          <TabsContent value="api">
            <ApiTab />
          </TabsContent>
        </Tabs>
      </motion.div>
    </motion.div>
  );
}