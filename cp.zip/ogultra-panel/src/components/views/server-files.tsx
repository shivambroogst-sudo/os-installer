'use client';
import { useState, useCallback, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { File, Folder, FolderOpen, Upload, Download, Trash2, Edit3, ChevronRight, ChevronDown, Plus, Search, MoreVertical, Archive, RefreshCw, Home, ArrowUp, Grid3X3, List, X, Loader2, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { useNavStore } from '@/lib/store';
import { listFiles, readFile, writeFile, deleteFile, createDirectory, type FileEntry as ApiFileEntry } from '@/lib/api';
import { formatBytes } from '@/lib/mock-data';
import { toast } from 'sonner';

// ============ Types ============

interface FileEntry {
  name: string;
  type: 'file' | 'folder';
  size: number;
  modified: string;
}

type ViewMode = 'list' | 'grid';

// ============ Helpers ============

function getFileExtension(name: string): string {
  const idx = name.lastIndexOf('.');
  if (idx < 1) return '';
  return name.slice(idx + 1).toLowerCase();
}

function getFileTypeColor(name: string): string {
  const ext = getFileExtension(name);
  switch (ext) {
    case 'yml':
    case 'yaml':
      return 'text-amber-400';
    case 'json':
      return 'text-emerald-400';
    case 'txt':
    case 'log':
      return 'text-zinc-400';
    case 'jar':
      return 'text-purple-400';
    case 'properties':
      return 'text-orange-400';
    case 'gz':
      return 'text-rose-400';
    case 'sh':
      return 'text-sky-400';
    default:
      return 'text-zinc-400';
  }
}

function getFileTypeBg(name: string): string {
  const ext = getFileExtension(name);
  switch (ext) {
    case 'yml':
    case 'yaml':
      return 'bg-amber-500/15';
    case 'json':
      return 'bg-emerald-500/15';
    case 'txt':
      return 'bg-zinc-500/15';
    case 'jar':
      return 'bg-purple-500/15';
    case 'log':
      return 'bg-sky-500/15';
    case 'properties':
      return 'bg-orange-500/15';
    case 'gz':
      return 'bg-rose-500/15';
    case 'dat':
      return 'bg-cyan-500/15';
    case 'mca':
      return 'bg-teal-500/15';
    default:
      return 'bg-zinc-500/15';
  }
}

function getFileTypeLabel(name: string): string {
  const ext = getFileExtension(name);
  if (!ext) return 'File';
  const labels: Record<string, string> = {
    yml: 'YAML Config', yaml: 'YAML Config',
    json: 'JSON File', txt: 'Text File',
    jar: 'Java Archive', log: 'Log File',
    properties: 'Properties File', gz: 'GZ Archive',
    dat: 'Data File', mca: 'Minecraft Region',
    lock: 'Lock File',
  };
  return labels[ext] || `${ext.toUpperCase()} File`;
}

function sortEntries(entries: FileEntry[]): FileEntry[] {
  return [...entries].sort((a, b) => {
    if (a.type === 'folder' && b.type !== 'folder') return -1;
    if (a.type !== 'folder' && b.type === 'folder') return 1;
    return a.name.localeCompare(b.name, undefined, { sensitivity: 'base' });
  });
}

// ============ Animation Variants ============

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.03, delayChildren: 0.05 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { type: 'spring', stiffness: 300, damping: 28, mass: 0.8 },
  },
};

const gridItemVariants = {
  hidden: { opacity: 0, scale: 0.92 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { type: 'spring', stiffness: 300, damping: 28, mass: 0.8 },
  },
};

// ============ File Icon Component ============

function FileIcon({ entry, size = 'md', isOpen = false }: { entry: FileEntry; size?: 'sm' | 'md' | 'lg'; isOpen?: boolean }) {
  const isFolder = entry.type === 'folder';
  const iconSize = size === 'sm' ? 'w-4 h-4' : size === 'lg' ? 'w-8 h-8' : 'w-5 h-5';

  if (isFolder) {
    const folderColor = isOpen ? 'text-amber-400' : 'text-amber-400/80';
    const folderBg = isOpen ? 'bg-amber-500/20' : 'bg-amber-500/12';
    const paddingClass = size === 'sm' ? 'p-1' : size === 'lg' ? 'p-3' : 'p-1.5';
    return (
      <div className={`${folderBg} ${paddingClass} rounded-lg`}>
        {isOpen ? (
          <FolderOpen className={`${iconSize} ${folderColor}`} />
        ) : (
          <Folder className={`${iconSize} ${folderColor}`} />
        )}
      </div>
    );
  }

  const colorClass = getFileTypeColor(entry.name);
  const bgClass = getFileTypeBg(entry.name);
  const paddingClass = size === 'sm' ? 'p-1' : size === 'lg' ? 'p-3' : 'p-1.5';
  return (
    <div className={`${bgClass} ${paddingClass} rounded-lg`}>
      <File className={`${iconSize} ${colorClass}`} />
    </div>
  );
}

// ============ Empty State Component ============

function EmptyState() {
  return (
    <motion.div
      className="flex flex-col items-center justify-center py-20 px-4"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="w-16 h-16 rounded-2xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center mb-4">
        <Folder className="w-7 h-7 text-zinc-600" />
      </div>
      <h3 className="text-sm font-medium text-foreground/80 mb-1">This folder is empty</h3>
      <p className="text-xs text-muted-foreground text-center max-w-[240px]">
        Create a new file or folder, or upload files to get started.
      </p>
    </motion.div>
  );
}

// ============ Main Component ============

export default function ServerFiles() {
  const { selectedServerId } = useNavStore();

  // ============ State ============
  const [currentPath, setCurrentPath] = useState<string[]>([]);
  const [entries, setEntries] = useState<FileEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [showDetailsPanel, setShowDetailsPanel] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Edit state
  const [editingFile, setEditingFile] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [editSaving, setEditSaving] = useState(false);

  // Modal states
  const [showNewFileDialog, setShowNewFileDialog] = useState(false);
  const [showNewFolderDialog, setShowNewFolderDialog] = useState(false);
  const [showRenameDialog, setShowRenameDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showUploadDialog, setShowUploadDialog] = useState(false);

  // Modal input states
  const [newFileName, setNewFileName] = useState('');
  const [newFolderName, setNewFolderName] = useState('');
  const [renameValue, setRenameValue] = useState('');
  const [creating, setCreating] = useState(false);
  const [deleting, setDeleting] = useState(false);

  // ============ Build API path ============

  const apiPath = useMemo(() => {
    if (currentPath.length === 0) return '/';
    return '/' + currentPath.join('/');
  }, [currentPath]);

  // ============ Fetch files ============

  const fetchFiles = useCallback(async () => {
    if (!selectedServerId) return;
    setLoading(true);
    try {
      const res = await listFiles(selectedServerId, apiPath);
      if (res.success && res.data) {
        setEntries(res.data.map((f: ApiFileEntry) => ({
          name: f.name,
          type: f.type,
          size: f.size,
          modified: f.modified,
        })));
      } else {
        toast.error('Failed to load files');
        setEntries([]);
      }
    } catch {
      toast.error('Failed to load files');
      setEntries([]);
    } finally {
      setLoading(false);
    }
  }, [selectedServerId, apiPath]);

  useEffect(() => {
    fetchFiles();
  }, [fetchFiles]);

  // ============ Derived State ============

  const filteredEntries = useMemo(() => {
    let filtered = entries;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = entries.filter((e) => e.name.toLowerCase().includes(q));
    }
    return sortEntries(filtered);
  }, [entries, searchQuery]);

  const selectedEntry = useMemo(() => {
    if (!selectedFile) return null;
    return entries.find((e) => e.name === selectedFile) || null;
  }, [selectedFile, entries]);

  const currentPathDisplay = ['home', ...currentPath];

  // ============ Navigation ============

  const navigateToFolder = useCallback((folderName: string) => {
    setCurrentPath((prev) => [...prev, folderName]);
    setSelectedFile(null);
    setSearchQuery('');
  }, []);

  const navigateToPathIndex = useCallback((index: number) => {
    if (index === 0) {
      setCurrentPath([]);
    } else {
      setCurrentPath((prev) => prev.slice(0, index));
    }
    setSelectedFile(null);
    setSearchQuery('');
  }, []);

  const navigateUp = useCallback(() => {
    setCurrentPath((prev) => prev.slice(0, -1));
    setSelectedFile(null);
    setSearchQuery('');
  }, []);

  // ============ Actions ============

  const handleRefresh = useCallback(() => {
    setIsRefreshing(true);
    fetchFiles().finally(() => setIsRefreshing(false));
  }, [fetchFiles]);

  const handleCreateFile = useCallback(async () => {
    if (!newFileName.trim() || !selectedServerId) return;
    setCreating(true);
    try {
      const filePath = apiPath === '/' ? `/${newFileName.trim()}` : `${apiPath}/${newFileName.trim()}`;
      const res = await writeFile(selectedServerId, filePath, '');
      if (res.success) {
        toast.success(`Created file: ${newFileName}`);
        setNewFileName('');
        setShowNewFileDialog(false);
        fetchFiles();
      } else {
        toast.error(res.error || 'Failed to create file');
      }
    } catch {
      toast.error('Failed to create file');
    } finally {
      setCreating(false);
    }
  }, [newFileName, selectedServerId, apiPath, fetchFiles]);

  const handleCreateFolder = useCallback(async () => {
    if (!newFolderName.trim() || !selectedServerId) return;
    setCreating(true);
    try {
      const folderPath = apiPath === '/' ? `/${newFolderName.trim()}` : `${apiPath}/${newFolderName.trim()}`;
      const res = await createDirectory(selectedServerId, folderPath);
      if (res.success) {
        toast.success(`Created folder: ${newFolderName}`);
        setNewFolderName('');
        setShowNewFolderDialog(false);
        fetchFiles();
      } else {
        toast.error(res.error || 'Failed to create folder');
      }
    } catch {
      toast.error('Failed to create folder');
    } finally {
      setCreating(false);
    }
  }, [newFolderName, selectedServerId, apiPath, fetchFiles]);

  const handleRename = useCallback(() => {
    if (!renameValue.trim() || !selectedFile) return;
    toast.info('Rename is not supported by the daemon API');
    setRenameValue('');
    setShowRenameDialog(false);
    setSelectedFile(null);
  }, [renameValue, selectedFile]);

  const handleDelete = useCallback(async () => {
    if (!selectedFile || !selectedServerId) return;
    setDeleting(true);
    try {
      const filePath = apiPath === '/' ? `/${selectedFile}` : `${apiPath}/${selectedFile}`;
      const res = await deleteFile(selectedServerId, filePath);
      if (res.success) {
        toast.success(`Deleted "${selectedFile}"`);
        setShowDeleteDialog(false);
        setSelectedFile(null);
        fetchFiles();
      } else {
        toast.error(res.error || 'Failed to delete');
      }
    } catch {
      toast.error('Failed to delete');
    } finally {
      setDeleting(false);
    }
  }, [selectedFile, selectedServerId, apiPath, fetchFiles]);

  const handleUpload = useCallback(() => {
    toast.info('File upload is not yet implemented');
    setShowUploadDialog(false);
  }, []);

  const handleDownload = useCallback(() => {
    if (!selectedFile) return;
    toast.info(`Downloading ${selectedFile}...`);
  }, [selectedFile]);

  const handleCompress = useCallback(() => {
    if (!selectedFile) return;
    toast.info('Compress is not yet implemented');
  }, [selectedFile]);

  const openRenameDialog = useCallback(() => {
    if (!selectedFile) return;
    setRenameValue(selectedFile);
    setShowRenameDialog(true);
  }, [selectedFile]);

  const handleOpenFile = useCallback(async (fileName: string) => {
    if (!selectedServerId) return;
    const filePath = apiPath === '/' ? `/${fileName}` : `${apiPath}/${fileName}`;
    setEditingFile(fileName);
    setEditContent('Loading...');
    try {
      const res = await readFile(selectedServerId, filePath);
      if (res.success && res.content !== undefined) {
        setEditContent(res.content);
      } else {
        toast.error(res.error || 'Failed to read file');
        setEditContent('');
        setEditingFile(null);
      }
    } catch {
      toast.error('Failed to read file');
      setEditContent('');
      setEditingFile(null);
    }
  }, [selectedServerId, apiPath]);

  const handleSaveFile = useCallback(async () => {
    if (!editingFile || !selectedServerId) return;
    setEditSaving(true);
    try {
      const filePath = apiPath === '/' ? `/${editingFile}` : `${apiPath}/${editingFile}`;
      const res = await writeFile(selectedServerId, filePath, editContent);
      if (res.success) {
        toast.success(`Saved ${editingFile}`);
        setEditingFile(null);
        setEditContent('');
        fetchFiles();
      } else {
        toast.error(res.error || 'Failed to save file');
      }
    } catch {
      toast.error('Failed to save file');
    } finally {
      setEditSaving(false);
    }
  }, [editingFile, selectedServerId, apiPath, editContent, fetchFiles]);

  // ============ Click handlers ============

  const handleEntryClick = useCallback((entry: FileEntry) => {
    if (entry.type === 'folder') {
      navigateToFolder(entry.name);
    } else {
      setSelectedFile(selectedFile === entry.name ? null : entry.name);
      setShowDetailsPanel(true);
    }
  }, [navigateToFolder, selectedFile]);

  // ============ File count info ============

  const folderCount = filteredEntries.filter((e) => e.type === 'folder').length;
  const fileCount = filteredEntries.filter((e) => e.type === 'file').length;
  const totalSize = filteredEntries.reduce((sum, e) => sum + e.size, 0);

  // ============ Render: Breadcrumb ============

  const renderBreadcrumb = () => (
    <nav className="flex items-center gap-0.5 min-w-0 overflow-x-auto" aria-label="File path navigation">
      <button
        onClick={() => navigateToPathIndex(0)}
        className="flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-white/[0.06] transition-colors shrink-0"
      >
        <Home className="w-3.5 h-3.5" />
        <span>home</span>
      </button>
      {currentPath.map((segment, idx) => (
        <div key={idx} className="flex items-center shrink-0">
          <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/50 mx-0.5" />
          <button
            onClick={() => navigateToPathIndex(idx + 1)}
            className={`px-2 py-1 rounded-md text-xs font-medium transition-colors ${
              idx === currentPath.length - 1
                ? 'text-foreground bg-white/[0.06]'
                : 'text-muted-foreground hover:text-foreground hover:bg-white/[0.06]'
            }`}
          >
            {segment}
          </button>
        </div>
      ))}
    </nav>
  );

  // ============ Render: List View ============

  const renderListView = () => (
    <div className="space-y-0.5">
      {/* List Header */}
      <div className="flex items-center gap-4 px-3 py-2 text-[11px] font-medium text-muted-foreground/60 uppercase tracking-wider border-b border-white/[0.04] mb-1">
        <div className="w-8" />
        <div className="flex-1 min-w-0">Name</div>
        <div className="w-24 text-right hidden sm:block">Size</div>
        <div className="w-36 text-right hidden md:block">Modified</div>
        <div className="w-8" />
      </div>

      <motion.div variants={containerVariants} initial="hidden" animate="visible">
        <AnimatePresence mode="popLayout">
          {filteredEntries.map((entry) => (
            <motion.div
              key={entry.name}
              variants={itemVariants}
              layout
              exit={{ opacity: 0, height: 0 }}
              className={`file-item group flex items-center gap-4 px-3 py-2.5 cursor-pointer rounded-lg ${
                selectedFile === entry.name
                  ? 'bg-brand-500/10 border border-brand-500/20'
                  : 'border border-transparent hover:bg-white/[0.04]'
              }`}
              onClick={() => handleEntryClick(entry)}
              onContextMenu={(e) => {
                e.preventDefault();
                setSelectedFile(entry.name);
                setShowDetailsPanel(true);
              }}
            >
              {/* Icon */}
              <FileIcon entry={entry} size="sm" />

              {/* Name */}
              <div className="flex-1 min-w-0">
                <span className={`text-sm truncate block ${
                  entry.type === 'folder'
                    ? 'text-foreground font-medium'
                    : 'text-foreground/90'
                }`}>
                  {entry.name}
                </span>
              </div>

              {/* Size */}
              <div className="w-24 text-right hidden sm:block">
                <span className="text-xs text-muted-foreground font-mono">
                  {entry.type === 'folder' ? '—' : formatBytes(entry.size)}
                </span>
              </div>

              {/* Modified */}
              <div className="w-36 text-right hidden md:block">
                <span className="text-xs text-muted-foreground">
                  {entry.modified}
                </span>
              </div>

              {/* Actions */}
              <div className="w-8 flex items-center justify-center">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground hover:bg-white/[0.08] transition-opacity"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <MoreVertical className="w-3.5 h-3.5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent
                    align="end"
                    className="w-48 bg-zinc-900/95 border-zinc-800 backdrop-blur-xl"
                  >
                    {entry.type === 'file' && (
                      <>
                        <DropdownMenuItem
                          onClick={(e) => { e.stopPropagation(); handleOpenFile(entry.name); }}
                          className="cursor-pointer"
                        >
                          <File className="w-4 h-4 mr-2 text-brand-400" />
                          Open
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={(e) => { e.stopPropagation(); handleOpenFile(entry.name); }}
                          className="cursor-pointer"
                        >
                          <Edit3 className="w-4 h-4 mr-2 text-amber-400" />
                          Edit
                        </DropdownMenuItem>
                      </>
                    )}
                    <DropdownMenuItem
                      onClick={(e) => { e.stopPropagation(); setSelectedFile(entry.name); openRenameDialog(); }}
                      className="cursor-pointer"
                    >
                      <Edit3 className="w-4 h-4 mr-2 text-sky-400" />
                      Rename
                    </DropdownMenuItem>
                    {entry.type === 'file' && (
                      <DropdownMenuItem
                        onClick={(e) => { e.stopPropagation(); setSelectedFile(entry.name); handleDownload(); }}
                        className="cursor-pointer"
                      >
                        <Download className="w-4 h-4 mr-2 text-emerald-400" />
                        Download
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem
                      onClick={(e) => { e.stopPropagation(); setSelectedFile(entry.name); handleCompress(); }}
                      className="cursor-pointer"
                    >
                      <Archive className="w-4 h-4 mr-2 text-purple-400" />
                      Compress
                    </DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-zinc-800" />
                    <DropdownMenuItem
                      onClick={(e) => { e.stopPropagation(); setSelectedFile(entry.name); setShowDeleteDialog(true); }}
                      className="text-red-400 focus:text-red-300 focus:bg-red-500/10 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>
    </div>
  );

  // ============ Render: Grid View ============

  const renderGridView = () => (
    <motion.div
      className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <AnimatePresence mode="popLayout">
        {filteredEntries.map((entry) => (
          <motion.div
            key={entry.name}
            variants={gridItemVariants}
            layout
            exit={{ opacity: 0, scale: 0.9 }}
            onClick={() => handleEntryClick(entry)}
            onContextMenu={(e) => {
              e.preventDefault();
              setSelectedFile(entry.name);
              setShowDetailsPanel(true);
            }}
            className={`group relative flex flex-col items-center gap-2.5 p-4 rounded-xl cursor-pointer border transition-all ${
              selectedFile === entry.name
                ? 'bg-brand-500/10 border-brand-500/25'
                : 'bg-white/[0.02] border-white/[0.06] hover:bg-white/[0.05] hover:border-white/[0.12]'
            }`}
          >
            <FileIcon entry={entry} size="lg" />
            <div className="text-center w-full min-w-0">
              <p className={`text-xs font-medium truncate ${
                entry.type === 'folder' ? 'text-foreground' : 'text-foreground/80'
              }`}>
                {entry.name}
              </p>
              <p className="text-[10px] text-muted-foreground/60 mt-0.5">
                {entry.type === 'folder' ? 'Folder' : formatBytes(entry.size)}
              </p>
            </div>

            {/* Grid context menu trigger */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 h-6 w-6 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground hover:bg-white/[0.08] transition-opacity"
                  onClick={(e) => e.stopPropagation()}
                >
                  <MoreVertical className="w-3 h-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="end"
                className="w-48 bg-zinc-900/95 border-zinc-800 backdrop-blur-xl"
              >
                {entry.type === 'file' && (
                  <>
                    <DropdownMenuItem
                      onClick={(e) => { e.stopPropagation(); handleOpenFile(entry.name); }}
                      className="cursor-pointer"
                    >
                      <File className="w-4 h-4 mr-2 text-brand-400" />
                      Open
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={(e) => { e.stopPropagation(); handleOpenFile(entry.name); }}
                      className="cursor-pointer"
                    >
                      <Edit3 className="w-4 h-4 mr-2 text-amber-400" />
                      Edit
                    </DropdownMenuItem>
                  </>
                )}
                <DropdownMenuItem
                  onClick={(e) => { e.stopPropagation(); setSelectedFile(entry.name); openRenameDialog(); }}
                  className="cursor-pointer"
                >
                  <Edit3 className="w-4 h-4 mr-2 text-sky-400" />
                  Rename
                </DropdownMenuItem>
                {entry.type === 'file' && (
                  <DropdownMenuItem
                    onClick={(e) => { e.stopPropagation(); setSelectedFile(entry.name); handleDownload(); }}
                    className="cursor-pointer"
                  >
                    <Download className="w-4 h-4 mr-2 text-emerald-400" />
                    Download
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem
                  onClick={(e) => { e.stopPropagation(); setSelectedFile(entry.name); handleCompress(); }}
                  className="cursor-pointer"
                >
                  <Archive className="w-4 h-4 mr-2 text-purple-400" />
                  Compress
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-zinc-800" />
                <DropdownMenuItem
                  onClick={(e) => { e.stopPropagation(); setSelectedFile(entry.name); setShowDeleteDialog(true); }}
                  className="text-red-400 focus:text-red-300 focus:bg-red-500/10 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </motion.div>
        ))}
      </AnimatePresence>
    </motion.div>
  );

  // ============ Render: Details Panel ============

  const renderDetailsPanel = () => {
    if (!showDetailsPanel || !selectedEntry) return null;

    const isFolder = selectedEntry.type === 'folder';
    const fullPath = '/' + [...currentPath, selectedEntry.name].join('/');

    return (
      <motion.aside
        initial={{ opacity: 0, x: 16, width: 0 }}
        animate={{ opacity: 1, x: 0, width: 280 }}
        exit={{ opacity: 0, x: 16, width: 0 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="flex-shrink-0 border-l border-glass-border bg-white/[0.02] overflow-hidden"
      >
        <div className="p-4 h-full flex flex-col">
          {/* Panel Header */}
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-foreground">Details</h3>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 text-muted-foreground hover:text-foreground hover:bg-white/[0.08]"
              onClick={() => setShowDetailsPanel(false)}
            >
              <X className="w-3.5 h-3.5" />
            </Button>
          </div>

          {/* File Icon */}
          <div className="flex justify-center mb-4">
            <FileIcon entry={selectedEntry} size="lg" isOpen={isFolder} />
          </div>

          {/* File Name */}
          <div className="text-center mb-6">
            <h4 className="text-sm font-semibold text-foreground break-all">{selectedEntry.name}</h4>
            <p className="text-xs text-muted-foreground mt-1">
              {isFolder ? 'Folder' : getFileTypeLabel(selectedEntry.name)}
            </p>
          </div>

          {/* Details Grid */}
          <div className="space-y-3 flex-1">
            <div className="flex items-center justify-between py-2 border-b border-white/[0.04]">
              <span className="text-xs text-muted-foreground">Type</span>
              <span className="text-xs text-foreground font-medium">
                {isFolder ? 'Folder' : getFileTypeLabel(selectedEntry.name)}
              </span>
            </div>
            {!isFolder && (
              <div className="flex items-center justify-between py-2 border-b border-white/[0.04]">
                <span className="text-xs text-muted-foreground">Size</span>
                <span className="text-xs text-foreground font-mono">{formatBytes(selectedEntry.size)}</span>
              </div>
            )}
            <div className="flex items-center justify-between py-2 border-b border-white/[0.04]">
              <span className="text-xs text-muted-foreground">Path</span>
              <span className="text-[10px] text-foreground/70 font-mono max-w-[140px] truncate text-right" title={fullPath}>
                {fullPath}
              </span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-white/[0.04]">
              <span className="text-xs text-muted-foreground">Modified</span>
              <span className="text-xs text-foreground">{selectedEntry.modified}</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="mt-4 space-y-2">
            {!isFolder && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full h-8 text-xs gap-2 border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.06]"
                  onClick={() => handleOpenFile(selectedEntry.name)}
                >
                  <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                  Edit File
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full h-8 text-xs gap-2 border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.06]"
                  onClick={handleDownload}
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  Download
                </Button>
              </>
            )}
            <Button
              variant="outline"
              size="sm"
              className="w-full h-8 text-xs gap-2 border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.06]"
              onClick={openRenameDialog}
            >
              <Edit3 className="w-3.5 h-3.5 text-sky-400" />
              Rename
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="w-full h-8 text-xs gap-2 border-red-500/20 bg-red-500/5 hover:bg-red-500/10 hover:text-red-400 text-red-400/80"
              onClick={() => setShowDeleteDialog(true)}
            >
              <Trash2 className="w-3.5 h-3.5" />
              Delete
            </Button>
            {!isFolder && (
              <Button
                variant="outline"
                size="sm"
                className="w-full h-8 text-xs gap-2 border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.06]"
                onClick={handleCompress}
              >
                <Archive className="w-3.5 h-3.5 text-purple-400" />
                Compress
              </Button>
            )}
          </div>
        </div>
      </motion.aside>
    );
  };

  // ============ Render: Editor Overlay ============

  const renderEditor = () => {
    if (!editingFile) return null;
    return (
      <Dialog open={!!editingFile} onOpenChange={(open) => { if (!open) { setEditingFile(null); setEditContent(''); } }}>
        <DialogContent className="sm:max-w-3xl bg-zinc-900/95 border-zinc-800 backdrop-blur-xl max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <div className="w-8 h-8 rounded-lg bg-amber-500/15 flex items-center justify-center">
                <Edit3 className="w-4 h-4 text-amber-400" />
              </div>
              Editing: {editingFile}
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 min-h-0 py-2">
            <textarea
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              className="w-full h-[400px] bg-black/40 border border-white/[0.08] rounded-lg p-4 text-sm font-mono text-foreground resize-none focus:outline-none focus:border-brand-500/40"
              spellCheck={false}
              autoFocus
            />
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              size="sm"
              className="border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.06]"
              onClick={() => { setEditingFile(null); setEditContent(''); }}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              className="bg-brand-600 hover:bg-brand-500 text-white gap-1.5"
              onClick={handleSaveFile}
              disabled={editSaving}
            >
              {editSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  };

  // ============ Render ============

  return (
    <motion.div
      className="space-y-4"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
    >
      {/* ============ Toolbar ============ */}
      <div className="glass-card !p-0 overflow-hidden">
        {/* Breadcrumb Row */}
        <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-glass-border">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            {currentPath.length > 0 && (
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 shrink-0 text-muted-foreground hover:text-foreground hover:bg-white/[0.08]"
                onClick={navigateUp}
              >
                <ArrowUp className="w-3.5 h-3.5" />
              </Button>
            )}
            <div className="min-w-0 flex-1">
              {renderBreadcrumb()}
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {/* Upload */}
            <Button
              variant="ghost"
              size="sm"
              className="h-8 px-2.5 text-xs gap-1.5 text-muted-foreground hover:text-foreground hover:bg-white/[0.08]"
              onClick={() => setShowUploadDialog(true)}
            >
              <Upload className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Upload</span>
            </Button>

            {/* New File */}
            <Button
              variant="ghost"
              size="sm"
              className="h-8 px-2.5 text-xs gap-1.5 text-muted-foreground hover:text-foreground hover:bg-white/[0.08]"
              onClick={() => setShowNewFileDialog(true)}
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">File</span>
            </Button>

            {/* New Folder */}
            <Button
              variant="ghost"
              size="sm"
              className="h-8 px-2.5 text-xs gap-1.5 text-muted-foreground hover:text-foreground hover:bg-white/[0.08]"
              onClick={() => setShowNewFolderDialog(true)}
            >
              <Folder className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Folder</span>
            </Button>

            {/* Separator */}
            <div className="w-px h-5 bg-white/[0.08] mx-1 hidden sm:block" />

            {/* Search */}
            <div className="relative hidden sm:block">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground/50" />
              <Input
                placeholder="Search files..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-8 w-48 lg:w-56 pl-8 pr-3 text-xs bg-white/[0.04] border-white/[0.08] focus:border-brand-500/40 focus:ring-1 focus:ring-brand-500/20 placeholder:text-muted-foreground/40"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground/50 hover:text-foreground"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            {/* View Toggle */}
            <div className="flex items-center bg-white/[0.04] rounded-lg p-0.5 border border-white/[0.06]">
              <Button
                variant="ghost"
                size="icon"
                className={`h-6 w-6 rounded-md transition-colors ${
                  viewMode === 'list'
                    ? 'bg-white/[0.1] text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                onClick={() => setViewMode('list')}
              >
                <List className="w-3.5 h-3.5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className={`h-6 w-6 rounded-md transition-colors ${
                  viewMode === 'grid'
                    ? 'bg-white/[0.1] text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                onClick={() => setViewMode('grid')}
              >
                <Grid3X3 className="w-3.5 h-3.5" />
              </Button>
            </div>

            {/* Refresh */}
            <Button
              variant="ghost"
              size="icon"
              className={`h-8 w-8 text-muted-foreground hover:text-foreground hover:bg-white/[0.08] ${isRefreshing ? 'animate-spin' : ''}`}
              onClick={handleRefresh}
              disabled={isRefreshing}
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </Button>

            {/* Toggle Details */}
            <Button
              variant="ghost"
              size="icon"
              className={`h-8 w-8 transition-colors ${
                showDetailsPanel
                  ? 'text-brand-400 bg-brand-500/10 hover:bg-brand-500/15'
                  : 'text-muted-foreground hover:text-foreground hover:bg-white/[0.08]'
              }`}
              onClick={() => setShowDetailsPanel(!showDetailsPanel)}
            >
              <ChevronRight className={`w-3.5 h-3.5 transition-transform ${showDetailsPanel ? 'rotate-180' : ''}`} />
            </Button>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="sm:hidden px-3 py-2 border-b border-glass-border">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground/50" />
            <Input
              placeholder="Search files..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-8 w-full pl-8 pr-8 text-xs bg-white/[0.04] border-white/[0.08] focus:border-brand-500/40 focus:ring-1 focus:ring-brand-500/20 placeholder:text-muted-foreground/40"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground/50 hover:text-foreground"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* Status Bar */}
        <div className="flex items-center gap-3 px-4 py-1.5 border-b border-glass-border bg-white/[0.01]">
          <span className="text-[11px] text-muted-foreground/60">
            {folderCount > 0 && `${folderCount} folder${folderCount > 1 ? 's' : ''}`}
            {folderCount > 0 && fileCount > 0 && ', '}
            {fileCount > 0 && `${fileCount} file${fileCount > 1 ? 's' : ''}`}
            {filteredEntries.length === 0 && 'No items'}
          </span>
          {totalSize > 0 && (
            <>
              <span className="text-muted-foreground/30">·</span>
              <span className="text-[11px] text-muted-foreground/60 font-mono">
                {formatBytes(totalSize)}
              </span>
            </>
          )}
          {searchQuery && (
            <>
              <span className="text-muted-foreground/30">·</span>
              <span className="text-[11px] text-brand-400">
                Filtered: &quot;{searchQuery}&quot;
              </span>
            </>
          )}
        </div>
      </div>

      {/* ============ File List Area + Details Panel ============ */}
      <div className="flex gap-4 min-h-[480px]">
        {/* Main File List */}
        <div className={`glass-card !p-4 flex-1 min-w-0 overflow-hidden ${showDetailsPanel ? '' : ''}`}>
          <ScrollArea className="h-[480px]">
            {loading ? (
              <div className="flex items-center justify-center h-32">
                <Loader2 className="w-6 h-6 text-brand-400 animate-spin" />
              </div>
            ) : filteredEntries.length === 0 ? (
              <EmptyState />
            ) : viewMode === 'list' ? (
              renderListView()
            ) : (
              renderGridView()
            )}
          </ScrollArea>
        </div>

        {/* Details Panel */}
        <AnimatePresence>
          {renderDetailsPanel()}
        </AnimatePresence>
      </div>

      {/* ============ Editor Overlay ============ */}
      {renderEditor()}

      {/* ============ Modals ============ */}

      {/* New File Dialog */}
      <Dialog open={showNewFileDialog} onOpenChange={setShowNewFileDialog}>
        <DialogContent className="sm:max-w-md bg-zinc-900/95 border-zinc-800 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <div className="w-8 h-8 rounded-lg bg-brand-500/15 flex items-center justify-center">
                <Plus className="w-4 h-4 text-brand-400" />
              </div>
              Create New File
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <label className="text-xs text-muted-foreground mb-2 block">
              File name
            </label>
            <Input
              placeholder="e.g. custom-config.yml"
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleCreateFile(); }}
              className="bg-white/[0.04] border-white/[0.08] focus:border-brand-500/40"
              autoFocus
            />
            <p className="text-[11px] text-muted-foreground/50 mt-2">
              File will be created in: /{currentPath.length > 0 ? currentPath.join('/') + '/' : ''}
            </p>
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              size="sm"
              className="border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.06]"
              onClick={() => { setShowNewFileDialog(false); setNewFileName(''); }}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              className="bg-brand-600 hover:bg-brand-500 text-white"
              onClick={handleCreateFile}
              disabled={!newFileName.trim() || creating}
            >
              {creating && <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />}
              Create File
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Folder Dialog */}
      <Dialog open={showNewFolderDialog} onOpenChange={setShowNewFolderDialog}>
        <DialogContent className="sm:max-w-md bg-zinc-900/95 border-zinc-800 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <div className="w-8 h-8 rounded-lg bg-amber-500/15 flex items-center justify-center">
                <Folder className="w-4 h-4 text-amber-400" />
              </div>
              Create New Folder
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <label className="text-xs text-muted-foreground mb-2 block">
              Folder name
            </label>
            <Input
              placeholder="e.g. custom-plugins"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleCreateFolder(); }}
              className="bg-white/[0.04] border-white/[0.08] focus:border-brand-500/40"
              autoFocus
            />
            <p className="text-[11px] text-muted-foreground/50 mt-2">
              Folder will be created in: /{currentPath.length > 0 ? currentPath.join('/') + '/' : ''}
            </p>
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              size="sm"
              className="border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.06]"
              onClick={() => { setShowNewFolderDialog(false); setNewFolderName(''); }}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              className="bg-brand-600 hover:bg-brand-500 text-white"
              onClick={handleCreateFolder}
              disabled={!newFolderName.trim() || creating}
            >
              {creating && <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />}
              Create Folder
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rename Dialog */}
      <Dialog open={showRenameDialog} onOpenChange={setShowRenameDialog}>
        <DialogContent className="sm:max-w-md bg-zinc-900/95 border-zinc-800 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <div className="w-8 h-8 rounded-lg bg-sky-500/15 flex items-center justify-center">
                <Edit3 className="w-4 h-4 text-sky-400" />
              </div>
              Rename Item
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <label className="text-xs text-muted-foreground mb-2 block">
              New name
            </label>
            <Input
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleRename(); }}
              className="bg-white/[0.04] border-white/[0.08] focus:border-brand-500/40"
              autoFocus
            />
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              size="sm"
              className="border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.06]"
              onClick={() => { setShowRenameDialog(false); setRenameValue(''); }}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              className="bg-brand-600 hover:bg-brand-500 text-white"
              onClick={handleRename}
              disabled={!renameValue.trim() || renameValue === selectedFile}
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="sm:max-w-md bg-zinc-900/95 border-zinc-800 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <div className="w-8 h-8 rounded-lg bg-red-500/15 flex items-center justify-center">
                <Trash2 className="w-4 h-4 text-red-400" />
              </div>
              Delete Confirmation
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm text-foreground/90">
              Are you sure you want to delete{' '}
              <span className="font-semibold text-foreground">{selectedFile}</span>?
            </p>
            <p className="text-xs text-red-400/80 mt-2">
              This action cannot be undone. The item will be permanently removed.
            </p>
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              size="sm"
              className="border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.06]"
              onClick={() => setShowDeleteDialog(false)}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              className="bg-red-600 hover:bg-red-500 text-white"
              onClick={handleDelete}
              disabled={deleting}
            >
              {deleting ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5 mr-1.5" />}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Upload Dialog */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent className="sm:max-w-lg bg-zinc-900/95 border-zinc-800 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/15 flex items-center justify-center">
                <Upload className="w-4 h-4 text-emerald-400" />
              </div>
              Upload Files
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            {/* Drop Zone */}
            <div className="relative border-2 border-dashed border-white/[0.12] rounded-xl p-10 text-center hover:border-brand-500/30 hover:bg-brand-500/5 transition-colors cursor-pointer group">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center mb-4 group-hover:border-brand-500/25 group-hover:bg-brand-500/10 transition-colors">
                <Upload className="w-6 h-6 text-muted-foreground group-hover:text-brand-400 transition-colors" />
              </div>
              <p className="text-sm font-medium text-foreground mb-1">
                Drag & drop files here
              </p>
              <p className="text-xs text-muted-foreground mb-4">
                or click to browse from your computer
              </p>
              <Button
                variant="outline"
                size="sm"
                className="border-brand-500/20 bg-brand-500/5 text-brand-400 hover:bg-brand-500/10 hover:text-brand-300"
                onClick={handleUpload}
              >
                <Upload className="w-3.5 h-3.5 mr-1.5" />
                Select Files
              </Button>
            </div>

            <div className="mt-3 flex items-center gap-2 text-[11px] text-muted-foreground/60">
              <span>Destination:</span>
              <span className="text-foreground/70 font-mono">/{currentPath.length > 0 ? currentPath.join('/') + '/' : ''}</span>
            </div>

            <div className="mt-3 flex items-center gap-2 text-[11px] text-muted-foreground/50">
              <span>Max file size: 100 MB</span>
              <span>·</span>
              <span>Supported: all file types</span>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              size="sm"
              className="border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.06]"
              onClick={() => setShowUploadDialog(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}