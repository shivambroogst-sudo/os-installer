'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus,
  Trash2,
  Star,
  Network,
  Globe,
  Wifi,
  Zap,
  Server,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { mockServers } from '@/lib/mock-data';
import { useNavStore } from '@/lib/store';
import { toast } from 'sonner';

// ============ Types ============

interface Allocation {
  id: string;
  ip: string;
  port: number;
  isDefault: boolean;
  notes: string;
}

// ============ Mock Data ============

const initialAllocations: Allocation[] = [
  { id: 'alloc_01', ip: '0.0.0.0', port: 25565, isDefault: true, notes: 'Main server port' },
  { id: 'alloc_02', ip: '0.0.0.0', port: 25566, isDefault: false, notes: 'Query port' },
  { id: 'alloc_03', ip: '0.0.0.0', port: 25567, isDefault: false, notes: 'RCON port' },
];

// ============ Component ============

export default function ServerNetwork() {
  const { selectedServerId } = useNavStore();
  const server = mockServers.find((s) => s.id === selectedServerId) ?? mockServers[0];

  const [allocations, setAllocations] = useState<Allocation[]>([...initialAllocations]);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [testingConnection, setTestingConnection] = useState(false);

  // Form
  const [formIp, setFormIp] = useState('0.0.0.0');
  const [formPort, setFormPort] = useState('');
  const [formNotes, setFormNotes] = useState('');

  const defaultAllocation = allocations.find((a) => a.isDefault);

  const handleAddAllocation = () => {
    const port = parseInt(formPort, 10);
    if (isNaN(port) || port < 1 || port > 65535) {
      toast.error('Invalid port number', { description: 'Port must be between 1 and 65535.' });
      return;
    }
    if (allocations.some((a) => a.port === port)) {
      toast.error('Port already allocated', { description: `Port ${port} is already in use.` });
      return;
    }

    const newAlloc: Allocation = {
      id: `alloc_${Date.now()}`,
      ip: formIp,
      port,
      isDefault: false,
      notes: formNotes,
    };
    setAllocations((prev) => [...prev, newAlloc]);
    setAddDialogOpen(false);
    setFormPort('');
    setFormNotes('');
    toast.success('Allocation added', {
      description: `${formIp}:${port} has been allocated.`,
    });
  };

  const handleMakeDefault = (id: string) => {
    setAllocations((prev) =>
      prev.map((a) => ({ ...a, isDefault: a.id === id }))
    );
    toast.success('Default allocation updated');
  };

  const handleDelete = (id: string) => {
    const alloc = allocations.find((a) => a.id === id);
    if (alloc?.isDefault) {
      toast.error('Cannot delete default allocation');
      return;
    }
    setAllocations((prev) => prev.filter((a) => a.id !== id));
    toast.success('Allocation removed');
  };

  const handleTestConnection = () => {
    setTestingConnection(true);
    setTimeout(() => {
      setTestingConnection(false);
      toast.success('Connection test successful', {
        description: `Server is reachable at ${server.ip}:${defaultAllocation?.port ?? server.port}`,
      });
    }, 2000);
  };

  return (
    <TooltipProvider>
      <motion.div
        className="space-y-6"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
      >
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white">Network / Allocations</h2>
            <p className="text-sm text-zinc-400 mt-1">
              Manage IP and port allocations for {server.name}
            </p>
          </div>
          <Button
            className="bg-brand-600 hover:bg-brand-500 text-white"
            onClick={() => setAddDialogOpen(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Allocation
          </Button>
        </div>

        {/* Connection Info Card */}
        <motion.div
          className="glass-card p-5"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
        >
          <div className="flex items-center gap-2 mb-5">
            <div className="p-1.5 rounded-md bg-emerald-500/20">
              <Globe className="w-4 h-4 text-emerald-400" />
            </div>
            <h3 className="text-sm font-semibold text-white">Connection Information</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="rounded-lg bg-white/[0.03] border border-zinc-800 p-4">
              <div className="flex items-center gap-2 mb-2">
                <Server className="w-3.5 h-3.5 text-zinc-500" />
                <span className="text-xs text-zinc-500 uppercase tracking-wider">Server Address</span>
              </div>
              <p className="text-sm font-mono text-white">
                {server.node.fqdn.split('.').slice(0, 1)[0]}.ogultra.io
              </p>
              <p className="text-xs text-zinc-400 font-mono mt-1">:{defaultAllocation?.port ?? server.port}</p>
            </div>

            <div className="rounded-lg bg-white/[0.03] border border-zinc-800 p-4">
              <div className="flex items-center gap-2 mb-2">
                <Wifi className="w-3.5 h-3.5 text-zinc-500" />
                <span className="text-xs text-zinc-500 uppercase tracking-wider">Query Port</span>
              </div>
              <p className="text-sm font-mono text-white">
                {allocations.find((a) => a.notes.toLowerCase().includes('query'))?.port ?? '25566'}
              </p>
              <p className="text-xs text-zinc-400 mt-1">Minecraft Query Protocol</p>
            </div>

            <div className="rounded-lg bg-white/[0.03] border border-zinc-800 p-4">
              <div className="flex items-center gap-2 mb-2">
                <Network className="w-3.5 h-3.5 text-zinc-500" />
                <span className="text-xs text-zinc-500 uppercase tracking-wider">SRV Records</span>
              </div>
              <p className="text-sm font-mono text-white">_minecraft._tcp</p>
              <p className="text-xs text-zinc-400 font-mono mt-1">{server.node.fqdn}</p>
            </div>

            <div className="rounded-lg bg-white/[0.03] border border-zinc-800 p-4 flex flex-col justify-between">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-3.5 h-3.5 text-zinc-500" />
                <span className="text-xs text-zinc-500 uppercase tracking-wider">Connection Test</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white mt-1 w-fit"
                onClick={handleTestConnection}
                disabled={testingConnection}
              >
                {testingConnection ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                    Testing...
                  </>
                ) : (
                  <>
                    <Zap className="w-3.5 h-3.5 mr-1.5" />
                    Test Connection
                  </>
                )}
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Allocations Table */}
        <motion.div
          className="glass-card overflow-hidden"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="px-5 py-4 border-b border-zinc-800/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-md bg-brand-500/20">
                  <Network className="w-4 h-4 text-brand-400" />
                </div>
                <h3 className="text-sm font-semibold text-white">Allocations</h3>
                <Badge variant="outline" className="border-zinc-700 text-zinc-400 text-xs">
                  {allocations.length}
                </Badge>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-zinc-800 hover:bg-transparent">
                  <TableHead className="text-zinc-400 font-medium">IP Address</TableHead>
                  <TableHead className="text-zinc-400 font-medium">Port</TableHead>
                  <TableHead className="text-zinc-400 font-medium">Default</TableHead>
                  <TableHead className="text-zinc-400 font-medium hidden sm:table-cell">Notes</TableHead>
                  <TableHead className="text-zinc-400 font-medium text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <AnimatePresence>
                  {allocations.map((alloc, index) => (
                    <motion.tr
                      key={alloc.id}
                      className="border-zinc-800 hover:bg-white/[0.02] transition-colors"
                      initial={{ opacity: 0, x: -12 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 12 }}
                      transition={{ delay: index * 0.04 }}
                    >
                      <TableCell className="font-mono text-sm text-white py-3.5">{alloc.ip}</TableCell>
                      <TableCell>
                        <span className="font-mono text-sm text-brand-400">{alloc.port}</span>
                      </TableCell>
                      <TableCell>
                        {alloc.isDefault ? (
                          <Badge className="bg-brand-500/20 text-brand-400 border-brand-500/30 text-xs">
                            <Star className="w-3 h-3 mr-1" />
                            Default
                          </Badge>
                        ) : (
                          <span className="text-xs text-zinc-600">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-zinc-400 text-sm hidden sm:table-cell">{alloc.notes}</TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          {!alloc.isDefault && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-zinc-400 hover:text-brand-400 hover:bg-brand-500/10"
                                  onClick={() => handleMakeDefault(alloc.id)}
                                >
                                  <Star className="w-3.5 h-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Make Default</TooltipContent>
                            </Tooltip>
                          )}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className={`h-8 w-8 ${alloc.isDefault ? 'text-zinc-700 cursor-not-allowed' : 'text-red-400/70 hover:text-red-400 hover:bg-red-500/10'}`}
                                onClick={() => handleDelete(alloc.id)}
                                disabled={alloc.isDefault}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              {alloc.isDefault ? 'Cannot delete default' : 'Delete'}
                            </TooltipContent>
                          </Tooltip>
                        </div>
                      </TableCell>
                    </motion.tr>
                  ))}
                </AnimatePresence>
              </TableBody>
            </Table>
          </div>
        </motion.div>

        {/* Add Allocation Dialog */}
        <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-md">
            <DialogHeader>
              <DialogTitle>Add Allocation</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label className="text-zinc-300 text-sm">IP Address</Label>
                <Input
                  value={formIp}
                  onChange={(e) => setFormIp(e.target.value)}
                  placeholder="0.0.0.0"
                  className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600 font-mono"
                />
                <p className="text-xs text-zinc-500">Use 0.0.0.0 to bind to all interfaces</p>
              </div>

              <div className="space-y-2">
                <Label className="text-zinc-300 text-sm">Port</Label>
                <Input
                  type="number"
                  value={formPort}
                  onChange={(e) => setFormPort(e.target.value)}
                  placeholder="25568"
                  className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600 font-mono"
                  min={1}
                  max={65535}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-zinc-300 text-sm">Notes</Label>
                <Input
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="e.g. Plugin API port"
                  className="bg-white/5 border-zinc-700 text-white placeholder:text-zinc-600"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                className="border-zinc-700 text-zinc-300 hover:bg-white/5 hover:text-white"
                onClick={() => setAddDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                className="bg-brand-600 hover:bg-brand-500 text-white"
                onClick={handleAddAllocation}
              >
                Add Allocation
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </motion.div>
    </TooltipProvider>
  );
}