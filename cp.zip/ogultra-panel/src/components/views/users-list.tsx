'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import {
  Plus,
  Pencil,
  Trash2,
  UserPlus,
  ShieldCheck,
  Mail,
  Clock,
  Server,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Switch } from '@/components/ui/switch';
import { mockUsers, getInitials } from '@/lib/mock-data';

// ─── Animation Variants ───
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05, delayChildren: 0.05 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.97 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { type: 'spring', stiffness: 260, damping: 24, mass: 0.8 },
  },
};

// ─── Role Config ───
const roleConfig: Record<string, { label: string; badgeClass: string; dotClass: string }> = {
  owner: {
    label: 'Owner',
    badgeClass: 'border-brand-500/30 text-brand-400 bg-brand-500/10',
    dotClass: 'bg-brand-400',
  },
  admin: {
    label: 'Admin',
    badgeClass: 'border-purple-500/30 text-purple-400 bg-purple-500/10',
    dotClass: 'bg-purple-400',
  },
  moderator: {
    label: 'Moderator',
    badgeClass: 'border-amber-500/30 text-amber-400 bg-amber-500/10',
    dotClass: 'bg-amber-400',
  },
  user: {
    label: 'User',
    badgeClass: 'border-white/10 text-muted-foreground bg-white/[0.05]',
    dotClass: 'bg-muted-foreground',
  },
};

const avatarColors = [
  'bg-brand-500/25 text-brand-300',
  'bg-purple-500/25 text-purple-300',
  'bg-accent-500/25 text-accent-300',
  'bg-amber-500/25 text-amber-300',
  'bg-pink-500/25 text-pink-300',
  'bg-cyan-500/25 text-cyan-300',
];

function getAvatarColor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return avatarColors[Math.abs(hash) % avatarColors.length];
}

// ─── Helpers ───
function getRelativeTime(timestamp: string): string {
  const now = Date.now();
  const then = new Date(timestamp).getTime();
  const diffMs = now - then;
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return 'Just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDay = Math.floor(diffHr / 24);
  if (diffDay < 30) return `${diffDay}d ago`;
  const diffMonth = Math.floor(diffDay / 30);
  return `${diffMonth}mo ago`;
}

// ─── Role Badge ───
function RoleBadge({ role }: { role: string }) {
  const config = roleConfig[role] ?? roleConfig.user;
  return (
    <Badge
      variant="outline"
      className={`text-[10px] px-2 py-0 h-5 font-medium uppercase tracking-wider ${config.badgeClass}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${config.dotClass} mr-1.5`} />
      {config.label}
    </Badge>
  );
}

// ─── Main Users List ───
export default function UsersList() {
  const [createOpen, setCreateOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<(typeof mockUsers)[0] | null>(null);

  // Create user form
  const [newUsername, setNewUsername] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newRole, setNewRole] = useState('user');

  // Edit user form
  const [editRole, setEditRole] = useState('');
  const [editEnabled, setEditEnabled] = useState(true);

  const handleCreate = () => {
    if (!newUsername.trim()) {
      toast.error('Username is required');
      return;
    }
    if (!newEmail.trim() || !newEmail.includes('@')) {
      toast.error('Valid email is required');
      return;
    }
    if (newPassword.length < 8) {
      toast.error('Password must be at least 8 characters');
      return;
    }
    toast.success(`User "${newUsername}" created successfully!`);
    setCreateOpen(false);
    setNewUsername('');
    setNewEmail('');
    setNewPassword('');
    setNewRole('user');
  };

  const openEdit = (user: (typeof mockUsers)[0]) => {
    setEditingUser(user);
    setEditRole(user.role);
    setEditEnabled(true);
    setEditOpen(true);
  };

  const handleEdit = () => {
    if (!editingUser) return;
    toast.success(`User "${editingUser.username}" updated successfully!`);
    setEditOpen(false);
    setEditingUser(null);
  };

  const handleImpersonate = (username: string) => {
    toast.info(`Impersonating ${username}...`);
  };

  const handleDelete = (username: string) => {
    toast.error(`User deletion is disabled in this demo`);
  };

  return (
    <motion.div
      className="space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* Page Header */}
      <motion.div variants={itemVariants} className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Users</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {mockUsers.length} registered users
          </p>
        </div>
        <Button
          onClick={() => setCreateOpen(true)}
          className="gap-2 gradient-brand text-white border-0 shadow-lg shadow-brand-600/20 hover:shadow-brand-600/30"
        >
          <UserPlus className="w-4 h-4" />
          Create User
        </Button>
      </motion.div>

      {/* Users Table */}
      <motion.div variants={itemVariants}>
        <Card className="glass-card !p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-white/[0.06] hover:bg-transparent">
                  <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider">
                    User
                  </TableHead>
                  <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider">
                    Email
                  </TableHead>
                  <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider">
                    Role
                  </TableHead>
                  <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider hidden sm:table-cell">
                    Last Login
                  </TableHead>
                  <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider hidden md:table-cell">
                    Servers
                  </TableHead>
                  <TableHead className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider text-right">
                    Actions
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockUsers.map((user, idx) => (
                  <motion.tr
                    key={user.id}
                    className="border-b border-white/[0.04] last:border-0 hover:bg-white/[0.02] transition-colors"
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.05 * idx, type: 'spring', stiffness: 300, damping: 25 }}
                  >
                    <TableCell className="py-3.5">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback
                            className={`text-xs font-bold ${getAvatarColor(user.username)}`}
                          >
                            {getInitials(user.username)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">
                            {user.username}
                          </p>
                          {user.isRootAdmin && (
                            <div className="flex items-center gap-1 mt-0.5">
                              <ShieldCheck className="w-3 h-3 text-brand-400" />
                              <span className="text-[10px] text-brand-400 font-medium">Root Admin</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="py-3.5">
                      <div className="flex items-center gap-1.5">
                        <Mail className="w-3 h-3 text-muted-foreground/50" />
                        <span className="text-sm text-muted-foreground">{user.email}</span>
                      </div>
                    </TableCell>
                    <TableCell className="py-3.5">
                      <RoleBadge role={user.role} />
                    </TableCell>
                    <TableCell className="py-3.5 hidden sm:table-cell">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3 h-3 text-muted-foreground/50" />
                        <span className="text-sm text-muted-foreground">
                          {getRelativeTime(user.lastLoginAt)}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="py-3.5 hidden md:table-cell">
                      <div className="flex items-center gap-1.5">
                        <Server className="w-3 h-3 text-muted-foreground/50" />
                        <span className="text-sm text-muted-foreground">{user.servers}</span>
                      </div>
                    </TableCell>
                    <TableCell className="py-3.5 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-[11px] gap-1 text-brand-400/80 hover:text-brand-300 hover:bg-brand-500/10"
                          onClick={() => openEdit(user)}
                        >
                          <Pencil className="w-3 h-3" />
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-[11px] gap-1 text-purple-400/80 hover:text-purple-300 hover:bg-purple-500/10"
                          onClick={() => handleImpersonate(user.username)}
                        >
                          <ShieldCheck className="w-3 h-3" />
                          Impersonate
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-[11px] gap-1 text-red-400/50 hover:text-red-300 hover:bg-red-500/10"
                          onClick={() => handleDelete(user.username)}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </TableCell>
                  </motion.tr>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      </motion.div>

      {/* Create User Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="glass-card !rounded-2xl max-w-md border-white/[0.08] bg-[#0c0c1a]/95 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold text-foreground">
              Create New User
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Username</Label>
              <Input
                placeholder="newuser"
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                className="glass-input h-10 text-sm bg-transparent"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Email</Label>
              <Input
                type="email"
                placeholder="user@example.com"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                className="glass-input h-10 text-sm bg-transparent"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Password</Label>
              <Input
                type="password"
                placeholder="Min. 8 characters"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="glass-input h-10 text-sm bg-transparent"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Role</Label>
              <Select value={newRole} onValueChange={setNewRole}>
                <SelectTrigger className="glass-input h-10 text-sm bg-transparent">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">User</SelectItem>
                  <SelectItem value="moderator">Moderator</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="gap-2 pt-2">
            <Button
              variant="ghost"
              onClick={() => setCreateOpen(false)}
              className="text-muted-foreground hover:text-foreground"
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreate}
              className="gradient-brand text-white border-0 shadow-lg shadow-brand-600/20"
            >
              Create User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="glass-card !rounded-2xl max-w-md border-white/[0.08] bg-[#0c0c1a]/95 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold text-foreground">
              Edit User — {editingUser?.username}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Role</Label>
              <Select value={editRole} onValueChange={setEditRole}>
                <SelectTrigger className="glass-input h-10 text-sm bg-transparent">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">User</SelectItem>
                  <SelectItem value="moderator">Moderator</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                  {editingUser?.role === 'owner' && (
                    <SelectItem value="owner">Owner</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <Button
              variant="outline"
              className="w-full h-10 border-white/10 text-sm text-muted-foreground hover:text-foreground hover:border-white/20"
              onClick={() => toast.success('Password reset email sent!')}
            >
              <Mail className="w-4 h-4 mr-2" />
              Send Password Reset Email
            </Button>

            <div className="flex items-center justify-between py-2">
              <div>
                <Label className="text-sm text-foreground">Account Enabled</Label>
                <p className="text-[11px] text-muted-foreground mt-0.5">
                  Disable to prevent user from logging in
                </p>
              </div>
              <Switch
                checked={editEnabled}
                onCheckedChange={setEditEnabled}
              />
            </div>
          </div>

          <DialogFooter className="gap-2 pt-2">
            <Button
              variant="ghost"
              onClick={() => setEditOpen(false)}
              className="text-muted-foreground hover:text-foreground"
            >
              Cancel
            </Button>
            <Button
              onClick={handleEdit}
              className="gradient-brand text-white border-0 shadow-lg shadow-brand-600/20"
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}