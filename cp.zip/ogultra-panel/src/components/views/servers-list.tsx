'use client';
import { useState, useMemo, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { useNavStore } from '@/lib/store';
import { listServers, createServer, deleteServer, serverAction, type ServerStatus } from '@/lib/api';
import {
  Plus,
  Search,
  Server,
  Cpu,
  MemoryStick,
  Power,
  PowerOff,
  RotateCcw,
  Terminal,
  Trash2,
  Filter,
  X,
  Loader2,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import {
  getStatusDotClass,
  getStatusLabel,
  formatMemory,
  getResourceBarClass,
} from '@/lib/mock-data';

// ─── Animation Variants ───
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05, delayChildren: 0.05 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.97 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { type: 'spring', stiffness: 260, damping: 24, mass: 0.8 },
  },
};

const cardHover = {
  rest: { y: 0, boxShadow: '0 0 0 0 rgba(92,124,250,0)' },
  hover: {
    y: -3,
    boxShadow: '0 8px 32px rgba(92,124,250,0.15), 0 0 0 1px rgba(92,124,250,0.2)',
    transition: { type: 'spring', stiffness: 400, damping: 25 },
  },
};

// ─── Server Card Component ───
function ServerCard({ server }: { server: ServerStatus }) {
  const selectServer = useNavStore((s) => s.selectServer);
  const cpuPercent = server.cpuLimit > 0 ? (server.cpuUsage / server.cpuLimit) * 100 : 0;
  const memPercent = server.memoryLimit > 0 ? (server.memoryUsage / server.memoryLimit) * 100 : 0;
  const isRunning = server.status === 'running';
  const isCrashed = server.status === 'crashed';

  return (
    <motion.div variants={itemVariants} whileHover="hover" initial="rest" animate="rest">
      <motion.div
        variants={cardHover}
        className="glass-card cursor-pointer h-full !p-0 overflow-hidden group"
        onClick={() => selectServer(server.id)}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') selectServer(server.id);
        }}
      >
        {/* Header */}
        <div className="px-5 pt-5 pb-3">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  isRunning
                    ? 'bg-brand-500/15'
                    : isCrashed
                    ? 'bg-red-500/15'
                    : 'bg-white/5'
                }`}
              >
                <Server
                  className={`w-4 h-4 ${
                    isRunning
                      ? 'text-brand-400'
                      : isCrashed
                      ? 'text-red-400'
                      : 'text-muted-foreground/50'
                  }`}
                />
              </div>
              <div className="min-w-0">
                <h3 className="text-sm font-semibold text-foreground truncate">{server.name}</h3>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className={`status-dot ${getStatusDotClass(server.status)}`} />
                  <span className="text-[11px] text-muted-foreground">{getStatusLabel(server.status)}</span>
                </div>
              </div>
            </div>
            <Badge
              variant="outline"
              className="text-[10px] px-2 py-0 h-5 border-white/10 text-muted-foreground bg-white/[0.03] flex-shrink-0"
            >
              :{server.port}
            </Badge>
          </div>

          {/* PID & Memory info */}
          <div className="flex items-center gap-4 mb-4">
            {server.pid && (
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-muted-foreground">PID:</span>
                <span className="text-[11px] text-foreground font-mono">{server.pid}</span>
              </div>
            )}
            {server.startedAt && (
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-muted-foreground">Uptime:</span>
                <span className="text-[11px] text-foreground font-mono">
                  {Math.floor((Date.now() - server.startedAt) / 60000)}m
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Resource Bars */}
        <div className="px-5 space-y-2.5 pb-4">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <Cpu className="w-3 h-3 text-muted-foreground/50" />
                <span className="text-[11px] text-muted-foreground">CPU</span>
              </div>
              <span className="text-[11px] text-muted-foreground font-mono">
                {server.cpuUsage.toFixed(1)}% / {server.cpuLimit}%
              </span>
            </div>
            <div className="resource-bar">
              <div
                className={`resource-bar-fill ${getResourceBarClass(cpuPercent)}`}
                style={{ width: `${cpuPercent}%` }}
              />
            </div>
          </div>
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <MemoryStick className="w-3 h-3 text-muted-foreground/50" />
                <span className="text-[11px] text-muted-foreground">Memory</span>
              </div>
              <span className="text-[11px] text-muted-foreground font-mono">
                {formatMemory(server.memoryUsage)} / {formatMemory(server.memoryLimit)}
              </span>
            </div>
            <div className="resource-bar">
              <div
                className={`resource-bar-fill ${getResourceBarClass(memPercent)}`}
                style={{ width: `${memPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="px-5 pb-4 pt-1 border-t border-white/[0.04]">
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              className={`h-7 px-2 text-[11px] gap-1 ${
                isRunning
                  ? 'text-red-400/80 hover:text-red-300 hover:bg-red-500/10'
                  : 'text-emerald-400/80 hover:text-emerald-300 hover:bg-emerald-500/10'
              }`}
              onClick={async (e) => {
                e.stopPropagation();
                const action = isRunning ? 'stop' : 'start';
                const res = await serverAction(server.id, action);
                if (res.success) toast.success(`${action === 'stop' ? 'Stopping' : 'Starting'} ${server.name}...`);
                else toast.error(res.error || `Failed to ${action}`);
              }}
            >
              {isRunning ? <PowerOff className="w-3 h-3" /> : <Power className="w-3 h-3" />}
              {isRunning ? 'Stop' : 'Start'}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-[11px] gap-1 text-amber-400/80 hover:text-amber-300 hover:bg-amber-500/10"
              onClick={async (e) => {
                e.stopPropagation();
                const res = await serverAction(server.id, 'restart');
                if (res.success) toast.success(`Restarting ${server.name}...`);
                else toast.error(res.error || 'Failed to restart');
              }}
            >
              <RotateCcw className="w-3 h-3" />
              Restart
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-[11px] gap-1 text-brand-400/80 hover:text-brand-300 hover:bg-brand-500/10"
              onClick={(e) => {
                e.stopPropagation();
                selectServer(server.id);
                useNavStore.getState().setServerTab('console');
              }}
            >
              <Terminal className="w-3 h-3" />
              Console
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-[11px] gap-1 text-red-400/50 hover:text-red-300 hover:bg-red-500/10 ml-auto"
              onClick={async (e) => {
                e.stopPropagation();
                const res = await deleteServer(server.id);
                if (res.success) toast.success(`Server "${server.name}" deleted`);
                else toast.error('Failed to delete server');
              }}
            >
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── Empty State ───
function EmptyState() {
  return (
    <motion.div variants={itemVariants} className="flex flex-col items-center justify-center py-20">
      <div className="w-16 h-16 rounded-2xl bg-white/[0.03] flex items-center justify-center mb-4">
        <Server className="w-7 h-7 text-muted-foreground/30" />
      </div>
      <h3 className="text-base font-semibold text-foreground mb-1">No servers found</h3>
      <p className="text-sm text-muted-foreground text-center max-w-xs">
        No servers match your current filters. Try adjusting your search or filter criteria.
      </p>
    </motion.div>
  );
}

// ─── Main Servers List ───
export default function ServersList() {
  const [servers, setServers] = useState<ServerStatus[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [createOpen, setCreateOpen] = useState(false);
  const [creating, setCreating] = useState(false);

  // Create server form
  const [newName, setNewName] = useState('');
  const [newMemory, setNewMemory] = useState([2048]);
  const [newCpu, setCpu] = useState(100);
  const [newPort, setNewPort] = useState(25565);

  // ─── Fetch servers ───
  const fetchServers = useCallback(async () => {
    try {
      const res = await listServers();
      if (res.success && res.data) {
        setServers(res.data);
      }
    } catch {
      toast.error('Failed to fetch servers');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchServers();
    const interval = setInterval(fetchServers, 5000);
    return () => clearInterval(interval);
  }, [fetchServers]);

  const filteredServers = useMemo(() => {
    return servers.filter((s) => {
      const matchesSearch =
        !search ||
        s.name.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === 'all' || s.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [servers, search, statusFilter]);

  const handleCreate = async () => {
    if (!newName.trim()) {
      toast.error('Server name is required');
      return;
    }
    setCreating(true);
    try {
      const serverId = newName.trim().toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') + '-' + Date.now().toString(36);
      const res = await createServer({
        id: serverId,
        name: newName.trim(),
        startupCommand: 'java -Xmx${MEMORY}M -jar server.jar nogui',
        memoryLimit: newMemory[0],
        cpuLimit: newCpu,
        port: newPort,
      });
      if (res.success) {
        toast.success(`Server "${newName}" created successfully!`);
        setCreateOpen(false);
        setNewName('');
        setNewMemory([2048]);
        setCpu(100);
        setNewPort(25565);
        fetchServers();
      } else {
        toast.error(res.error || 'Failed to create server');
      }
    } catch {
      toast.error('Failed to create server');
    } finally {
      setCreating(false);
    }
  };

  return (
    <motion.div
      className="space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* Page Header */}
      <motion.div variants={itemVariants} className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Servers</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {filteredServers.length} of {servers.length} servers shown
          </p>
        </div>
        <Button
          onClick={() => setCreateOpen(true)}
          className="gap-2 gradient-brand text-white border-0 shadow-lg shadow-brand-600/20 hover:shadow-brand-600/30"
        >
          <Plus className="w-4 h-4" />
          Create Server
        </Button>
      </motion.div>

      {/* Filter Bar */}
      <motion.div
        variants={itemVariants}
        className="glass-card !p-0 overflow-hidden"
      >
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 p-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50" />
            <Input
              placeholder="Search servers..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="glass-input h-9 pl-9 text-sm bg-transparent"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground/50 hover:text-foreground transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px] h-9 glass-input bg-transparent text-sm">
                <Filter className="w-3.5 h-3.5 mr-1.5 text-muted-foreground/50" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="running">Running</SelectItem>
                <SelectItem value="stopped">Stopped</SelectItem>
                <SelectItem value="crashed">Crashed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </motion.div>

      {/* Loading State */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 text-brand-400 animate-spin" />
        </div>
      ) : filteredServers.length === 0 ? (
        <EmptyState />
      ) : (
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-4"
          variants={containerVariants}
        >
          {filteredServers.map((server) => (
            <ServerCard key={server.id} server={server} />
          ))}
        </motion.div>
      )}

      {/* Create Server Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="glass-card !rounded-2xl max-w-lg border-white/[0.08] bg-[#0c0c1a]/95 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold text-foreground">
              Create New Server
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Server Name</Label>
              <Input
                placeholder="My New Server"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="glass-input h-10 text-sm bg-transparent"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm text-muted-foreground">Memory Allocation</Label>
                <span className="text-sm font-mono text-brand-400">{formatMemory(newMemory[0])}</span>
              </div>
              <Slider
                value={newMemory}
                onValueChange={setNewMemory}
                min={512}
                max={16384}
                step={512}
                className="w-full"
              />
              <div className="flex justify-between text-[10px] text-muted-foreground/50">
                <span>512 MB</span>
                <span>16 GB</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">CPU Limit (%)</Label>
                <Input
                  type="number"
                  value={newCpu}
                  onChange={(e) => setCpu(Number(e.target.value))}
                  min={10}
                  max={400}
                  className="glass-input h-10 text-sm bg-transparent"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Port</Label>
                <Input
                  type="number"
                  value={newPort}
                  onChange={(e) => setNewPort(Number(e.target.value))}
                  min={1024}
                  max={65535}
                  className="glass-input h-10 text-sm bg-transparent"
                />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2 pt-2">
            <Button
              variant="ghost"
              onClick={() => setCreateOpen(false)}
              className="text-muted-foreground hover:text-foreground"
              disabled={creating}
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreate}
              className="gradient-brand text-white border-0 shadow-lg shadow-brand-600/20"
              disabled={creating}
            >
              {creating && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Create Server
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}