'use client';

import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  Server,
  Terminal,
  FolderOpen,
  Database,
  Settings2,
  Puzzle,
  HardDriveDownload,
  Clock,
  Network,
  Settings,
  HardDrive,
  Users,
  Activity,
  Shield,
  LogOut,
  ShieldCheck,
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Sheet,
  SheetContent,
  SheetTitle,
} from '@/components/ui/sheet';
import {
  useNavStore,
  useAuthStore,
  type View,
  type ServerTab,
} from '@/lib/store';
import { mockUser, getInitials } from '@/lib/mock-data';
import { useIsMobile } from '@/hooks/use-mobile';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

// ============ Navigation Config ============

interface NavItem {
  label: string;
  icon: React.ElementType;
  view?: View;
  tab?: ServerTab;
  action?: () => void;
}

interface NavSection {
  id: string;
  label: string;
  items: NavItem[];
  condition?: boolean;
}

function useNavSections(): NavSection[] {
  const { currentView, selectedServerId, selectedServerTab, setView, setServerTab } = useNavStore();
  const user = useAuthStore((s) => s.user);

  const isAdmin = user?.role === 'owner' || user?.role === 'admin';
  const showServerTabs = selectedServerId !== null;

  const mainItems: NavItem[] = [
    { label: 'Dashboard', icon: LayoutDashboard, view: 'dashboard' },
    { label: 'Servers', icon: Server, view: 'servers' },
  ];

  const serverItems: NavItem[] = [
    { label: 'Console', icon: Terminal, tab: 'console' },
    { label: 'Files', icon: FolderOpen, tab: 'files' },
    { label: 'Databases', icon: Database, tab: 'databases' },
    { label: 'Startup', icon: Settings2, tab: 'startup' },
    { label: 'Plugins', icon: Puzzle, tab: 'plugins' },
    { label: 'Backups', icon: HardDriveDownload, tab: 'backups' },
    { label: 'Schedules', icon: Clock, tab: 'schedules' },
    { label: 'Network', icon: Network, tab: 'network' },
    { label: 'Settings', icon: Settings, tab: 'settings' },
  ];

  const adminItems: NavItem[] = [
    { label: 'Nodes', icon: HardDrive, view: 'nodes' },
    { label: 'Users', icon: Users, view: 'users' },
    { label: 'Activity', icon: Activity, view: 'activity' },
    { label: 'Admin', icon: Shield, view: 'admin' },
  ];

  const sections: NavSection[] = [
    { id: 'main', label: 'Main', items: mainItems },
    {
      id: 'server',
      label: 'Server',
      items: serverItems,
      condition: showServerTabs,
    },
    {
      id: 'admin',
      label: 'Administration',
      items: adminItems,
      condition: isAdmin,
    },
  ];

  return sections;
}

function isItemActive(
  item: NavItem,
  currentView: View,
  selectedServerTab: ServerTab
): boolean {
  if (item.tab) {
    return currentView === 'server-detail' && selectedServerTab === item.tab;
  }
  return currentView === item.view;
}

// ============ Nav Item Component ============

interface NavItemButtonProps {
  item: NavItem;
  isActive: boolean;
  onClick: () => void;
}

function NavItemButton({ item: { label, icon: Icon }, isActive, onClick }: NavItemButtonProps) {
  return (
    <motion.button
      onClick={onClick}
      className={cn(
        'group relative flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors duration-200',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500/50 focus-visible:ring-offset-1 focus-visible:ring-offset-transparent',
        isActive
          ? 'bg-brand-600/10 text-brand-400'
          : 'text-muted-foreground hover:bg-white/[0.04] hover:text-foreground'
      )}
      whileHover={{ x: 2 }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: 'spring', stiffness: 500, damping: 30 }}
    >
      {isActive && (
        <motion.div
          layoutId="sidebar-active-indicator"
          className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r-full bg-brand-500"
          transition={{ type: 'spring', stiffness: 500, damping: 35 }}
        />
      )}
      <Icon className={cn('size-4 shrink-0', isActive && 'text-brand-400')} />
      <span className="truncate">{label}</span>
    </motion.button>
  );
}

// ============ Section Label ============

function SectionLabel({ label }: { label: string }) {
  return (
    <div className="px-3 pt-4 pb-1.5">
      <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/60">
        {label}
      </span>
    </div>
  );
}

// ============ User Section (Bottom) ============

function UserSection() {
  const user = useAuthStore((s) => s.user) ?? mockUser;
  const logout = useAuthStore((s) => s.logout);

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
  };

  return (
    <div className="flex flex-col gap-3 p-4">
      <Separator className="bg-white/[0.06]" />
      <div className="flex items-center gap-3">
        <Avatar className="size-9">
          <AvatarImage src={user.avatar ?? undefined} alt={user.username} />
          <AvatarFallback className="bg-brand-600/20 text-brand-400 text-xs font-semibold">
            {getInitials(user.firstName ? `${user.firstName} ${user.lastName ?? ''}` : user.username)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-foreground truncate">
            {user.firstName ?? user.username}
          </p>
          <Badge
            variant="outline"
            className="mt-0.5 h-4 px-1.5 text-[10px] font-medium uppercase border-brand-500/30 text-brand-400 bg-brand-600/5"
          >
            {user.role}
          </Badge>
        </div>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-8 text-muted-foreground hover:text-destructive shrink-0"
                onClick={handleLogout}
              >
                <LogOut className="size-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="top" sideOffset={8}>
              <p>Logout</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    </div>
  );
}

// ============ Sidebar Content ============

function SidebarContent() {
  const { currentView, selectedServerTab, setView, setServerTab } = useNavStore();
  const sections = useNavSections();

  const handleItemClick = (item: NavItem) => {
    if (item.tab) {
      setServerTab(item.tab);
    } else if (item.view) {
      setView(item.view);
    }
  };

  return (
    <div className="flex h-full flex-col">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 py-5">
        <div className="flex size-8 items-center justify-center rounded-lg gradient-brand shadow-lg shadow-brand-600/20">
          <ShieldCheck className="size-4 text-white" />
        </div>
        <span className="text-lg font-bold tracking-tight gradient-text">
          OGUltra
        </span>
      </div>

      <Separator className="mx-4 w-auto bg-white/[0.06]" />

      {/* Navigation */}
      <ScrollArea className="flex-1 px-3 py-2">
        <nav className="flex flex-col gap-0.5">
          {sections.map(
            (section) =>
              section.condition !== false && (
                <div key={section.id}>
                  <SectionLabel label={section.label} />
                  {section.items.map((item) => (
                    <NavItemButton
                      key={item.label}
                      item={item}
                      isActive={isItemActive(item, currentView, selectedServerTab)}
                      onClick={() => handleItemClick(item)}
                    />
                  ))}
                </div>
              )
          )}
        </nav>
      </ScrollArea>

      {/* User Section */}
      <UserSection />
    </div>
  );
}

// ============ Main Sidebar Export ============

export default function Sidebar() {
  const isMobile = useIsMobile();
  const { sidebarOpen, setSidebarOpen } = useNavStore();

  // Mobile: render inside a Sheet
  if (isMobile) {
    return (
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent
          side="left"
          className="w-[260px] max-w-[260px] p-0 glass-sidebar border-none"
        >
          <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
          <SidebarContent />
        </SheetContent>
      </Sheet>
    );
  }

  // Desktop: render inline
  return (
    <TooltipProvider delayDuration={0}>
      <aside className="hidden md:flex w-[260px] shrink-0 flex-col h-screen sticky top-0 glass-sidebar">
        <SidebarContent />
      </aside>
    </TooltipProvider>
  );
}