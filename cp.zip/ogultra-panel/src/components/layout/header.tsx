'use client';

import { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Menu,
  Sun,
  Moon,
  Bell,
  User,
  Settings,
  KeyRound,
  LogOut,
  ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { useNavStore, useThemeStore, useAuthStore, type View, type ServerTab } from '@/lib/store';
import { mockUser, getInitials, mockServers } from '@/lib/mock-data';
import { useIsMobile } from '@/hooks/use-mobile';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

// ============ Breadcrumb Helpers ============

const viewLabels: Record<View, string> = {
  dashboard: 'Dashboard',
  servers: 'Servers',
  'server-detail': 'Server',
  nodes: 'Nodes',
  'node-detail': 'Node',
  users: 'Users',
  admin: 'Admin',
  'admin-settings': 'Admin Settings',
  'admin-branding': 'Branding',
  'admin-roles': 'Roles',
  'admin-security': 'Security',
  activity: 'Activity',
};

const serverTabLabels: Record<ServerTab, string> = {
  console: 'Console',
  files: 'Files',
  databases: 'Databases',
  startup: 'Startup',
  plugins: 'Plugins',
  backups: 'Backups',
  schedules: 'Schedules',
  network: 'Network',
  settings: 'Settings',
};

// ============ Theme Toggle ============

function ThemeToggle() {
  const { theme, toggleTheme } = useThemeStore();

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="relative size-9 text-muted-foreground hover:text-foreground"
            onClick={toggleTheme}
            aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
          >
            <AnimatePresence mode="wait" initial={false}>
              {theme === 'dark' ? (
                <motion.div
                  key="moon"
                  initial={{ rotate: -90, opacity: 0, scale: 0.5 }}
                  animate={{ rotate: 0, opacity: 1, scale: 1 }}
                  exit={{ rotate: 90, opacity: 0, scale: 0.5 }}
                  transition={{ duration: 0.2 }}
                >
                  <Moon className="size-[18px]" />
                </motion.div>
              ) : (
                <motion.div
                  key="sun"
                  initial={{ rotate: 90, opacity: 0, scale: 0.5 }}
                  animate={{ rotate: 0, opacity: 1, scale: 1 }}
                  exit={{ rotate: -90, opacity: 0, scale: 0.5 }}
                  transition={{ duration: 0.2 }}
                >
                  <Sun className="size-[18px]" />
                </motion.div>
              )}
            </AnimatePresence>
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom" sideOffset={8}>
          <p>{theme === 'dark' ? 'Light mode' : 'Dark mode'}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// ============ Notification Bell ============

function NotificationBell() {
  const count = 3;

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="relative size-9 text-muted-foreground hover:text-foreground"
            onClick={() => toast.info('Notifications coming soon')}
          >
            <Bell className="size-[18px]" />
            {count > 0 && (
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-0.5 -right-0.5 flex size-4 items-center justify-center rounded-full bg-brand-600 text-[10px] font-bold text-white"
              >
                {count}
              </motion.span>
            )}
          </Button>
        </TooltipTrigger>
        <TooltipContent side="bottom" sideOffset={8}>
          <p>Notifications</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// ============ User Dropdown ============

function UserDropdown() {
  const user = useAuthStore((s) => s.user) ?? mockUser;
  const logout = useAuthStore((s) => s.logout);

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className="relative flex items-center gap-2 rounded-lg px-2 py-1.5 h-9 hover:bg-white/[0.04]"
        >
          <Avatar className="size-7">
            <AvatarImage src={user.avatar ?? undefined} alt={user.username} />
            <AvatarFallback className="bg-brand-600/20 text-brand-400 text-[11px] font-semibold">
              {getInitials(user.firstName ? `${user.firstName} ${user.lastName ?? ''}` : user.username)}
            </AvatarFallback>
          </Avatar>
          <span className="hidden sm:block text-sm font-medium text-foreground max-w-[120px] truncate">
            {user.firstName ?? user.username}
          </span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuItem className="gap-2.5 cursor-pointer" onClick={() => toast.info('Profile page coming soon')}>
          <User className="size-4" />
          Profile
        </DropdownMenuItem>
        <DropdownMenuItem className="gap-2.5 cursor-pointer" onClick={() => toast.info('Settings page coming soon')}>
          <Settings className="size-4" />
          Settings
        </DropdownMenuItem>
        <DropdownMenuItem className="gap-2.5 cursor-pointer" onClick={() => toast.info('API Tokens page coming soon')}>
          <KeyRound className="size-4" />
          API Tokens
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          variant="destructive"
          className="gap-2.5 cursor-pointer"
          onClick={handleLogout}
        >
          <LogOut className="size-4" />
          Logout
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

// ============ Breadcrumb ============

function Breadcrumb() {
  const { currentView, selectedServerId, selectedServerTab } = useNavStore();

  const { segments } = useMemo(() => {
    const items: { label: string; icon?: React.ReactNode }[] = [];

    // If we're on a server detail view, show Servers > Server Name > Tab
    if (currentView === 'server-detail' && selectedServerId) {
      const server = mockServers.find((s) => s.id === selectedServerId);
      items.push({ label: 'Servers' });
      items.push({
        label: server?.name ?? 'Server',
      });
      items.push({
        label: serverTabLabels[selectedServerTab],
      });
    } else if (currentView === 'node-detail') {
      items.push({ label: 'Nodes' });
      items.push({ label: 'Node Detail' });
    } else if (viewLabels[currentView]) {
      items.push({ label: viewLabels[currentView] });
    }

    return { segments: items };
  }, [currentView, selectedServerId, selectedServerTab]);

  return (
    <nav aria-label="Breadcrumb" className="flex items-center gap-1 text-sm">
      {segments.map((segment, index) => (
        <div key={index} className="flex items-center gap-1">
          {index > 0 && (
            <ChevronRight className="size-3.5 text-muted-foreground/50" />
          )}
          <span
            className={cn(
              'font-medium transition-colors',
              index === segments.length - 1
                ? 'text-foreground'
                : 'text-muted-foreground hover:text-foreground'
            )}
          >
            {segment.label}
          </span>
        </div>
      ))}
    </nav>
  );
}

// ============ Main Header Export ============

export default function Header() {
  const isMobile = useIsMobile();
  const toggleSidebar = useNavStore((s) => s.toggleSidebar);

  return (
    <header className="sticky top-0 z-40 flex h-14 items-center gap-3 border-b border-white/[0.06] px-4 glass">
      {/* Left: Mobile hamburger + Breadcrumb */}
      <div className="flex items-center gap-2 flex-1 min-w-0">
        {isMobile && (
          <Button
            variant="ghost"
            size="icon"
            className="size-9 shrink-0 text-muted-foreground hover:text-foreground"
            onClick={toggleSidebar}
            aria-label="Toggle sidebar"
          >
            <Menu className="size-5" />
          </Button>
        )}
        <Breadcrumb />
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-1 shrink-0">
        <ThemeToggle />
        <NotificationBell />
        <Separator orientation="vertical" className="mx-1.5 h-5 bg-white/[0.06]" />
        <UserDropdown />
      </div>
    </header>
  );
}