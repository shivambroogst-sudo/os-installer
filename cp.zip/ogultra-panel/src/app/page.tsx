'use client';

import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useAuthStore, useNavStore, useThemeStore } from '@/lib/store';
import { mockNodes, mockServers, formatMemory, formatBytes, getStatusDotClass } from '@/lib/mock-data';
import AuthPage from '@/components/auth/auth-page';
import Sidebar from '@/components/layout/sidebar';
import Header from '@/components/layout/header';
import Dashboard from '@/components/views/dashboard';
import ServersList from '@/components/views/servers-list';
import ServerConsole from '@/components/views/server-console';
import ServerFiles from '@/components/views/server-files';
import ServerDatabases from '@/components/views/server-databases';
import ServerStartup from '@/components/views/server-startup';
import ServerPlugins from '@/components/views/server-plugins';
import ServerBackups from '@/components/views/server-backups';
import ServerSchedules from '@/components/views/server-schedules';
import ServerNetwork from '@/components/views/server-network';
import ServerSettings from '@/components/views/server-settings';
import NodesList from '@/components/views/nodes-list';
import UsersList from '@/components/views/users-list';
import ActivityLog from '@/components/views/activity-log';
import AdminPanel from '@/components/views/admin-panel';

function NodeDetailView() {
  const { selectedNodeId } = useNavStore();
  const node = selectedNodeId ? mockNodes.find((n) => n.id === selectedNodeId) : null;

  if (!node) return null;

  return (
    <div className="page-enter space-y-6">
      <div className="flex items-center gap-3">
        <button onClick={() => useNavStore.getState().setView('nodes')} className="text-muted-foreground hover:text-foreground transition-colors">← Nodes</button>
        <span className="text-muted-foreground">/</span>
        <h1 className="text-2xl font-bold">{node.name}</h1>
        <span className={`status-dot ${node.status === 'online' ? 'status-dot-online' : 'status-dot-offline'}`} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'CPU', value: `${node.usedCpu.toFixed(1)}%` },
          { label: 'Memory', value: `${formatMemory(node.usedMemory)} / ${formatMemory(node.totalMemory)}` },
          { label: 'Disk', value: `${formatBytes(node.usedDisk * 1024 * 1024)} / ${formatBytes(node.totalDisk * 1024 * 1024)}` },
          { label: 'Servers', value: `${node.serverCount}` },
        ].map((stat) => (
          <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <div className="glass-card p-4">
              <div className="text-muted-foreground text-sm mb-1">{stat.label}</div>
              <div className="text-2xl font-bold">{stat.value}</div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="glass-card p-6">
        <h2 className="text-lg font-semibold mb-4">Node Details</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div><span className="text-muted-foreground">FQDN:</span> <span className="ml-2 font-mono">{node.fqdn}</span></div>
          <div><span className="text-muted-foreground">Daemon Port:</span> <span className="ml-2 font-mono">{node.daemonPort}</span></div>
          <div><span className="text-muted-foreground">Status:</span> <span className={`ml-2 ${node.status === 'online' ? 'text-status-online' : 'text-status-offline'}`}>{node.status}</span></div>
          <div><span className="text-muted-foreground">Public:</span> <span className="ml-2">{node.isPublic ? 'Yes' : 'No'}</span></div>
          <div><span className="text-muted-foreground">Last Ping:</span> <span className="ml-2">{node.lastPingAt ? new Date(node.lastPingAt).toLocaleString() : 'Never'}</span></div>
          <div><span className="text-muted-foreground">Created:</span> <span className="ml-2">{new Date(node.createdAt).toLocaleString()}</span></div>
        </div>
      </div>

      <div className="glass-card p-6">
        <h2 className="text-lg font-semibold mb-4">Servers on this Node</h2>
        <div className="space-y-3">
          {mockServers
            .filter((s) => s.nodeId === node.id)
            .map((server) => (
              <div key={server.id} className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-brand-500/20 transition-colors cursor-pointer" onClick={() => useNavStore.getState().selectServer(server.id)}>
                <div className="flex items-center gap-3">
                  <span className={`status-dot ${getStatusDotClass(server.status)}`} />
                  <div>
                    <div className="font-medium">{server.name}</div>
                    <div className="text-xs text-muted-foreground">{server.software}</div>
                  </div>
                </div>
                <div className="text-right text-sm text-muted-foreground">
                  CPU: {server.cpuUsage.toFixed(1)}% | RAM: {server.memoryUsage}/{server.memoryLimit} MB
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}

function ServerDetailView() {
  const { selectedServerId, selectedServerTab } = useNavStore();
  const server = selectedServerId ? mockServers.find((s) => s.id === selectedServerId) : null;

  const tabs = [
    { id: 'console' as const, label: 'Console' },
    { id: 'files' as const, label: 'Files' },
    { id: 'databases' as const, label: 'Databases' },
    { id: 'startup' as const, label: 'Startup' },
    { id: 'plugins' as const, label: 'Plugins' },
    { id: 'backups' as const, label: 'Backups' },
    { id: 'schedules' as const, label: 'Schedules' },
    { id: 'network' as const, label: 'Network' },
    { id: 'settings' as const, label: 'Settings' },
  ];

  if (!server) return null;

  return (
    <div className="page-enter flex flex-col h-full">
      <div className="flex items-center gap-3 mb-4 flex-shrink-0">
        <button onClick={() => useNavStore.getState().setView('servers')} className="text-muted-foreground hover:text-foreground transition-colors text-sm">← Servers</button>
        <span className="text-muted-foreground text-sm">/</span>
        <h1 className="text-xl font-bold">{server.name}</h1>
        <span className={`status-dot ${getStatusDotClass(server.status)}`} />
        <span className="text-sm text-muted-foreground">{server.software} · {server.version}</span>
      </div>

      <div className="flex gap-1 mb-4 overflow-x-auto pb-1 flex-shrink-0 scrollbar-none">
        {tabs.map((tab) => (
          <button key={tab.id} onClick={() => useNavStore.getState().setServerTab(tab.id)} className={`px-3 py-1.5 text-sm rounded-lg whitespace-nowrap transition-all ${selectedServerTab === tab.id ? 'bg-brand-600/15 text-brand-400 font-medium' : 'text-muted-foreground hover:text-foreground hover:bg-white/[0.04]'}`}>
            {tab.label}
          </button>
        ))}
      </div>

      <div className="flex-1 min-h-0">
        <AnimatePresence mode="wait">
          <motion.div key={selectedServerTab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.15 }} className="h-full">
            {selectedServerTab === 'console' && <ServerConsole />}
            {selectedServerTab === 'files' && <ServerFiles />}
            {selectedServerTab === 'databases' && <ServerDatabases />}
            {selectedServerTab === 'startup' && <ServerStartup />}
            {selectedServerTab === 'plugins' && <ServerPlugins />}
            {selectedServerTab === 'backups' && <ServerBackups />}
            {selectedServerTab === 'schedules' && <ServerSchedules />}
            {selectedServerTab === 'network' && <ServerNetwork />}
            {selectedServerTab === 'settings' && <ServerSettings />}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

function AppShell() {
  const { currentView } = useNavStore();
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <AnimatePresence mode="wait">
            <motion.div key={currentView} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.2, ease: 'easeOut' }} className="h-full">
              {currentView === 'dashboard' && <Dashboard />}
              {currentView === 'servers' && <ServersList />}
              {currentView === 'server-detail' && <ServerDetailView />}
              {currentView === 'nodes' && <NodesList />}
              {currentView === 'node-detail' && <NodeDetailView />}
              {currentView === 'users' && <UsersList />}
              {currentView === 'activity' && <ActivityLog />}
              {currentView === 'admin' && <AdminPanel />}
              {(currentView === 'admin-settings' || currentView === 'admin-branding' || currentView === 'admin-roles' || currentView === 'admin-security') && <AdminPanel />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

export default function Home() {
  const { isAuthenticated } = useAuthStore();
  const { theme } = useThemeStore();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
      document.body.style.background = '#050510';
      document.body.style.color = '#e2e8f0';
    } else {
      document.documentElement.classList.add('light');
      document.documentElement.classList.remove('dark');
      document.body.style.background = '#f8fafc';
      document.body.style.color = '#1e293b';
    }
  }, [theme, mounted]);

  if (!mounted) {
    return (
      <div className="h-screen flex items-center justify-center bg-[#050510]">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-xl gradient-brand flex items-center justify-center animate-pulse">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></svg>
          </div>
          <span className="text-muted-foreground text-sm">Loading OGUltra Panel...</span>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-grid-pattern' : ''}`}>
      <AnimatePresence mode="wait">
        {isAuthenticated ? (
          <motion.div key="app" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
            <AppShell />
          </motion.div>
        ) : (
          <motion.div key="auth" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
            <AuthPage />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}