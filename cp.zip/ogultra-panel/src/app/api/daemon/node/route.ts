import { NextResponse } from 'next/server';
import { daemonFetch } from '@/lib/daemon';

// GET: proxy to daemon /api/node
export async function GET() {
  try {
    const res = await daemonFetch('/api/node');
    const data = await res.json();
    return NextResponse.json(data);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 502 });
  }
}