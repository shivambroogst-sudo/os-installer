import { NextResponse } from 'next/server';
import { daemonFetch } from '@/lib/daemon';

// GET: list files — query param `path` (default '/')
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const filePath = searchParams.get('path') || '/';

    const res = await daemonFetch(
      `/api/servers/${id}/files?path=${encodeURIComponent(filePath)}`
    );
    const data = await res.json();
    return NextResponse.json(data);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 502 });
  }
}

// POST: file operations — read, write, delete, mkdir
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { operation, path: filePath, content } = body as {
      operation: 'read' | 'write' | 'delete' | 'mkdir';
      path: string;
      content?: string;
    };

    if (!filePath) {
      return NextResponse.json(
        { success: false, error: 'Path is required' },
        { status: 400 }
      );
    }

    let res: Response;

    switch (operation) {
      case 'read': {
        res = await daemonFetch(
          `/api/servers/${id}/files/read?path=${encodeURIComponent(filePath)}`
        );
        break;
      }
      case 'write': {
        res = await daemonFetch(`/api/servers/${id}/files/write`, {
          method: 'POST',
          body: JSON.stringify({ path: filePath, content }),
        });
        break;
      }
      case 'delete': {
        res = await daemonFetch(`/api/servers/${id}/files/delete`, {
          method: 'POST',
          body: JSON.stringify({ path: filePath }),
        });
        break;
      }
      case 'mkdir': {
        res = await daemonFetch(`/api/servers/${id}/files/mkdir`, {
          method: 'POST',
          body: JSON.stringify({ path: filePath }),
        });
        break;
      }
      default: {
        return NextResponse.json(
          { success: false, error: `Invalid operation: ${operation}` },
          { status: 400 }
        );
      }
    }

    const data = await res.json();
    return NextResponse.json(data, { status: res.status });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 502 });
  }
}