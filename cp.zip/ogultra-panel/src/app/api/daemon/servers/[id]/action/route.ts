import { NextResponse } from 'next/server';
import { daemonFetch } from '@/lib/daemon';

type ServerAction = 'start' | 'stop' | 'restart' | 'kill';

// POST: perform action on server (start, stop, restart, kill, command)
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { action, command } = body as {
      action: ServerAction | 'command';
      command?: string;
    };

    let daemonPath: string;
    let fetchOpts: RequestInit = { method: 'POST' };

    if (action === 'command') {
      // Send command to server console
      daemonPath = `/api/servers/${id}/command`;
      fetchOpts.body = JSON.stringify({ command });
    } else if (['start', 'stop', 'restart', 'kill'].includes(action)) {
      daemonPath = `/api/servers/${id}/${action}`;
    } else {
      return NextResponse.json(
        { success: false, error: `Invalid action: ${action}` },
        { status: 400 }
      );
    }

    const res = await daemonFetch(daemonPath, fetchOpts);
    const data = await res.json();
    return NextResponse.json(data, { status: res.status });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 502 });
  }
}