import { NextResponse } from 'next/server';
import { daemonFetch } from '@/lib/daemon';

// GET: list all servers from daemon
export async function GET() {
  try {
    const res = await daemonFetch('/api/servers');
    const data = await res.json();
    return NextResponse.json(data);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 502 });
  }
}

// POST: create a server on daemon
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const res = await daemonFetch('/api/servers', {
      method: 'POST',
      body: JSON.stringify(body),
    });
    const data = await res.json();
    return NextResponse.json(data, { status: res.status });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 502 });
  }
}